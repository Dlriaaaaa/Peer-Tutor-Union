import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2.49.1";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

serve(async (req) => {
  if (req.method === "OPTIONS") return new Response(null, { headers: corsHeaders });

  try {
    const authHeader = req.headers.get("Authorization");
    if (!authHeader) throw new Error("Not authenticated");

    const url = Deno.env.get("SUPABASE_URL");
    const anonKey = Deno.env.get("SUPABASE_ANON_KEY");
    const serviceKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY");
    if (!url || !anonKey || !serviceKey) throw new Error("Backend is not configured");

    const callerClient = createClient(url, anonKey, {
      global: { headers: { Authorization: authHeader } },
      auth: { persistSession: false },
    });
    const { data: { user: caller } } = await callerClient.auth.getUser();
    if (!caller) throw new Error("Not authenticated");

    const adminClient = createClient(url, serviceKey, { auth: { persistSession: false } });
    const { data: roleRow } = await adminClient
      .from("user_roles")
      .select("role")
      .eq("user_id", caller.id)
      .eq("role", "admin")
      .maybeSingle();
    if (!roleRow) throw new Error("Admin access required");

    const body = await req.json();
    const email = String(body.email || "").trim().toLowerCase();
    const password = String(body.password || "");
    const name = String(body.name || "").trim();
    const displayRole = String(body.displayRole || "Student");
    const schoolId = body.schoolId ? String(body.schoolId) : null;
    if (!email || !name || password.length < 6) throw new Error("Name, email and a password of at least 6 characters are required");

    let userId: string | null = null;
    let page = 1;
    while (!userId) {
      const { data, error } = await adminClient.auth.admin.listUsers({ page, perPage: 1000 });
      if (error) throw error;
      const existing = data.users.find((user) => user.email?.toLowerCase() === email);
      if (existing) userId = existing.id;
      if (existing || data.users.length < 1000) break;
      page += 1;
    }

    if (userId) {
      const { error } = await adminClient.auth.admin.updateUserById(userId, {
        password,
        email_confirm: true,
        user_metadata: { name },
      });
      if (error) throw error;
    } else {
      const { data, error } = await adminClient.auth.admin.createUser({
        email,
        password,
        email_confirm: true,
        user_metadata: { name },
      });
      if (error) throw error;
      userId = data.user.id;
    }

    const appRole = ["President", "VicePresident", "Teacher", "GeneralSecretary"].includes(displayRole)
      ? "admin"
      : "student";
    const { error: profileError } = await adminClient.from("profiles").upsert({
      user_id: userId,
      name,
      is_approved: true,
      display_role: displayRole,
      school_id: schoolId,
    }, { onConflict: "user_id" });
    if (profileError) throw profileError;

    const { error: deleteRoleError } = await adminClient.from("user_roles").delete().eq("user_id", userId);
    if (deleteRoleError) throw deleteRoleError;
    const { error: roleError } = await adminClient.from("user_roles").insert({ user_id: userId, role: appRole });
    if (roleError) throw roleError;

    return new Response(JSON.stringify({ ok: true, userId }), {
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  } catch (error) {
    return new Response(JSON.stringify({ error: error instanceof Error ? error.message : "Unable to create member" }), {
      status: 400,
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }
});