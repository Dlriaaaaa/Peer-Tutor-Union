import { createClient } from "https://esm.sh/@supabase/supabase-js@2.49.1";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

const json = (body: unknown, status = 200) =>
  new Response(JSON.stringify(body), { status, headers: { ...corsHeaders, "Content-Type": "application/json" } });

const stripHtml = (html: string | null) =>
  (html || "").replace(/<[^>]*>/g, " ").replace(/&nbsp;/g, " ").replace(/\s+/g, " ").trim();

const GRADE_SCHEMA = {
  type: "json_schema",
  name: "frq_grade",
  strict: true,
  schema: {
    type: "object",
    additionalProperties: false,
    properties: {
      score: { type: "number", description: "Points awarded, between 0 and the maximum points" },
      feedback: { type: "string", description: "Short feedback for the student, 1-3 sentences" },
    },
    required: ["score", "feedback"],
  },
};

async function gradeOne(apiKey: string, prompt: string): Promise<{ score: number; feedback: string } | null> {
  const res = await fetch("https://ai.gateway.lovable.dev/v1/responses", {
    method: "POST",
    headers: { "Content-Type": "application/json", "Lovable-API-Key": apiKey, "X-Lovable-AIG-SDK": "fetch" },
    body: JSON.stringify({
      model: "openai/gpt-6-astra",
      input: prompt,
      stream: true,
      reasoning: { effort: "low", summary: "auto" },
      text: { format: GRADE_SCHEMA },
    }),
  });

  if (!res.ok || !res.body) {
    const detail = await res.text().catch(() => "");
    throw Object.assign(new Error(detail || "AI gateway error"), { status: res.status });
  }

  const reader = res.body.getReader();
  const decoder = new TextDecoder();
  let buffer = "";
  let text = "";
  while (true) {
    const { done, value } = await reader.read();
    if (done) break;
    buffer += decoder.decode(value, { stream: true });
    const lines = buffer.split("\n");
    buffer = lines.pop() || "";
    for (const line of lines) {
      if (!line.startsWith("data:")) continue;
      const payload = line.slice(5).trim();
      if (!payload || payload === "[DONE]") continue;
      try {
        const evt = JSON.parse(payload);
        if (evt.type === "response.output_text.delta" && typeof evt.delta === "string") text += evt.delta;
        if (evt.type === "response.completed" && !text && evt.response?.output_text) text = evt.response.output_text;
      } catch { /* ignore keep-alive fragments */ }
    }
  }

  try {
    const parsed = JSON.parse(text);
    if (typeof parsed.score !== "number") return null;
    return { score: parsed.score, feedback: String(parsed.feedback ?? "") };
  } catch {
    return null;
  }
}

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response(null, { headers: corsHeaders });

  try {
    const apiKey = Deno.env.get("LOVABLE_API_KEY");
    if (!apiKey) return json({ error: "AI is not configured" }, 500);

    const url = Deno.env.get("SUPABASE_URL")!;
    const authHeader = req.headers.get("Authorization") || "";
    const userClient = createClient(url, Deno.env.get("SUPABASE_ANON_KEY")!, {
      global: { headers: { Authorization: authHeader } },
    });
    const { data: userRes } = await userClient.auth.getUser();
    const user = userRes?.user;
    if (!user) return json({ error: "Not signed in" }, 401);

    const body = await req.json().catch(() => ({}));
    const sessionId = String(body.sessionId || "");
    if (!sessionId) return json({ error: "Missing sessionId" }, 400);

    const admin = createClient(url, Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!);

    const { data: session } = await admin
      .from("practice_sessions").select("*").eq("id", sessionId).maybeSingle();
    if (!session) return json({ error: "Session not found" }, 404);

    const { data: canAuthor } = await admin.rpc("can_author_questions", { _user_id: user.id });
    if (session.user_id !== user.id && !canAuthor) return json({ error: "Not allowed" }, 403);

    const { data: answers } = await admin
      .from("practice_answers").select("*").eq("session_id", sessionId);
    const { data: questions } = await admin
      .from("questions").select("*").in("id", session.question_ids || []);
    const { data: parts } = await admin
      .from("question_parts").select("*").in("question_id", (questions || []).map((q: any) => q.id));

    const frqIds = new Set((questions || []).filter((q: any) => q.question_type === "frq").map((q: any) => q.id));
    const pending = (answers || []).filter(
      (a: any) => frqIds.has(a.question_id) && a.points_awarded === null && stripHtml(a.text_answer).length > 0,
    );

    let graded = 0;
    for (const a of pending) {
      const q = (questions || []).find((x: any) => x.id === a.question_id);
      const part = (parts || []).find((p: any) => p.id === a.part_id);
      const maxPoints = Number(part?.points ?? q?.max_points ?? 0) || 0;
      if (!maxPoints) continue;

      const sample = stripHtml(part?.sample_answer ?? null);
      const prompt = [
        "You are an experienced AP exam grader. Grade the student's free-response answer.",
        "Award partial credit for partially correct work. Be fair but rigorous.",
        `Return the score in points (0 to ${maxPoints}, at most one decimal) and short feedback.`,
        "Write the feedback in the same language the student used.",
        "",
        `Question: ${stripHtml(q?.stem ?? null) || "(see attached material)"}`,
        part?.prompt ? `Part ${part.label || ""}: ${stripHtml(part.prompt)}` : "",
        sample ? `Reference / sample answer: ${sample}` : "No reference answer was provided; grade on subject-matter correctness.",
        q?.explanation ? `Teacher explanation: ${stripHtml(q.explanation)}` : "",
        `Maximum points: ${maxPoints}`,
        "",
        `Student answer: ${stripHtml(a.text_answer)}`,
      ].filter(Boolean).join("\n");

      const result = await gradeOne(apiKey, prompt);
      if (!result) continue;

      const score = Math.max(0, Math.min(maxPoints, Math.round(result.score * 10) / 10));
      await admin.from("practice_answers").update({
        points_awarded: score,
        feedback: result.feedback ? `AI: ${result.feedback}` : "AI graded",
        is_correct: score >= maxPoints * 0.8,
        graded_at: new Date().toISOString(),
      }).eq("id", a.id);
      graded++;
    }

    // Recompute the session total: MCQ auto-score + graded FRQ points
    const { data: fresh } = await admin.from("practice_answers").select("*").eq("session_id", sessionId);
    let score = 0;
    for (const qq of questions || []) {
      if (qq.question_type === "mcq") {
        const a = (fresh || []).find((r: any) => r.question_id === qq.id && !r.part_id);
        if (a?.is_correct) score += Number(qq.max_points || 1);
      } else {
        for (const r of (fresh || []).filter((x: any) => x.question_id === qq.id)) {
          score += Number(r.points_awarded || 0);
        }
      }
    }
    await admin.from("practice_sessions").update({ score }).eq("id", sessionId);

    return json({ graded, score });
  } catch (e) {
    const status = (e as any)?.status;
    const message = status === 402
      ? "AI credits are used up. Please add credits to continue."
      : status === 429
        ? "Too many requests right now. Please try again in a moment."
        : (e as Error).message || "Grading failed";
    return json({ error: message }, status && status >= 400 && status < 600 ? status : 500);
  }
});
