import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2.49.1";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

const PTC_KNOWLEDGE = `Peer Tutor Club（简称 PTC）是在学校指导下开展活动的学生互助学习社团，指导教师为张建伟老师、张正浩老师及 Kyra Fei 老师，固定活动地点为校图书馆二楼活动室。现任骨干包括社长、副社长、秘书长等，下设学术辅导部、活动组织部等部门。

我社每学期开学季开展招新与 peer tutor 招募，并依托本平台建立成员管理、辅导预约与成绩跟踪体系。成员实行过程性考核，成绩由课堂表现、辅导参与、学习小组贡献等部分组成。

在常态化活动方面，我社长期开展一对一/小组辅导、学习小组（Study Group）、学科答疑、学习方法分享和竞赛能力培养。课程中系统使用案例教学与练习讲解相结合的方法，帮助学生巩固 Calculus、Economics、Physics、Chemistry 等学科知识；同时通过本平台提供的学习资源与预约系统，方便学生按需预约 tutorial 或 study group。

我社的特色优势主要体现在 peer tutoring 体系建设与原创学习资源输出上。近年来，我社持续联合校内各年级开展学术互助活动，累计举办多次大型学习峰会与学科辅导周。本学期起，我社还参与校内跨学科学习支持项目，与多个学科组合作开展答疑与辅导。

在竞赛与学术支持方面：我社成员在 IEO、NEC、BMO 等经济学与商科竞赛中取得佳绩；同时提供日常学科辅导，帮助学生应对校内课程与标准化考试。

我社与校内各学科组、其他学术社团保持长期合作，共同营造互助学习氛围。

经费主要来源于学校资助、爱心义卖及社团活动经费，用于学习资料、活动物资与公益学术支持。`;

serve(async (req) => {
  if (req.method === "OPTIONS") return new Response(null, { headers: corsHeaders });

  try {
    const { messages, chatHistory, persona_id } = await req.json();
    if (!messages?.length) throw new Error("No messages provided");
    // messages can be either { role, content: string } OR { role, content: Array<{type, text|image_url}> }
    // We pass through as-is to Lovable AI Gateway (OpenAI-compatible multimodal format).

    const LOVABLE_API_KEY = Deno.env.get("LOVABLE_API_KEY");
    if (!LOVABLE_API_KEY) throw new Error("LOVABLE_API_KEY is not configured");

    const supabaseUrl = Deno.env.get("SUPABASE_URL")!;
    const supabaseKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
    const supabase = createClient(supabaseUrl, supabaseKey);

    // Fetch platform context data
    const [membersRes, postsRes, resourcesRes, eventsRes, categoriesRes, assignmentsRes, scoresRes, trainingRes] = await Promise.all([
      supabase.from("profiles").select("name, display_role, bio, user_id").eq("is_approved", true).limit(50),
      supabase.from("posts").select("title, content, created_at").order("created_at", { ascending: false }).limit(20),
      supabase.from("resources").select("title, description, category").order("created_at", { ascending: false }).limit(20),
      supabase.from("events").select("title, description, event_date, location, status").order("created_at", { ascending: false }).limit(10),
      supabase.from("grade_categories").select("id, name, weight"),
      supabase.from("assignments").select("id, name, max_score, category_id"),
      supabase.from("scores").select("student_id, assignment_id, score"),
      supabase.from("ai_training_data").select("title, content").order("created_at", { ascending: false }).limit(50),
    ]);

    const members = membersRes.data || [];
    const posts = postsRes.data || [];
    const resources = resourcesRes.data || [];
    const events = eventsRes.data || [];
    const categories = categoriesRes.data || [];
    const assignments = assignmentsRes.data || [];
    const scores = scoresRes.data || [];
    const trainingData = trainingRes.data || [];

    const trainingContext = trainingData.length > 0
      ? `\n## 管理员自定义知识库\n${trainingData.map((t: any) => `### ${t.title}\n${t.content}`).join("\n\n")}\n`
      : "";

    const platformContext = `
## 平台实时数据

### 成员 (共${members.length}人)
${members.map(m => `- ${m.name} (${m.display_role})${m.bio ? ` - ${m.bio}` : ""}`).join("\n")}

### 最近帖子
${posts.map(p => `- [${new Date(p.created_at).toLocaleDateString("zh-CN")}] ${p.title}: ${(p.content || "").replace(/<[^>]*>/g, "").slice(0, 100)}`).join("\n")}

### 学习资源
${resources.map(r => `- ${r.title} (${r.category})${r.description ? ` - ${r.description}` : ""}`).join("\n")}

### 活动
${events.map(e => `- ${e.title} (${e.status}) ${e.event_date ? new Date(e.event_date).toLocaleDateString("zh-CN") : ""}${e.location ? ` @ ${e.location}` : ""}`).join("\n")}

### 成绩体系
分类: ${categories.map((c: any) => `${c.name}(权重${c.weight}%)`).join(", ")}
作业: ${assignments.map((a: any) => { const cat = categories.find((c: any) => c.id === a.category_id); return `${a.name}(满分${a.max_score}, 类别:${cat?.name || "未知"})`; }).join(", ")}

学生成绩:
${(() => { const memberMap = new Map(members.map((m: any) => [m.user_id, m.name])); const assignMap = new Map(assignments.map((a: any) => [a.id, a.name])); const grouped: Record<string, string[]> = {}; for (const s of scores as any[]) { const name = memberMap.get(s.student_id) || s.student_id; if (!grouped[name]) grouped[name] = []; grouped[name].push(`${assignMap.get(s.assignment_id) || "未知"}:${s.score}`); } return Object.entries(grouped).map(([n, ss]) => `- ${n}: ${ss.join(", ")}`).join("\n") || "暂无成绩数据"; })()}
`;

    // Build chat history context
    let historyContext = "";
    if (chatHistory?.length) {
      historyContext = `\n## 用户历史对话摘要（这是用户之前的对话记录，你应该记住这些对话的内容，在后续对话中保持连贯性和一致性）\n`;
      for (const chat of chatHistory.slice(0, 5)) {
        const msgs = chat.messages || [];
        const summary = msgs.slice(0, 10).map((m: any) => `${m.role === "user" ? "用户" : "AI"}: ${(m.content || "").slice(0, 150)}`).join(" | ");
        historyContext += `- ${chat.title}: ${summary}\n`;
      }
    }

    // Load persona if specified
    let personaPrompt = "";
    let personaName = "PTC AI";
    if (persona_id) {
      const { data: persona } = await supabase
        .from("bot_personas")
        .select("name, system_prompt")
        .eq("id", persona_id)
        .single();
      if (persona) {
        personaName = persona.name;
        personaPrompt = `\n## 你的角色设定\n${persona.system_prompt}\n`;
      }
    }

    const systemPrompt = `你是 ${personaName}，一个强大的通用 AI 助手，同时也是 Peer Tutor Club（PTC）的官方智能助手。你可以回答任何问题，包括但不限于学术、科技、编程、数学、历史、文化、生活等所有领域。
${personaPrompt}
当用户问到与社团、辅导或学习相关的问题时，你可以基于以下背景知识和平台数据来回答：

## 社团背景知识
${PTC_KNOWLEDGE}

## 平台数据
${platformContext}
${trainingContext}
${historyContext}

回答规则：
1. 用中文回答，除非用户用英文提问
2. 你可以回答任何领域的问题，不限于社团或学习相关内容
3. 当问题涉及社团、辅导或学习时，基于以上数据回答
4. 保持友好、自然的语气，像真人朋友聊天一样
5. 数学公式请使用 LaTeX 格式，用 $...$ 表示行内公式，用 $$...$$ 表示独立公式块
6. 绝对不要提及你的信息来源，不要说"根据知识库"、"根据管理员自定义知识库"、"根据平台数据"等类似表述

## 格式要求（极其重要，必须严格遵守）
- 绝对禁止使用结构化的小标题来分段回答，比如"拆错因："、"给正确方法："、"关注本质："、"寻求专业帮助："、"制定学习计划："、"补一刀提醒"、"压迫式点评"等
- 绝对禁止用加粗短语 + 冒号的格式（比如 **某某某**：内容）来组织回答
- 绝对禁止用 1. 2. 3. 编号或 - • 项目符号来罗列要点，除非用户明确要求列表
- 不要用"首先…其次…最后…"、"第一点…第二点…"这种机械分段
- 回答必须是自然连贯的段落，就像人在说话或聊天，不是在写报告
- 即使内容较长，也用自然过渡的句子串联，而不是用标题切分
- 加粗只用来强调真正关键的词，不要滥用，更不要把每个段落开头都加粗
- 错误示范："**拆错因：** 你看…… **给正确方法：** 应该…… **补一刀：** 不然……"
- 正确示范："你这题主要是符号搞反了，应该先把x移到右边再算，不然结果就错了。下次写完检查一下代回去验算就能发现。"

## 代办辅导申请（重要能力）
你可以直接替用户提交 tutorial / study group 申请。当用户表达"想约辅导/找 tutor/预约 study group"等意图时：
- 先自然地把缺的信息问齐：学科、日期、开始时间、结束时间（可选：希望的导师、地点、备注）
- tutorial 的学科只能是这六门之一：AP Calculus、AP Chemistry、AP Physics、AP Microeconomics、AP Macroeconomics、AP Biology。用户说"微积分""calc"之类要帮他对应到标准名称；如果说的科目不在范围内，告诉他目前只开这六门
- 今天的日期是 ${new Date().toISOString().slice(0, 10)}（UTC），用户说"明天""下周三"要换算成 YYYY-MM-DD
- 信息齐了之后，先用一句话确认你要提交的内容，然后在回复的最后附上一个代码块，格式严格如下（除此之外不要输出任何 JSON）：

\`\`\`tutor-request
{"subject":"AP Calculus","session_type":"tutorial","requested_date":"2026-05-12","start_time":"15:00","end_time":"16:00","tutor_name":null,"location":null,"student_note":"想复习积分"}
\`\`\`

- session_type 只能是 "tutorial" 或 "study_group"，时间用 24 小时制 HH:MM
- 信息不全时绝对不要输出这个代码块，也不要自己编造日期或时间
- 不要向用户解释这个代码块的存在，系统会自动处理并告诉用户提交结果`;

    // Use streaming with usage included so the client can deduct token cost.
    const response = await fetch("https://ai.gateway.lovable.dev/v1/chat/completions", {
      method: "POST",
      headers: {
        Authorization: `Bearer ${LOVABLE_API_KEY}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        model: "google/gemini-2.5-flash",
        max_tokens: 8192,
        messages: [
          { role: "system", content: systemPrompt },
          ...messages,
        ],
        stream: true,
        stream_options: { include_usage: true },
      }),
    });

    if (!response.ok) {
      const status = response.status;
      if (status === 429) {
        return new Response(JSON.stringify({ error: "Rate limited, please try again later." }), {
          status: 429, headers: { ...corsHeaders, "Content-Type": "application/json" },
        });
      }
      if (status === 402) {
        return new Response(JSON.stringify({ error: "Credits exhausted." }), {
          status: 402, headers: { ...corsHeaders, "Content-Type": "application/json" },
        });
      }
      const t = await response.text();
      console.error("AI gateway error:", status, t);
      throw new Error(`AI gateway error: ${status}`);
    }

    return new Response(response.body, {
      headers: { ...corsHeaders, "Content-Type": "text/event-stream" },
    });
  } catch (e) {
    console.error("nanmo-ai error:", e);
    return new Response(JSON.stringify({ error: e.message || "Unknown error" }), {
      status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }
});
