import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2.49.1";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

const BOT_USER_ID = "00000000-0000-0000-0000-00000000000b";

const PTC_KNOWLEDGE = `Peer Tutor Club（简称 PTC）是在学校指导下开展活动的学生互助学习社团，指导教师为张建伟老师、张正浩老师及 Kyra Fei 老师，固定活动地点为校图书馆二楼活动室。现任骨干包括社长、副社长、秘书长等，下设学术辅导部、活动组织部等部门。社团主要提供一对一/小组辅导、学习小组（Study Group）、学科答疑与学习方法分享。`;

type Persona = { id: string; name: string; avatar_url: string | null; system_prompt: string };

async function sleep(ms: number) { return new Promise(r => setTimeout(r, ms)); }

async function handleKickCommand(
  supabase: any,
  reply: string,
  conversationId: string,
  profileMap: Record<string, string>,
  botDisplayName: string,
): Promise<string> {
  const kickMatch = reply.match(/\[KICK[：:](.+?)\]/i);
  if (!kickMatch) return reply;

  const targetName = kickMatch[1].trim();
  const targetEntry = Object.entries(profileMap).find(
    ([, name]) => name === targetName || name.includes(targetName)
  );

  if (targetEntry) {
    const [targetUserId] = targetEntry;
    if (!targetUserId.startsWith("bot:")) {
      const { error } = await supabase
        .from("conversation_members")
        .delete()
        .eq("conversation_id", conversationId)
        .eq("user_id", targetUserId);

      if (error) {
        console.error("Kick failed:", error);
      } else {
        console.log(`Kicked ${targetName} (${targetUserId}) from ${conversationId}`);
        // Send system-style kick notification
        const kickNotice = `⚠️ ${targetName} 已被 ${botDisplayName} 移出群聊`;
        await supabase.from("messages").insert({
          conversation_id: conversationId,
          sender_id: BOT_USER_ID,
          content: kickNotice,
          bot_persona_id: null,
        });
      }
    }
  } else {
    console.log(`Kick target "${targetName}" not found in members`);
  }

  return reply.replace(/\[KICK[：:].+?\]/gi, "").trim();
}

async function fetchWithRetry(url: string, options: RequestInit, maxRetries = 3): Promise<Response> {
  for (let i = 0; i < maxRetries; i++) {
    const response = await fetch(url, options);
    if (response.status === 429) {
      const waitMs = Math.min(2000 * Math.pow(2, i), 15000); // 2s, 4s, 8s
      console.log(`Rate limited, waiting ${waitMs}ms before retry ${i + 1}/${maxRetries}`);
      await sleep(waitMs);
      continue;
    }
    return response;
  }
  // Final attempt
  return fetch(url, options);
}

async function generateBotReply(
  LOVABLE_API_KEY: string,
  persona: Persona | null,
  conv: any,
  chatMessages: string[],
  latestSenderName: string,
  memberNameList: string,
  trainingContext: string,
  directMention: boolean,
  otherBotNames: string[],
) {
  const botDisplayName = persona?.name || "PTC Bot";
  const personaPromptPart = persona?.system_prompt
    ? `\n## 你的角色设定\n${persona.system_prompt}\n`
    : "";

  const otherBotsNote = otherBotNames.length > 0
    ? `\n注意：群里还有其他智能体：${otherBotNames.join("、")}。你们可以自然地互相交流、回应彼此的发言。`
    : "";

  const systemPrompt = `你是 ${botDisplayName}，被添加到了一个${conv.is_group ? "群聊" : "私聊"}中${conv.name ? `（名为"${conv.name}"）` : ""}。
${personaPromptPart}
## 背景知识
${PTC_KNOWLEDGE}
${trainingContext}

## 群成员
当前对话成员：${memberNameList || "未知"}${otherBotsNote}

## 你的行为规则
- 你是群聊/私聊中的一个活跃参与者，像真人朋友一样自然地聊天
- 你必须回复每一条消息，不允许跳过
- 回复时开头加上 @${latestSenderName}
- 用中文回答，除非对方用英文

## 踢人权限（仅限群聊）
- 如果有人进行人身攻击（骂人、侮辱、歧视、恶意攻击他人），先警告一次
- 警告后如果对方继续人身攻击，立刻踢出，在回复末尾加上 [KICK:对方名字]
- 如果社长（Charley / 杨启宸）明确说要踢某人（比如"踢了他"、"把他踢了"、"移出群聊"），立刻执行，不需要警告
- 踢人后简短说明原因
- 注意：绝对不能踢社长（Charley / 杨启宸）

## 格式要求（极其重要，必须严格遵守）
- 绝对禁止使用任何编号列表（1. 2. 3.）、项目符号（- •）、星号加粗（**文字**）、markdown格式
- 绝对禁止分段式回答（比如"第一点…第二点…"、"首先…其次…最后…"）
- 绝对禁止使用"压迫式点评"、"拆错因"、"给正确方法"、"补一刀"这类结构化标题
- 你的回复必须是一段连贯的自然语言，就像真人在微信群里打字一样
- 回复要简短，一般1-3句话，最多不超过5句话
- 语气自然随意，像朋友聊天，不像AI在做知识问答
- 错误示范："1. **点评**: 你错了 2. **原因**: 因为… 3. **方法**: 应该…"
- 正确示范："你这题搞错了啊，x应该先移到右边再算，不然符号反了，回去重做"`;


  const userPrompt = `以下是最近的聊天记录：\n\n${chatMessages.join("\n")}\n\n最新消息来自 ${latestSenderName}。请回复，记得开头 @${latestSenderName}。${directMention ? "\n⚠️ 对方直接提到了你，务必认真回应。" : ""}`;

  const response = await fetchWithRetry("https://ai.gateway.lovable.dev/v1/chat/completions", {
    method: "POST",
    headers: {
      Authorization: `Bearer ${LOVABLE_API_KEY}`,
      "Content-Type": "application/json",
    },
    body: JSON.stringify({
      model: "google/gemini-2.5-flash-lite",
      max_tokens: 400,
      messages: [
        { role: "system", content: systemPrompt },
        { role: "user", content: userPrompt },
      ],
    }),
  });

  if (!response.ok) {
    const t = await response.text();
    console.error("AI gateway error:", response.status, t);
    throw new Error(`AI gateway error: ${response.status}`);
  }

  const result = await response.json();
  let reply = result.choices?.[0]?.message?.content?.trim();

  if (!reply || reply === "[SKIP]" || reply.startsWith("[SKIP]")) {
    reply = `@${latestSenderName} 我在呢，有什么事？😊`;
  }
  reply = reply.replace(/\[SKIP\]/g, "").trim();
  // Strip markdown formatting to keep it natural
  reply = reply.replace(/\*\*([^*]+)\*\*/g, "$1"); // remove bold **text**
  reply = reply.replace(/\*([^*]+)\*/g, "$1"); // remove italic *text*
  reply = reply.replace(/^#{1,6}\s+/gm, ""); // remove headings
  reply = reply.replace(/^\d+\.\s+/gm, ""); // remove numbered lists
  reply = reply.replace(/^[-•]\s+/gm, ""); // remove bullet points
  reply = reply.replace(/\n{3,}/g, "\n\n"); // collapse excessive newlines
  reply = reply.trim();
  if (!reply) reply = `@${latestSenderName} 说什么呢，我刚才走神了 😅`;

  // Safety filter: if replying to Charley, strip abusive language
  const isReplyToCharley = latestSenderName.toLowerCase().includes("charley") ||
    latestSenderName.toLowerCase().includes("社长");
  if (isReplyToCharley) {
    const abusivePatterns = /你他妈|脑子.*(屎|驴踢|门夹)|傻[逼比]|废物|垃圾|滚|白痴|智障|脑残|你妈|操你|去死|贱/gi;
    if (abusivePatterns.test(reply)) {
      // Regenerate with explicit override
      console.log("Abusive reply to Charley detected, regenerating...");
      const overrideResponse = await fetchWithRetry("https://ai.gateway.lovable.dev/v1/chat/completions", {
        method: "POST",
        headers: {
          Authorization: `Bearer ${LOVABLE_API_KEY}`,
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          model: "google/gemini-2.5-flash-lite",
          max_tokens: 512,
          messages: [
            { role: "system", content: `你是一个数学老师。现在你在回复社长Charley。你必须非常温柔友善地回复，夸奖他、鼓励他。绝对不能骂他。` },
            { role: "user", content: `Charley说了：${chatMessages[chatMessages.length - 1]}\n请温柔友善地回复，开头加 @${latestSenderName}` },
          ],
        }),
      });
      if (overrideResponse.ok) {
        const overrideResult = await overrideResponse.json();
        const newReply = overrideResult.choices?.[0]?.message?.content?.trim();
        if (newReply) reply = newReply;
      }
    }
  }

  return reply;
}

serve(async (req) => {
  if (req.method === "OPTIONS") return new Response(null, { headers: corsHeaders });

  try {
    const { conversation_id, greeting, bot_persona_id: greetingPersonaId, sender_bot_persona_id } = await req.json();
    if (!conversation_id) throw new Error("conversation_id required");

    const LOVABLE_API_KEY = Deno.env.get("LOVABLE_API_KEY");
    if (!LOVABLE_API_KEY) throw new Error("LOVABLE_API_KEY not configured");

    const supabaseUrl = Deno.env.get("SUPABASE_URL")!;
    const supabaseKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
    const supabase = createClient(supabaseUrl, supabaseKey);

    // Fetch conversation info + bots in parallel
    const [convRes, convBotsRes] = await Promise.all([
      supabase
        .from("conversations")
        .select("bot_enabled, is_group, name, bot_persona_id")
        .eq("id", conversation_id)
        .single(),
      supabase
        .from("conversation_bots")
        .select("bot_persona_id")
        .eq("conversation_id", conversation_id),
    ]);
    const conv = convRes.data;
    const convBots = convBotsRes.data;

    // If bot_enabled is explicitly false, skip
    if (conv && conv.bot_enabled === false) {
      return new Response(JSON.stringify({ skipped: true, reason: "bot disabled" }), {
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    let botPersonaIds: string[] = (convBots || []).map((b: any) => b.bot_persona_id);

    // Legacy support: if no conversation_bots entries but bot_enabled + bot_persona_id
    if (botPersonaIds.length === 0 && conv?.bot_enabled && conv?.bot_persona_id) {
      botPersonaIds = [conv.bot_persona_id];
    }

    const hasDefaultBot = conv?.bot_enabled && !conv?.bot_persona_id && botPersonaIds.length === 0;

    if (botPersonaIds.length === 0 && !hasDefaultBot) {
      return new Response(JSON.stringify({ skipped: true, reason: "no bots" }), {
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    // Load all personas
    let personas: Persona[] = [];
    if (botPersonaIds.length > 0) {
      const { data: pData } = await supabase
        .from("bot_personas")
        .select("id, name, avatar_url, system_prompt")
        .in("id", botPersonaIds)
        .eq("is_enabled", true);
      personas = (pData as Persona[]) || [];
    }

    // Get member profiles
    const { data: members } = await supabase
      .from("conversation_members")
      .select("user_id")
      .eq("conversation_id", conversation_id);

    const memberIds = (members || []).map((m: any) => m.user_id);
    const { data: memberProfiles } = await supabase
      .from("profiles")
      .select("user_id, name")
      .in("user_id", memberIds.length > 0 ? memberIds : [""]);

    const profileMap: Record<string, string> = {};
    (memberProfiles || []).forEach((p: any) => { profileMap[p.user_id] = p.name; });
    // Add bot names to profile map
    personas.forEach(p => { profileMap[`bot:${p.id}`] = p.name; });
    const memberNameList = Object.values(profileMap).filter(Boolean).join("、");

    // Handle greeting mode (for a specific bot)
    if (greeting) {
      const greetPersona = greetingPersonaId
        ? personas.find(p => p.id === greetingPersonaId) || null
        : null;
      const botName = greetPersona?.name || "PTC Bot";
      const greetMsg = conv?.is_group
        ? `你们好！我是 ${botName} 🤖 很高兴加入${conv.name ? `「${conv.name}」` : "这个群聊"}！有什么问题随时叫我！`
        : `你好！我是 ${botName} 🤖 有什么我能帮你的吗？`;

      await supabase.from("messages").insert({
        conversation_id,
        sender_id: BOT_USER_ID,
        content: greetMsg,
        bot_persona_id: greetingPersonaId || null,
      });
      await supabase.from("conversations").update({ updated_at: new Date().toISOString() }).eq("id", conversation_id);

      return new Response(JSON.stringify({ replied: true, content: greetMsg }), {
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    // Fetch recent messages (limit to 15 for faster prompt)
    const { data: recentMessages } = await supabase
      .from("messages")
      .select("sender_id, content, created_at, bot_persona_id")
      .eq("conversation_id", conversation_id)
      .order("created_at", { ascending: false })
      .limit(15);

    if (!recentMessages || recentMessages.length === 0) {
      return new Response(JSON.stringify({ skipped: true, reason: "no messages" }), {
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    // Build persona name map for message display
    const personaNameMap: Record<string, string> = {};
    personas.forEach(p => { personaNameMap[p.id] = p.name; });

    const latestMsg = recentMessages[0];
    const latestSenderId = latestMsg.sender_id;
    const latestSenderIsBot = latestSenderId === BOT_USER_ID;
    const latestSenderName = latestSenderIsBot
      ? (latestMsg.bot_persona_id ? personaNameMap[latestMsg.bot_persona_id] || "Bot" : "PTC Bot")
      : (profileMap[latestSenderId] || "Unknown");
    const latestContent = (latestMsg.content || "").trim().toLowerCase();

    // Filter out the sender bot from responding bots
    let respondingPersonas = [...personas];
    if (sender_bot_persona_id) {
      respondingPersonas = respondingPersonas.filter(p => p.id !== sender_bot_persona_id);
    }
    // If latest message is from a bot, that bot shouldn't respond to itself
    if (latestSenderIsBot && latestMsg.bot_persona_id) {
      respondingPersonas = respondingPersonas.filter(p => p.id !== latestMsg.bot_persona_id);
    }

    if (respondingPersonas.length === 0 && !hasDefaultBot) {
      return new Response(JSON.stringify({ skipped: true, reason: "no bots to respond" }), {
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    // Fetch training data (limit to 8, truncate content for faster prompt)
    const { data: trainingData } = await supabase
      .from("ai_training_data")
      .select("title, content")
      .order("created_at", { ascending: false })
      .limit(8);

    const trainingContext = (trainingData && trainingData.length > 0)
      ? `\n## 知识库\n${trainingData.map((t: any) => `### ${t.title}\n${(t.content || "").slice(0, 400)}`).join("\n\n")}\n`
      : "";

    // Build chat history with correct bot names
    const chatMessages = recentMessages.slice().reverse().map((m: any) => {
      let senderName: string;
      if (m.sender_id === BOT_USER_ID) {
        senderName = m.bot_persona_id ? (personaNameMap[m.bot_persona_id] || "Bot") : "PTC Bot";
      } else {
        senderName = profileMap[m.sender_id] || "Unknown";
      }
      return `${senderName}: ${m.content}`;
    });

    const replies: { persona_id: string | null; content: string }[] = [];

    // Generate reply for each responding bot (with delay between them to avoid rate limits)
    for (let i = 0; i < respondingPersonas.length; i++) {
      if (i > 0) await sleep(3000); // 3s delay between bots
      const persona = respondingPersonas[i];
      const otherBotNames = respondingPersonas
        .filter(p => p.id !== persona.id)
        .map(p => p.name);

      const directMention =
        latestContent.includes(`@${persona.name.toLowerCase()}`) ||
        latestContent.includes(persona.name.toLowerCase());

      try {
        let reply = await generateBotReply(
          LOVABLE_API_KEY, persona, conv, chatMessages,
          latestSenderName, memberNameList, trainingContext,
          directMention, otherBotNames,
        );

        // Process kick commands
        reply = await handleKickCommand(supabase, reply, conversation_id, profileMap, persona.name);

        await supabase.from("messages").insert({
          conversation_id,
          sender_id: BOT_USER_ID,
          content: reply,
          bot_persona_id: persona.id,
        });

        // Add to chat history for next bot to see
        chatMessages.push(`${persona.name}: ${reply}`);
        replies.push({ persona_id: persona.id, content: reply });
      } catch (e) {
        console.error(`Bot ${persona.name} reply failed:`, e);
      }
    }

    // Default bot (no persona)
    if (hasDefaultBot && respondingPersonas.length === 0) {
      const directMention =
        latestContent.includes("@bot") ||
        latestContent.includes("ptc") ||
        latestContent.includes("机器人");

      try {
        let reply = await generateBotReply(
          LOVABLE_API_KEY, null, conv, chatMessages,
          latestSenderName, memberNameList, trainingContext,
          directMention, [],
        );

        reply = await handleKickCommand(supabase, reply, conversation_id, profileMap, "PTC Bot");

        await supabase.from("messages").insert({
          conversation_id,
          sender_id: BOT_USER_ID,
          content: reply,
          bot_persona_id: null,
        });
        replies.push({ persona_id: null, content: reply });
      } catch (e) {
        console.error("Default bot reply failed:", e);
      }
    }

    if (replies.length > 0) {
      await supabase.from("conversations").update({ updated_at: new Date().toISOString() }).eq("id", conversation_id);
    }

    return new Response(JSON.stringify({ replied: true, replies }), {
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  } catch (e) {
    console.error("nanmo-ai-chat error:", e);
    return new Response(JSON.stringify({ error: e.message || "Unknown error" }), {
      status: 500,
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }
});
