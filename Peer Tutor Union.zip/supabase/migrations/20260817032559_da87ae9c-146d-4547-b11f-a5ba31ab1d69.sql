DROP POLICY IF EXISTS "Users upload to own path in attachments" ON storage.objects;
CREATE POLICY "Users upload to own path in attachments"
ON storage.objects FOR INSERT TO authenticated
WITH CHECK (bucket_id = 'attachments' AND (auth.uid())::text = (storage.foldername(name))[1]);