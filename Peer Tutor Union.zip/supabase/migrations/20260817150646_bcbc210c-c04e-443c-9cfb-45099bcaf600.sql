DROP POLICY IF EXISTS "Anyone can read attachments" ON storage.objects;
DROP POLICY IF EXISTS "Authenticated users read attachments" ON storage.objects;

CREATE POLICY "Read own or post-linked attachments"
ON storage.objects
FOR SELECT
TO authenticated
USING (
  bucket_id = 'attachments'
  AND (
    (auth.uid())::text = (storage.foldername(name))[1]
    OR EXISTS (
      SELECT 1 FROM public.post_attachments pa
      WHERE pa.file_url = storage.objects.name
    )
    OR public.has_role(auth.uid(), 'admin')
  )
);