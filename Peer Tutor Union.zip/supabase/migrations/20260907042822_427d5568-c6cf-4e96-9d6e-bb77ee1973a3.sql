
REVOKE EXECUTE ON FUNCTION public.is_super_admin(uuid) FROM anon, public;
REVOKE EXECUTE ON FUNCTION public.is_club_member(uuid, uuid) FROM anon, public;
REVOKE EXECUTE ON FUNCTION public.is_club_leader(uuid, uuid) FROM anon, public;
REVOKE EXECUTE ON FUNCTION public.is_club_staff(uuid, uuid) FROM anon, public;
REVOKE EXECUTE ON FUNCTION public.can_manage_subject_row(uuid, uuid) FROM anon, public;
