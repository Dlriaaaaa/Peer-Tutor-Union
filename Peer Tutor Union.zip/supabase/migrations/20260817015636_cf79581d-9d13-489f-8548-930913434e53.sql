CREATE OR REPLACE FUNCTION public.get_study_group_invite(_group_id uuid)
RETURNS TABLE(
  id uuid,
  title text,
  subject text,
  meeting_time text,
  frequency text,
  location text,
  max_members integer,
  content text,
  is_public boolean,
  status text,
  member_count integer,
  is_member boolean
)
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT g.id, g.title, g.subject, g.meeting_time, g.frequency, g.location,
         g.max_members, g.content, g.is_public, g.status,
         (SELECT count(*)::int FROM public.study_group_members m WHERE m.group_id = g.id),
         EXISTS (SELECT 1 FROM public.study_group_members m2 WHERE m2.group_id = g.id AND m2.user_id = auth.uid())
  FROM public.study_groups g
  WHERE g.id = _group_id
    AND (g.expires_at IS NULL OR g.expires_at >= CURRENT_DATE);
$$;

GRANT EXECUTE ON FUNCTION public.get_study_group_invite(uuid) TO authenticated;