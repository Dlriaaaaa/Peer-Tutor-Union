CREATE TABLE public.study_group_sessions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  group_id uuid NOT NULL REFERENCES public.study_groups(id) ON DELETE CASCADE,
  session_date date NOT NULL,
  start_time text NOT NULL,
  end_time text NOT NULL,
  location text,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

GRANT SELECT, INSERT, UPDATE, DELETE ON public.study_group_sessions TO authenticated;
GRANT ALL ON public.study_group_sessions TO service_role;

ALTER TABLE public.study_group_sessions ENABLE ROW LEVEL SECURITY;

CREATE POLICY "View sessions of visible groups"
ON public.study_group_sessions FOR SELECT TO authenticated
USING (
  public.is_study_group_member(auth.uid(), group_id)
  OR EXISTS (SELECT 1 FROM public.study_groups g WHERE g.id = group_id AND (g.is_public OR g.creator_id = auth.uid()))
);

CREATE POLICY "Creator manages sessions"
ON public.study_group_sessions FOR ALL TO authenticated
USING (EXISTS (SELECT 1 FROM public.study_groups g WHERE g.id = group_id AND g.creator_id = auth.uid()))
WITH CHECK (EXISTS (SELECT 1 FROM public.study_groups g WHERE g.id = group_id AND g.creator_id = auth.uid()));

CREATE INDEX idx_study_group_sessions_group ON public.study_group_sessions(group_id);

CREATE TRIGGER update_study_group_sessions_updated_at
BEFORE UPDATE ON public.study_group_sessions
FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

DROP POLICY IF EXISTS "Authenticated create notifications" ON public.notifications;