ALTER TABLE public.knowledge_points ADD COLUMN IF NOT EXISTS sort_order integer NOT NULL DEFAULT 0;

DROP POLICY IF EXISTS "Creator or admin updates study group" ON public.study_groups;
CREATE POLICY "Creator, leaders or admin update study group"
ON public.study_groups FOR UPDATE TO authenticated
USING (
  creator_id = auth.uid()
  OR has_role(auth.uid(), 'admin'::app_role)
  OR EXISTS (SELECT 1 FROM public.profiles p WHERE p.user_id = auth.uid() AND p.display_role IN ('President','VicePresident'))
)
WITH CHECK (
  creator_id = auth.uid()
  OR has_role(auth.uid(), 'admin'::app_role)
  OR EXISTS (SELECT 1 FROM public.profiles p WHERE p.user_id = auth.uid() AND p.display_role IN ('President','VicePresident'))
);