CREATE OR REPLACE FUNCTION public.prevent_display_role_self_change()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  IF NEW.display_role IS DISTINCT FROM OLD.display_role
     AND NOT public.has_role(auth.uid(), 'admin')
     AND auth.role() <> 'service_role' THEN
    NEW.display_role := OLD.display_role;
  END IF;
  IF NEW.is_approved IS DISTINCT FROM OLD.is_approved
     AND NOT public.has_role(auth.uid(), 'admin')
     AND auth.role() <> 'service_role' THEN
    NEW.is_approved := OLD.is_approved;
  END IF;
  RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS profiles_guard_privileged_fields ON public.profiles;
CREATE TRIGGER profiles_guard_privileged_fields
BEFORE UPDATE ON public.profiles
FOR EACH ROW EXECUTE FUNCTION public.prevent_display_role_self_change();