CREATE POLICY "Users view questions of published quizzes"
ON public.quiz_questions FOR SELECT TO authenticated
USING (EXISTS (SELECT 1 FROM public.quizzes q WHERE q.id = quiz_questions.quiz_id AND q.is_published));

CREATE POLICY "Users view options of published quizzes"
ON public.quiz_options FOR SELECT TO authenticated
USING (EXISTS (
  SELECT 1 FROM public.quiz_questions qq
  JOIN public.quizzes q ON q.id = qq.quiz_id
  WHERE qq.id = quiz_options.question_id AND q.is_published
));

GRANT SELECT ON public.quiz_questions TO authenticated;
GRANT SELECT ON public.quiz_options TO authenticated;