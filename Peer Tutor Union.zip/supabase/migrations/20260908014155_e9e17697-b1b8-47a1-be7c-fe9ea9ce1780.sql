CREATE OR REPLACE FUNCTION public.can_manage_study_group(_user_id uuid, _group_id uuid)
RETURNS boolean
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT EXISTS (
    SELECT 1 FROM public.study_groups g
    WHERE g.id = _group_id AND g.creator_id = _user_id
  ) OR EXISTS (
    SELECT 1 FROM public.profiles p
    WHERE p.user_id = _user_id AND p.display_role IN ('President', 'Vice President')
  ) OR public.is_super_admin(_user_id)
$$;

REVOKE ALL ON FUNCTION public.can_manage_study_group(uuid, uuid) FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION public.can_manage_study_group(uuid, uuid) TO authenticated, service_role;

DROP POLICY IF EXISTS "Creator manages sessions" ON public.study_group_sessions;

CREATE POLICY "Leaders manage sessions"
ON public.study_group_sessions FOR ALL TO authenticated
USING (public.can_manage_study_group(auth.uid(), group_id))
WITH CHECK (public.can_manage_study_group(auth.uid(), group_id));

DROP POLICY IF EXISTS "View sessions of visible groups" ON public.study_group_sessions;

CREATE POLICY "View sessions of visible groups"
ON public.study_group_sessions FOR SELECT TO authenticated
USING (
  public.is_study_group_member(auth.uid(), group_id)
  OR EXISTS (SELECT 1 FROM public.study_groups g WHERE g.id = group_id AND (g.is_public OR g.creator_id = auth.uid()))
  OR public.can_manage_study_group(auth.uid(), group_id)
);