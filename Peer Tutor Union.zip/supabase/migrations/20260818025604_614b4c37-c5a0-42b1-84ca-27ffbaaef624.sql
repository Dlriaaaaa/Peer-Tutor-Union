ALTER TABLE public.tutoring_requests
  ADD COLUMN IF NOT EXISTS parent_request_id uuid REFERENCES public.tutoring_requests(id) ON DELETE CASCADE;

CREATE INDEX IF NOT EXISTS tutoring_requests_parent_idx ON public.tutoring_requests(parent_request_id);

CREATE OR REPLACE FUNCTION public.list_tutor_courses()
RETURNS TABLE(
  id uuid,
  subject text,
  requested_date date,
  start_time text,
  end_time text,
  tutor_name text,
  location text,
  enrolled integer,
  already_requested boolean
)
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT r.id, r.subject, r.requested_date, r.start_time, r.end_time,
         r.tutor_name, r.location,
         (SELECT count(*)::int FROM public.tutoring_requests j
           WHERE j.parent_request_id = r.id AND j.status = 'approved'),
         EXISTS (SELECT 1 FROM public.tutoring_requests j2
                  WHERE j2.parent_request_id = r.id
                    AND j2.user_id = auth.uid()
                    AND j2.status IN ('pending','approved'))
  FROM public.tutoring_requests r
  WHERE r.status = 'approved'
    AND r.session_type = 'tutorial'
    AND r.parent_request_id IS NULL
    AND r.requested_date >= CURRENT_DATE
    AND auth.uid() IS NOT NULL
  ORDER BY r.requested_date, r.start_time;
$$;

GRANT EXECUTE ON FUNCTION public.list_tutor_courses() TO authenticated;