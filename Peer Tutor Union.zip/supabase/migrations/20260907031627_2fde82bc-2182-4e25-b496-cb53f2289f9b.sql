
-- Helper: who may author questions
CREATE OR REPLACE FUNCTION public.can_author_questions(_user_id uuid)
RETURNS boolean LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public AS $$
  SELECT EXISTS (
    SELECT 1 FROM public.profiles p
    WHERE p.user_id = _user_id AND p.display_role IN ('President','VicePresident','Teacher')
  ) OR public.has_role(_user_id, 'admin')
$$;
REVOKE ALL ON FUNCTION public.can_author_questions(uuid) FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION public.can_author_questions(uuid) TO authenticated, service_role;

CREATE OR REPLACE FUNCTION public.can_manage_subjects(_user_id uuid)
RETURNS boolean LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public AS $$
  SELECT EXISTS (
    SELECT 1 FROM public.profiles p
    WHERE p.user_id = _user_id AND p.display_role IN ('President','VicePresident')
  ) OR public.has_role(_user_id, 'admin')
$$;
REVOKE ALL ON FUNCTION public.can_manage_subjects(uuid) FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION public.can_manage_subjects(uuid) TO authenticated, service_role;

-- SUBJECTS
CREATE TABLE public.subjects (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  created_by uuid,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
CREATE UNIQUE INDEX subjects_name_unique ON public.subjects (lower(btrim(name)));
GRANT SELECT, INSERT, UPDATE, DELETE ON public.subjects TO authenticated;
GRANT ALL ON public.subjects TO service_role;
ALTER TABLE public.subjects ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Signed-in can view subjects" ON public.subjects FOR SELECT TO authenticated USING (true);
CREATE POLICY "Managers insert subjects" ON public.subjects FOR INSERT TO authenticated WITH CHECK (public.can_manage_subjects(auth.uid()));
CREATE POLICY "Managers update subjects" ON public.subjects FOR UPDATE TO authenticated USING (public.can_manage_subjects(auth.uid())) WITH CHECK (public.can_manage_subjects(auth.uid()));
CREATE POLICY "Managers delete subjects" ON public.subjects FOR DELETE TO authenticated USING (public.can_manage_subjects(auth.uid()));
CREATE TRIGGER update_subjects_updated_at BEFORE UPDATE ON public.subjects FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

-- QUESTIONS
CREATE TABLE public.questions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  subject_id uuid NOT NULL REFERENCES public.subjects(id) ON DELETE RESTRICT,
  difficulty int NOT NULL DEFAULT 1 CHECK (difficulty BETWEEN 1 AND 3),
  question_type text NOT NULL CHECK (question_type IN ('mcq','frq')),
  stem text NOT NULL,
  stimulus_text text,
  stimulus_file_url text,
  stimulus_file_name text,
  option_a text,
  option_b text,
  option_c text,
  option_d text,
  correct_option text CHECK (correct_option IN ('A','B','C','D')),
  explanation text,
  max_points numeric NOT NULL DEFAULT 1,
  created_by uuid NOT NULL,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.questions TO authenticated;
GRANT ALL ON public.questions TO service_role;
ALTER TABLE public.questions ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Signed-in can view questions" ON public.questions FOR SELECT TO authenticated USING (true);
CREATE POLICY "Authors insert questions" ON public.questions FOR INSERT TO authenticated WITH CHECK (public.can_author_questions(auth.uid()) AND created_by = auth.uid());
CREATE POLICY "Authors update questions" ON public.questions FOR UPDATE TO authenticated USING (public.can_author_questions(auth.uid())) WITH CHECK (public.can_author_questions(auth.uid()));
CREATE POLICY "Authors delete questions" ON public.questions FOR DELETE TO authenticated USING (public.can_author_questions(auth.uid()));
CREATE TRIGGER update_questions_updated_at BEFORE UPDATE ON public.questions FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();
CREATE INDEX questions_subject_idx ON public.questions (subject_id, difficulty, question_type);

-- QUESTION PARTS (FRQ sub-parts)
CREATE TABLE public.question_parts (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  question_id uuid NOT NULL REFERENCES public.questions(id) ON DELETE CASCADE,
  label text NOT NULL,
  prompt text NOT NULL,
  points numeric NOT NULL DEFAULT 1,
  sample_answer text,
  sort_order int NOT NULL DEFAULT 0,
  created_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.question_parts TO authenticated;
GRANT ALL ON public.question_parts TO service_role;
ALTER TABLE public.question_parts ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Signed-in can view parts" ON public.question_parts FOR SELECT TO authenticated USING (true);
CREATE POLICY "Authors insert parts" ON public.question_parts FOR INSERT TO authenticated WITH CHECK (public.can_author_questions(auth.uid()));
CREATE POLICY "Authors update parts" ON public.question_parts FOR UPDATE TO authenticated USING (public.can_author_questions(auth.uid())) WITH CHECK (public.can_author_questions(auth.uid()));
CREATE POLICY "Authors delete parts" ON public.question_parts FOR DELETE TO authenticated USING (public.can_author_questions(auth.uid()));

-- PRACTICE SESSIONS
CREATE TABLE public.practice_sessions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL,
  mode text NOT NULL CHECK (mode IN ('untimed','timed')),
  title text NOT NULL DEFAULT 'Practice',
  subject_id uuid REFERENCES public.subjects(id) ON DELETE SET NULL,
  difficulty int,
  question_ids uuid[] NOT NULL DEFAULT '{}',
  section_seconds jsonb NOT NULL DEFAULT '{}'::jsonb,
  sections_submitted text[] NOT NULL DEFAULT '{}',
  status text NOT NULL DEFAULT 'active',
  score numeric,
  total_points numeric,
  started_at timestamptz NOT NULL DEFAULT now(),
  completed_at timestamptz,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.practice_sessions TO authenticated;
GRANT ALL ON public.practice_sessions TO service_role;
ALTER TABLE public.practice_sessions ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Own or staff view sessions" ON public.practice_sessions FOR SELECT TO authenticated USING (user_id = auth.uid() OR public.can_author_questions(auth.uid()));
CREATE POLICY "Own insert sessions" ON public.practice_sessions FOR INSERT TO authenticated WITH CHECK (user_id = auth.uid());
CREATE POLICY "Own update sessions" ON public.practice_sessions FOR UPDATE TO authenticated USING (user_id = auth.uid()) WITH CHECK (user_id = auth.uid());
CREATE POLICY "Own delete sessions" ON public.practice_sessions FOR DELETE TO authenticated USING (user_id = auth.uid());
CREATE TRIGGER update_practice_sessions_updated_at BEFORE UPDATE ON public.practice_sessions FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

-- PRACTICE ANSWERS
CREATE TABLE public.practice_answers (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  session_id uuid NOT NULL REFERENCES public.practice_sessions(id) ON DELETE CASCADE,
  question_id uuid NOT NULL REFERENCES public.questions(id) ON DELETE CASCADE,
  part_id uuid REFERENCES public.question_parts(id) ON DELETE CASCADE,
  user_id uuid NOT NULL,
  selected_option text,
  text_answer text,
  is_correct boolean,
  flagged boolean NOT NULL DEFAULT false,
  points_awarded numeric,
  feedback text,
  graded_by uuid,
  graded_at timestamptz,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
CREATE UNIQUE INDEX practice_answers_unique ON public.practice_answers (session_id, question_id, COALESCE(part_id, '00000000-0000-0000-0000-000000000000'::uuid));
GRANT SELECT, INSERT, UPDATE, DELETE ON public.practice_answers TO authenticated;
GRANT ALL ON public.practice_answers TO service_role;
ALTER TABLE public.practice_answers ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Own or staff view answers" ON public.practice_answers FOR SELECT TO authenticated USING (user_id = auth.uid() OR public.can_author_questions(auth.uid()));
CREATE POLICY "Own insert answers" ON public.practice_answers FOR INSERT TO authenticated WITH CHECK (user_id = auth.uid());
CREATE POLICY "Own or grader update answers" ON public.practice_answers FOR UPDATE TO authenticated USING (user_id = auth.uid() OR public.can_author_questions(auth.uid())) WITH CHECK (user_id = auth.uid() OR public.can_author_questions(auth.uid()));
CREATE POLICY "Own delete answers" ON public.practice_answers FOR DELETE TO authenticated USING (user_id = auth.uid());
CREATE TRIGGER update_practice_answers_updated_at BEFORE UPDATE ON public.practice_answers FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

-- QUIZ PAPER ASSEMBLY
ALTER TABLE public.quizzes ADD COLUMN IF NOT EXISTS passing_score numeric;

CREATE TABLE public.quiz_paper_questions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  quiz_id uuid NOT NULL REFERENCES public.quizzes(id) ON DELETE CASCADE,
  question_id uuid NOT NULL REFERENCES public.questions(id) ON DELETE CASCADE,
  section text NOT NULL DEFAULT 'Section A',
  sort_order int NOT NULL DEFAULT 0,
  created_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (quiz_id, question_id)
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.quiz_paper_questions TO authenticated;
GRANT ALL ON public.quiz_paper_questions TO service_role;
ALTER TABLE public.quiz_paper_questions ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Signed-in view paper questions" ON public.quiz_paper_questions FOR SELECT TO authenticated USING (true);
CREATE POLICY "Authors insert paper questions" ON public.quiz_paper_questions FOR INSERT TO authenticated WITH CHECK (public.can_author_questions(auth.uid()));
CREATE POLICY "Authors update paper questions" ON public.quiz_paper_questions FOR UPDATE TO authenticated USING (public.can_author_questions(auth.uid())) WITH CHECK (public.can_author_questions(auth.uid()));
CREATE POLICY "Authors delete paper questions" ON public.quiz_paper_questions FOR DELETE TO authenticated USING (public.can_author_questions(auth.uid()));

-- Seed existing AP subjects
INSERT INTO public.subjects (name) VALUES
  ('AP Calculus'), ('AP Chemistry'), ('AP Physics'),
  ('AP Microeconomics'), ('AP Macroeconomics'), ('AP Biology')
ON CONFLICT DO NOTHING;
