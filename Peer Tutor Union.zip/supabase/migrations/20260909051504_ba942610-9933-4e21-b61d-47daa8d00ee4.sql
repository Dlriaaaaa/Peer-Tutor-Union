CREATE TABLE public.question_upload_grants (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL UNIQUE,
  granted_by uuid,
  is_active boolean NOT NULL DEFAULT true,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

GRANT SELECT, INSERT, UPDATE, DELETE ON public.question_upload_grants TO authenticated;
GRANT ALL ON public.question_upload_grants TO service_role;

ALTER TABLE public.question_upload_grants ENABLE ROW LEVEL SECURITY;

CREATE OR REPLACE FUNCTION public.can_grant_question_upload(_user_id uuid)
RETURNS boolean LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public AS $$
  SELECT public.has_role(_user_id, 'admin')
      OR public.is_super_admin(_user_id)
      OR EXISTS (
        SELECT 1 FROM public.profiles p
        WHERE p.user_id = _user_id AND p.display_role IN ('President','VicePresident')
      )
      OR EXISTS (
        SELECT 1 FROM public.club_members cm
        WHERE cm.user_id = _user_id AND cm.status = 'approved'
          AND cm.club_role IN ('President','VicePresident')
      )
$$;

REVOKE EXECUTE ON FUNCTION public.can_grant_question_upload(uuid) FROM anon, public;
GRANT EXECUTE ON FUNCTION public.can_grant_question_upload(uuid) TO authenticated;

CREATE POLICY "Read own or manageable upload grants" ON public.question_upload_grants
FOR SELECT TO authenticated
USING (user_id = auth.uid() OR public.can_grant_question_upload(auth.uid()));

CREATE POLICY "Managers create upload grants" ON public.question_upload_grants
FOR INSERT TO authenticated
WITH CHECK (public.can_grant_question_upload(auth.uid()));

CREATE POLICY "Managers update upload grants" ON public.question_upload_grants
FOR UPDATE TO authenticated
USING (public.can_grant_question_upload(auth.uid()))
WITH CHECK (public.can_grant_question_upload(auth.uid()));

CREATE POLICY "Managers delete upload grants" ON public.question_upload_grants
FOR DELETE TO authenticated
USING (public.can_grant_question_upload(auth.uid()));

CREATE TRIGGER update_question_upload_grants_updated_at
BEFORE UPDATE ON public.question_upload_grants
FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

CREATE OR REPLACE FUNCTION public.has_question_upload_grant(_user_id uuid)
RETURNS boolean LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public AS $$
  SELECT EXISTS (
    SELECT 1 FROM public.question_upload_grants g
    WHERE g.user_id = _user_id AND g.is_active
  )
$$;

REVOKE EXECUTE ON FUNCTION public.has_question_upload_grant(uuid) FROM anon, public;
GRANT EXECUTE ON FUNCTION public.has_question_upload_grant(uuid) TO authenticated;

DROP POLICY "Authors insert questions" ON public.questions;
CREATE POLICY "Authors insert questions" ON public.questions
FOR INSERT TO authenticated
WITH CHECK (
  (public.can_author_questions(auth.uid()) OR public.has_question_upload_grant(auth.uid()))
  AND created_by = auth.uid()
);