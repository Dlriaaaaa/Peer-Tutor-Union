CREATE TABLE public.tutoring_requests (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL,
  subject text NOT NULL,
  session_type text NOT NULL DEFAULT 'tutorial',
  requested_date date NOT NULL,
  start_time text NOT NULL,
  end_time text NOT NULL,
  tutor_name text,
  location text,
  student_note text,
  admin_note text,
  status text NOT NULL DEFAULT 'pending',
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

GRANT SELECT, INSERT, UPDATE, DELETE ON public.tutoring_requests TO authenticated;
GRANT ALL ON public.tutoring_requests TO service_role;
ALTER TABLE public.tutoring_requests ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users view own requests, staff view all" ON public.tutoring_requests
FOR SELECT TO authenticated
USING (user_id = auth.uid() OR public.has_role(auth.uid(), 'admin') OR EXISTS (
  SELECT 1 FROM public.profiles p WHERE p.user_id = auth.uid()
    AND p.display_role IN ('President','VicePresident','Teacher','GeneralSecretary')
));

CREATE POLICY "Users create own requests" ON public.tutoring_requests
FOR INSERT TO authenticated WITH CHECK (user_id = auth.uid());

CREATE POLICY "Staff update requests" ON public.tutoring_requests
FOR UPDATE TO authenticated
USING (public.has_role(auth.uid(), 'admin') OR EXISTS (
  SELECT 1 FROM public.profiles p WHERE p.user_id = auth.uid()
    AND p.display_role IN ('President','VicePresident','Teacher','GeneralSecretary')
));

CREATE POLICY "Users delete own pending requests, staff delete any" ON public.tutoring_requests
FOR DELETE TO authenticated
USING ((user_id = auth.uid() AND status = 'pending') OR public.has_role(auth.uid(), 'admin') OR EXISTS (
  SELECT 1 FROM public.profiles p WHERE p.user_id = auth.uid()
    AND p.display_role IN ('President','VicePresident','Teacher','GeneralSecretary')
));

CREATE TRIGGER update_tutoring_requests_updated_at
BEFORE UPDATE ON public.tutoring_requests
FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();