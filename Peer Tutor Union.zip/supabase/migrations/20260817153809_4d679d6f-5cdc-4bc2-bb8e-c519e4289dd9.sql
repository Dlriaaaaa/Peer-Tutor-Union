DROP POLICY IF EXISTS "Questions viewable by authenticated" ON public.quiz_questions;
CREATE POLICY "Admins view questions" ON public.quiz_questions FOR SELECT TO authenticated USING (has_role(auth.uid(), 'admin'::app_role));
DROP POLICY IF EXISTS "Options viewable by authenticated" ON public.quiz_options;
CREATE POLICY "Admins view options" ON public.quiz_options FOR SELECT TO authenticated USING (has_role(auth.uid(), 'admin'::app_role));