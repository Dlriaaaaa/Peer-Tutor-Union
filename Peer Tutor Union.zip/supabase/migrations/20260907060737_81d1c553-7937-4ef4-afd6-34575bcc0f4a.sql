
-- 1. Block direct client edits of economy/progression fields via triggers
CREATE OR REPLACE FUNCTION public.guard_team_manager_fields()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  IF current_user IN ('authenticated', 'anon') AND NOT has_role(auth.uid(), 'admin'::app_role) THEN
    NEW.coins := OLD.coins;
    NEW.current_league := OLD.current_league;
    NEW.league_wins := OLD.league_wins;
    NEW.total_wins := OLD.total_wins;
    NEW.total_losses := OLD.total_losses;
    NEW.wc_titles := OLD.wc_titles;
    NEW.world_tour_titles := OLD.world_tour_titles;
    NEW.current_tour_season := OLD.current_tour_season;
    NEW.coach_key := OLD.coach_key;
    NEW.coach_matches_left := OLD.coach_matches_left;
    NEW.user_id := OLD.user_id;
  END IF;
  RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS guard_team_manager_fields_trg ON public.team_managers;
CREATE TRIGGER guard_team_manager_fields_trg
BEFORE UPDATE ON public.team_managers
FOR EACH ROW EXECUTE FUNCTION public.guard_team_manager_fields();

CREATE OR REPLACE FUNCTION public.guard_player_card_fields()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  IF current_user IN ('authenticated', 'anon') AND NOT has_role(auth.uid(), 'admin'::app_role) THEN
    NEW.level := OLD.level;
    NEW.bonus_speed := OLD.bonus_speed;
    NEW.bonus_shooting := OLD.bonus_shooting;
    NEW.bonus_three_point := OLD.bonus_three_point;
    NEW.bonus_defense := OLD.bonus_defense;
    NEW.bonus_dunk := OLD.bonus_dunk;
    NEW.stamina := OLD.stamina;
    NEW.stamina_updated_at := OLD.stamina_updated_at;
    NEW.template_id := OLD.template_id;
    NEW.user_id := OLD.user_id;
  END IF;
  RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS guard_player_card_fields_trg ON public.player_cards;
CREATE TRIGGER guard_player_card_fields_trg
BEFORE UPDATE ON public.player_cards
FOR EACH ROW EXECUTE FUNCTION public.guard_player_card_fields();

CREATE OR REPLACE FUNCTION public.guard_consumable_fields()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  IF current_user IN ('authenticated', 'anon') AND NOT has_role(auth.uid(), 'admin'::app_role) THEN
    -- users may only consume (decrease) their items, never grant themselves more
    IF NEW.quantity > OLD.quantity THEN
      NEW.quantity := OLD.quantity;
    END IF;
    IF NEW.quantity < 0 THEN
      NEW.quantity := 0;
    END IF;
    NEW.item_key := OLD.item_key;
    NEW.user_id := OLD.user_id;
  END IF;
  RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS guard_consumable_fields_trg ON public.consumables;
CREATE TRIGGER guard_consumable_fields_trg
BEFORE UPDATE ON public.consumables
FOR EACH ROW EXECUTE FUNCTION public.guard_consumable_fields();

-- add explicit WITH CHECK on ownership policies
DROP POLICY IF EXISTS "Users update own team" ON public.team_managers;
CREATE POLICY "Users update own team" ON public.team_managers
FOR UPDATE TO authenticated
USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);

DROP POLICY IF EXISTS "Users update own cards" ON public.player_cards;
CREATE POLICY "Users update own cards" ON public.player_cards
FOR UPDATE TO authenticated
USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);

DROP POLICY IF EXISTS "Users update own consumables" ON public.consumables;
CREATE POLICY "Users update own consumables" ON public.consumables
FOR UPDATE TO authenticated
USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);

-- 2. Leaderboard scores only through a validating server-side function
DROP POLICY IF EXISTS "Users insert own scores" ON public.game_leaderboards;
REVOKE INSERT ON public.game_leaderboards FROM authenticated;

CREATE OR REPLACE FUNCTION public.submit_game_score(_game_type text, _score numeric, _mode text)
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  _uid uuid := auth.uid();
  _max numeric;
BEGIN
  IF _uid IS NULL THEN
    RAISE EXCEPTION 'Not authenticated';
  END IF;
  IF _game_type IS NULL OR length(_game_type) > 40 THEN
    RAISE EXCEPTION 'Invalid game type';
  END IF;
  IF _mode IS NULL OR _mode NOT IN ('single', 'vsRobot', 'multi') THEN
    RAISE EXCEPTION 'Invalid mode';
  END IF;
  IF _score IS NULL OR _score < 0 THEN
    RAISE EXCEPTION 'Invalid score';
  END IF;

  _max := CASE
    WHEN _game_type = 'game24' THEN 3600
    WHEN _game_type = 'shooting' THEN 10000
    WHEN _game_type = 'subway' THEN 1000000
    WHEN _game_type LIKE 'basketball%' THEN 500
    ELSE 1000000
  END;

  IF _score > _max THEN
    RAISE EXCEPTION 'Score out of range';
  END IF;

  -- basic flood protection: at most one record per game every 5 seconds
  IF EXISTS (
    SELECT 1 FROM public.game_leaderboards
    WHERE user_id = _uid AND game_type = _game_type AND created_at > now() - interval '5 seconds'
  ) THEN
    RETURN;
  END IF;

  INSERT INTO public.game_leaderboards (user_id, game_type, score, mode)
  VALUES (_uid, _game_type, _score, _mode);
END;
$$;

REVOKE ALL ON FUNCTION public.submit_game_score(text, numeric, text) FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION public.submit_game_score(text, numeric, text) TO authenticated;

-- 3. Restrict role visibility
DROP POLICY IF EXISTS "Roles viewable by authenticated" ON public.user_roles;
CREATE POLICY "Users view own role or admins view all" ON public.user_roles
FOR SELECT TO authenticated
USING (auth.uid() = user_id OR has_role(auth.uid(), 'admin'::app_role));
