-- 1. Feed scope
ALTER TABLE public.posts
  ADD COLUMN IF NOT EXISTS school_id uuid REFERENCES public.schools(id) ON DELETE SET NULL,
  ADD COLUMN IF NOT EXISTS scope text NOT NULL DEFAULT 'school';

ALTER TABLE public.posts DROP CONSTRAINT IF EXISTS posts_scope_check;
ALTER TABLE public.posts ADD CONSTRAINT posts_scope_check
  CHECK (scope IN ('global','country','region','city','school'));

UPDATE public.posts p
   SET school_id = pr.school_id
  FROM public.profiles pr
 WHERE pr.user_id = p.author_id AND p.school_id IS NULL;

CREATE INDEX IF NOT EXISTS posts_school_scope_idx ON public.posts (school_id, scope);

-- 2. Staff grading of written quiz answers
DROP POLICY IF EXISTS "Staff view quiz answers" ON public.quiz_answers;
CREATE POLICY "Staff view quiz answers" ON public.quiz_answers
  FOR SELECT TO authenticated
  USING (public.can_author_questions(auth.uid()));

DROP POLICY IF EXISTS "Staff grade quiz answers" ON public.quiz_answers;
CREATE POLICY "Staff grade quiz answers" ON public.quiz_answers
  FOR UPDATE TO authenticated
  USING (public.can_author_questions(auth.uid()))
  WITH CHECK (public.can_author_questions(auth.uid()));

DROP POLICY IF EXISTS "Staff view quiz attempts" ON public.quiz_attempts;
CREATE POLICY "Staff view quiz attempts" ON public.quiz_attempts
  FOR SELECT TO authenticated
  USING (public.can_author_questions(auth.uid()));

DROP POLICY IF EXISTS "Staff update quiz attempts" ON public.quiz_attempts;
CREATE POLICY "Staff update quiz attempts" ON public.quiz_attempts
  FOR UPDATE TO authenticated
  USING (public.can_author_questions(auth.uid()))
  WITH CHECK (public.can_author_questions(auth.uid()));

-- 3. Block privilege escalation on profile creation
DROP POLICY IF EXISTS "Users insert own profile" ON public.profiles;
CREATE POLICY "Users insert own profile" ON public.profiles
  FOR INSERT TO authenticated
  WITH CHECK (
    auth.uid() = user_id
    AND (
      public.has_role(auth.uid(), 'admin')
      OR (display_role = 'Student' AND is_approved = false)
    )
  );