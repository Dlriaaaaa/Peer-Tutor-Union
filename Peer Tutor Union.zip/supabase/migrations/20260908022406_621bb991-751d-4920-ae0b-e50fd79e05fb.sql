
-- 1. Role string fix
CREATE OR REPLACE FUNCTION public.can_manage_study_group(_user_id uuid, _group_id uuid)
RETURNS boolean LANGUAGE sql STABLE SECURITY DEFINER SET search_path TO 'public' AS $$
  SELECT EXISTS (
    SELECT 1 FROM public.study_groups g WHERE g.id = _group_id AND g.creator_id = _user_id
  ) OR EXISTS (
    SELECT 1 FROM public.profiles p
    WHERE p.user_id = _user_id AND p.display_role IN ('President', 'VicePresident')
  ) OR public.is_super_admin(_user_id)
$$;

-- 2. INSERT guards (UPDATE guards already exist)
CREATE OR REPLACE FUNCTION public.guard_team_manager_insert()
RETURNS trigger LANGUAGE plpgsql SECURITY DEFINER SET search_path TO 'public' AS $$
BEGIN
  IF current_user IN ('authenticated','anon') AND NOT public.has_role(auth.uid(),'admin') THEN
    NEW.user_id := auth.uid();
    NEW.coins := LEAST(COALESCE(NEW.coins, 1000), 1000);
    NEW.current_league := 'bronze';
    NEW.league_wins := 0; NEW.total_wins := 0; NEW.total_losses := 0;
    NEW.wc_titles := 0; NEW.world_tour_titles := '{}'::jsonb;
    NEW.coach_key := NULL; NEW.coach_matches_left := 0;
  END IF;
  RETURN NEW;
END; $$;
DROP TRIGGER IF EXISTS guard_team_manager_insert_trg ON public.team_managers;
CREATE TRIGGER guard_team_manager_insert_trg BEFORE INSERT ON public.team_managers
FOR EACH ROW EXECUTE FUNCTION public.guard_team_manager_insert();

CREATE OR REPLACE FUNCTION public.guard_player_card_insert()
RETURNS trigger LANGUAGE plpgsql SECURITY DEFINER SET search_path TO 'public' AS $$
BEGIN
  IF current_user IN ('authenticated','anon') AND NOT public.has_role(auth.uid(),'admin') THEN
    NEW.user_id := auth.uid();
    NEW.level := 1;
    NEW.bonus_speed := 0; NEW.bonus_shooting := 0; NEW.bonus_three_point := 0;
    NEW.bonus_defense := 0; NEW.bonus_dunk := 0;
    NEW.stamina := LEAST(COALESCE(NEW.stamina,100), 100);
  END IF;
  RETURN NEW;
END; $$;
DROP TRIGGER IF EXISTS guard_player_card_insert_trg ON public.player_cards;
CREATE TRIGGER guard_player_card_insert_trg BEFORE INSERT ON public.player_cards
FOR EACH ROW EXECUTE FUNCTION public.guard_player_card_insert();

CREATE OR REPLACE FUNCTION public.guard_consumable_insert()
RETURNS trigger LANGUAGE plpgsql SECURITY DEFINER SET search_path TO 'public' AS $$
BEGIN
  IF current_user IN ('authenticated','anon') AND NOT public.has_role(auth.uid(),'admin') THEN
    NEW.user_id := auth.uid();
    NEW.quantity := 0;
  END IF;
  RETURN NEW;
END; $$;
DROP TRIGGER IF EXISTS guard_consumable_insert_trg ON public.consumables;
CREATE TRIGGER guard_consumable_insert_trg BEFORE INSERT ON public.consumables
FOR EACH ROW EXECUTE FUNCTION public.guard_consumable_insert();

-- 3. Server-authoritative economy
DROP POLICY IF EXISTS "Users insert own history" ON public.match_history;
DROP POLICY IF EXISTS "Users insert own lottery history" ON public.lottery_history;
DROP POLICY IF EXISTS "Users create own challenges" ON public.friend_challenges;

CREATE OR REPLACE FUNCTION public.grant_consumable(_user_id uuid, _item_key text, _qty integer)
RETURNS void LANGUAGE plpgsql SECURITY DEFINER SET search_path TO 'public' AS $$
BEGIN
  IF _qty IS NULL OR _qty <= 0 THEN RETURN; END IF;
  UPDATE public.consumables SET quantity = quantity + _qty, updated_at = now()
   WHERE user_id = _user_id AND item_key = _item_key;
  IF NOT FOUND THEN
    INSERT INTO public.consumables (user_id, item_key, quantity)
    VALUES (_user_id, _item_key, _qty);
  END IF;
END; $$;

CREATE OR REPLACE FUNCTION public.lottery_slices()
RETURNS TABLE(ord int, key text, weight numeric, coins bigint, item_key text, item_qty int)
LANGUAGE sql IMMUTABLE SET search_path TO 'public' AS $$
  SELECT * FROM (VALUES
    (1,'jackpot_1m', 0.01::numeric, 1000000::bigint, NULL::text, 0),
    (2,'big_100k',   0.1,  100000, NULL, 0),
    (3,'mid_10k',    0.5,  10000,  NULL, 0),
    (4,'break_even', 20,   100,    NULL, 0),
    (5,'small_50',   25,   50,     NULL, 0),
    (6,'small_30',   25,   30,     NULL, 0),
    (7,'small_10',   20,   10,     NULL, 0),
    (8,'item_water', 4,    0,      'water', 1),
    (9,'item_banana',3,    0,      'banana', 1),
    (10,'item_elixir',1,   0,      'elixir', 1),
    (11,'bust',      1.39, 0,      NULL, 0)
  ) v(ord,key,weight,coins,item_key,item_qty);
$$;

CREATE OR REPLACE FUNCTION public.spin_lottery(_kind text)
RETURNS jsonb LANGUAGE plpgsql SECURITY DEFINER SET search_path TO 'public' AS $$
DECLARE
  _me uuid := auth.uid();
  _team record; _cost bigint; _n int; _mult int := 1; _iqty int := 1;
  _keys text[] := '{}'; _total bigint := 0; _r numeric; _i int;
  _slice record; _items jsonb := '{}'::jsonb; _k text; _has_payback boolean := false;
BEGIN
  IF _me IS NULL THEN RAISE EXCEPTION 'Not authenticated'; END IF;
  IF _kind = 'spin' THEN _cost := 100; _n := 1;
  ELSIF _kind = 'spin_x10' THEN _cost := 1000; _n := 10;
  ELSIF _kind = 'golden' THEN _cost := 10000; _n := 1; _mult := 100; _iqty := 3;
  ELSIF _kind = 'golden_x10' THEN _cost := 100000; _n := 10; _mult := 100; _iqty := 3;
  ELSIF _kind = 'golden_x100' THEN _cost := 5000000; _n := 100; _mult := 100; _iqty := 3;
  ELSE RAISE EXCEPTION 'Unknown lottery kind'; END IF;

  SELECT * INTO _team FROM public.team_managers WHERE user_id = _me FOR UPDATE;
  IF NOT FOUND THEN RAISE EXCEPTION 'No team'; END IF;
  IF _team.coins < _cost THEN RAISE EXCEPTION 'Not enough coins'; END IF;

  FOR _i IN 1.._n LOOP
    _r := random() * 100;
    SELECT s.key, s.coins, s.item_key, s.item_qty INTO _slice
      FROM (SELECT l.*, sum(l.weight) OVER (ORDER BY l.ord) AS cum FROM public.lottery_slices() l) s
     WHERE s.cum >= _r ORDER BY s.cum LIMIT 1;
    IF _slice IS NULL THEN
      SELECT l.key, l.coins, l.item_key, l.item_qty INTO _slice FROM public.lottery_slices() l ORDER BY l.ord DESC LIMIT 1;
    END IF;
    _keys := array_append(_keys, _slice.key);
    _total := _total + _slice.coins * _mult;
    IF _slice.coins * _mult >= 100 * _mult THEN _has_payback := true; END IF;
    IF _slice.item_key IS NOT NULL THEN
      _items := jsonb_set(_items, ARRAY[_slice.item_key],
        to_jsonb(COALESCE((_items ->> _slice.item_key)::int, 0) + _slice.item_qty * _iqty));
    END IF;
  END LOOP;

  IF _n >= 10 AND NOT _has_payback THEN
    _keys[array_length(_keys,1)] := 'break_even';
    _total := _total + 100 * _mult;
  END IF;

  UPDATE public.team_managers SET coins = GREATEST(0, coins - _cost + _total)
   WHERE user_id = _me RETURNING coins INTO _team.coins;

  FOR _k IN SELECT jsonb_object_keys(_items) LOOP
    PERFORM public.grant_consumable(_me, _k, (_items ->> _k)::int);
  END LOOP;

  INSERT INTO public.lottery_history (user_id, kind, cost, reward_coins, reward_items)
  VALUES (_me, _kind, _cost, _total,
    COALESCE((SELECT jsonb_agg(jsonb_build_object('item_key', k, 'qty', (_items ->> k)::int))
              FROM jsonb_object_keys(_items) k), '[]'::jsonb));

  RETURN jsonb_build_object('ok', true, 'slice_keys', to_jsonb(_keys),
    'total_coins', _total, 'cost', _cost, 'coins', _team.coins);
END; $$;

CREATE OR REPLACE FUNCTION public.buy_scratch_ticket(_face integer)
RETURNS jsonb LANGUAGE plpgsql SECURITY DEFINER SET search_path TO 'public' AS $$
DECLARE
  _me uuid := auth.uid();
  _team record; _prizes jsonb; _total numeric := 0; _r numeric; _acc numeric := 0;
  _p jsonb; _prize jsonb := NULL; _coin_reward bigint := 0;
BEGIN
  IF _me IS NULL THEN RAISE EXCEPTION 'Not authenticated'; END IF;
  IF _face NOT IN (100, 1000, 100000, 2000000) THEN RAISE EXCEPTION 'Invalid ticket'; END IF;

  SELECT prizes INTO _prizes FROM public.scratch_card_configs WHERE face_value = _face;
  IF _prizes IS NULL OR jsonb_array_length(_prizes) = 0 THEN RAISE EXCEPTION 'Scratch card not configured'; END IF;

  SELECT * INTO _team FROM public.team_managers WHERE user_id = _me FOR UPDATE;
  IF NOT FOUND THEN RAISE EXCEPTION 'No team'; END IF;
  IF _team.coins < _face THEN RAISE EXCEPTION 'Not enough coins'; END IF;

  SELECT COALESCE(sum((e ->> 'weight')::numeric), 0) INTO _total FROM jsonb_array_elements(_prizes) e;
  IF _total <= 0 THEN RAISE EXCEPTION 'Scratch card not configured'; END IF;
  _r := random() * _total;
  FOR _p IN SELECT e FROM jsonb_array_elements(_prizes) e LOOP
    _acc := _acc + COALESCE((_p ->> 'weight')::numeric, 0);
    IF _acc >= _r THEN _prize := _p; EXIT; END IF;
  END LOOP;
  IF _prize IS NULL THEN _prize := _prizes -> (jsonb_array_length(_prizes) - 1); END IF;

  IF (_prize ->> 'kind') = 'coins' THEN
    _coin_reward := COALESCE((_prize ->> 'amount')::bigint, 0);
  END IF;

  UPDATE public.team_managers SET coins = GREATEST(0, coins - _face + _coin_reward)
   WHERE user_id = _me RETURNING coins INTO _team.coins;

  IF (_prize ->> 'kind') = 'item' AND (_prize ->> 'item_key') IS NOT NULL THEN
    PERFORM public.grant_consumable(_me, _prize ->> 'item_key', COALESCE((_prize ->> 'qty')::int, 1));
  END IF;

  INSERT INTO public.lottery_history (user_id, kind, cost, reward_coins, reward_items)
  VALUES (_me, 'scratch_' || _face, _face, _coin_reward,
    CASE WHEN (_prize ->> 'kind') = 'item'
      THEN jsonb_build_array(jsonb_build_object('item_key', _prize ->> 'item_key', 'qty', COALESCE((_prize ->> 'qty')::int,1)))
      ELSE '[]'::jsonb END);

  RETURN jsonb_build_object('ok', true, 'prize', _prize, 'coins', _team.coins);
END; $$;

CREATE OR REPLACE FUNCTION public.settle_league_match(_league text, _player_score integer, _ai_score integer, _won boolean)
RETURNS jsonb LANGUAGE plpgsql SECURITY DEFINER SET search_path TO 'public' AS $$
DECLARE
  _me uuid := auth.uid();
  _team record; _entry int; _reward int; _penalty int; _promo int := 5;
  _next text; _difficulty text; _is_rematch boolean; _net int;
  _new_league text; _new_wins int; _promoted boolean := false; _updated record;
BEGIN
  IF _me IS NULL THEN RAISE EXCEPTION 'Not authenticated'; END IF;
  IF _league NOT IN ('bronze','silver','gold','allstar','nba') THEN RAISE EXCEPTION 'Invalid league'; END IF;
  IF _player_score IS NULL OR _ai_score IS NULL OR _player_score < 0 OR _ai_score < 0
     OR _player_score > 500 OR _ai_score > 500 THEN RAISE EXCEPTION 'Invalid score'; END IF;

  SELECT * INTO _team FROM public.team_managers WHERE user_id = _me FOR UPDATE;
  IF NOT FOUND THEN RAISE EXCEPTION 'No team'; END IF;

  SELECT v.entry, v.reward, v.penalty, v.nxt, v.diff
    INTO _entry, _reward, _penalty, _next, _difficulty
  FROM (VALUES
    ('bronze',  50,   100,  25,   'silver',  'easy'),
    ('silver',  150,  300,  75,   'gold',    'medium'),
    ('gold',    400,  800,  200,  'allstar', 'hard'),
    ('allstar', 1000, 2000, 500,  'nba',     'allstar'),
    ('nba',     2500, 5000, 1250, NULL,      'nba')
  ) v(lg, entry, reward, penalty, nxt, diff)
  WHERE v.lg = _league;

  _is_rematch := (_league = 'nba' AND COALESCE(_team.league_wins,0) >= _promo);
  IF _is_rematch THEN _entry := 10000; _reward := 300000; _penalty := 0; END IF;

  _net := CASE WHEN _won THEN _reward ELSE -(_entry + _penalty) END;

  _new_league := _team.current_league;
  IF _league <> _team.current_league THEN
    _new_wins := _team.league_wins;
  ELSE
    _new_wins := CASE WHEN _won THEN _team.league_wins + 1 ELSE 0 END;
    IF _won AND _next IS NOT NULL AND _new_wins >= _promo THEN
      _new_league := _next; _new_wins := 0; _promoted := true;
    END IF;
  END IF;

  UPDATE public.team_managers SET
    coins = GREATEST(0, coins + _net),
    league_wins = _new_wins,
    current_league = _new_league,
    total_wins = total_wins + CASE WHEN _won THEN 1 ELSE 0 END,
    total_losses = total_losses + CASE WHEN _won THEN 0 ELSE 1 END
  WHERE user_id = _me RETURNING * INTO _updated;

  INSERT INTO public.match_history (user_id, league, ai_difficulty, player_score, ai_score, won, coins_change)
  VALUES (_me, _league, _difficulty, _player_score, _ai_score, _won, _net);

  RETURN jsonb_build_object('ok', true, 'team', to_jsonb(_updated),
    'coins_change', _net, 'promoted', _promoted);
END; $$;

-- 4. Practice answers: server-side grading
CREATE OR REPLACE FUNCTION public.guard_practice_answer_grading()
RETURNS trigger LANGUAGE plpgsql SECURITY DEFINER SET search_path TO 'public' AS $$
DECLARE _qtype text; _correct text;
BEGIN
  IF current_user IN ('authenticated','anon') AND NOT public.can_author_questions(auth.uid()) THEN
    IF TG_OP = 'INSERT' THEN
      NEW.user_id := auth.uid();
      NEW.points_awarded := NULL; NEW.feedback := NULL; NEW.graded_by := NULL; NEW.graded_at := NULL;
    ELSE
      NEW.user_id := OLD.user_id;
      NEW.points_awarded := OLD.points_awarded; NEW.feedback := OLD.feedback;
      NEW.graded_by := OLD.graded_by; NEW.graded_at := OLD.graded_at;
    END IF;

    SELECT q.question_type, q.correct_option INTO _qtype, _correct
      FROM public.questions q WHERE q.id = NEW.question_id;

    IF _qtype = 'mcq' AND NEW.part_id IS NULL THEN
      NEW.is_correct := (NEW.selected_option IS NOT NULL AND _correct IS NOT NULL
                         AND NEW.selected_option = _correct);
    ELSE
      NEW.is_correct := CASE WHEN TG_OP = 'INSERT' THEN NULL ELSE OLD.is_correct END;
    END IF;
  END IF;
  RETURN NEW;
END; $$;
DROP TRIGGER IF EXISTS guard_practice_answer_grading_trg ON public.practice_answers;
CREATE TRIGGER guard_practice_answer_grading_trg BEFORE INSERT OR UPDATE ON public.practice_answers
FOR EACH ROW EXECUTE FUNCTION public.guard_practice_answer_grading();

-- 5. Quiz answers: only via save_quiz_answer RPC
DROP POLICY IF EXISTS "Students create own answers" ON public.quiz_answers;
DROP POLICY IF EXISTS "Students update own answers" ON public.quiz_answers;

-- 6. Remove anonymous execution of privileged functions
DO $$
DECLARE r record;
BEGIN
  FOR r IN
    SELECT p.oid::regprocedure AS sig
    FROM pg_proc p JOIN pg_namespace n ON n.oid = p.pronamespace
    WHERE n.nspname = 'public' AND p.prosecdef
  LOOP
    EXECUTE format('REVOKE ALL ON FUNCTION %s FROM anon, PUBLIC', r.sig);
    EXECUTE format('GRANT EXECUTE ON FUNCTION %s TO authenticated, service_role', r.sig);
  END LOOP;
END $$;
