ALTER TABLE public.questions
  ADD COLUMN IF NOT EXISTS title text,
  ADD COLUMN IF NOT EXISTS options text[],
  ADD COLUMN IF NOT EXISTS answer_file_url text,
  ADD COLUMN IF NOT EXISTS answer_file_name text;

ALTER TABLE public.questions ALTER COLUMN stem DROP NOT NULL;
ALTER TABLE public.questions DROP CONSTRAINT IF EXISTS questions_correct_option_check;
ALTER TABLE public.questions ADD CONSTRAINT questions_correct_option_check
  CHECK (correct_option IS NULL OR correct_option = ANY (ARRAY['A','B','C','D','E','F']));

ALTER TABLE public.question_parts
  ADD COLUMN IF NOT EXISTS sample_answer_file_url text,
  ADD COLUMN IF NOT EXISTS sample_answer_file_name text;
ALTER TABLE public.question_parts ALTER COLUMN prompt DROP NOT NULL;

DROP POLICY IF EXISTS "Signed-in can view questions" ON public.questions;
DROP POLICY IF EXISTS "Signed-in can view parts" ON public.question_parts;

CREATE POLICY "View parts of visible questions"
ON public.question_parts FOR SELECT TO authenticated
USING (EXISTS (
  SELECT 1 FROM public.questions q
  WHERE q.id = question_parts.question_id
    AND (q.visibility = 'public' OR q.club_id IS NULL OR q.created_by = auth.uid()
         OR public.is_club_member(auth.uid(), q.club_id) OR public.is_super_admin(auth.uid()))
));