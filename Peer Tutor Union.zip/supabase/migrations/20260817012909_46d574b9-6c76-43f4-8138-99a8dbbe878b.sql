CREATE TABLE public.study_groups (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  creator_id uuid NOT NULL,
  title text NOT NULL,
  subject text NOT NULL,
  meeting_time text,
  frequency text,
  location text,
  max_members integer NOT NULL DEFAULT 6,
  content text,
  requirements text,
  is_public boolean NOT NULL DEFAULT true,
  expires_at date,
  status text NOT NULL DEFAULT 'active',
  created_at timestamp with time zone NOT NULL DEFAULT now(),
  updated_at timestamp with time zone NOT NULL DEFAULT now()
);

GRANT SELECT, INSERT, UPDATE, DELETE ON public.study_groups TO authenticated;
GRANT ALL ON public.study_groups TO service_role;
ALTER TABLE public.study_groups ENABLE ROW LEVEL SECURITY;

CREATE TABLE public.study_group_members (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  group_id uuid NOT NULL REFERENCES public.study_groups(id) ON DELETE CASCADE,
  user_id uuid NOT NULL,
  created_at timestamp with time zone NOT NULL DEFAULT now(),
  UNIQUE (group_id, user_id)
);

GRANT SELECT, INSERT, DELETE ON public.study_group_members TO authenticated;
GRANT ALL ON public.study_group_members TO service_role;
ALTER TABLE public.study_group_members ENABLE ROW LEVEL SECURITY;

CREATE OR REPLACE FUNCTION public.is_study_group_member(_user_id uuid, _group_id uuid)
RETURNS boolean LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public AS $$
  SELECT EXISTS (SELECT 1 FROM public.study_group_members WHERE user_id = _user_id AND group_id = _group_id)
$$;

CREATE POLICY "View public or own study groups" ON public.study_groups FOR SELECT TO authenticated
USING (is_public OR creator_id = auth.uid() OR public.is_study_group_member(auth.uid(), id) OR public.has_role(auth.uid(), 'admin'));

CREATE POLICY "Members create study groups" ON public.study_groups FOR INSERT TO authenticated
WITH CHECK (creator_id = auth.uid());

CREATE POLICY "Creator or admin updates study group" ON public.study_groups FOR UPDATE TO authenticated
USING (creator_id = auth.uid() OR public.has_role(auth.uid(), 'admin'))
WITH CHECK (creator_id = auth.uid() OR public.has_role(auth.uid(), 'admin'));

CREATE POLICY "Creator or admin deletes study group" ON public.study_groups FOR DELETE TO authenticated
USING (creator_id = auth.uid() OR public.has_role(auth.uid(), 'admin'));

CREATE POLICY "View members of visible groups" ON public.study_group_members FOR SELECT TO authenticated
USING (EXISTS (SELECT 1 FROM public.study_groups g WHERE g.id = group_id
  AND (g.is_public OR g.creator_id = auth.uid() OR public.is_study_group_member(auth.uid(), g.id) OR public.has_role(auth.uid(), 'admin'))));

CREATE POLICY "Join study group" ON public.study_group_members FOR INSERT TO authenticated
WITH CHECK (user_id = auth.uid());

CREATE POLICY "Leave or remove from study group" ON public.study_group_members FOR DELETE TO authenticated
USING (user_id = auth.uid()
  OR EXISTS (SELECT 1 FROM public.study_groups g WHERE g.id = group_id AND g.creator_id = auth.uid())
  OR public.has_role(auth.uid(), 'admin'));

CREATE TRIGGER update_study_groups_updated_at BEFORE UPDATE ON public.study_groups
FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();