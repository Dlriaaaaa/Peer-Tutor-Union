-- Restrict student visibility of answer keys to after results are published
DROP POLICY IF EXISTS "Users view questions of published quizzes" ON public.quiz_questions;
CREATE POLICY "Users view questions after results published"
ON public.quiz_questions FOR SELECT TO authenticated
USING (EXISTS (SELECT 1 FROM public.quizzes q WHERE q.id = quiz_questions.quiz_id AND q.is_published AND q.results_published));

DROP POLICY IF EXISTS "Users view options of published quizzes" ON public.quiz_options;
CREATE POLICY "Users view options after results published"
ON public.quiz_options FOR SELECT TO authenticated
USING (EXISTS (
  SELECT 1 FROM public.quiz_questions qq JOIN public.quizzes q ON q.id = qq.quiz_id
  WHERE qq.id = quiz_options.question_id AND q.is_published AND q.results_published));

-- Answer-free question feed for taking a quiz
CREATE OR REPLACE FUNCTION public.get_quiz_items(_quiz_id uuid)
RETURNS TABLE(id uuid, question_text text, question_type text, image_url text, points integer, sort_order integer, options jsonb)
LANGUAGE sql STABLE SECURITY DEFINER SET search_path TO 'public'
AS $$
  SELECT qq.id, qq.question_text, qq.question_type, qq.image_url, qq.points, qq.sort_order,
    COALESCE((
      SELECT jsonb_agg(jsonb_build_object('id', o.id, 'question_id', o.question_id, 'option_text', o.option_text, 'sort_order', o.sort_order) ORDER BY o.sort_order)
      FROM public.quiz_options o WHERE o.question_id = qq.id
    ), '[]'::jsonb)
  FROM public.quiz_questions qq
  JOIN public.quizzes q ON q.id = qq.quiz_id
  WHERE qq.quiz_id = _quiz_id AND q.is_published AND auth.uid() IS NOT NULL
  ORDER BY qq.sort_order;
$$;
REVOKE EXECUTE ON FUNCTION public.get_quiz_items(uuid) FROM anon, public;
GRANT EXECUTE ON FUNCTION public.get_quiz_items(uuid) TO authenticated;

-- Server-side grading of a single answer
CREATE OR REPLACE FUNCTION public.save_quiz_answer(_attempt_id uuid, _question_id uuid, _option_id uuid, _option_ids uuid[], _text text)
RETURNS void
LANGUAGE plpgsql SECURITY DEFINER SET search_path TO 'public'
AS $$
DECLARE
  _qtype text; _correct boolean := false; _existing uuid;
BEGIN
  IF NOT EXISTS (SELECT 1 FROM public.quiz_attempts a WHERE a.id = _attempt_id AND a.student_id = auth.uid() AND a.completed_at IS NULL) THEN
    RAISE EXCEPTION 'Attempt not found or already completed';
  END IF;

  SELECT question_type INTO _qtype FROM public.quiz_questions WHERE id = _question_id;

  IF _qtype = 'multiple_choice' THEN
    SELECT COALESCE(is_correct, false) INTO _correct FROM public.quiz_options WHERE id = _option_id;
  ELSIF _qtype = 'multiple_select' THEN
    SELECT COALESCE((SELECT array_agg(o.id ORDER BY o.id) FROM public.quiz_options o WHERE o.question_id = _question_id AND o.is_correct), '{}')
         = COALESCE((SELECT array_agg(x ORDER BY x) FROM unnest(COALESCE(_option_ids, '{}')) x), '{}')
    INTO _correct;
  ELSE
    SELECT lower(btrim(COALESCE(_text, ''))) = lower(btrim(COALESCE(correct_answer, '')))
      AND COALESCE(_text, '') <> '' INTO _correct
    FROM public.quiz_questions WHERE id = _question_id;
  END IF;

  SELECT id INTO _existing FROM public.quiz_answers WHERE attempt_id = _attempt_id AND question_id = _question_id;
  IF _existing IS NOT NULL THEN
    UPDATE public.quiz_answers
      SET selected_option_id = _option_id, selected_option_ids = _option_ids, text_answer = _text, is_correct = COALESCE(_correct, false)
      WHERE id = _existing;
  ELSE
    INSERT INTO public.quiz_answers (attempt_id, question_id, selected_option_id, selected_option_ids, text_answer, is_correct)
    VALUES (_attempt_id, _question_id, _option_id, _option_ids, _text, COALESCE(_correct, false));
  END IF;
END;
$$;
REVOKE EXECUTE ON FUNCTION public.save_quiz_answer(uuid, uuid, uuid, uuid[], text) FROM anon, public;
GRANT EXECUTE ON FUNCTION public.save_quiz_answer(uuid, uuid, uuid, uuid[], text) TO authenticated;

-- Finalize and score an attempt server-side
CREATE OR REPLACE FUNCTION public.finalize_quiz_attempt(_attempt_id uuid)
RETURNS jsonb
LANGUAGE plpgsql SECURITY DEFINER SET search_path TO 'public'
AS $$
DECLARE _quiz uuid; _total numeric; _score numeric;
BEGIN
  SELECT quiz_id INTO _quiz FROM public.quiz_attempts WHERE id = _attempt_id AND student_id = auth.uid();
  IF _quiz IS NULL THEN RAISE EXCEPTION 'Attempt not found'; END IF;

  SELECT COALESCE(sum(points), 0) INTO _total FROM public.quiz_questions WHERE quiz_id = _quiz;
  SELECT COALESCE(sum(qq.points), 0) INTO _score
    FROM public.quiz_answers a JOIN public.quiz_questions qq ON qq.id = a.question_id
    WHERE a.attempt_id = _attempt_id AND a.is_correct;

  UPDATE public.quiz_attempts
    SET score = _score, total_points = _total, completed_at = COALESCE(completed_at, now())
    WHERE id = _attempt_id;

  RETURN jsonb_build_object('score', _score, 'total', _total);
END;
$$;
REVOKE EXECUTE ON FUNCTION public.finalize_quiz_attempt(uuid) FROM anon, public;
GRANT EXECUTE ON FUNCTION public.finalize_quiz_attempt(uuid) TO authenticated;