
-- ============ SCHOOLS ============
CREATE TABLE public.schools (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  country text NOT NULL,
  region text NOT NULL,
  city text NOT NULL,
  name text NOT NULL,
  is_active boolean NOT NULL DEFAULT true,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (country, region, city, name)
);
GRANT SELECT ON public.schools TO anon;
GRANT SELECT, INSERT, UPDATE, DELETE ON public.schools TO authenticated;
GRANT ALL ON public.schools TO service_role;
ALTER TABLE public.schools ENABLE ROW LEVEL SECURITY;

CREATE OR REPLACE FUNCTION public.is_super_admin(_user_id uuid)
RETURNS boolean LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public
AS $$
  SELECT EXISTS (SELECT 1 FROM auth.users u WHERE u.id = _user_id AND lower(u.email) = 'ria7883@outlook.com')
$$;

CREATE POLICY "Anyone can view schools" ON public.schools FOR SELECT USING (true);
CREATE POLICY "Super admin manages schools" ON public.schools FOR ALL TO authenticated
  USING (public.is_super_admin(auth.uid())) WITH CHECK (public.is_super_admin(auth.uid()));

CREATE TRIGGER update_schools_updated_at BEFORE UPDATE ON public.schools
  FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

-- ============ CLUBS ============
CREATE TABLE public.clubs (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  school_id uuid NOT NULL REFERENCES public.schools(id) ON DELETE CASCADE,
  name text NOT NULL,
  description text,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (school_id, name)
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.clubs TO authenticated;
GRANT ALL ON public.clubs TO service_role;
ALTER TABLE public.clubs ENABLE ROW LEVEL SECURITY;

CREATE TABLE public.club_members (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  club_id uuid NOT NULL REFERENCES public.clubs(id) ON DELETE CASCADE,
  user_id uuid NOT NULL,
  club_role text NOT NULL DEFAULT 'Member',
  status text NOT NULL DEFAULT 'pending',
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (club_id, user_id)
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.club_members TO authenticated;
GRANT ALL ON public.club_members TO service_role;
ALTER TABLE public.club_members ENABLE ROW LEVEL SECURITY;

CREATE OR REPLACE FUNCTION public.is_club_member(_user_id uuid, _club_id uuid)
RETURNS boolean LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public
AS $$
  SELECT EXISTS (SELECT 1 FROM public.club_members cm
    WHERE cm.user_id = _user_id AND cm.club_id = _club_id AND cm.status = 'approved')
$$;

CREATE OR REPLACE FUNCTION public.is_club_leader(_user_id uuid, _club_id uuid)
RETURNS boolean LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public
AS $$
  SELECT public.is_super_admin(_user_id) OR EXISTS (
    SELECT 1 FROM public.club_members cm
    WHERE cm.user_id = _user_id AND cm.club_id = _club_id AND cm.status = 'approved'
      AND cm.club_role IN ('President','VicePresident'))
$$;

CREATE OR REPLACE FUNCTION public.is_club_staff(_user_id uuid, _club_id uuid)
RETURNS boolean LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public
AS $$
  SELECT public.is_super_admin(_user_id) OR EXISTS (
    SELECT 1 FROM public.club_members cm
    WHERE cm.user_id = _user_id AND cm.club_id = _club_id AND cm.status = 'approved'
      AND cm.club_role IN ('President','VicePresident','Teacher'))
$$;

CREATE POLICY "Signed-in users view clubs" ON public.clubs FOR SELECT TO authenticated USING (true);
CREATE POLICY "Super admin inserts clubs" ON public.clubs FOR INSERT TO authenticated
  WITH CHECK (public.is_super_admin(auth.uid()));
CREATE POLICY "Leaders update clubs" ON public.clubs FOR UPDATE TO authenticated
  USING (public.is_club_leader(auth.uid(), id)) WITH CHECK (public.is_club_leader(auth.uid(), id));
CREATE POLICY "Super admin deletes clubs" ON public.clubs FOR DELETE TO authenticated
  USING (public.is_super_admin(auth.uid()));
CREATE TRIGGER update_clubs_updated_at BEFORE UPDATE ON public.clubs
  FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

CREATE POLICY "View own or club memberships" ON public.club_members FOR SELECT TO authenticated
  USING (user_id = auth.uid() OR public.is_club_member(auth.uid(), club_id) OR public.is_super_admin(auth.uid()));
CREATE POLICY "Request to join a club" ON public.club_members FOR INSERT TO authenticated
  WITH CHECK (user_id = auth.uid() AND status = 'pending' AND club_role = 'Member');
CREATE POLICY "Leaders manage memberships" ON public.club_members FOR UPDATE TO authenticated
  USING (public.is_club_leader(auth.uid(), club_id)) WITH CHECK (public.is_club_leader(auth.uid(), club_id));
CREATE POLICY "Leaders or self remove membership" ON public.club_members FOR DELETE TO authenticated
  USING (user_id = auth.uid() OR public.is_club_leader(auth.uid(), club_id));
CREATE TRIGGER update_club_members_updated_at BEFORE UPDATE ON public.club_members
  FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

-- ============ PROFILE SCHOOL ============
ALTER TABLE public.profiles ADD COLUMN IF NOT EXISTS school_id uuid REFERENCES public.schools(id);

-- Harden profile insert (privilege escalation finding)
DROP POLICY IF EXISTS "Users insert own profile" ON public.profiles;
CREATE POLICY "Users insert own profile" ON public.profiles FOR INSERT TO authenticated
  WITH CHECK (
    auth.uid() = user_id
    AND (public.has_role(auth.uid(), 'admin') OR (display_role = 'Student' AND is_approved = false))
  );

-- ============ SUBJECTS + KNOWLEDGE POINTS ============
ALTER TABLE public.subjects ADD COLUMN IF NOT EXISTS club_id uuid REFERENCES public.clubs(id) ON DELETE CASCADE;

CREATE TABLE public.knowledge_points (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  subject_id uuid NOT NULL REFERENCES public.subjects(id) ON DELETE CASCADE,
  name text NOT NULL,
  created_by uuid,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
CREATE UNIQUE INDEX knowledge_points_subject_name_key
  ON public.knowledge_points (subject_id, lower(btrim(name)));
GRANT SELECT, INSERT, UPDATE, DELETE ON public.knowledge_points TO authenticated;
GRANT ALL ON public.knowledge_points TO service_role;
ALTER TABLE public.knowledge_points ENABLE ROW LEVEL SECURITY;

CREATE OR REPLACE FUNCTION public.can_manage_subject_row(_user_id uuid, _club_id uuid)
RETURNS boolean LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public
AS $$
  SELECT public.is_super_admin(_user_id)
      OR public.has_role(_user_id, 'admin')
      OR (_club_id IS NOT NULL AND public.is_club_leader(_user_id, _club_id))
      OR (_club_id IS NULL AND EXISTS (
            SELECT 1 FROM public.profiles p WHERE p.user_id = _user_id
              AND p.display_role IN ('President','VicePresident')))
$$;

CREATE POLICY "Signed-in view knowledge points" ON public.knowledge_points FOR SELECT TO authenticated USING (true);
CREATE POLICY "Leaders insert knowledge points" ON public.knowledge_points FOR INSERT TO authenticated
  WITH CHECK (public.can_manage_subject_row(auth.uid(),
    (SELECT s.club_id FROM public.subjects s WHERE s.id = subject_id)));
CREATE POLICY "Leaders update knowledge points" ON public.knowledge_points FOR UPDATE TO authenticated
  USING (public.can_manage_subject_row(auth.uid(),
    (SELECT s.club_id FROM public.subjects s WHERE s.id = subject_id)))
  WITH CHECK (public.can_manage_subject_row(auth.uid(),
    (SELECT s.club_id FROM public.subjects s WHERE s.id = subject_id)));
CREATE POLICY "Leaders delete knowledge points" ON public.knowledge_points FOR DELETE TO authenticated
  USING (public.can_manage_subject_row(auth.uid(),
    (SELECT s.club_id FROM public.subjects s WHERE s.id = subject_id)));
CREATE TRIGGER update_knowledge_points_updated_at BEFORE UPDATE ON public.knowledge_points
  FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

-- ============ QUESTIONS: knowledge point, club, visibility ============
ALTER TABLE public.questions
  ADD COLUMN IF NOT EXISTS knowledge_point_id uuid REFERENCES public.knowledge_points(id) ON DELETE SET NULL,
  ADD COLUMN IF NOT EXISTS club_id uuid REFERENCES public.clubs(id) ON DELETE SET NULL,
  ADD COLUMN IF NOT EXISTS visibility text NOT NULL DEFAULT 'public';

CREATE INDEX IF NOT EXISTS questions_knowledge_point_idx ON public.questions (knowledge_point_id);
CREATE INDEX IF NOT EXISTS questions_visibility_idx ON public.questions (visibility);

DROP POLICY IF EXISTS "Signed-in users can view questions" ON public.questions;
DROP POLICY IF EXISTS "Anyone signed in can view questions" ON public.questions;
CREATE POLICY "View public or own club questions" ON public.questions FOR SELECT TO authenticated
  USING (
    visibility = 'public'
    OR club_id IS NULL
    OR created_by = auth.uid()
    OR public.is_club_member(auth.uid(), club_id)
    OR public.is_super_admin(auth.uid())
  );

-- ============ TIME SPENT ============
ALTER TABLE public.practice_answers ADD COLUMN IF NOT EXISTS time_spent_seconds integer NOT NULL DEFAULT 0;

-- ============ WRONG QUESTION BOOK ============
CREATE TABLE public.wrong_questions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL,
  question_id uuid NOT NULL REFERENCES public.questions(id) ON DELETE CASCADE,
  created_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (user_id, question_id)
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.wrong_questions TO authenticated;
GRANT ALL ON public.wrong_questions TO service_role;
ALTER TABLE public.wrong_questions ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Own wrong questions" ON public.wrong_questions FOR ALL TO authenticated
  USING (user_id = auth.uid()) WITH CHECK (user_id = auth.uid());
