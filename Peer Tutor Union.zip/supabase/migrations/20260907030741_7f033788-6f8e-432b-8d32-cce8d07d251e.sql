DROP POLICY IF EXISTS "Authenticated users can view all teams" ON public.team_managers;
DROP POLICY IF EXISTS "Teams viewable by authenticated" ON public.team_managers;
CREATE POLICY "Users view own team" ON public.team_managers
FOR SELECT TO authenticated
USING (auth.uid() = user_id OR public.has_role(auth.uid(), 'admin'));