DROP POLICY IF EXISTS "Training data viewable by authenticated" ON public.ai_training_data;
CREATE POLICY "Training data viewable by staff"
ON public.ai_training_data
FOR SELECT
TO authenticated
USING (
  public.has_role(auth.uid(), 'admin')
  OR public.is_super_admin(auth.uid())
  OR created_by = auth.uid()
  OR EXISTS (
    SELECT 1 FROM public.profiles p
    WHERE p.user_id = auth.uid()
      AND p.display_role IN ('President', 'VicePresident', 'Teacher', 'GeneralSecretary')
  )
);