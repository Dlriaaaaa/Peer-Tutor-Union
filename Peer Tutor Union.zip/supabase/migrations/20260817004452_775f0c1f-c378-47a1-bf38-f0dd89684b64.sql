CREATE TABLE public.tutoring_slots (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  week_number integer NOT NULL,
  day_of_week text NOT NULL,
  start_time text NOT NULL,
  end_time text NOT NULL,
  subject text NOT NULL,
  session_type text NOT NULL DEFAULT 'tutorial',
  tutor_name text,
  location text,
  capacity integer NOT NULL DEFAULT 10,
  created_by uuid NOT NULL,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

GRANT SELECT, INSERT, UPDATE, DELETE ON public.tutoring_slots TO authenticated;
GRANT ALL ON public.tutoring_slots TO service_role;
ALTER TABLE public.tutoring_slots ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Authenticated can view slots" ON public.tutoring_slots
FOR SELECT TO authenticated USING (true);

CREATE POLICY "Staff can insert slots" ON public.tutoring_slots
FOR INSERT TO authenticated
WITH CHECK (public.has_role(auth.uid(), 'admin') OR EXISTS (
  SELECT 1 FROM public.profiles p WHERE p.user_id = auth.uid()
    AND p.display_role IN ('President','VicePresident','Teacher','GeneralSecretary')
));

CREATE POLICY "Staff can update slots" ON public.tutoring_slots
FOR UPDATE TO authenticated
USING (public.has_role(auth.uid(), 'admin') OR EXISTS (
  SELECT 1 FROM public.profiles p WHERE p.user_id = auth.uid()
    AND p.display_role IN ('President','VicePresident','Teacher','GeneralSecretary')
));

CREATE POLICY "Staff can delete slots" ON public.tutoring_slots
FOR DELETE TO authenticated
USING (public.has_role(auth.uid(), 'admin') OR EXISTS (
  SELECT 1 FROM public.profiles p WHERE p.user_id = auth.uid()
    AND p.display_role IN ('President','VicePresident','Teacher','GeneralSecretary')
));

CREATE TRIGGER update_tutoring_slots_updated_at
BEFORE UPDATE ON public.tutoring_slots
FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

CREATE TABLE public.tutoring_bookings (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  slot_id uuid NOT NULL REFERENCES public.tutoring_slots(id) ON DELETE CASCADE,
  user_id uuid NOT NULL,
  status text NOT NULL DEFAULT 'pending',
  admin_note text,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (slot_id, user_id)
);

GRANT SELECT, INSERT, UPDATE, DELETE ON public.tutoring_bookings TO authenticated;
GRANT ALL ON public.tutoring_bookings TO service_role;
ALTER TABLE public.tutoring_bookings ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users view own bookings, staff view all" ON public.tutoring_bookings
FOR SELECT TO authenticated
USING (user_id = auth.uid() OR public.has_role(auth.uid(), 'admin') OR EXISTS (
  SELECT 1 FROM public.profiles p WHERE p.user_id = auth.uid()
    AND p.display_role IN ('President','VicePresident','Teacher','GeneralSecretary')
));

CREATE POLICY "Users create own bookings" ON public.tutoring_bookings
FOR INSERT TO authenticated WITH CHECK (user_id = auth.uid());

CREATE POLICY "Staff update bookings" ON public.tutoring_bookings
FOR UPDATE TO authenticated
USING (public.has_role(auth.uid(), 'admin') OR EXISTS (
  SELECT 1 FROM public.profiles p WHERE p.user_id = auth.uid()
    AND p.display_role IN ('President','VicePresident','Teacher','GeneralSecretary')
));

CREATE POLICY "Users delete own pending bookings, staff delete any" ON public.tutoring_bookings
FOR DELETE TO authenticated
USING ((user_id = auth.uid() AND status = 'pending') OR public.has_role(auth.uid(), 'admin') OR EXISTS (
  SELECT 1 FROM public.profiles p WHERE p.user_id = auth.uid()
    AND p.display_role IN ('President','VicePresident','Teacher','GeneralSecretary')
));

CREATE TRIGGER update_tutoring_bookings_updated_at
BEFORE UPDATE ON public.tutoring_bookings
FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();