DROP POLICY IF EXISTS "Users can create notifications" ON public.notifications;
DROP POLICY IF EXISTS "Authenticated users can create notifications" ON public.notifications;
DROP POLICY IF EXISTS "Users can insert notifications" ON public.notifications;

CREATE POLICY "Users can create legitimate notifications"
ON public.notifications
FOR INSERT
TO authenticated
WITH CHECK (
  actor_id = auth.uid()
  AND user_id <> auth.uid()
  AND (
    (post_id IS NOT NULL AND EXISTS (
      SELECT 1 FROM public.posts p WHERE p.id = notifications.post_id AND p.author_id = notifications.user_id
    ))
    OR
    (post_id IS NULL AND EXISTS (
      SELECT 1 FROM public.follows f WHERE f.follower_id = auth.uid() AND f.following_id = notifications.user_id
    ))
  )
);