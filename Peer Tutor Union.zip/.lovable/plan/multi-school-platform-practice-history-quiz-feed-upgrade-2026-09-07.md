# Multi-school platform, Practice History, Quiz & Feed upgrade

This is a large build. I'll do it in four phases so each part can be checked as it lands. The Practice module (upload, untimed/timed modes, question bank) already exists — the work below extends it.

## Phase 1 — Schools, clubs and roles

**Data**
- School registry: country, region/state, city, school name, active flag.
- Clubs belong to a school.
- Club memberships link a person to a club with a role (President, Vice President, Teacher, Member) and an approval state.
- Every existing account is moved into 贵阳市第一中学 with its current role intact.
- ria7883@outlook.com becomes Super Admin with access everywhere.

**Screens**
- Sign-up gains cascading pickers: Country → Region → City → School. Only schools already in the registry can be chosen; a note tells people to contact the Super Admin if theirs is missing. After the school is chosen they can request to join one or more of its clubs.
- Super Admin area: school list → clubs of a school → that club's members, roles, question bank and quizzes. Add / rename / deactivate schools, and appoint or remove President and Vice President for any club.
- President / Vice President can appoint President and Vice President inside their own club and approve join requests.

## Phase 2 — Knowledge points and question visibility

- Knowledge-point categories nested under each subject, added by President / Vice President only, duplicates inside a subject rejected.
- Subjects also become club-owned, duplicates rejected.
- Every question gains a knowledge point and a Public / Private setting. Public is visible everywhere; Private only to the uploader's club. Visibility is set by President / Vice President.
- Question upload form, question bank filters and the practice filter panel all gain subject → knowledge point → difficulty → type → visibility, with a live count of matching questions before starting.

## Phase 3 — Practice History

New History tab under Practice:
- Four summary cards: questions attempted, overall accuracy, average time per question, wrong-question book count.
- Weakness insights: knowledge points under 60% accuracy ranked worst-first, top 3 strongest (5+ questions), and an accuracy-by-subject bar chart when more than one subject has been attempted.
- Filter bar: subject, knowledge point, difficulty, type, result (correct / incorrect / partially correct / unscored), date range with Today / 7 days / 30 days / custom, and a wrong-book-only toggle.
- List rows: 80-character stem preview, subject / knowledge point / difficulty / type tags, result icon, your answer vs correct answer for multiple choice, score or "Pending" for free response, time spent, date, bookmark icon.
- Detail view: full question and stimulus as shown during practice, the answer given, correct answer and explanation, grader score / feedback / date for free response, plus Add-or-remove from wrong-question book, Redo this question, and Practice similar questions.
- Wrong-question book: per-person and private, "Practice All Wrong Questions" starts an untimed session, and answering a bookmarked question correctly prompts "Remove from Wrong-Question Book?".
- Time spent per question is recorded during practice runs (needed for the stats above).

## Phase 4 — Quiz and Feed

- Quiz: remove the separate quiz upload path; papers are assembled purely by picking questions from the Practice bank with the same filters, drag-to-reorder, section labels, time limit and passing score. Taking a quiz reads the live question from the bank, so edits show up. Free-response answers go to the same manual grading queue.
- Feed: cascading scope filter (Global → Country → Region → City → School), defaulting to the viewer's own city, with a "Viewing: …" label and instant refresh. Each post shows its origin tags Country → Region → City → School. Private club posts stay hidden from non-members at every scope; Super Admin sees everything.

## Notes

- Existing styling, navigation and all other modules stay as they are.
- Grading of free response stays with President / Vice President / Teacher; members can only take and review.
