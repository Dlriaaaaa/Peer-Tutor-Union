---
name: Glassmorphism macOS Design
description: Global glassmorphism/macOS style - frosted glass cards, blur, subtle shadows, Outfit headings + Figtree body, dark red palette
type: design
---
- All cards use bg-card/72 backdrop-blur-xl with subtle border/shadow
- Primary color: HSL 350 75% 50% (rich dark red)
- Background: HSL 40 24% 96% (light cream/off-white)
- Font: Outfit for headings, Figtree for body, fallback to SF Pro Display
- Inputs/selects: bg-card/50 backdrop-blur-sm, border-border/60
- Dialogs: bg-card/80 backdrop-blur-2xl rounded-2xl
- Buttons: active:scale-[0.97] with shadow-primary/25
- Tables: subtle border-border/30, uppercase tracking-wider headers
- Scrollbar: macOS-thin 8px with rounded thumb
- Border radius: 0.75rem default (rounded-xl)
- CSS variables: --glass-bg, --glass-border, --glass-shadow
