# Project Memory

## Core
Peer Tutor Club (PTC) - student tutoring and study groups platform.
macOS glassmorphism UI, Outfit headings + Figtree body, primary dark red (#c92a3d → HSL 350 75% 50%).
Lovable Cloud for auth, DB, storage. Admin-only member creation + self-registration with approval.
TipTap for rich text editor. Role-based: admin/student.
react-easy-crop for avatar upload. Realtime chat with Supabase.
New users must be approved by admin before accessing platform (is_approved on profiles).

## Memories
- [DB Schema](mem://features/db-schema) — All tables, RLS policies, role system
- [Pages](mem://features/pages) — Dashboard, Resources, Grades, Members, Profile, Admin, Chat, Contacts, Events
- [Quiz System](mem://features/quiz) — Quiz with MC/multi-select/fill-blank, timer, real-time save, retake control, results publishing, motivation badges
- [Glassmorphism Design](mem://design/glassmorphism) — Global frosted glass style, macOS-inspired components, blur/shadow tokens
- [Practice & Question Bank](mem://features/question-bank) — Shared subjects, MCQ/FRQ upload, practice modes, AP timed test, quiz paper assembly

