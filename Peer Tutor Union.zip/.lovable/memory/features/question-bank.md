---
name: Practice & Question Bank
description: Shared question bank (MCQ + College Board FRQ), Practice module modes, quiz paper assembly, subject rules
type: feature
---

# Practice & Question Bank

- Shared `subjects` table is the single source of truth for Practice and Quiz. Only President/VicePresident (or admin) may add subjects; duplicate names (case-insensitive) rejected.
- Question authoring (President / VicePresident / Teacher / admin): `questions` (mcq | frq) with subject, 1–3 star difficulty, stem, stimulus text and/or attached file (PDF/image/DOCX ≤ 20MB in `attachments` bucket under `question-bank/`), MCQ options A–D + correct option + explanation; FRQ sub-parts in `question_parts` (label, prompt, points, sample answer).
- Practice module (`/practice`, run at `/practice/:sessionId`): untimed (pause, reveal answer/sample per question) and timed AP-style test with per-section timers (Section I MCQ, Section II FRQ), navigator grid, flags, no return after section submit, auto-submit at zero, result screen.
- MCQ auto-scored; FRQ graded manually in `/admin/question-bank` → FRQ grading tab (points + feedback added to session score).
- Quiz upgrade: `/admin/quizzes` has Paper assembly (select bank questions, drag-reorder, section labels, time limit, passing score → `quiz_paper_questions`) plus Question bank tab. Original quiz builder retained.
- LaTeX via `$…$` rendered by MathText (react-markdown + KaTeX); FRQ answers use TipTap rich text.
