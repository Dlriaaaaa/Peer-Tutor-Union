import { useState, useRef } from "react";
import { useSignedUrl } from "@/hooks/useSignedUrl";
import {
  FolderOpen, Folder, FileText, ChevronRight, ChevronDown, Download, File, Eye,
} from "lucide-react";
import { cn } from "@/lib/utils";

export type ResourceItem = {
  id: string; title: string; file_url: string; file_name: string;
  category: string; sort_order?: number;
};
export type FolderItem = {
  id: string; name: string; sort_order: number; parent_id: string | null; color: string;
};

const colorMap: Record<string, { open: string; closed: string }> = {
  blue:   { open: "text-blue-500",   closed: "text-blue-500/70" },
  red:    { open: "text-red-500",    closed: "text-red-500/70" },
  green:  { open: "text-green-500",  closed: "text-green-500/70" },
  yellow: { open: "text-yellow-500", closed: "text-yellow-500/70" },
  purple: { open: "text-purple-500", closed: "text-purple-500/70" },
  pink:   { open: "text-pink-500",   closed: "text-pink-500/70" },
  orange: { open: "text-orange-500", closed: "text-orange-500/70" },
  teal:   { open: "text-teal-500",   closed: "text-teal-500/70" },
  gray:   { open: "text-gray-500",   closed: "text-gray-500/70" },
};

export const buildPath = (folder: FolderItem, all: FolderItem[]): string => {
  const parts: string[] = [folder.name];
  let cur = folder;
  while (cur.parent_id) {
    const p = all.find(f => f.id === cur.parent_id);
    if (!p) break;
    parts.unshift(p.name);
    cur = p;
  }
  return parts.join(" / ");
};

function getFileIcon(fileName: string) {
  const ext = fileName.split(".").pop()?.toLowerCase();
  if (ext === "pdf") return <FileText className="h-4 w-4 text-red-500 shrink-0" />;
  if (["doc", "docx"].includes(ext || "")) return <FileText className="h-4 w-4 text-blue-500 shrink-0" />;
  if (["xls", "xlsx"].includes(ext || "")) return <FileText className="h-4 w-4 text-green-600 shrink-0" />;
  if (["ppt", "pptx"].includes(ext || "")) return <FileText className="h-4 w-4 text-orange-500 shrink-0" />;
  if (["png", "jpg", "jpeg", "gif", "webp"].includes(ext || "")) return <File className="h-4 w-4 text-purple-500 shrink-0" />;
  return <File className="h-4 w-4 text-muted-foreground shrink-0" />;
}

const getFileExt = (fileName: string) => fileName.split(".").pop()?.toUpperCase() || "FILE";

// Drag payload encoded in dataTransfer
type DragPayload =
  | { kind: "folder"; id: string }
  | { kind: "file"; id: string };

const DRAG_MIME = "application/x-resource-item";

interface FileRowProps {
  resource: ResourceItem;
  depth: number;
  draggable: boolean;
  onPreview: () => void;
  dropTarget: string | null;
  setDropTarget: (id: string | null) => void;
  onItemDrop: (target: { kind: "file" | "folder"; id: string } | { kind: "root" }, payload: DragPayload | null, files: FileList | null) => void;
}

function FileRow({ resource, depth, draggable, onPreview, dropTarget, setDropTarget, onItemDrop }: FileRowProps) {
  const signedUrl = useSignedUrl(resource.file_url);
  const isOver = dropTarget === `file:${resource.id}`;

  return (
    <div
      draggable={draggable}
      onDragStart={(e) => {
        if (!draggable) return;
        const payload: DragPayload = { kind: "file", id: resource.id };
        e.dataTransfer.setData(DRAG_MIME, JSON.stringify(payload));
        e.dataTransfer.effectAllowed = "move";
      }}
      onDragOver={(e) => {
        if (!draggable) return;
        // accept reorder OR external file
        const hasInternal = e.dataTransfer.types.includes(DRAG_MIME);
        const hasFiles = e.dataTransfer.types.includes("Files");
        if (!hasInternal && !hasFiles) return;
        e.preventDefault();
        e.dataTransfer.dropEffect = hasFiles ? "copy" : "move";
        setDropTarget(`file:${resource.id}`);
      }}
      onDragLeave={() => setDropTarget(null)}
      onDrop={(e) => {
        if (!draggable) return;
        e.preventDefault();
        e.stopPropagation();
        setDropTarget(null);
        const raw = e.dataTransfer.getData(DRAG_MIME);
        const payload = raw ? (JSON.parse(raw) as DragPayload) : null;
        onItemDrop({ kind: "file", id: resource.id }, payload, e.dataTransfer.files);
      }}
      className={cn(
        "flex items-center gap-2.5 py-2 pr-3 rounded-lg transition-colors hover:bg-muted/50 group",
        isOver && "bg-primary/10 ring-1 ring-primary/40",
        draggable && "cursor-grab active:cursor-grabbing"
      )}
      style={{ paddingLeft: `${depth * 20 + 36}px` }}
    >
      <button onClick={onPreview} className="flex items-center gap-2.5 flex-1 min-w-0 text-left">
        {getFileIcon(resource.file_name)}
        <span className="text-sm text-primary hover:underline truncate">{resource.title}</span>
        <span className="text-[11px] text-muted-foreground shrink-0 ml-1">{getFileExt(resource.file_name)}</span>
      </button>
      <button onClick={onPreview} className="opacity-0 group-hover:opacity-100 transition-opacity p-1 rounded hover:bg-muted shrink-0" title="Preview">
        <Eye className="h-3.5 w-3.5 text-muted-foreground" />
      </button>
      {signedUrl && (
        <a
          href={signedUrl}
          download={resource.file_name}
          target="_blank"
          rel="noopener noreferrer"
          onClick={(e) => e.stopPropagation()}
          className="opacity-0 group-hover:opacity-100 transition-opacity p-1 rounded hover:bg-muted shrink-0"
          title="Download"
        >
          <Download className="h-3.5 w-3.5 text-muted-foreground" />
        </a>
      )}
    </div>
  );
}

interface ResourceTreeProps {
  folders: FolderItem[];
  resources: ResourceItem[];
  search: string;
  expanded: Set<string>;
  toggleExpand: (id: string) => void;
  onPreview: (r: ResourceItem) => void;
  draggable?: boolean;
  /**
   * Called when something is dropped onto a target.
   * - target.kind = 'folder': dropped onto a folder body (move into folder)
   * - target.kind = 'file': dropped onto a file row (reorder before/after that row, same parent of file)
   * - target.kind = 'root': dropped on empty area (move to root)
   * - payload: internal drag source (file or folder being moved/reordered)
   * - files: external files dropped from the OS
   */
  onDropAction?: (
    target: { kind: "file" | "folder"; id: string } | { kind: "root" },
    payload: DragPayload | null,
    files: FileList | null
  ) => void;
}

export default function ResourceTree({
  folders, resources, search, expanded, toggleExpand, onPreview,
  draggable = false, onDropAction,
}: ResourceTreeProps) {
  const [dropTarget, setDropTarget] = useState<string | null>(null);
  const rootRef = useRef<HTMLDivElement>(null);

  const filtered = resources.filter((r) =>
    r.title.toLowerCase().includes(search.toLowerCase())
  );

  // When searching, force-expand all folders that contain matches
  const searchExpanded = (() => {
    if (!search) return expanded;
    const set = new Set<string>();
    const matchedPaths = new Set(filtered.map(r => r.category));
    folders.forEach(f => {
      const path = buildPath(f, folders);
      const hasMatch = [...matchedPaths].some(mp => mp === path || mp.startsWith(path + " / "));
      if (hasMatch) {
        set.add(f.id);
        let cur: FolderItem | undefined = f;
        while (cur?.parent_id) {
          set.add(cur.parent_id);
          cur = folders.find(x => x.id === cur!.parent_id);
        }
      }
    });
    return set;
  })();

  const handleItemDrop = (
    target: { kind: "file" | "folder"; id: string } | { kind: "root" },
    payload: DragPayload | null,
    files: FileList | null
  ) => {
    onDropAction?.(target, payload, files);
  };

  const renderTree = (parentId: string | null, depth: number = 0): JSX.Element[] => {
    const children = folders
      .filter(f => f.parent_id === parentId)
      .sort((a, b) => a.sort_order - b.sort_order);
    return children.flatMap(f => {
      const path = buildPath(f, folders);
      const folderFiles = filtered
        .filter(r => r.category === path)
        .sort((a, b) => (a.sort_order ?? 0) - (b.sort_order ?? 0));
      const subFolders = folders.filter(c => c.parent_id === f.id);
      if (search) {
        const hasAnyMatch = filtered.some(r => r.category === path || r.category.startsWith(path + " / "));
        if (!hasAnyMatch) return [];
      }
      const isOpen = searchExpanded.has(f.id);
      const colors = colorMap[f.color] || colorMap.blue;
      const isOver = dropTarget === `folder:${f.id}`;

      const rows: JSX.Element[] = [
        <div
          key={f.id}
          draggable={draggable}
          onDragStart={(e) => {
            if (!draggable) return;
            const payload: DragPayload = { kind: "folder", id: f.id };
            e.dataTransfer.setData(DRAG_MIME, JSON.stringify(payload));
            e.dataTransfer.effectAllowed = "move";
          }}
          onDragOver={(e) => {
            if (!draggable) return;
            const hasInternal = e.dataTransfer.types.includes(DRAG_MIME);
            const hasFiles = e.dataTransfer.types.includes("Files");
            if (!hasInternal && !hasFiles) return;
            e.preventDefault();
            e.dataTransfer.dropEffect = hasFiles ? "copy" : "move";
            setDropTarget(`folder:${f.id}`);
          }}
          onDragLeave={() => setDropTarget(null)}
          onDrop={(e) => {
            if (!draggable) return;
            e.preventDefault();
            e.stopPropagation();
            setDropTarget(null);
            const raw = e.dataTransfer.getData(DRAG_MIME);
            const payload = raw ? (JSON.parse(raw) as DragPayload) : null;
            handleItemDrop({ kind: "folder", id: f.id }, payload, e.dataTransfer.files);
          }}
          className={cn(
            "transition-colors rounded-lg",
            isOver && "bg-primary/10 ring-1 ring-primary/40",
            draggable && "cursor-grab active:cursor-grabbing"
          )}
        >
          <button
            onClick={() => toggleExpand(f.id)}
            className="w-full flex items-center gap-2 py-2.5 pr-3 rounded-lg text-left hover:bg-muted/60"
            style={{ paddingLeft: `${depth * 20 + 8}px` }}
          >
            <span className="text-muted-foreground">
              {isOpen ? <ChevronDown className="h-4 w-4" /> : <ChevronRight className="h-4 w-4" />}
            </span>
            {isOpen
              ? <FolderOpen className={cn("h-5 w-5 shrink-0", colors.open)} />
              : <Folder className={cn("h-5 w-5 shrink-0", colors.closed)} />}
            <span className="text-sm font-medium text-primary">{f.name}</span>
            {(folderFiles.length > 0 || subFolders.length > 0) && (
              <span className="text-[11px] text-muted-foreground ml-1">
                {folderFiles.length > 0 && `${folderFiles.length} files`}
                {folderFiles.length > 0 && subFolders.length > 0 && " · "}
                {subFolders.length > 0 && `${subFolders.length} folders`}
              </span>
            )}
          </button>
        </div>
      ];
      if (isOpen) {
        rows.push(...renderTree(f.id, depth + 1));
        folderFiles.forEach(res => {
          rows.push(
            <FileRow
              key={res.id}
              resource={res}
              depth={depth}
              draggable={draggable}
              onPreview={() => onPreview(res)}
              dropTarget={dropTarget}
              setDropTarget={setDropTarget}
              onItemDrop={handleItemDrop}
            />
          );
        });
      }
      return rows;
    });
  };

  return (
    <div
      ref={rootRef}
      onDragOver={(e) => {
        if (!draggable) return;
        const hasInternal = e.dataTransfer.types.includes(DRAG_MIME);
        const hasFiles = e.dataTransfer.types.includes("Files");
        if (!hasInternal && !hasFiles) return;
        e.preventDefault();
        e.dataTransfer.dropEffect = hasFiles ? "copy" : "move";
      }}
      onDrop={(e) => {
        if (!draggable) return;
        e.preventDefault();
        const raw = e.dataTransfer.getData(DRAG_MIME);
        const payload = raw ? (JSON.parse(raw) as DragPayload) : null;
        handleItemDrop({ kind: "root" }, payload, e.dataTransfer.files);
      }}
    >
      {renderTree(null)}
    </div>
  );
}
