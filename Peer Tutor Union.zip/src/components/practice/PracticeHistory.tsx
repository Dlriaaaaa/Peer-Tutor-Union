import { useCallback, useEffect, useMemo, useState } from "react";
import { useNavigate } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent } from "@/components/ui/card";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Progress } from "@/components/ui/progress";
import { toast } from "sonner";
import { Bookmark, BookmarkCheck, CheckCircle2, RotateCcw, XCircle, Clock, Target, ListChecks, BookOpen } from "lucide-react";
import { useAuth } from "@/contexts/AuthContext";
import MathText from "@/components/questions/MathText";
import StimulusPanel from "@/components/questions/StimulusPanel";
import DifficultyStars from "@/components/questions/DifficultyStars";
import AttachmentPreview from "@/components/questions/AttachmentPreview";
import {
  fetchKnowledgePoints,
  fetchParts,
  fetchSubjects,
  KnowledgePoint,
  Question,
  QuestionPart,
  questionOptions,
  Subject,
} from "@/lib/questionBank";

type AnswerRow = {
  id: string;
  session_id: string;
  question_id: string;
  part_id: string | null;
  selected_option: string | null;
  text_answer: string | null;
  is_correct: boolean | null;
  points_awarded: number | null;
  feedback: string | null;
  time_spent_seconds: number | null;
  created_at: string;
};

export default function PracticeHistory({ refreshKey = 0 }: { refreshKey?: number }) {
  const { user } = useAuth();
  const navigate = useNavigate();

  const [answers, setAnswers] = useState<AnswerRow[]>([]);
  const [questions, setQuestions] = useState<Record<string, Question>>({});
  const [parts, setParts] = useState<Record<string, QuestionPart[]>>({});
  const [subjects, setSubjects] = useState<Subject[]>([]);
  const [points, setPoints] = useState<KnowledgePoint[]>([]);
  const [wrongBook, setWrongBook] = useState<string[]>([]);
  const [loading, setLoading] = useState(true);
  const [detail, setDetail] = useState<AnswerRow | null>(null);

  const [fSubject, setFSubject] = useState("all");
  const [fPoint, setFPoint] = useState("all");
  const [fDiff, setFDiff] = useState("all");
  const [fType, setFType] = useState("all");
  const [fResult, setFResult] = useState("all");
  const [fFrom, setFFrom] = useState("");
  const [fTo, setFTo] = useState("");
  const [onlyWrongBook, setOnlyWrongBook] = useState(false);

  const loadWrongBook = useCallback(async () => {
    if (!user) return;
    const { data } = await supabase.from("wrong_questions").select("question_id").eq("user_id", user.id);
    setWrongBook((data || []).map((r: any) => r.question_id));
  }, [user]);

  useEffect(() => {
    fetchSubjects().then(setSubjects);
    fetchKnowledgePoints().then(setPoints);
  }, []);

  useEffect(() => {
    const load = async () => {
      if (!user) return;
      setLoading(true);
      const { data } = await supabase
        .from("practice_answers")
        .select("id, session_id, question_id, part_id, selected_option, text_answer, is_correct, points_awarded, feedback, time_spent_seconds, created_at")
        .eq("user_id", user.id)
        .order("created_at", { ascending: false })
        .limit(500);
      const rows = (data as AnswerRow[]) || [];
      setAnswers(rows);
      const ids = [...new Set(rows.map((r) => r.question_id))];
      if (ids.length) {
        const { data: qs } = await supabase.from("questions").select("*").in("id", ids);
        setQuestions(Object.fromEntries(((qs as Question[]) || []).map((q) => [q.id, q])));
        setParts(await fetchParts(ids));
      }
      await loadWrongBook();
      setLoading(false);
    };
    load();
  }, [user, refreshKey, loadWrongBook]);

  const subjectName = useMemo(() => Object.fromEntries(subjects.map((s) => [s.id, s.name])), [subjects]);
  const pointName = useMemo(() => Object.fromEntries(points.map((p) => [p.id, p.name])), [points]);
  const pointsOfSubject = useMemo(
    () => (fSubject === "all" ? points : points.filter((p) => p.subject_id === fSubject)),
    [points, fSubject]
  );

  // Only the top-level row per question (part rows are shown inside the detail view)
  const baseRows = useMemo(() => answers.filter((a) => !a.part_id), [answers]);

  const filtered = useMemo(() => {
    return baseRows.filter((a) => {
      const q = questions[a.question_id];
      if (!q) return false;
      if (fSubject !== "all" && q.subject_id !== fSubject) return false;
      if (fPoint !== "all" && q.knowledge_point_id !== fPoint) return false;
      if (fDiff !== "all" && q.difficulty !== Number(fDiff)) return false;
      if (fType !== "all" && q.question_type !== fType) return false;
      if (fResult === "correct" && a.is_correct !== true) return false;
      if (fResult === "wrong" && a.is_correct !== false) return false;
      if (fResult === "pending" && a.is_correct !== null) return false;
      if (fFrom && new Date(a.created_at) < new Date(fFrom)) return false;
      if (fTo && new Date(a.created_at) > new Date(`${fTo}T23:59:59`)) return false;
      if (onlyWrongBook && !wrongBook.includes(a.question_id)) return false;
      return true;
    });
  }, [baseRows, questions, fSubject, fPoint, fDiff, fType, fResult, fFrom, fTo, onlyWrongBook, wrongBook]);

  const stats = useMemo(() => {
    const graded = baseRows.filter((a) => a.is_correct !== null);
    const correct = graded.filter((a) => a.is_correct).length;
    const times = baseRows.map((a) => a.time_spent_seconds || 0).filter((t) => t > 0);
    return {
      attempted: baseRows.length,
      accuracy: graded.length ? Math.round((correct / graded.length) * 100) : 0,
      avgTime: times.length ? Math.round(times.reduce((s, t) => s + t, 0) / times.length) : 0,
      wrongCount: wrongBook.length,
    };
  }, [baseRows, wrongBook]);

  /** Accuracy per knowledge point and per subject, used for the weakness insights. */
  const insights = useMemo(() => {
    const byPoint: Record<string, { total: number; correct: number }> = {};
    const bySubject: Record<string, { total: number; correct: number }> = {};
    baseRows.forEach((a) => {
      const q = questions[a.question_id];
      if (!q || a.is_correct === null) return;
      const kp = q.knowledge_point_id;
      if (kp) {
        byPoint[kp] ||= { total: 0, correct: 0 };
        byPoint[kp].total++;
        if (a.is_correct) byPoint[kp].correct++;
      }
      bySubject[q.subject_id] ||= { total: 0, correct: 0 };
      bySubject[q.subject_id].total++;
      if (a.is_correct) bySubject[q.subject_id].correct++;
    });
    const pointList = Object.entries(byPoint)
      .filter(([, v]) => v.total >= 2)
      .map(([id, v]) => ({ id, name: pointName[id] || "—", pct: Math.round((v.correct / v.total) * 100), total: v.total }));
    return {
      weakest: [...pointList].sort((a, b) => a.pct - b.pct).slice(0, 5),
      strongest: [...pointList].sort((a, b) => b.pct - a.pct).slice(0, 3),
      subjects: Object.entries(bySubject).map(([id, v]) => ({
        id,
        name: subjectName[id] || "—",
        pct: Math.round((v.correct / v.total) * 100),
        total: v.total,
      })),
    };
  }, [baseRows, questions, pointName, subjectName]);

  const toggleWrongBook = async (questionId: string) => {
    if (!user) return;
    if (wrongBook.includes(questionId)) {
      await supabase.from("wrong_questions").delete().eq("user_id", user.id).eq("question_id", questionId);
      setWrongBook((w) => w.filter((x) => x !== questionId));
      toast.success("Removed from your wrong-question book");
    } else {
      await supabase.from("wrong_questions").insert({ user_id: user.id, question_id: questionId });
      setWrongBook((w) => [...w, questionId]);
      toast.success("Added to your wrong-question book");
    }
  };

  const startSession = async (questionIds: string[], title: string) => {
    if (!user || questionIds.length === 0) { toast.error("No questions to practise"); return; }
    const { data, error } = await supabase
      .from("practice_sessions")
      .insert({
        user_id: user.id,
        mode: "untimed",
        title,
        question_ids: questionIds,
        section_seconds: {},
      })
      .select("id")
      .single();
    if (error) { toast.error(error.message); return; }
    navigate(`/practice/${data.id}`);
  };

  const practiceSimilar = async (q: Question) => {
    let query = supabase.from("questions").select("id").eq("subject_id", q.subject_id).neq("id", q.id).limit(10);
    if (q.knowledge_point_id) query = query.eq("knowledge_point_id", q.knowledge_point_id);
    const { data } = await query;
    const ids = (data || []).map((r: any) => r.id);
    if (ids.length === 0) { toast.error("No similar questions available yet"); return; }
    startSession(ids, "Similar questions");
  };

  if (loading) return <p className="text-sm text-muted-foreground">Loading…</p>;

  const detailQuestion = detail ? questions[detail.question_id] : null;

  return (
    <div className="space-y-4">
      <div className="grid gap-3 sm:grid-cols-4">
        <Card className="glass-card"><CardContent className="p-4">
          <p className="flex items-center gap-2 text-xs text-muted-foreground"><ListChecks className="h-3.5 w-3.5" /> Questions attempted</p>
          <p className="text-2xl font-bold">{stats.attempted}</p>
        </CardContent></Card>
        <Card className="glass-card"><CardContent className="p-4">
          <p className="flex items-center gap-2 text-xs text-muted-foreground"><Target className="h-3.5 w-3.5" /> Accuracy</p>
          <p className="text-2xl font-bold">{stats.accuracy}%</p>
        </CardContent></Card>
        <Card className="glass-card"><CardContent className="p-4">
          <p className="flex items-center gap-2 text-xs text-muted-foreground"><Clock className="h-3.5 w-3.5" /> Average time</p>
          <p className="text-2xl font-bold">{stats.avgTime}s</p>
        </CardContent></Card>
        <Card className="glass-card"><CardContent className="p-4">
          <p className="flex items-center gap-2 text-xs text-muted-foreground"><BookOpen className="h-3.5 w-3.5" /> Wrong-question book</p>
          <p className="text-2xl font-bold">{stats.wrongCount}</p>
        </CardContent></Card>
      </div>

      <div className="flex flex-wrap items-center gap-2">
        <Button size="sm" className="gap-2" disabled={wrongBook.length === 0}
          onClick={() => startSession(wrongBook, "Wrong-question practice")}>
          <RotateCcw className="h-4 w-4" /> Practice all wrong questions
        </Button>
        <Button size="sm" variant={onlyWrongBook ? "secondary" : "outline"} onClick={() => setOnlyWrongBook((v) => !v)}>
          {onlyWrongBook ? "Showing wrong book only" : "Wrong book only"}
        </Button>
      </div>

      <div className="grid gap-2 sm:grid-cols-3 lg:grid-cols-6">
        <Select value={fSubject} onValueChange={(v) => { setFSubject(v); setFPoint("all"); }}>
          <SelectTrigger><SelectValue placeholder="Subject" /></SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All subjects</SelectItem>
            {subjects.map((s) => <SelectItem key={s.id} value={s.id}>{s.name}</SelectItem>)}
          </SelectContent>
        </Select>
        <Select value={fPoint} onValueChange={setFPoint}>
          <SelectTrigger><SelectValue placeholder="Knowledge point" /></SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All knowledge points</SelectItem>
            {pointsOfSubject.map((p) => <SelectItem key={p.id} value={p.id}>{p.name}</SelectItem>)}
          </SelectContent>
        </Select>
        <Select value={fDiff} onValueChange={setFDiff}>
          <SelectTrigger><SelectValue placeholder="Difficulty" /></SelectTrigger>
          <SelectContent>
            <SelectItem value="all">Any difficulty</SelectItem>
            <SelectItem value="1">★☆☆</SelectItem>
            <SelectItem value="2">★★☆</SelectItem>
            <SelectItem value="3">★★★</SelectItem>
          </SelectContent>
        </Select>
        <Select value={fType} onValueChange={setFType}>
          <SelectTrigger><SelectValue placeholder="Type" /></SelectTrigger>
          <SelectContent>
            <SelectItem value="all">MCQ + FRQ</SelectItem>
            <SelectItem value="mcq">MCQ</SelectItem>
            <SelectItem value="frq">FRQ</SelectItem>
          </SelectContent>
        </Select>
        <Select value={fResult} onValueChange={setFResult}>
          <SelectTrigger><SelectValue placeholder="Result" /></SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All results</SelectItem>
            <SelectItem value="correct">Correct</SelectItem>
            <SelectItem value="wrong">Incorrect</SelectItem>
            <SelectItem value="pending">Awaiting grading</SelectItem>
          </SelectContent>
        </Select>
        <div className="flex gap-1">
          <div className="flex-1">
            <Label className="text-[10px] text-muted-foreground">From</Label>
            <Input type="date" className="h-9" value={fFrom} onChange={(e) => setFFrom(e.target.value)} />
          </div>
          <div className="flex-1">
            <Label className="text-[10px] text-muted-foreground">To</Label>
            <Input type="date" className="h-9" value={fTo} onChange={(e) => setFTo(e.target.value)} />
          </div>
        </div>
      </div>

      {filtered.length === 0 && <p className="text-sm text-muted-foreground">No practice records match these filters.</p>}

      <div className="space-y-2">
        {filtered.map((a) => {
          const q = questions[a.question_id];
          const inBook = wrongBook.includes(a.question_id);
          return (
            <div key={a.id} className="rounded-xl border bg-muted/10 p-3">
              <div className="flex items-start gap-3">
                <div className="mt-1">
                  {a.is_correct === true && <CheckCircle2 className="h-4 w-4 text-emerald-500" />}
                  {a.is_correct === false && <XCircle className="h-4 w-4 text-destructive" />}
                  {a.is_correct === null && <Clock className="h-4 w-4 text-muted-foreground" />}
                </div>
                <div className="min-w-0 flex-1">
                  <div className="mb-1 flex flex-wrap items-center gap-2">
                    <Badge variant="outline" className="text-[10px]">{q.question_type.toUpperCase()}</Badge>
                    <Badge variant="secondary" className="text-[10px]">{subjectName[q.subject_id] || "—"}</Badge>
                    {q.knowledge_point_id && (
                      <Badge variant="outline" className="text-[10px]">{pointName[q.knowledge_point_id] || "—"}</Badge>
                    )}
                    <DifficultyStars level={q.difficulty} />
                    <span className="text-[11px] text-muted-foreground">
                      {new Date(a.created_at).toLocaleDateString()} · {a.time_spent_seconds || 0}s
                      {q.question_type === "frq" && ` · ${a.points_awarded ?? "pending"} pts`}
                    </span>
                  </div>
                  <div className="line-clamp-2"><MathText text={q.stem} /></div>
                </div>
                <div className="flex items-center gap-1">
                  <Button variant="ghost" size="icon" className="h-8 w-8" onClick={() => toggleWrongBook(a.question_id)}>
                    {inBook ? <BookmarkCheck className="h-4 w-4 text-primary" /> : <Bookmark className="h-4 w-4" />}
                  </Button>
                  <Button size="sm" variant="outline" onClick={() => setDetail(a)}>Details</Button>
                </div>
              </div>
            </div>
          );
        })}
      </div>

      {(insights.weakest.length > 0 || insights.subjects.length > 0) && (
        <div className="grid gap-4 md:grid-cols-2">
          <Card className="glass-card"><CardContent className="space-y-3 p-4">
            <p className="text-sm font-semibold">Weakest knowledge points</p>
            {insights.weakest.length === 0 && <p className="text-xs text-muted-foreground">Not enough data yet.</p>}
            {insights.weakest.map((w) => (
              <div key={w.id} className="space-y-1">
                <div className="flex justify-between text-xs"><span>{w.name}</span><span>{w.pct}% · {w.total} qs</span></div>
                <Progress value={w.pct} className="h-1.5" />
              </div>
            ))}
            {insights.strongest.length > 0 && (
              <p className="pt-2 text-xs text-muted-foreground">
                Strongest: {insights.strongest.map((s) => `${s.name} (${s.pct}%)`).join(", ")}
              </p>
            )}
          </CardContent></Card>
          <Card className="glass-card"><CardContent className="space-y-3 p-4">
            <p className="text-sm font-semibold">Accuracy by subject</p>
            {insights.subjects.map((s) => (
              <div key={s.id} className="space-y-1">
                <div className="flex justify-between text-xs"><span>{s.name}</span><span>{s.pct}% · {s.total} qs</span></div>
                <Progress value={s.pct} className="h-1.5" />
              </div>
            ))}
          </CardContent></Card>
        </div>
      )}

      <Dialog open={!!detail} onOpenChange={(v) => !v && setDetail(null)}>
        <DialogContent className="max-h-[90vh] max-w-3xl overflow-y-auto">
          <DialogHeader><DialogTitle>Question review</DialogTitle></DialogHeader>
          {detail && detailQuestion && (
            <div className="space-y-4">
              <div className="flex flex-wrap items-center gap-2 text-xs text-muted-foreground">
                <Badge variant="outline" className="text-[10px]">{detailQuestion.question_type.toUpperCase()}</Badge>
                <Badge variant="secondary" className="text-[10px]">{subjectName[detailQuestion.subject_id] || "—"}</Badge>
                {detailQuestion.knowledge_point_id && (
                  <Badge variant="outline" className="text-[10px]">{pointName[detailQuestion.knowledge_point_id]}</Badge>
                )}
                <DifficultyStars level={detailQuestion.difficulty} />
                <span>{new Date(detail.created_at).toLocaleString()} · {detail.time_spent_seconds || 0}s</span>
              </div>

              <StimulusPanel
                text={detailQuestion.stimulus_text}
                filePath={detailQuestion.stimulus_file_url}
                fileName={detailQuestion.stimulus_file_name}
                className="max-h-72"
              />
              {detailQuestion.title && <p className="font-semibold">{detailQuestion.title}</p>}
              <MathText text={detailQuestion.stem} />

              {detailQuestion.question_type === "mcq" ? (
                <div className="space-y-1 text-sm">
                  {questionOptions(detailQuestion).map(({ letter, text }) => {
                    const isRight = detailQuestion.correct_option === letter;
                    const chosen = detail.selected_option === letter;
                    return (
                      <div key={letter} className={isRight ? "font-semibold text-primary" : chosen ? "text-destructive" : "text-muted-foreground"}>
                        {letter}. {text}{isRight ? "  ✓ correct" : ""}{chosen && !isRight ? "  ← your answer" : ""}
                      </div>
                    );
                  })}
                </div>
              ) : (
                <div className="space-y-2">
                  {(parts[detailQuestion.id] || []).map((p) => {
                    const pa = answers.find((x) => x.question_id === detailQuestion.id && x.part_id === p.id);
                    return (
                      <div key={p.id} className="rounded-lg border bg-background/50 p-2 text-sm">
                        <p className="font-medium">{p.label} <span className="text-xs text-muted-foreground">({p.points} pts)</span></p>
                        <MathText text={p.prompt} />
                        <div className="prose prose-sm mt-1 max-w-none" dangerouslySetInnerHTML={{ __html: pa?.text_answer || "<em>No response</em>" }} />
                        <p className="mt-1 text-xs text-muted-foreground">
                          Score: {pa?.points_awarded ?? "pending"} / {p.points}{pa?.feedback ? ` · ${pa.feedback}` : ""}
                        </p>
                        {p.sample_answer && <p className="mt-1 text-xs text-muted-foreground">Guideline: {p.sample_answer}</p>}
                        <AttachmentPreview path={p.sample_answer_file_url} name={p.sample_answer_file_name} className="mt-2" />
                      </div>
                    );
                  })}
                  {(parts[detailQuestion.id] || []).length === 0 && (
                    <div className="rounded-lg border bg-background/50 p-2 text-sm">
                      <div className="prose prose-sm max-w-none" dangerouslySetInnerHTML={{ __html: detail.text_answer || "<em>No response</em>" }} />
                      <p className="mt-1 text-xs text-muted-foreground">
                        Score: {detail.points_awarded ?? "pending"} / {detailQuestion.max_points}
                        {detail.feedback ? ` · ${detail.feedback}` : ""}
                      </p>
                    </div>
                  )}
                </div>
              )}

              {(detailQuestion.explanation || detailQuestion.answer_file_url) && (
                <div className="rounded-lg border border-primary/30 bg-primary/5 p-3 text-sm space-y-2">
                  <p className="mb-1 text-xs font-semibold uppercase text-primary">Explanation</p>
                  <MathText text={detailQuestion.explanation} />
                  <AttachmentPreview path={detailQuestion.answer_file_url} name={detailQuestion.answer_file_name} />
                </div>
              )}

              <div className="flex flex-wrap gap-2">
                <Button size="sm" variant="outline" className="gap-2" onClick={() => toggleWrongBook(detailQuestion.id)}>
                  {wrongBook.includes(detailQuestion.id)
                    ? <><BookmarkCheck className="h-4 w-4" /> Remove from wrong book</>
                    : <><Bookmark className="h-4 w-4" /> Add to wrong book</>}
                </Button>
                <Button size="sm" className="gap-2" onClick={() => startSession([detailQuestion.id], "Redo question")}>
                  <RotateCcw className="h-4 w-4" /> Redo this question
                </Button>
                <Button size="sm" variant="outline" onClick={() => practiceSimilar(detailQuestion)}>
                  Practise similar questions
                </Button>
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}
