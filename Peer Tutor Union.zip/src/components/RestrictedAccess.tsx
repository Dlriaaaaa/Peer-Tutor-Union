import { Lock } from "lucide-react";
import { Card } from "@/components/ui/card";

export default function RestrictedAccess({ message }: { message?: string }) {
  return (
    <div className="min-h-[60vh] flex items-center justify-center p-6">
      <Card className="glass-card max-w-md w-full p-8 text-center space-y-3">
        <div className="mx-auto w-12 h-12 rounded-full bg-destructive/10 flex items-center justify-center">
          <Lock className="h-6 w-6 text-destructive" />
        </div>
        <h2 className="text-xl font-semibold text-foreground">Access Restricted</h2>
        <p className="text-sm text-muted-foreground">
          {message || "Your account does not have permission to use this feature. Please contact an administrator."}
        </p>
      </Card>
    </div>
  );
}
