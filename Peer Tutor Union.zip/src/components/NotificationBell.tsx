import { useState, useEffect, useCallback, useRef } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/contexts/AuthContext";
import { Bell, Heart, MessageCircle, UserPlus, Award } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { ScrollArea } from "@/components/ui/scroll-area";
import { formatDistanceToNow } from "date-fns";
import { useNavigate } from "react-router-dom";
import { CelebrityInfo, getVirtualLikes, getVirtualFollowers, formatCount } from "@/lib/celebrityUtils";

type Notification = {
  id: string;
  type: string;
  actor_id: string;
  post_id: string | null;
  comment_content: string | null;
  is_read: boolean;
  created_at: string;
};

type VirtualNotification = {
  id: string;
  type: "virtual_likes" | "virtual_followers";
  text: string;
  created_at: string;
  is_read: boolean;
};

type ProfileMap = Record<string, { name: string; avatar_url: string | null }>;

/** Stacked avatars component – shows 3 overlapping profile pics */
function StackedAvatars({ allProfiles }: { allProfiles: { name: string; avatar_url: string | null }[] }) {
  const picks = allProfiles.slice(0, 3);
  return (
    <div className="flex items-center shrink-0 mt-0.5" style={{ width: 44 }}>
      {picks.map((p, i) => (
        <Avatar
          key={i}
          className="h-7 w-7 border-2 border-background"
          style={{ marginLeft: i === 0 ? 0 : -10, zIndex: 3 - i }}
        >
          <AvatarImage src={p.avatar_url || undefined} />
          <AvatarFallback className="text-[9px]">{p.name?.charAt(0) || "?"}</AvatarFallback>
        </Avatar>
      ))}
    </div>
  );
}

export default function NotificationBell() {
  const { user } = useAuth();
  const navigate = useNavigate();
  const [notifications, setNotifications] = useState<Notification[]>([]);
  const [virtualNotifs, setVirtualNotifs] = useState<VirtualNotification[]>([]);
  const virtualNotifsLoaded = useRef(false);
  const [profiles, setProfiles] = useState<ProfileMap>({});
  const [allProfilesList, setAllProfilesList] = useState<{ name: string; avatar_url: string | null }[]>([]);
  const [unreadCount, setUnreadCount] = useState(0);
  const [open, setOpen] = useState(false);

  // Virtual growth tracking
  const prevLikes = useRef<number | null>(null);
  const prevFollowers = useRef<number | null>(null);
  const celebrityRef = useRef<CelebrityInfo | null>(null);
  const postsRef = useRef<{ id: string; created_at: string }[]>([]);

  // Load virtual notifs from localStorage on mount
  useEffect(() => {
    if (!user || virtualNotifsLoaded.current) return;
    virtualNotifsLoaded.current = true;
    try {
      const stored = localStorage.getItem(`vnotifs_${user.id}`);
      if (stored) {
        const parsed = JSON.parse(stored) as VirtualNotification[];
        setVirtualNotifs(parsed);
      }
      const storedLikes = localStorage.getItem(`vprev_likes_${user.id}`);
      const storedFollowers = localStorage.getItem(`vprev_followers_${user.id}`);
      if (storedLikes) prevLikes.current = Number(storedLikes);
      if (storedFollowers) prevFollowers.current = Number(storedFollowers);
    } catch {}
  }, [user]);

  // Persist virtual notifs to localStorage
  useEffect(() => {
    if (!user || !virtualNotifsLoaded.current) return;
    localStorage.setItem(`vnotifs_${user.id}`, JSON.stringify(virtualNotifs));
  }, [virtualNotifs, user]);

  const fetchNotifications = useCallback(async () => {
    if (!user) return;
    const { data } = await supabase
      .from("notifications")
      .select("*")
      .eq("user_id", user.id)
      .order("created_at", { ascending: false })
      .limit(30);
    const notifs = (data || []) as Notification[];
    setNotifications(notifs);
    setUnreadCount(notifs.filter((n) => !n.is_read).length);

    const actorIds = [...new Set(notifs.map((n) => n.actor_id))];
    if (actorIds.length > 0) {
      const { data: profs } = await supabase
        .from("profiles")
        .select("user_id, name, avatar_url")
        .in("user_id", actorIds);
      const map: ProfileMap = {};
      (profs || []).forEach((p) => { map[p.user_id] = { name: p.name, avatar_url: p.avatar_url }; });
      setProfiles(map);
    }
  }, [user]);

  useEffect(() => { fetchNotifications(); }, [fetchNotifications]);

  // Fetch all profiles for stacked avatars
  useEffect(() => {
    supabase.from("profiles").select("name, avatar_url").then(({ data }) => {
      if (data) {
        const shuffled = [...data].sort(() => 0.5 - Math.random());
        setAllProfilesList(shuffled);
      }
    });
  }, []);

  // Realtime subscription
  useEffect(() => {
    if (!user) return;
    const channel = supabase
      .channel("my-notifications")
      .on(
        "postgres_changes",
        { event: "INSERT", schema: "public", table: "notifications", filter: `user_id=eq.${user.id}` },
        () => { fetchNotifications(); }
      )
      .subscribe();
    return () => { supabase.removeChannel(channel); };
  }, [user, fetchNotifications]);

  // Helper to compute current totals
  const computeTotals = useCallback(() => {
    const cel = celebrityRef.current;
    if (!cel || !user) return null;
    const totalLikes = postsRef.current.reduce(
      (sum, p) => sum + getVirtualLikes(p.id, p.created_at, cel.likes_multiplier || 1, cel.likes_multiplier_changed_at), 0
    );
    const followers = getVirtualFollowers(user.id, cel.created_at, cel.follower_multiplier || 1, cel.follower_multiplier_changed_at, (cel as any).virtual_follower_seed || 0);
    return { totalLikes, followers };
  }, [user]);

  // Virtual growth notifications: 20s interval, persist, 50 items max
  useEffect(() => {
    if (!user?.id) return;
    let cancelled = false;

    const init = async () => {
      const [celRes, postsRes] = await Promise.all([
        supabase.from("celebrities").select("*").eq("user_id", user.id).maybeSingle(),
        supabase.from("posts").select("id, created_at").eq("author_id", user.id),
      ]);
      if (cancelled || !celRes.data) return;
      const cel = celRes.data as unknown as CelebrityInfo;
      celebrityRef.current = cel;
      postsRef.current = postsRes.data || [];

      const totals = computeTotals();
      if (!totals) return;

      // On first load (coming online), if we have previous values stored,
      // push the accumulated offline growth immediately
      if (prevLikes.current !== null && prevFollowers.current !== null) {
        const likeDiff = totals.totalLikes - prevLikes.current;
        const followerDiff = totals.followers - prevFollowers.current;
        const now = new Date().toISOString();
        const newNotifs: VirtualNotification[] = [];
        if (likeDiff > 0) {
          newNotifs.push({
            id: "vl-" + Date.now(),
            type: "virtual_likes" as const,
            text: `Liked by others and ${formatCount(likeDiff)} others`,
            created_at: now,
            is_read: false,
          });
        }
        if (followerDiff > 0) {
          newNotifs.push({
            id: "vf-" + Date.now(),
            type: "virtual_followers" as const,
            text: `${formatCount(followerDiff)} people followed you`,
            created_at: now,
            is_read: false,
          });
        }
        if (newNotifs.length > 0) {
          setVirtualNotifs(prev => [...newNotifs, ...prev].slice(0, 50));
        }
      }

      prevLikes.current = totals.totalLikes;
      prevFollowers.current = totals.followers;
      localStorage.setItem(`vprev_likes_${user.id}`, String(totals.totalLikes));
      localStorage.setItem(`vprev_followers_${user.id}`, String(totals.followers));
    };

    init();

    // Push every 20 seconds while online
    const timer = setInterval(() => {
      const totals = computeTotals();
      if (!totals) return;

      const now = new Date().toISOString();
      const newNotifs: VirtualNotification[] = [];

      if (prevLikes.current !== null) {
        const diff = totals.totalLikes - prevLikes.current;
        if (diff > 0) {
          newNotifs.push({
            id: "vl-" + Date.now(),
            type: "virtual_likes" as const,
            text: `Liked by others and ${formatCount(diff)} others`,
            created_at: now,
            is_read: false,
          });
        }
      }
      if (prevFollowers.current !== null) {
        const diff = totals.followers - prevFollowers.current;
        if (diff > 0) {
          newNotifs.push({
            id: "vf-" + Date.now(),
            type: "virtual_followers" as const,
            text: `${formatCount(diff)} people followed you`,
            created_at: now,
            is_read: false,
          });
        }
      }

      if (newNotifs.length > 0) {
        setVirtualNotifs(prev => [...newNotifs, ...prev].slice(0, 50));
      }

      prevLikes.current = totals.totalLikes;
      prevFollowers.current = totals.followers;
      localStorage.setItem(`vprev_likes_${user.id}`, String(totals.totalLikes));
      localStorage.setItem(`vprev_followers_${user.id}`, String(totals.followers));
    }, 20_000);

    return () => { cancelled = true; clearInterval(timer); };
  }, [user?.id, computeTotals]);

  const markAllRead = async () => {
    if (!user) return;
    // Mark real notifications read
    const unreadIds = notifications.filter((n) => !n.is_read).map((n) => n.id);
    if (unreadIds.length > 0) {
      await supabase.from("notifications").update({ is_read: true }).in("id", unreadIds);
      setNotifications((prev) => prev.map((n) => ({ ...n, is_read: true })));
    }
    // Mark virtual notifications read
    setVirtualNotifs(prev => prev.map(n => ({ ...n, is_read: true })));
    setUnreadCount(0);
  };

  const handleClick = (n: Notification) => {
    if (n.type === "follow") {
      navigate(`/profile/${n.actor_id}`);
    } else if (n.type === "award") {
      navigate("/profile");
    } else if (n.post_id) {
      setOpen(false);
    }
  };

  const getIcon = (type: string) => {
    switch (type) {
      case "like": return <Heart className="h-4 w-4 text-red-500 fill-red-500 shrink-0" />;
      case "comment": return <MessageCircle className="h-4 w-4 text-primary shrink-0" />;
      case "follow": return <UserPlus className="h-4 w-4 text-green-500 shrink-0" />;
      case "award": return <Award className="h-4 w-4 text-yellow-500 shrink-0" />;
      case "virtual_likes": return <Heart className="h-4 w-4 text-red-500 fill-red-500 shrink-0" />;
      case "virtual_followers": return <UserPlus className="h-4 w-4 text-green-500 shrink-0" />;
      default: return <Bell className="h-4 w-4 shrink-0" />;
    }
  };

  const getText = (n: Notification) => {
    const name = profiles[n.actor_id]?.name || "Someone";
    switch (n.type) {
      case "like": return <><span className="font-medium">{name}</span> liked your post</>;
      case "comment": return <><span className="font-medium">{name}</span> commented on your post{n.comment_content ? `: "${n.comment_content.slice(0, 30)}${n.comment_content.length > 30 ? "…" : ""}"` : ""}</>;
      case "follow": return <><span className="font-medium">{name}</span> followed you</>;
      case "award": return <><span className="font-medium">{name}</span> granted you an award 🏆</>;
      default: return <><span className="font-medium">{name}</span> sent you a notification</>;
    }
  };

  if (!user) return null;

  // Merge real + virtual notifications sorted by time
  type MergedItem =
    | { kind: "real"; data: Notification }
    | { kind: "virtual"; data: VirtualNotification };

  const merged: MergedItem[] = [
    ...notifications.map(n => ({ kind: "real" as const, data: n })),
    ...virtualNotifs.map(n => ({ kind: "virtual" as const, data: n })),
  ].sort((a, b) => new Date(b.data.created_at).getTime() - new Date(a.data.created_at).getTime());

  const virtualUnread = virtualNotifs.filter(n => !n.is_read).length;
  const totalUnread = unreadCount + virtualUnread;

  return (
    <Popover open={open} onOpenChange={(o) => {
      setOpen(o);
      if (o) markAllRead();
    }}>
      <PopoverTrigger asChild>
        <Button variant="ghost" size="icon" className="relative h-9 w-9">
          <Bell className="h-5 w-5" />
          {totalUnread > 0 && (
            <span className="absolute -top-0.5 -right-0.5 h-4 min-w-[16px] px-1 rounded-full bg-destructive text-destructive-foreground text-[10px] font-bold flex items-center justify-center">
              {totalUnread > 99 ? "99+" : totalUnread}
            </span>
          )}
        </Button>
      </PopoverTrigger>
      <PopoverContent className="w-80 p-0" align="end">
        <div className="flex items-center justify-between px-4 py-3 border-b border-border">
          <h4 className="text-sm font-semibold">Notifications</h4>
        </div>
        <ScrollArea className="h-80">
          {merged.length === 0 ? (
            <div className="py-8 text-center text-sm text-muted-foreground">No notifications</div>
          ) : (
            <div className="divide-y divide-border">
              {merged.map((item) => {
                if (item.kind === "virtual") {
                  const v = item.data;
                  return (
                    <div
                      key={v.id}
                      className={`w-full flex items-center gap-3 px-4 py-3 ${!v.is_read ? "bg-primary/5" : ""}`}
                    >
                      <StackedAvatars allProfiles={allProfilesList} />
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center gap-1.5">
                          {getIcon(v.type)}
                          <p className="text-sm leading-snug font-medium">{v.text}</p>
                        </div>
                        <p className="text-[10px] text-muted-foreground mt-0.5">
                          {formatDistanceToNow(new Date(v.created_at), { addSuffix: true })}
                        </p>
                      </div>
                    </div>
                  );
                }
                const n = item.data;
                return (
                  <button
                    key={n.id}
                    onClick={() => handleClick(n)}
                    className={`w-full flex items-start gap-3 px-4 py-3 text-left hover:bg-muted/50 transition-colors ${!n.is_read ? "bg-primary/5" : ""}`}
                  >
                    <Avatar className="h-8 w-8 shrink-0 mt-0.5">
                      <AvatarImage src={profiles[n.actor_id]?.avatar_url || undefined} />
                      <AvatarFallback className="text-xs">{profiles[n.actor_id]?.name?.charAt(0) || "?"}</AvatarFallback>
                    </Avatar>
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-1.5">
                        {getIcon(n.type)}
                        <p className="text-sm leading-snug">{getText(n)}</p>
                      </div>
                      <p className="text-[10px] text-muted-foreground mt-0.5">
                        {formatDistanceToNow(new Date(n.created_at), { addSuffix: true })}
                      </p>
                    </div>
                  </button>
                );
              })}
            </div>
          )}
        </ScrollArea>
      </PopoverContent>
    </Popover>
  );
}
