import { useSignedUrl } from "@/hooks/useSignedUrl";
import { FileDown } from "lucide-react";

/** Inline preview for an uploaded image / PDF / document stored in the attachments bucket. */
export default function AttachmentPreview({
  path,
  name,
  className = "",
}: {
  path?: string | null;
  name?: string | null;
  className?: string;
}) {
  const url = useSignedUrl(path || undefined);
  if (!path || !url) return null;
  const isImage = /\.(png|jpe?g|webp|gif)$/i.test(path);
  const isPdf = /\.pdf$/i.test(path);
  if (isImage) return <img src={url} alt={name || "Attachment"} className={`w-full max-w-xl rounded-lg border ${className}`} />;
  if (isPdf) return <iframe src={url} title={name || "Attachment"} className={`w-full h-[50vh] rounded-lg border bg-background ${className}`} />;
  return (
    <a href={url} target="_blank" rel="noreferrer" className="inline-flex items-center gap-2 text-sm text-primary underline">
      <FileDown className="h-4 w-4" /> {name || "Download attachment"}
    </a>
  );
}
