import { useEffect, useMemo, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Checkbox } from "@/components/ui/checkbox";
import { Trash2, ChevronDown, ChevronRight, Pencil } from "lucide-react";
import QuestionUploadDialog from "./QuestionUploadDialog";
import { toast } from "sonner";
import DifficultyStars from "./DifficultyStars";
import MathText from "./MathText";
import StimulusPanel from "./StimulusPanel";
import AttachmentPreview from "./AttachmentPreview";
import { fetchKnowledgePoints, fetchParts, fetchQuestions, fetchSubjects, KnowledgePoint, Question, QuestionPart, questionOptions, Subject } from "@/lib/questionBank";
import { useAuth } from "@/contexts/AuthContext";
import { canAuthorQuestions } from "@/lib/questionBank";

export default function QuestionBankBrowser({
  refreshKey = 0,
  selectable = false,
  selectedIds = [],
  onToggleSelect,
}: {
  refreshKey?: number;
  selectable?: boolean;
  selectedIds?: string[];
  onToggleSelect?: (q: Question) => void;
}) {
  const { displayRole, isAdmin, clubRole } = useAuth();
  const canEdit = canAuthorQuestions(displayRole, isAdmin, clubRole || undefined);
  const [subjects, setSubjects] = useState<Subject[]>([]);
  const [creators, setCreators] = useState<{ user_id: string; name: string }[]>([]);
  const [questions, setQuestions] = useState<Question[]>([]);
  const [parts, setParts] = useState<Record<string, QuestionPart[]>>({});
  const [knowledgePoints, setKnowledgePoints] = useState<KnowledgePoint[]>([]);
  const [expanded, setExpanded] = useState<string | null>(null);
  const [editing, setEditing] = useState<Question | null>(null);
  const [fSubject, setFSubject] = useState("all");
  const [fPoint, setFPoint] = useState("all");
  const [fDiff, setFDiff] = useState("all");
  const [fType, setFType] = useState("all");
  const [fCreator, setFCreator] = useState("all");
  const [fVis, setFVis] = useState("all");
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchSubjects().then(setSubjects);
    supabase.from("profiles").select("user_id, name").then(({ data }) => setCreators(data || []));
  }, []);

  useEffect(() => {
    setFPoint("all");
    fetchKnowledgePoints(fSubject === "all" ? undefined : fSubject).then(setKnowledgePoints);
  }, [fSubject]);

  const load = async () => {
    setLoading(true);
    const qs = await fetchQuestions({
      subjectId: fSubject !== "all" ? fSubject : undefined,
      knowledgePointId: fPoint !== "all" ? fPoint : undefined,
      difficulty: fDiff !== "all" ? Number(fDiff) : undefined,
      type: fType !== "all" ? (fType as "mcq" | "frq") : undefined,
      creatorId: fCreator !== "all" ? fCreator : undefined,
      visibility: fVis !== "all" ? (fVis as "public" | "private") : undefined,
    });
    setQuestions(qs);
    setParts(await fetchParts(qs.map((q) => q.id)));
    setLoading(false);
  };

  useEffect(() => { load(); /* eslint-disable-next-line */ }, [fSubject, fPoint, fDiff, fType, fCreator, fVis, refreshKey]);

  const subjectName = useMemo(() => Object.fromEntries(subjects.map((s) => [s.id, s.name])), [subjects]);
  const creatorName = useMemo(() => Object.fromEntries(creators.map((c) => [c.user_id, c.name])), [creators]);

  const remove = async (id: string) => {
    const { error } = await supabase.from("questions").delete().eq("id", id);
    if (error) { toast.error(error.message); return; }
    toast.success("Question deleted");
    load();
  };

  return (
    <div className="space-y-4">
      <div className="grid gap-2 sm:grid-cols-3 lg:grid-cols-6">
        <Select value={fSubject} onValueChange={setFSubject}>
          <SelectTrigger><SelectValue placeholder="Subject" /></SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All subjects</SelectItem>
            {subjects.map((s) => <SelectItem key={s.id} value={s.id}>{s.name}</SelectItem>)}
          </SelectContent>
        </Select>
        <Select value={fPoint} onValueChange={setFPoint}>
          <SelectTrigger><SelectValue placeholder="Knowledge point" /></SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All knowledge points</SelectItem>
            {knowledgePoints.map((k) => <SelectItem key={k.id} value={k.id}>{k.name}</SelectItem>)}
          </SelectContent>
        </Select>
        <Select value={fDiff} onValueChange={setFDiff}>
          <SelectTrigger><SelectValue placeholder="Difficulty" /></SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All difficulties</SelectItem>
            <SelectItem value="1">★☆☆</SelectItem>
            <SelectItem value="2">★★☆</SelectItem>
            <SelectItem value="3">★★★</SelectItem>
          </SelectContent>
        </Select>
        <Select value={fType} onValueChange={setFType}>
          <SelectTrigger><SelectValue placeholder="Type" /></SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All types</SelectItem>
            <SelectItem value="mcq">MCQ</SelectItem>
            <SelectItem value="frq">FRQ</SelectItem>
          </SelectContent>
        </Select>
        <Select value={fCreator} onValueChange={setFCreator}>
          <SelectTrigger><SelectValue placeholder="Creator" /></SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All creators</SelectItem>
            {creators.map((c) => <SelectItem key={c.user_id} value={c.user_id}>{c.name}</SelectItem>)}
          </SelectContent>
        </Select>
        <Select value={fVis} onValueChange={setFVis}>
          <SelectTrigger><SelectValue placeholder="Visibility" /></SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All visibility</SelectItem>
            <SelectItem value="public">Public</SelectItem>
            <SelectItem value="private">Private</SelectItem>
          </SelectContent>
        </Select>
      </div>


      {loading && <p className="text-sm text-muted-foreground">Loading…</p>}
      {!loading && questions.length === 0 && <p className="text-sm text-muted-foreground">No questions match these filters.</p>}

      <div className="space-y-2">
        {questions.map((q) => {
          const open = expanded === q.id;
          return (
            <div key={q.id} className="rounded-xl border bg-muted/10 p-3">
              <div className="flex items-start gap-3">
                {selectable && (
                  <Checkbox checked={selectedIds.includes(q.id)} onCheckedChange={() => onToggleSelect?.(q)} className="mt-1" />
                )}
                <button className="mt-0.5 text-muted-foreground" onClick={() => setExpanded(open ? null : q.id)}>
                  {open ? <ChevronDown className="h-4 w-4" /> : <ChevronRight className="h-4 w-4" />}
                </button>
                <div className="flex-1 min-w-0">
                  <div className="flex flex-wrap items-center gap-2 mb-1">
                    <Badge variant="outline" className="text-[10px]">{q.question_type.toUpperCase()}</Badge>
                    <Badge variant="secondary" className="text-[10px]">{subjectName[q.subject_id] || "—"}</Badge>
                    <Badge variant="outline" className="text-[10px]">{q.visibility === "public" ? "Public" : "Private"}</Badge>
                    <DifficultyStars level={q.difficulty} />
                    <span className="text-[11px] text-muted-foreground">
                      {q.max_points} pt{Number(q.max_points) > 1 ? "s" : ""} · {creatorName[q.created_by] || "Unknown"}
                    </span>
                  </div>
                  {q.title && <p className="text-sm font-semibold">{q.title}</p>}
                  <div className="line-clamp-2"><MathText text={q.stem} /></div>
                </div>
                {canEdit && (
                  <div className="flex items-center">
                    <Button variant="ghost" size="icon" className="h-8 w-8" onClick={() => setEditing(q)}>
                      <Pencil className="h-4 w-4" />
                    </Button>
                    <Button variant="ghost" size="icon" className="h-8 w-8" onClick={() => remove(q.id)}>
                      <Trash2 className="h-4 w-4 text-destructive" />
                    </Button>
                  </div>
                )}
              </div>

              {open && (
                <div className="mt-3 space-y-3 pl-7">
                  <StimulusPanel text={q.stimulus_text} filePath={q.stimulus_file_url} fileName={q.stimulus_file_name} className="max-h-80" />
                  {q.question_type === "mcq" ? (
                    <div className="space-y-1 text-sm">
                      {questionOptions(q).map(({ letter, text }) => {
                        const isRight = q.correct_option === letter;
                        return (
                          <div key={letter} className={isRight ? "font-semibold text-primary" : "text-muted-foreground"}>
                            {letter}. {text}{isRight ? "  ✓" : ""}
                          </div>
                        );
                      })}
                    </div>
                  ) : (
                    <div className="space-y-2">
                      {(parts[q.id] || []).map((p) => (
                        <div key={p.id} className="rounded-lg border bg-background/50 p-2 text-sm">
                          <p className="font-medium">{p.label} <span className="text-xs text-muted-foreground">({p.points} pts)</span></p>
                          <MathText text={p.prompt} />
                          {p.sample_answer && <p className="mt-1 text-xs text-muted-foreground">Guideline: {p.sample_answer}</p>}
                          <AttachmentPreview path={p.sample_answer_file_url} name={p.sample_answer_file_name} className="mt-2" />
                        </div>
                      ))}
                    </div>
                  )}
                  {(q.explanation || q.answer_file_url) && (
                    <div className="rounded-lg border border-primary/30 bg-primary/5 p-2 text-sm space-y-2">
                      <p className="text-xs font-semibold uppercase text-primary mb-1">Explanation</p>
                      <MathText text={q.explanation} />
                      <AttachmentPreview path={q.answer_file_url} name={q.answer_file_name} />
                    </div>
                  )}
                </div>
              )}
            </div>
          );
        })}
      </div>

      <QuestionUploadDialog
        open={!!editing}
        onOpenChange={(v) => { if (!v) setEditing(null); }}
        question={editing}
        onSaved={() => { setEditing(null); load(); }}
      />
    </div>
  );
}
