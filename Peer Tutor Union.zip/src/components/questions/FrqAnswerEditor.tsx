import { useEditor, EditorContent } from "@tiptap/react";
import StarterKit from "@tiptap/starter-kit";
import { Bold, Italic, List, ListOrdered, Sigma } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useEffect } from "react";

/** Rich-text answer box for free response: bold / italic / lists + LaTeX insert. */
export default function FrqAnswerEditor({
  value,
  onChange,
  placeholder = "Type your response…",
  minHeight = 160,
}: {
  value: string;
  onChange: (html: string) => void;
  placeholder?: string;
  minHeight?: number;
}) {
  const editor = useEditor({
    extensions: [StarterKit],
    content: value || "",
    onUpdate: ({ editor }) => onChange(editor.getHTML()),
    editorProps: {
      attributes: {
        class: "prose prose-sm max-w-none focus:outline-none px-3 py-2",
        style: `min-height:${minHeight}px`,
      },
    },
  });

  useEffect(() => {
    if (editor && !editor.isFocused && value !== editor.getHTML()) {
      editor.commands.setContent(value || "", { emitUpdate: false });
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [value]);

  if (!editor) return null;

  return (
    <div className="rounded-xl border bg-background/60 backdrop-blur">
      <div className="flex items-center gap-1 border-b px-2 py-1">
        <Button type="button" size="icon" variant={editor.isActive("bold") ? "secondary" : "ghost"} className="h-7 w-7"
          onClick={() => editor.chain().focus().toggleBold().run()}><Bold className="h-3.5 w-3.5" /></Button>
        <Button type="button" size="icon" variant={editor.isActive("italic") ? "secondary" : "ghost"} className="h-7 w-7"
          onClick={() => editor.chain().focus().toggleItalic().run()}><Italic className="h-3.5 w-3.5" /></Button>
        <Button type="button" size="icon" variant={editor.isActive("bulletList") ? "secondary" : "ghost"} className="h-7 w-7"
          onClick={() => editor.chain().focus().toggleBulletList().run()}><List className="h-3.5 w-3.5" /></Button>
        <Button type="button" size="icon" variant={editor.isActive("orderedList") ? "secondary" : "ghost"} className="h-7 w-7"
          onClick={() => editor.chain().focus().toggleOrderedList().run()}><ListOrdered className="h-3.5 w-3.5" /></Button>
        <Button type="button" size="sm" variant="ghost" className="h-7 gap-1 text-xs"
          onClick={() => editor.chain().focus().insertContent("$x^2$").run()}>
          <Sigma className="h-3.5 w-3.5" /> LaTeX
        </Button>
        <span className="ml-auto text-[11px] text-muted-foreground pr-1">Use $…$ for math</span>
      </div>
      <EditorContent editor={editor} data-placeholder={placeholder} />
    </div>
  );
}
