import { useEffect, useState } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { toast } from "sonner";
import { Plus, Trash2, Star, Paperclip, X } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/contexts/AuthContext";
import {
  canManageSubjects,
  fetchKnowledgePoints,
  fetchParts,
  fetchSubjects,
  KnowledgePoint,
  OPTION_LETTERS,
  Question,
  questionOptions,
  Subject,
  uploadQuestionFile,
} from "@/lib/questionBank";
import { cn } from "@/lib/utils";

type PartDraft = {
  label: string;
  prompt: string;
  points: string;
  sample_answer: string;
  file: File | null;
  existingPath?: string | null;
  existingName?: string | null;
};

function FilePicker({
  file,
  onPick,
  label,
  existingName,
  onClearExisting,
}: {
  file: File | null;
  onPick: (f: File | null) => void;
  label: string;
  existingName?: string | null;
  onClearExisting?: () => void;
}) {
  return (
    <div className="flex flex-wrap items-center gap-2">
      <label className="cursor-pointer inline-flex items-center gap-2 rounded-lg border px-3 py-1.5 text-sm hover:bg-accent">
        <Paperclip className="h-4 w-4" /> {label}
        <input type="file" className="hidden" accept=".pdf,.png,.jpg,.jpeg,.webp,.gif,.doc,.docx"
          onChange={(e) => onPick(e.target.files?.[0] || null)} />
      </label>
      {file ? (
        <span className="inline-flex items-center gap-1 text-sm text-muted-foreground">
          {file.name}
          <button type="button" onClick={() => onPick(null)}><X className="h-3 w-3" /></button>
        </span>
      ) : existingName ? (
        <span className="inline-flex items-center gap-1 text-sm text-muted-foreground">
          {existingName}
          {onClearExisting && (
            <button type="button" onClick={onClearExisting}><X className="h-3 w-3" /></button>
          )}
        </span>
      ) : null}
    </div>
  );
}

export default function QuestionUploadDialog({
  open,
  onOpenChange,
  onSaved,
  question,
}: {
  open: boolean;
  onOpenChange: (v: boolean) => void;
  onSaved?: () => void;
  question?: Question | null;
}) {
  const { user, displayRole, isAdmin, clubRole, activeClubId } = useAuth();
  const canSetVisibility = canManageSubjects(displayRole, isAdmin, clubRole || undefined);
  const editing = !!question;
  const [subjects, setSubjects] = useState<Subject[]>([]);
  const [subjectId, setSubjectId] = useState("");
  const [knowledgePoints, setKnowledgePoints] = useState<KnowledgePoint[]>([]);
  const [knowledgePointId, setKnowledgePointId] = useState("");
  const [visibility, setVisibility] = useState<"public" | "private">("private");
  const [difficulty, setDifficulty] = useState(1);
  const [type, setType] = useState<"mcq" | "frq">("mcq");
  const [title, setTitle] = useState("");
  const [stem, setStem] = useState("");
  const [stimulusText, setStimulusText] = useState("");
  const [file, setFile] = useState<File | null>(null);
  const [stimPath, setStimPath] = useState<string | null>(null);
  const [stimName, setStimName] = useState<string | null>(null);
  const [options, setOptions] = useState<string[]>(["", "", "", ""]);
  const [correctIndex, setCorrectIndex] = useState<number | null>(null);
  const [explanation, setExplanation] = useState("");
  const [answerFile, setAnswerFile] = useState<File | null>(null);
  const [ansPath, setAnsPath] = useState<string | null>(null);
  const [ansName, setAnsName] = useState<string | null>(null);
  const [points, setPoints] = useState("1");
  const [parts, setParts] = useState<PartDraft[]>([]);
  const [saving, setSaving] = useState(false);

  useEffect(() => { if (open) fetchSubjects().then(setSubjects); }, [open]);

  useEffect(() => {
    if (!subjectId) { setKnowledgePoints([]); return; }
    fetchKnowledgePoints(subjectId).then(setKnowledgePoints);
  }, [subjectId]);

  const reset = () => {
    setSubjectId(""); setKnowledgePointId(""); setVisibility("private");
    setDifficulty(1); setType("mcq"); setTitle(""); setStem(""); setStimulusText("");
    setFile(null); setStimPath(null); setStimName(null);
    setOptions(["", "", "", ""]); setCorrectIndex(null); setExplanation("");
    setAnswerFile(null); setAnsPath(null); setAnsName(null); setPoints("1"); setParts([]);
  };

  // Prefill when editing an existing question
  useEffect(() => {
    if (!open) return;
    if (!question) { reset(); return; }
    setSubjectId(question.subject_id);
    setKnowledgePointId(question.knowledge_point_id || "");
    setVisibility((question.visibility as "public" | "private") || "private");
    setDifficulty(question.difficulty || 1);
    setType(question.question_type);
    setTitle(question.title || "");
    setStem(question.stem || "");
    setStimulusText(question.stimulus_text || "");
    setFile(null);
    setStimPath(question.stimulus_file_url || null);
    setStimName(question.stimulus_file_name || null);
    setExplanation(question.explanation || "");
    setAnswerFile(null);
    setAnsPath(question.answer_file_url || null);
    setAnsName(question.answer_file_name || null);
    setPoints(String(question.max_points ?? 1));

    const opts = questionOptions(question);
    if (question.question_type === "mcq") {
      const list = opts.length > 0 ? opts.map((o) => o.text) : ["", "", "", ""];
      setOptions(list);
      const idx = OPTION_LETTERS.indexOf((question.correct_option || "") as any);
      setCorrectIndex(idx >= 0 ? idx : null);
    } else {
      setOptions(["", "", "", ""]);
      setCorrectIndex(null);
    }

    fetchParts([question.id]).then((map) => {
      const rows = map[question.id] || [];
      setParts(rows.map((p) => ({
        label: p.label || "",
        prompt: p.prompt || "",
        points: String(p.points ?? 1),
        sample_answer: p.sample_answer || "",
        file: null,
        existingPath: p.sample_answer_file_url || null,
        existingName: p.sample_answer_file_name || null,
      })));
    });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [open, question?.id]);

  const validate = (): string | null => {
    if (!subjectId) return "Select a subject";
    if (type === "mcq" && correctIndex === null) return "Select the correct answer";
    return null;
  };

  const save = async () => {
    if (!user) return;
    const err = validate();
    if (err) { toast.error(err); return; }
    setSaving(true);

    const upload = async (f: File | null) => {
      if (!f) return { path: null as string | null, error: null as string | null };
      const res = await uploadQuestionFile(f);
      return { path: res.path || null, error: res.error || null };
    };

    const stim = await upload(file);
    if (stim.error) { toast.error(stim.error); setSaving(false); return; }
    const ans = await upload(answerFile);
    if (ans.error) { toast.error(ans.error); setSaving(false); return; }

    const typed = options.map((o) => o.trim()).filter(Boolean);
    const cleanOptions = typed.length > 0 ? typed : options.map(() => "");
    let correctLetter: string | null = null;
    if (type === "mcq" && correctIndex !== null) {
      if (typed.length === 0) {
        correctLetter = OPTION_LETTERS[correctIndex] || null;
      } else {
        const kept = options.map((o, i) => ({ o: o.trim(), i })).filter((x) => x.o);
        const pos = kept.findIndex((x) => x.i === correctIndex);
        correctLetter = pos >= 0 ? OPTION_LETTERS[pos] : OPTION_LETTERS[correctIndex] || null;
      }
    }

    const totalPoints = type === "frq" && parts.length > 0
      ? parts.reduce((s, p) => s + (Number(p.points) || 0), 0)
      : Number(points) || 1;

    const payload: any = {
      subject_id: subjectId,
      knowledge_point_id: knowledgePointId || null,
      visibility: canSetVisibility ? visibility : "private",
      difficulty,
      question_type: type,
      title: title.trim() || null,
      stem: stem.trim() || null,
      stimulus_text: stimulusText.trim() || null,
      stimulus_file_url: file ? stim.path : stimPath,
      stimulus_file_name: file ? file.name : stimName,
      options: type === "mcq" ? cleanOptions : null,
      option_a: null, option_b: null, option_c: null, option_d: null,
      correct_option: correctLetter,
      explanation: explanation.trim() || null,
      answer_file_url: answerFile ? ans.path : ansPath,
      answer_file_name: answerFile ? answerFile.name : ansName,
      max_points: totalPoints,
    };

    let questionId = question?.id || "";

    if (editing) {
      const { error } = await supabase.from("questions").update(payload).eq("id", questionId);
      if (error) { toast.error(error.message); setSaving(false); return; }
      await supabase.from("question_parts").delete().eq("question_id", questionId);
    } else {
      const { data, error } = await supabase.from("questions").insert({
        ...payload,
        club_id: activeClubId,
        created_by: user.id,
      }).select("id").single();
      if (error) { toast.error(error.message); setSaving(false); return; }
      questionId = data.id;
    }

    if (type === "frq" && parts.length > 0) {
      const rows = [];
      for (let i = 0; i < parts.length; i++) {
        const p = parts[i];
        const pf = await upload(p.file);
        if (pf.error) { toast.error(pf.error); setSaving(false); return; }
        rows.push({
          question_id: questionId,
          label: p.label.trim() || `(${String.fromCharCode(97 + i)})`,
          prompt: p.prompt.trim() || null,
          points: Number(p.points) || 1,
          sample_answer: p.sample_answer.trim() || null,
          sample_answer_file_url: p.file ? pf.path : p.existingPath ?? null,
          sample_answer_file_name: p.file ? p.file.name : p.existingName ?? null,
          sort_order: i,
        });
      }
      const { error: pErr } = await supabase.from("question_parts").insert(rows as any);
      if (pErr) { toast.error(pErr.message); setSaving(false); return; }
    }

    setSaving(false);
    toast.success(editing ? "Question updated" : "Question added to the bank");
    reset();
    onOpenChange(false);
    onSaved?.();
  };

  const setOption = (i: number, v: string) => setOptions(options.map((o, j) => (j === i ? v : o)));
  const removeOption = (i: number) => {
    setOptions(options.filter((_, j) => j !== i));
    if (correctIndex === i) setCorrectIndex(null);
    else if (correctIndex !== null && correctIndex > i) setCorrectIndex(correctIndex - 1);
  };

  return (
    <Dialog open={open} onOpenChange={(v) => { onOpenChange(v); if (!v) reset(); }}>
      <DialogContent className="max-w-3xl max-h-[90vh] overflow-y-auto">
        <DialogHeader><DialogTitle>{editing ? "Edit question" : "Upload question"}</DialogTitle></DialogHeader>

        <div className="grid gap-4 md:grid-cols-3">
          <div>
            <Label className="text-xs">Subject *</Label>
            <Select value={subjectId} onValueChange={setSubjectId}>
              <SelectTrigger><SelectValue placeholder="Select subject" /></SelectTrigger>
              <SelectContent>
                {subjects.map((s) => <SelectItem key={s.id} value={s.id}>{s.name}</SelectItem>)}
              </SelectContent>
            </Select>
          </div>
          <div>
            <Label className="text-xs">Difficulty *</Label>
            <div className="flex items-center gap-1 h-10">
              {[1, 2, 3].map((i) => (
                <button key={i} type="button" onClick={() => setDifficulty(i)}>
                  <Star className={cn("h-6 w-6", i <= difficulty ? "fill-amber-400 text-amber-400" : "text-muted-foreground/40")} />
                </button>
              ))}
            </div>
          </div>
          <div>
            <Label className="text-xs">Question type *</Label>
            <Select value={type} onValueChange={(v) => setType(v as "mcq" | "frq")}>
              <SelectTrigger><SelectValue /></SelectTrigger>
              <SelectContent>
                <SelectItem value="mcq">Multiple Choice (MCQ)</SelectItem>
                <SelectItem value="frq">Free Response (FRQ)</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </div>

        <div className="grid gap-4 md:grid-cols-2">
          <div>
            <Label className="text-xs">Knowledge point</Label>
            <Select value={knowledgePointId} onValueChange={setKnowledgePointId} disabled={!subjectId}>
              <SelectTrigger><SelectValue placeholder={subjectId ? "Select knowledge point" : "Select a subject first"} /></SelectTrigger>
              <SelectContent>
                {knowledgePoints.map((k) => <SelectItem key={k.id} value={k.id}>{k.name}</SelectItem>)}
              </SelectContent>
            </Select>
          </div>
          <div>
            <Label className="text-xs">Visibility</Label>
            <Select value={visibility} onValueChange={(v) => setVisibility(v as "public" | "private")} disabled={!canSetVisibility}>
              <SelectTrigger><SelectValue /></SelectTrigger>
              <SelectContent>
                <SelectItem value="private">Private — only this club</SelectItem>
                <SelectItem value="public">Public — every club</SelectItem>
              </SelectContent>
            </Select>
            {!canSetVisibility && (
              <p className="mt-1 text-[11px] text-muted-foreground">Only the President / Vice President can publish questions.</p>
            )}
          </div>
        </div>

        <div>
          <Label className="text-xs">Question title (optional)</Label>
          <Input value={title} onChange={(e) => setTitle(e.target.value)} placeholder="e.g. 2019 FRQ #3 — Circular motion" />
        </div>

        <div>
          <Label className="text-xs">Question stem (optional — supports LaTeX with $…$)</Label>
          <Textarea value={stem} onChange={(e) => setStem(e.target.value)} rows={3}
            placeholder="Leave blank if the question is fully contained in the uploaded image" />
        </div>

        <div className="rounded-xl border bg-muted/20 p-3 space-y-3">
          <p className="text-xs font-semibold uppercase tracking-wide text-muted-foreground">Question image / stimulus material (optional)</p>
          <Textarea value={stimulusText} onChange={(e) => setStimulusText(e.target.value)} rows={4}
            placeholder="Reading passage, data table, documents… (LaTeX and markdown tables supported)" />
          <FilePicker file={file} onPick={setFile} existingName={stimName}
            onClearExisting={() => { setStimPath(null); setStimName(null); }}
            label="Attach image or file (PDF / image / DOCX, max 20MB)" />
          <p className="text-[11px] text-muted-foreground">
            For subjects with complex notation you can upload one image containing the question and all its options.
          </p>
        </div>

        {type === "mcq" ? (
          <div className="space-y-2">
            {options.map((val, i) => (
              <div key={i} className="flex items-center gap-2">
                <button type="button" onClick={() => setCorrectIndex(i)}
                  className={cn("h-7 w-7 shrink-0 rounded-full border-2 text-xs font-semibold",
                    correctIndex === i ? "border-primary bg-primary text-primary-foreground" : "border-muted-foreground/40")}>
                  {OPTION_LETTERS[i]}
                </button>
                <Input value={val} onChange={(e) => setOption(i, e.target.value)} placeholder={`Option ${OPTION_LETTERS[i]}`} />
                <Button type="button" variant="ghost" size="icon" disabled={options.length <= 2} onClick={() => removeOption(i)}>
                  <Trash2 className="h-4 w-4 text-destructive" />
                </Button>
              </div>
            ))}
            <div className="flex items-center gap-3">
              <Button type="button" size="sm" variant="outline" disabled={options.length >= OPTION_LETTERS.length}
                onClick={() => setOptions([...options, ""])}>
                <Plus className="h-4 w-4 mr-1" /> Add option
              </Button>
              <p className="text-xs text-muted-foreground">2–6 options. Click a letter to mark the correct answer.</p>
            </div>
            <div className="w-32">
              <Label className="text-xs">Points</Label>
              <Input type="number" min="1" value={points} onChange={(e) => setPoints(e.target.value)} />
            </div>
          </div>
        ) : (
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <p className="text-sm font-medium">Sub-parts (a), (b), (c) — optional</p>
              <Button type="button" size="sm" variant="outline"
                onClick={() => setParts([...parts, { label: `(${String.fromCharCode(97 + parts.length)})`, prompt: "", points: "1", sample_answer: "", file: null }])}>
                <Plus className="h-4 w-4 mr-1" /> Add part
              </Button>
            </div>
            {parts.map((p, i) => (
              <div key={i} className="rounded-xl border bg-muted/20 p-3 space-y-2">
                <div className="flex items-center gap-2">
                  <Input className="w-20" value={p.label} onChange={(e) => setParts(parts.map((x, j) => j === i ? { ...x, label: e.target.value } : x))} />
                  <Input className="w-24" type="number" min="0" value={p.points}
                    onChange={(e) => setParts(parts.map((x, j) => j === i ? { ...x, points: e.target.value } : x))} placeholder="Points" />
                  <Button type="button" variant="ghost" size="icon" className="ml-auto" onClick={() => setParts(parts.filter((_, j) => j !== i))}>
                    <Trash2 className="h-4 w-4 text-destructive" />
                  </Button>
                </div>
                <Textarea rows={2} value={p.prompt} placeholder="Part prompt (optional)"
                  onChange={(e) => setParts(parts.map((x, j) => j === i ? { ...x, prompt: e.target.value } : x))} />
                <Textarea rows={2} value={p.sample_answer} placeholder="Sample answer / scoring guideline (optional)"
                  onChange={(e) => setParts(parts.map((x, j) => j === i ? { ...x, sample_answer: e.target.value } : x))} />
                <FilePicker file={p.file} onPick={(f) => setParts(parts.map((x, j) => j === i ? { ...x, file: f } : x))}
                  existingName={p.existingName}
                  onClearExisting={() => setParts(parts.map((x, j) => j === i ? { ...x, existingPath: null, existingName: null } : x))}
                  label="Attach sample answer image / file" />
              </div>
            ))}
            {parts.length === 0 && (
              <div className="w-32">
                <Label className="text-xs">Points</Label>
                <Input type="number" min="1" value={points} onChange={(e) => setPoints(e.target.value)} />
              </div>
            )}
          </div>
        )}

        <div className="space-y-2">
          <Label className="text-xs">
            {type === "mcq" ? "Explanation / rationale (optional)" : "Sample answer / explanation (optional)"}
          </Label>
          <Textarea value={explanation} onChange={(e) => setExplanation(e.target.value)} rows={3}
            placeholder="Students see this after they submit their answer" />
          <FilePicker file={answerFile} onPick={setAnswerFile} existingName={ansName}
            onClearExisting={() => { setAnsPath(null); setAnsName(null); }}
            label="Attach sample answer image / file" />
        </div>

        <div className="flex justify-end gap-2">
          <Button variant="ghost" onClick={() => onOpenChange(false)}>Cancel</Button>
          <Button onClick={save} disabled={saving}>{saving ? "Saving…" : editing ? "Save changes" : "Save question"}</Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}
