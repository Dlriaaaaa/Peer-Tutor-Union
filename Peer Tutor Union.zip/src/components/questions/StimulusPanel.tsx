import { useSignedUrl } from "@/hooks/useSignedUrl";
import MathText from "./MathText";
import { FileDown } from "lucide-react";

function StimulusFile({ path, name }: { path: string; name?: string | null }) {
  const url = useSignedUrl(path);
  if (!url) return null;
  const isImage = /\.(png|jpe?g|webp|gif)$/i.test(path);
  const isPdf = /\.pdf$/i.test(path);
  if (isImage) return <img src={url} alt={name || "Stimulus"} className="w-full rounded-lg border" />;
  if (isPdf) return <iframe src={url} title={name || "Stimulus"} className="w-full h-[60vh] rounded-lg border bg-background" />;
  return (
    <a href={url} target="_blank" rel="noreferrer" className="inline-flex items-center gap-2 text-sm text-primary underline">
      <FileDown className="h-4 w-4" /> {name || "Download stimulus"}
    </a>
  );
}

export default function StimulusPanel({
  text,
  filePath,
  fileName,
  className = "",
}: {
  text?: string | null;
  filePath?: string | null;
  fileName?: string | null;
  className?: string;
}) {
  if (!text && !filePath) return null;
  return (
    <div className={`glass-card rounded-xl border p-4 space-y-3 overflow-y-auto ${className}`}>
      <p className="text-xs font-semibold uppercase tracking-wide text-muted-foreground">Stimulus</p>
      {text && <MathText text={text} />}
      {filePath && <StimulusFile path={filePath} name={fileName} />}
    </div>
  );
}
