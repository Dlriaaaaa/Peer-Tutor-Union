import { useEffect, useState } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { toast } from "sonner";
import { Plus, BookPlus, ChevronRight, ChevronDown, ArrowUp, ArrowDown, Pencil, Trash2, Check, X } from "lucide-react";
import {
  addKnowledgePoint,
  addSubject,
  deleteKnowledgePoint,
  fetchKnowledgePoints,
  fetchSubjects,
  KnowledgePoint,
  renameKnowledgePoint,
  reorderKnowledgePoints,
  Subject,
} from "@/lib/questionBank";
import { useAuth } from "@/contexts/AuthContext";

export default function SubjectManagerDialog({ onChanged }: { onChanged?: () => void }) {
  const { user, activeClubId } = useAuth();
  const [open, setOpen] = useState(false);
  const [subjects, setSubjects] = useState<Subject[]>([]);
  const [points, setPoints] = useState<Record<string, KnowledgePoint[]>>({});
  const [expanded, setExpanded] = useState<string | null>(null);
  const [name, setName] = useState("");
  const [kpDraft, setKpDraft] = useState<Record<string, string>>({});
  const [saving, setSaving] = useState(false);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [editingName, setEditingName] = useState("");

  const saveRename = async (id: string) => {
    const { error } = await renameKnowledgePoint(id, editingName);
    if (error) { toast.error(error); return; }
    setEditingId(null);
    toast.success("Knowledge point updated");
    load();
    onChanged?.();
  };

  const removePoint = async (k: KnowledgePoint) => {
    if (!confirm(`Delete "${k.name}"? Questions keep their content but lose this knowledge point.`)) return;
    const { error } = await deleteKnowledgePoint(k.id);
    if (error) { toast.error(error); return; }
    toast.success("Knowledge point deleted");
    load();
    onChanged?.();
  };

  const movePoint = async (subjectId: string, index: number, dir: -1 | 1) => {
    const list = [...(points[subjectId] || [])];
    const target = index + dir;
    if (target < 0 || target >= list.length) return;
    [list[index], list[target]] = [list[target], list[index]];
    setPoints({ ...points, [subjectId]: list });
    const { error } = await reorderKnowledgePoints(list.map((k) => k.id));
    if (error) { toast.error(error); load(); return; }
    onChanged?.();
  };

  const load = async () => {
    const subs = await fetchSubjects();
    setSubjects(subs);
    const all = await fetchKnowledgePoints();
    const grouped: Record<string, KnowledgePoint[]> = {};
    all.forEach((k) => { (grouped[k.subject_id] ||= []).push(k); });
    setPoints(grouped);
  };
  useEffect(() => { if (open) load(); }, [open]);

  const submit = async () => {
    if (!user) return;
    setSaving(true);
    const { error } = await addSubject(name, user.id, activeClubId);
    setSaving(false);
    if (error) { toast.error(error); return; }
    toast.success("Subject added");
    setName("");
    load();
    onChanged?.();
  };

  const submitPoint = async (subjectId: string) => {
    if (!user) return;
    const value = kpDraft[subjectId] || "";
    const { error } = await addKnowledgePoint(subjectId, value, user.id);
    if (error) { toast.error(error); return; }
    toast.success("Knowledge point added");
    setKpDraft({ ...kpDraft, [subjectId]: "" });
    load();
    onChanged?.();
  };

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <Button variant="outline" size="sm" className="gap-2"><BookPlus className="h-4 w-4" /> Subjects</Button>
      </DialogTrigger>
      <DialogContent className="max-w-lg">
        <DialogHeader><DialogTitle>Subjects &amp; knowledge points</DialogTitle></DialogHeader>
        <div className="flex gap-2">
          <Input value={name} onChange={(e) => setName(e.target.value)} placeholder="New subject name"
            onKeyDown={(e) => { if (e.key === "Enter") { e.preventDefault(); submit(); } }} />
          <Button onClick={submit} disabled={saving || !name.trim()}><Plus className="h-4 w-4" /></Button>
        </div>
        <div className="max-h-80 overflow-y-auto space-y-1">
          {subjects.map((s) => {
            const isOpen = expanded === s.id;
            const kps = points[s.id] || [];
            return (
              <div key={s.id} className="rounded-lg border bg-muted/20 px-3 py-2 text-sm">
                <button className="flex w-full items-center gap-2 text-left" onClick={() => setExpanded(isOpen ? null : s.id)}>
                  {isOpen ? <ChevronDown className="h-4 w-4" /> : <ChevronRight className="h-4 w-4" />}
                  <span className="font-medium">{s.name}</span>
                  <span className="ml-auto text-xs text-muted-foreground">{kps.length} knowledge points</span>
                </button>
                {isOpen && (
                  <div className="mt-2 space-y-2 pl-6">
                    {kps.map((k, i) => (
                      <div key={k.id} className="flex items-center gap-1 rounded-md border bg-background/60 px-2 py-1 text-xs">
                        {editingId === k.id ? (
                          <>
                            <Input
                              className="h-7 text-xs"
                              value={editingName}
                              autoFocus
                              onChange={(e) => setEditingName(e.target.value)}
                              onKeyDown={(e) => {
                                if (e.key === "Enter") { e.preventDefault(); saveRename(k.id); }
                                if (e.key === "Escape") setEditingId(null);
                              }}
                            />
                            <Button size="icon" variant="ghost" className="h-7 w-7" onClick={() => saveRename(k.id)}>
                              <Check className="h-3.5 w-3.5" />
                            </Button>
                            <Button size="icon" variant="ghost" className="h-7 w-7" onClick={() => setEditingId(null)}>
                              <X className="h-3.5 w-3.5" />
                            </Button>
                          </>
                        ) : (
                          <>
                            <span className="flex-1 truncate">{k.name}</span>
                            <Button size="icon" variant="ghost" className="h-7 w-7" disabled={i === 0} onClick={() => movePoint(s.id, i, -1)}>
                              <ArrowUp className="h-3.5 w-3.5" />
                            </Button>
                            <Button size="icon" variant="ghost" className="h-7 w-7" disabled={i === kps.length - 1} onClick={() => movePoint(s.id, i, 1)}>
                              <ArrowDown className="h-3.5 w-3.5" />
                            </Button>
                            <Button size="icon" variant="ghost" className="h-7 w-7" onClick={() => { setEditingId(k.id); setEditingName(k.name); }}>
                              <Pencil className="h-3.5 w-3.5" />
                            </Button>
                            <Button size="icon" variant="ghost" className="h-7 w-7 text-destructive" onClick={() => removePoint(k)}>
                              <Trash2 className="h-3.5 w-3.5" />
                            </Button>
                          </>
                        )}
                      </div>
                    ))}
                    {kps.length === 0 && <p className="text-xs text-muted-foreground">No knowledge points yet.</p>}
                    <div className="flex gap-2">
                      <Input
                        className="h-8 text-xs"
                        placeholder="New knowledge point"
                        value={kpDraft[s.id] || ""}
                        onChange={(e) => setKpDraft({ ...kpDraft, [s.id]: e.target.value })}
                        onKeyDown={(e) => { if (e.key === "Enter") { e.preventDefault(); submitPoint(s.id); } }}
                      />
                      <Button size="sm" className="h-8" onClick={() => submitPoint(s.id)} disabled={!(kpDraft[s.id] || "").trim()}>
                        <Plus className="h-3.5 w-3.5" />
                      </Button>
                    </div>
                  </div>
                )}
              </div>
            );
          })}
          {subjects.length === 0 && <p className="text-sm text-muted-foreground">No subjects yet.</p>}
        </div>
      </DialogContent>
    </Dialog>
  );
}
