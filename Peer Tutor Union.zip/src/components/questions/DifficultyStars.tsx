import { Star } from "lucide-react";
import { cn } from "@/lib/utils";

export default function DifficultyStars({
  level,
  className = "",
}: {
  level: number;
  className?: string;
}) {
  return (
    <span className={cn("inline-flex items-center gap-0.5 align-middle", className)} aria-label={`${level} star difficulty`}>
      {[1, 2, 3].map((i) => (
        <Star
          key={i}
          className={cn("h-3.5 w-3.5", i <= level ? "fill-amber-400 text-amber-400" : "text-muted-foreground/40")}
        />
      ))}
    </span>
  );
}
