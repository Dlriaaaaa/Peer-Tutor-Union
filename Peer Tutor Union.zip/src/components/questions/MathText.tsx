import ReactMarkdown from "react-markdown";
import remarkMath from "remark-math";
import rehypeKatex from "rehype-katex";
import "katex/dist/katex.min.css";
import { cn } from "@/lib/utils";

/** Renders text with LaTeX support ($inline$ and $$block$$) plus light markdown. */
export default function MathText({ text, className = "" }: { text?: string | null; className?: string }) {
  if (!text) return null;
  return (
    <div className={cn("prose prose-sm max-w-none dark:prose-invert break-words", className)}>
      <ReactMarkdown remarkPlugins={[remarkMath]} rehypePlugins={[rehypeKatex]}>
        {text}
      </ReactMarkdown>
    </div>
  );
}
