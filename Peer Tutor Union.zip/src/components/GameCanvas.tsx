/**
 * GameCanvas — React component wrapping the HTML5 Canvas.
 * Handles requestAnimationFrame loop and forwards RenderState.
 */

import { useRef, useEffect } from "react";
import { renderFrame, type RenderState } from "@/render/canvasRenderer";
import { FIELD } from "@/render/sprites";

interface GameCanvasProps {
  renderState: RenderState;
}

export default function GameCanvas({ renderState }: GameCanvasProps) {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const stateRef = useRef(renderState);
  const rafRef = useRef<number>(0);

  // Keep latest state in ref for the animation loop
  stateRef.current = renderState;

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;

    let running = true;

    const loop = () => {
      if (!running) return;
      renderFrame(ctx, stateRef.current);
      rafRef.current = requestAnimationFrame(loop);
    };

    rafRef.current = requestAnimationFrame(loop);

    return () => {
      running = false;
      cancelAnimationFrame(rafRef.current);
    };
  }, []);

  return (
    <canvas
      ref={canvasRef}
      width={FIELD.width}
      height={FIELD.height}
      className="rounded-lg border-2 border-border shadow-xl w-full max-w-[800px]"
      style={{ imageRendering: "auto", aspectRatio: `${FIELD.width}/${FIELD.height}` }}
    />
  );
}
