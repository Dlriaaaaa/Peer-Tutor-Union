import { useState, useMemo, useRef } from "react";
import { Canvas } from "@react-three/fiber";
import { OrbitControls, Text } from "@react-three/drei";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { RotateCcw } from "lucide-react";
import MathKeyboard from "./MathKeyboard";
import * as THREE from "three";

const mathHelpers3D = {
  __logb: (base: number, val: number) => Math.log(val) / Math.log(base),
  __csc: (x: number) => 1 / Math.sin(x),
  __sec: (x: number) => 1 / Math.cos(x),
  __cot: (x: number) => Math.cos(x) / Math.sin(x),
  __acsc: (x: number) => Math.asin(1 / x),
  __asec: (x: number) => Math.acos(1 / x),
  __acot: (x: number) => Math.atan(1 / x),
  __csch: (x: number) => 1 / Math.sinh(x),
  __sech: (x: number) => 1 / Math.cosh(x),
  __coth: (x: number) => Math.cosh(x) / Math.sinh(x),
};
const h3Keys = Object.keys(mathHelpers3D);
const h3Vals = Object.values(mathHelpers3D);

function parse3DExpr(rawExpr: string): ((x: number, y: number) => number) | null {
  try {
    let expr = rawExpr.trim();
    const eqMatch = expr.match(/^z\s*=\s*(.+)$/i);
    if (eqMatch) expr = eqMatch[1];

    let e = expr
      .replace(/\^/g, "**")
      .replace(/log[_]?(\d+(?:\.\d+)?)\s*\(/g, '__logb($1,')
      .replace(/\bacsc\b/g, "__acsc")
      .replace(/\basec\b/g, "__asec")
      .replace(/\bacot\b/g, "__acot")
      .replace(/\bcsch\b/g, "__csch")
      .replace(/\bsech\b/g, "__sech")
      .replace(/\bcoth\b/g, "__coth")
      .replace(/\bcsc\b/g, "__csc")
      .replace(/\bsec\b/g, "__sec")
      .replace(/\bcot\b/g, "__cot")
      .replace(/sinh/g, "Math.sinh")
      .replace(/cosh/g, "Math.cosh")
      .replace(/tanh/g, "Math.tanh")
      .replace(/asin/g, "Math.asin")
      .replace(/acos/g, "Math.acos")
      .replace(/atan/g, "Math.atan")
      .replace(/sin/g, "Math.sin")
      .replace(/cos/g, "Math.cos")
      .replace(/tan/g, "Math.tan")
      .replace(/sqrt/g, "Math.sqrt")
      .replace(/cbrt/g, "Math.cbrt")
      .replace(/abs/g, "Math.abs")
      .replace(/\bln\b/g, "Math.log")
      .replace(/\blog\b(?!\d)/g, "Math.log10")
      .replace(/\bexp\b/g, "Math.exp")
      .replace(/pi/gi, `(${Math.PI})`)
      .replace(/π/g, `(${Math.PI})`);
    e = e.replace(/(\d)([xy(])/g, "$1*$2");
    e = e.replace(/([xy)])(\d)/g, "$1*$2");
    e = e.replace(/([xy])\(/g, "$1*(");
    e = e.replace(/\)([xy])/g, ")*$1");
    const fn = new Function("x", "y", ...h3Keys, `"use strict"; try { return (${e}); } catch { return NaN; }`);
    fn(1, 1, ...h3Vals);
    return ((x: number, y: number) => fn(x, y, ...h3Vals)) as (x: number, y: number) => number;
  } catch {
    return null;
  }
}

function Surface({ expr, range }: { expr: string; range: number }) {
  const geometry = useMemo(() => {
    const fn = parse3DExpr(expr);
    const res = 80;
    const geo = new THREE.PlaneGeometry(range * 2, range * 2, res, res);
    const pos = geo.attributes.position;
    const colors = new Float32Array(pos.count * 3);

    let minZ = Infinity, maxZ = -Infinity;
    const zVals: number[] = [];

    for (let i = 0; i < pos.count; i++) {
      const x = pos.getX(i);
      const y = pos.getY(i);
      const z = fn ? fn(x, y) : 0;
      const cz = isFinite(z) ? Math.max(-range, Math.min(range, z)) : 0;
      zVals.push(cz);
      pos.setZ(i, cz);
      if (cz < minZ) minZ = cz;
      if (cz > maxZ) maxZ = cz;
    }

    const zRange = maxZ - minZ || 1;
    for (let i = 0; i < pos.count; i++) {
      const t = (zVals[i] - minZ) / zRange;
      const c = new THREE.Color();
      c.setHSL(0.66 - t * 0.66, 0.85, 0.55);
      colors[i * 3] = c.r;
      colors[i * 3 + 1] = c.g;
      colors[i * 3 + 2] = c.b;
    }

    geo.setAttribute("color", new THREE.Float32BufferAttribute(colors, 3));
    geo.computeVertexNormals();
    return geo;
  }, [expr, range]);

  return (
    <mesh geometry={geometry} rotation={[-Math.PI / 2, 0, 0]}>
      <meshPhongMaterial vertexColors side={THREE.DoubleSide} shininess={30} transparent opacity={0.85} />
    </mesh>
  );
}

function AxisLabels({ range }: { range: number }) {
  const r = range + 0.5;
  return (
    <>
      <Text position={[r, 0, 0]} fontSize={0.5} color="#EF4444" anchorX="left">X</Text>
      <Text position={[0, r, 0]} fontSize={0.5} color="#10B981" anchorX="center">Z</Text>
      <Text position={[0, 0, r]} fontSize={0.5} color="#3B82F6" anchorX="left">Y</Text>
    </>
  );
}

function Axes({ range }: { range: number }) {
  const r = range;
  return (
    <group>
      <line>
        <bufferGeometry>
          <bufferAttribute attach="attributes-position" args={[new Float32Array([-r,0,0, r,0,0]), 3]} count={2} itemSize={3} />
        </bufferGeometry>
        <lineBasicMaterial color="#EF4444" />
      </line>
      <line>
        <bufferGeometry>
          <bufferAttribute attach="attributes-position" args={[new Float32Array([0,-r,0, 0,r,0]), 3]} count={2} itemSize={3} />
        </bufferGeometry>
        <lineBasicMaterial color="#10B981" />
      </line>
      <line>
        <bufferGeometry>
          <bufferAttribute attach="attributes-position" args={[new Float32Array([0,0,-r, 0,0,r]), 3]} count={2} itemSize={3} />
        </bufferGeometry>
        <lineBasicMaterial color="#3B82F6" />
      </line>
    </group>
  );
}

function GridFloor({ range }: { range: number }) {
  return <gridHelper args={[range * 2, range * 2, 0x444444, 0x333333]} position={[0, -0.01, 0]} />;
}

export default function Graph3D() {
  const [expr, setExpr] = useState("sin(sqrt(x*x+y*y))");
  const [rangeInput, setRangeInput] = useState("5");
  const [appliedExpr, setAppliedExpr] = useState("sin(sqrt(x*x+y*y))");
  const [appliedRange, setAppliedRange] = useState(5);
  const controlsRef = useRef<any>(null);

  const handleKeyboardInsert = (text: string) => {
    if (text === "__BACKSPACE__") {
      setExpr(e => e.slice(0, -1));
    } else {
      setExpr(e => e + text);
    }
  };

  const apply = () => {
    setAppliedExpr(expr);
    const r = parseFloat(rangeInput);
    if (r > 0 && isFinite(r)) setAppliedRange(r);
  };

  const reset = () => {
    setExpr("sin(sqrt(x*x+y*y))");
    setAppliedExpr("sin(sqrt(x*x+y*y))");
    setRangeInput("5");
    setAppliedRange(5);
    if (controlsRef.current) controlsRef.current.reset();
  };

  const validFn = parse3DExpr(expr);

  return (
    <div className="flex flex-col h-full gap-3">
      <div className="flex items-center gap-2">
        <Input
          value={expr}
          onChange={e => setExpr(e.target.value)}
          onKeyDown={e => e.key === "Enter" && apply()}
          placeholder="e.g. sin(sqrt(x^2+y^2)), z=x*y"
          className={`h-8 text-sm font-mono flex-1 ${!validFn && expr ? "border-destructive" : ""}`}
        />
        <span className="text-xs text-muted-foreground shrink-0">Range ±</span>
        <Input
          value={rangeInput}
          onChange={e => setRangeInput(e.target.value)}
          onKeyDown={e => e.key === "Enter" && apply()}
          className="h-8 w-16 text-sm font-mono"
        />
        <Button size="sm" onClick={apply} className="text-xs h-8">Plot</Button>
        <Button variant="ghost" size="icon" className="h-8 w-8" onClick={reset}><RotateCcw className="h-3.5 w-3.5" /></Button>
      </div>

      <MathKeyboard onInsert={handleKeyboardInsert} variables={["x", "y"]} />

      {!validFn && expr && (
        <div className="text-xs text-destructive">Invalid expression. Use x and y variables, e.g. x^2+y^2</div>
      )}

      <div className="flex-1 min-h-0 rounded-xl border border-border/50 overflow-hidden bg-[#0a0a0f]">
        <Canvas camera={{ position: [appliedRange * 1.5, appliedRange * 1.2, appliedRange * 1.5], fov: 50 }}>
          <ambientLight intensity={0.4} />
          <directionalLight position={[5, 10, 5]} intensity={0.8} />
          <directionalLight position={[-5, 5, -5]} intensity={0.3} />
          <Surface expr={appliedExpr} range={appliedRange} />
          <Axes range={appliedRange} />
          <AxisLabels range={appliedRange} />
          <GridFloor range={appliedRange} />
          <OrbitControls ref={controlsRef} enableDamping dampingFactor={0.1} />
        </Canvas>
      </div>

      <div className="text-[10px] text-muted-foreground text-center">
        拖拽旋转 · 滚轮缩放 · 直接输入表达式或 z=...
        支持：sin cos tan csc sec cot · asin acos atan acsc asec acot · sinh cosh tanh csch sech coth · ln log logₐ exp sqrt cbrt abs · π e
      </div>
    </div>
  );
}
