import { useState, useCallback } from "react";
import { Button } from "@/components/ui/button";
import { Delete } from "lucide-react";

export default function ScientificCalculator() {
  const [display, setDisplay] = useState("0");
  const [expression, setExpression] = useState("");
  const [memory, setMemory] = useState(0);
  const [isSecond, setIsSecond] = useState(false);
  const [isDeg, setIsDeg] = useState(true);

  const safeEval = useCallback((expr: string): number => {
    let e = expr
      .replace(/×/g, "*")
      .replace(/÷/g, "/")
      .replace(/π/g, `(${Math.PI})`)
      .replace(/e(?![x])/g, `(${Math.E})`);
    // functions
    const toRad = isDeg ? `(Math.PI/180)*` : "";
    const fromRad = isDeg ? `(180/Math.PI)*` : "";
    e = e.replace(/sin\(/g, `Math.sin(${toRad}(`);
    e = e.replace(/cos\(/g, `Math.cos(${toRad}(`);
    e = e.replace(/tan\(/g, `Math.tan(${toRad}(`);
    e = e.replace(/asin\(/g, `(${fromRad}Math.asin(`);
    e = e.replace(/acos\(/g, `(${fromRad}Math.acos(`);
    e = e.replace(/atan\(/g, `(${fromRad}Math.atan(`);
    e = e.replace(/ln\(/g, "Math.log(");
    e = e.replace(/log\(/g, "Math.log10(");
    e = e.replace(/sqrt\(/g, "Math.sqrt(");
    e = e.replace(/cbrt\(/g, "Math.cbrt(");
    e = e.replace(/abs\(/g, "Math.abs(");
    e = e.replace(/exp\(/g, "Math.exp(");
    e = e.replace(/(\d+)!/g, (_, n) => {
      let r = 1; for (let i = 2; i <= +n; i++) r *= i; return `${r}`;
    });
    // fix unclosed parens
    const opens = (e.match(/\(/g) || []).length;
    const closes = (e.match(/\)/g) || []).length;
    for (let i = 0; i < opens - closes; i++) e += ")";
    try {
      const fn = new Function(`"use strict"; return (${e})`);
      const result = fn();
      if (typeof result !== "number" || !isFinite(result)) throw new Error();
      return result;
    } catch {
      throw new Error("Error");
    }
  }, [isDeg]);

  const handleInput = (val: string) => {
    if (display === "Error") {
      setDisplay(val);
      setExpression(val);
      return;
    }
    if (display === "0" && ![".", "+", "-", "×", "÷"].includes(val)) {
      setDisplay(val);
      setExpression(val);
    } else {
      setDisplay(display + val);
      setExpression(expression + val);
    }
  };

  const handleFunc = (fn: string) => {
    handleInput(fn + "(");
  };

  const calculate = () => {
    try {
      const result = safeEval(expression);
      const str = Number.isInteger(result) ? result.toString() : result.toPrecision(10).replace(/\.?0+$/, "");
      setDisplay(str);
      setExpression(str);
    } catch {
      setDisplay("Error");
      setExpression("");
    }
  };

  const clear = () => { setDisplay("0"); setExpression(""); };
  const backspace = () => {
    if (display.length <= 1 || display === "Error") { clear(); return; }
    const nd = display.slice(0, -1);
    setDisplay(nd);
    setExpression(expression.slice(0, -1));
  };

  const btnClass = "h-11 text-sm font-medium rounded-lg transition-colors";
  const numClass = `${btnClass} bg-muted/50 hover:bg-muted text-foreground`;
  const opClass = `${btnClass} bg-primary/20 hover:bg-primary/30 text-primary`;
  const funcClass = `${btnClass} bg-card hover:bg-muted/60 text-muted-foreground text-xs`;

  return (
    <div className="w-full max-w-md mx-auto space-y-3">
      {/* Display */}
      <div className="bg-card border border-border/50 rounded-xl p-4 min-h-[80px] flex flex-col justify-end items-end">
        <div className="text-xs text-muted-foreground truncate w-full text-right">{expression || "\u00A0"}</div>
        <div className="text-3xl font-mono font-bold text-foreground truncate w-full text-right">{display}</div>
      </div>

      {/* Controls row */}
      <div className="flex gap-2 text-xs">
        <Button variant="ghost" size="sm" onClick={() => setIsDeg(!isDeg)} className="text-xs">{isDeg ? "DEG" : "RAD"}</Button>
        <Button variant="ghost" size="sm" onClick={() => setIsSecond(!isSecond)} className={`text-xs ${isSecond ? "text-primary" : ""}`}>2nd</Button>
        <div className="flex-1" />
        <Button variant="ghost" size="sm" onClick={() => setMemory(0)} className="text-xs">MC</Button>
        <Button variant="ghost" size="sm" onClick={() => handleInput(memory.toString())} className="text-xs">MR</Button>
        <Button variant="ghost" size="sm" onClick={() => { try { setMemory(memory + safeEval(expression)); } catch {} }} className="text-xs">M+</Button>
        <Button variant="ghost" size="sm" onClick={() => { try { setMemory(memory - safeEval(expression)); } catch {} }} className="text-xs">M−</Button>
      </div>

      {/* Button grid */}
      <div className="grid grid-cols-5 gap-1.5">
        {/* Row 1 - functions */}
        <button className={funcClass} onClick={() => handleFunc(isSecond ? "asin" : "sin")}>{isSecond ? "sin⁻¹" : "sin"}</button>
        <button className={funcClass} onClick={() => handleFunc(isSecond ? "acos" : "cos")}>{isSecond ? "cos⁻¹" : "cos"}</button>
        <button className={funcClass} onClick={() => handleFunc(isSecond ? "atan" : "tan")}>{isSecond ? "tan⁻¹" : "tan"}</button>
        <button className={funcClass} onClick={() => handleInput("π")}>π</button>
        <button className={funcClass} onClick={() => handleInput("e")}>e</button>

        {/* Row 2 */}
        <button className={funcClass} onClick={() => handleInput("^2")}>x²</button>
        <button className={funcClass} onClick={() => handleInput("^")}>xʸ</button>
        <button className={funcClass} onClick={() => handleFunc(isSecond ? "cbrt" : "sqrt")}>{isSecond ? "∛x" : "√x"}</button>
        <button className={funcClass} onClick={() => handleFunc("exp")}>exp</button>
        <button className={funcClass} onClick={() => handleInput("!")}>n!</button>

        {/* Row 3 */}
        <button className={funcClass} onClick={() => handleFunc("ln")}>ln</button>
        <button className={funcClass} onClick={() => handleFunc("log")}>log</button>
        <button className={funcClass} onClick={() => handleFunc("abs")}>|x|</button>
        <button className={funcClass} onClick={() => handleInput("(")}>(</button>
        <button className={funcClass} onClick={() => handleInput(")")}>)</button>

        {/* Row 4: 7 8 9 ÷ ⌫ */}
        <button className={numClass} onClick={() => handleInput("7")}>7</button>
        <button className={numClass} onClick={() => handleInput("8")}>8</button>
        <button className={numClass} onClick={() => handleInput("9")}>9</button>
        <button className={opClass} onClick={() => handleInput("÷")}>÷</button>
        <button className={`${btnClass} bg-destructive/20 hover:bg-destructive/30 text-destructive`} onClick={backspace}><Delete className="h-4 w-4 mx-auto" /></button>

        {/* Row 5: 4 5 6 × C */}
        <button className={numClass} onClick={() => handleInput("4")}>4</button>
        <button className={numClass} onClick={() => handleInput("5")}>5</button>
        <button className={numClass} onClick={() => handleInput("6")}>6</button>
        <button className={opClass} onClick={() => handleInput("×")}>×</button>
        <button className={`${btnClass} bg-destructive/20 hover:bg-destructive/30 text-destructive`} onClick={clear}>C</button>

        {/* Row 6: 1 2 3 - */}
        <button className={numClass} onClick={() => handleInput("1")}>1</button>
        <button className={numClass} onClick={() => handleInput("2")}>2</button>
        <button className={numClass} onClick={() => handleInput("3")}>3</button>
        <button className={opClass} onClick={() => handleInput("-")}>−</button>
        <button className={opClass} onClick={() => handleInput("+")}>+</button>

        {/* Row 7: +/- 0 . = (span 2) */}
        <button className={numClass} onClick={() => {
          if (display !== "0" && display !== "Error") {
            const nd = display.startsWith("-") ? display.slice(1) : "-" + display;
            setDisplay(nd);
            setExpression(nd);
          }
        }}>±</button>
        <button className={numClass} onClick={() => handleInput("0")}>0</button>
        <button className={numClass} onClick={() => handleInput(".")}>.</button>
        <button className={`col-span-2 h-11 text-sm font-bold rounded-lg bg-primary hover:bg-primary/90 text-primary-foreground transition-colors`} onClick={calculate}>=</button>
      </div>
    </div>
  );
}
