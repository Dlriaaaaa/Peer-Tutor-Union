import { useState, useRef, useEffect, useCallback } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Plus, Trash2, ZoomIn, ZoomOut, RotateCcw, X } from "lucide-react";
import MathKeyboard from "./MathKeyboard";

interface FuncEntry {
  id: number;
  expr: string;
  color: string;
}

interface PinnedPoint {
  x: number;
  y: number;
  color: string;
  label: string;
}

const COLORS = ["#3B82F6", "#EF4444", "#10B981", "#F59E0B", "#8B5CF6", "#EC4899"];

const mathHelpers = {
  __logb: (base: number, val: number) => Math.log(val) / Math.log(base),
  __csc: (x: number) => 1 / Math.sin(x),
  __sec: (x: number) => 1 / Math.cos(x),
  __cot: (x: number) => Math.cos(x) / Math.sin(x),
  __acsc: (x: number) => Math.asin(1 / x),
  __asec: (x: number) => Math.acos(1 / x),
  __acot: (x: number) => Math.atan(1 / x),
  __csch: (x: number) => 1 / Math.sinh(x),
  __sech: (x: number) => 1 / Math.cosh(x),
  __coth: (x: number) => Math.cosh(x) / Math.sinh(x),
};
const helperKeys = Object.keys(mathHelpers);
const helperVals = Object.values(mathHelpers);

function parseExpr(rawExpr: string): ((x: number) => number) | null {
  try {
    let expr = rawExpr.trim();
    const eqMatch = expr.match(/^[yf]\s*(?:\(x\))?\s*=\s*(.+)$/i);
    if (eqMatch) expr = eqMatch[1];
    let e = expr
      .replace(/\^/g, "**")
      .replace(/log[_]?(\d+(?:\.\d+)?)\s*\(/g, '__logb($1,')
      .replace(/\bacsc\b/g, "__acsc")
      .replace(/\basec\b/g, "__asec")
      .replace(/\bacot\b/g, "__acot")
      .replace(/\bcsch\b/g, "__csch")
      .replace(/\bsech\b/g, "__sech")
      .replace(/\bcoth\b/g, "__coth")
      .replace(/\bcsc\b/g, "__csc")
      .replace(/\bsec\b/g, "__sec")
      .replace(/\bcot\b/g, "__cot")
      .replace(/sinh/g, "Math.sinh")
      .replace(/cosh/g, "Math.cosh")
      .replace(/tanh/g, "Math.tanh")
      .replace(/asin/g, "Math.asin")
      .replace(/acos/g, "Math.acos")
      .replace(/atan/g, "Math.atan")
      .replace(/sin/g, "Math.sin")
      .replace(/cos/g, "Math.cos")
      .replace(/tan/g, "Math.tan")
      .replace(/sqrt/g, "Math.sqrt")
      .replace(/cbrt/g, "Math.cbrt")
      .replace(/abs/g, "Math.abs")
      .replace(/\bln\b/g, "Math.log")
      .replace(/\blog\b(?!\d)/g, "Math.log10")
      .replace(/\bexp\b/g, "Math.exp")
      .replace(/pi/gi, `(${Math.PI})`)
      .replace(/π/g, `(${Math.PI})`)
      .replace(/e(?![x\w])/g, `(${Math.E})`);
    e = e.replace(/(\d)([x(])/g, "$1*$2");
    e = e.replace(/([x)])(\d)/g, "$1*$2");
    e = e.replace(/(x)\(/g, "x*(");
    e = e.replace(/\)(x)/g, ")*x");
    const fn = new Function("x", ...helperKeys, `"use strict"; try { return (${e}); } catch { return NaN; }`);
    fn(1, ...helperVals);
    return ((x: number) => fn(x, ...helperVals)) as (x: number) => number;
  } catch {
    return null;
  }
}

export default function Graph2D() {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [funcs, setFuncs] = useState<FuncEntry[]>([
    { id: 1, expr: "sin(x)", color: COLORS[0] },
  ]);
  const [nextId, setNextId] = useState(2);
  const [center, setCenter] = useState({ x: 0, y: 0 });
  const [scale, setScale] = useState<number | null>(null);
  const [xRange, setXRange] = useState("10");
  const [yRange, setYRange] = useState("10");
  const [pinnedPoints, setPinnedPoints] = useState<PinnedPoint[]>([]);
  const [hoverInfo, setHoverInfo] = useState<{ mx: number; my: number; x: number; y: number; color: string } | null>(null);
  const [activeInputId, setActiveInputId] = useState<number>(1);
  const initializedRef = useRef(false);
  const dragRef = useRef<{ sx: number; sy: number; cx: number; cy: number } | null>(null);

  const handleKeyboardInsert = (text: string) => {
    setFuncs(f => f.map(entry => {
      if (entry.id !== activeInputId) return entry;
      if (text === "__BACKSPACE__") {
        return { ...entry, expr: entry.expr.slice(0, -1) };
      }
      return { ...entry, expr: entry.expr + text };
    }));
  };

  const addFunc = () => {
    setFuncs(f => [...f, { id: nextId, expr: "", color: COLORS[f.length % COLORS.length] }]);
    setNextId(n => n + 1);
  };

  const removeFunc = (id: number) => setFuncs(f => f.filter(e => e.id !== id));
  const updateExpr = (id: number, expr: string) => setFuncs(f => f.map(e => e.id === id ? { ...e, expr } : e));

  // Find closest function point to mouse using screen-space sampling around the cursor
  const findClosestPoint = useCallback((clientX: number, clientY: number) => {
    const canvas = canvasRef.current;
    if (!canvas || scale === null) return null;
    const rect = canvas.getBoundingClientRect();
    const cssMx = clientX - rect.left;
    const cssMy = clientY - rect.top;
    const cssOx = rect.width / 2 + center.x * scale;
    const cssOy = rect.height / 2 - center.y * scale;
    const graphX = (cssMx - cssOx) / scale;
    const snapRadiusPx = 24;
    const sampleStepPx = 1;

    let closest: { x: number; y: number; color: string; cssDist: number } | null = null;

    for (const f of funcs) {
      const fn = parseExpr(f.expr);
      if (!fn) continue;
      for (let offsetPx = -snapRadiusPx; offsetPx <= snapRadiusPx; offsetPx += sampleStepPx) {
        const sx = graphX + offsetPx / scale;
        const y = fn(sx);
        if (!isFinite(y) || Math.abs(y) > 1e6) continue;
        const cssPy = cssOy - y * scale;
        const cssPx = cssOx + sx * scale;
        const dist = Math.sqrt((cssPx - cssMx) ** 2 + (cssPy - cssMy) ** 2);
        if (dist <= snapRadiusPx && (!closest || dist < closest.cssDist)) {
          closest = { x: sx, y, color: f.color, cssDist: dist };
        }
      }
    }
    return closest ? { mx: cssMx, my: cssMy, x: closest.x, y: closest.y, color: closest.color } : null;
  }, [funcs, center, scale]);

  const draw = useCallback(() => {
    const canvas = canvasRef.current;
    if (!canvas || scale === null) return;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;
    const rect = canvas.getBoundingClientRect();
    const W = rect.width;
    const H = rect.height;
    ctx.clearRect(0, 0, W, H);

    const ox = W / 2 + center.x * scale;
    const oy = H / 2 - center.y * scale;

    // grid
    ctx.strokeStyle = "rgba(128,128,128,0.15)";
    ctx.lineWidth = 1;
    // Dynamic grid step based on zoom level
    const rawStep = 50 / scale; // ~50px between grid lines
    const mag = Math.pow(10, Math.floor(Math.log10(rawStep)));
    const norm = rawStep / mag;
    const step = norm < 2 ? mag : norm < 5 ? 2 * mag : 5 * mag;
    const xMin = -ox / scale;
    const xMax = (W - ox) / scale;
    const yMin = -(H - oy) / scale;
    const yMax = oy / scale;

    for (let gx = Math.ceil(xMin / step) * step; gx <= xMax; gx += step) {
      const px = ox + gx * scale;
      ctx.beginPath(); ctx.moveTo(px, 0); ctx.lineTo(px, H); ctx.stroke();
    }
    for (let gy = Math.ceil(yMin / step) * step; gy <= yMax; gy += step) {
      const py = oy - gy * scale;
      ctx.beginPath(); ctx.moveTo(0, py); ctx.lineTo(W, py); ctx.stroke();
    }

    // axes
    ctx.strokeStyle = "rgba(128,128,128,0.5)";
    ctx.lineWidth = 1.5;
    ctx.beginPath(); ctx.moveTo(0, oy); ctx.lineTo(W, oy); ctx.stroke();
    ctx.beginPath(); ctx.moveTo(ox, 0); ctx.lineTo(ox, H); ctx.stroke();

    // labels
    const decimals = step < 0.01 ? 3 : step < 0.1 ? 2 : step < 1 ? 1 : 0;
    const fmt = (v: number) => {
      const r = Math.round(v / step) * step;
      return decimals > 0 ? r.toFixed(decimals) : r.toString();
    };
    ctx.fillStyle = "rgba(128,128,128,0.7)";
    ctx.font = "11px monospace";
    ctx.textAlign = "center";
    for (let gx = Math.ceil(xMin / step) * step; gx <= xMax; gx += step) {
      if (Math.abs(gx) < step * 0.1) continue;
      const px = ox + gx * scale;
      ctx.fillText(fmt(gx), px, oy + 14);
    }
    ctx.textAlign = "right";
    for (let gy = Math.ceil(yMin / step) * step; gy <= yMax; gy += step) {
      if (Math.abs(gy) < step * 0.1) continue;
      const py = oy - gy * scale;
      ctx.fillText(fmt(gy), ox - 6, py + 4);
    }

    // draw functions
    for (const f of funcs) {
      const fn = parseExpr(f.expr);
      if (!fn) continue;
      ctx.strokeStyle = f.color;
      ctx.lineWidth = 2;
      ctx.beginPath();
      let started = false;
      for (let px = 0; px < W; px++) {
        const x = (px - ox) / scale;
        const y = fn(x);
        if (!isFinite(y) || Math.abs(y) > 1e6) { started = false; continue; }
        const py = oy - y * scale;
        if (!started) { ctx.moveTo(px, py); started = true; } else ctx.lineTo(px, py);
      }
      ctx.stroke();
    }

    // draw pinned points
    for (const p of pinnedPoints) {
      const px = ox + p.x * scale;
      const py = oy - p.y * scale;
      // dot
      ctx.beginPath();
      ctx.arc(px, py, 5, 0, Math.PI * 2);
      ctx.fillStyle = p.color;
      ctx.fill();
      ctx.strokeStyle = "#fff";
      ctx.lineWidth = 1.5;
      ctx.stroke();
      // label
      ctx.fillStyle = "rgba(0,0,0,0.8)";
      ctx.fillRect(px + 8, py - 20, ctx.measureText(p.label).width + 12, 22);
      ctx.fillStyle = "#fff";
      ctx.font = "11px monospace";
      ctx.textAlign = "left";
      ctx.fillText(p.label, px + 14, py - 5);
    }

    // draw hover point
    if (hoverInfo) {
      const px = ox + hoverInfo.x * scale;
      const py = oy - hoverInfo.y * scale;
      // crosshair lines
      ctx.setLineDash([4, 4]);
      ctx.strokeStyle = "rgba(128,128,128,0.4)";
      ctx.lineWidth = 1;
      ctx.beginPath(); ctx.moveTo(px, 0); ctx.lineTo(px, H); ctx.stroke();
      ctx.beginPath(); ctx.moveTo(0, py); ctx.lineTo(W, py); ctx.stroke();
      ctx.setLineDash([]);
      // dot
      ctx.beginPath();
      ctx.arc(px, py, 6, 0, Math.PI * 2);
      ctx.fillStyle = hoverInfo.color;
      ctx.fill();
      ctx.strokeStyle = "#fff";
      ctx.lineWidth = 2;
      ctx.stroke();
      // tooltip
      const label = `(${hoverInfo.x.toFixed(3)}, ${hoverInfo.y.toFixed(3)})`;
      const tw = ctx.measureText(label).width + 16;
      const tx = px + 12;
      const ty = py - 28;
      ctx.fillStyle = "rgba(0,0,0,0.85)";
      ctx.beginPath();
      ctx.roundRect(tx, ty, tw, 24, 6);
      ctx.fill();
      ctx.fillStyle = "#fff";
      ctx.font = "12px monospace";
      ctx.textAlign = "left";
      ctx.fillText(label, tx + 8, ty + 16);
    }
  }, [funcs, center, scale, pinnedPoints, hoverInfo]);

  // Auto-fit when range changes
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const rect = canvas.parentElement!.getBoundingClientRect();
    const xR = parseFloat(xRange) || 10;
    const yR = parseFloat(yRange) || 10;
    const newScale = Math.min((rect.width * 0.9) / (xR * 2), (rect.height * 0.9) / (yR * 2));
    setScale(Math.max(5, newScale));
    setCenter({ x: 0, y: 0 });
  }, [xRange, yRange]);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const resize = () => {
      const rect = canvas.parentElement!.getBoundingClientRect();
      const dpr = window.devicePixelRatio || 1;
      canvas.width = Math.floor(rect.width * dpr);
      canvas.height = Math.floor(rect.height * dpr);
      canvas.style.width = rect.width + "px";
      canvas.style.height = rect.height + "px";
      const ctx = canvas.getContext("2d");
      if (ctx) ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
      if (!initializedRef.current) {
        initializedRef.current = true;
        const xR = parseFloat(xRange) || 10;
        const yR = parseFloat(yRange) || 10;
        const newScale = Math.min((rect.width * 0.9) / (xR * 2), (rect.height * 0.9) / (yR * 2));
        setScale(Math.max(5, newScale));
        return;
      }
      draw();
    };
    resize();
    const ro = new ResizeObserver(resize);
    ro.observe(canvas.parentElement!);
    return () => ro.disconnect();
  }, [draw]);

  useEffect(() => { draw(); }, [draw]);

  const handleWheel = (e: React.WheelEvent) => {
    e.preventDefault();
    setScale(s => Math.max(5, Math.min(500, (s ?? 40) * (e.deltaY < 0 ? 1.15 : 0.87))));
  };

  const handleMouseDown = (e: React.MouseEvent) => {
    dragRef.current = { sx: e.clientX, sy: e.clientY, cx: center.x, cy: center.y };
  };
  const handleMouseMove = (e: React.MouseEvent) => {
    if (dragRef.current) {
      const dx = e.clientX - dragRef.current.sx;
      const dy = e.clientY - dragRef.current.sy;
      setCenter({ x: dragRef.current.cx + dx / (scale ?? 40), y: dragRef.current.cy - dy / (scale ?? 40) });
      setHoverInfo(null);
      return;
    }
    // hover detection
    const point = findClosestPoint(e.clientX, e.clientY);
    setHoverInfo(point);
  };
  const handleMouseUp = () => { dragRef.current = null; };

  const handleClick = (e: React.MouseEvent) => {
    if (dragRef.current) return;
    const point = findClosestPoint(e.clientX, e.clientY);
    if (point) {
      setPinnedPoints(prev => [
        ...prev,
        { x: point.x, y: point.y, color: point.color, label: `(${point.x.toFixed(3)}, ${point.y.toFixed(3)})` },
      ]);
    }
  };

  return (
    <div className="flex flex-col h-full gap-3">
      <div className="flex flex-col gap-2 max-h-[160px] overflow-y-auto">
        {funcs.map((f) => (
          <div key={f.id} className="flex items-center gap-2">
            <div className="w-3 h-3 rounded-full shrink-0" style={{ backgroundColor: f.color }} />
            <Input
              value={f.expr}
              onChange={e => updateExpr(f.id, e.target.value)}
              onFocus={() => setActiveInputId(f.id)}
              placeholder="e.g. sin(x), y=x^2, csc(x)+1"
              className={`h-8 text-sm font-mono flex-1 ${activeInputId === f.id ? "ring-2 ring-primary/30" : ""}`}
            />
            {funcs.length > 1 && (
              <Button variant="ghost" size="icon" className="h-7 w-7 shrink-0" onClick={() => removeFunc(f.id)}>
                <Trash2 className="h-3 w-3" />
              </Button>
            )}
          </div>
        ))}
      </div>

      <div className="flex gap-2 items-center flex-wrap">
        <Button variant="outline" size="sm" onClick={addFunc} className="text-xs gap-1">
          <Plus className="h-3 w-3" /> Add Function
        </Button>
        <MathKeyboard onInsert={handleKeyboardInsert} variables={["x"]} />
        <div className="flex items-center gap-1 ml-auto">
          <span className="text-xs text-muted-foreground">x:</span>
          <span className="text-xs text-muted-foreground">±</span>
          <Input value={xRange} onChange={e => setXRange(e.target.value)} className="h-7 w-14 text-xs font-mono px-1.5" />
          <span className="text-xs text-muted-foreground ml-1">y:</span>
          <span className="text-xs text-muted-foreground">±</span>
          <Input value={yRange} onChange={e => setYRange(e.target.value)} className="h-7 w-14 text-xs font-mono px-1.5" />
        </div>
        <Button variant="ghost" size="icon" className="h-7 w-7" onClick={() => setScale(s => Math.min(500, (s ?? 40) * 1.3))}><ZoomIn className="h-3.5 w-3.5" /></Button>
        <Button variant="ghost" size="icon" className="h-7 w-7" onClick={() => setScale(s => Math.max(5, (s ?? 40) / 1.3))}><ZoomOut className="h-3.5 w-3.5" /></Button>
        <Button variant="ghost" size="icon" className="h-7 w-7" onClick={() => { setCenter({ x: 0, y: 0 }); setXRange("10"); setYRange("10"); setPinnedPoints([]); }}><RotateCcw className="h-3.5 w-3.5" /></Button>
      </div>

      {/* Pinned points list */}
      {pinnedPoints.length > 0 && (
        <div className="flex gap-1.5 flex-wrap max-h-[60px] overflow-y-auto">
          {pinnedPoints.map((p, i) => (
            <span key={i} className="inline-flex items-center gap-1 text-[10px] font-mono bg-muted/50 rounded px-1.5 py-0.5">
              <span className="w-2 h-2 rounded-full" style={{ backgroundColor: p.color }} />
              {p.label}
              <button onClick={() => setPinnedPoints(prev => prev.filter((_, j) => j !== i))} className="hover:text-destructive ml-0.5">
                <X className="h-2.5 w-2.5" />
              </button>
            </span>
          ))}
        </div>
      )}

      {/* Input guide */}
      <div className="text-[10px] text-muted-foreground leading-relaxed px-1">
        <span className="font-medium">输入指引：</span>直接输入表达式或方程（如 <code className="bg-muted/50 px-0.5 rounded">y=x^2</code>）。支持：sin cos tan csc sec cot · asin acos atan acsc asec acot · sinh cosh tanh csch sech coth · ln log log_a() exp sqrt cbrt abs · π e
      </div>

      <div
        className="flex-1 min-h-0 rounded-xl border border-border/50 bg-card overflow-hidden cursor-crosshair"
        style={{ cursor: dragRef.current ? 'grabbing' : hoverInfo ? 'crosshair' : 'grab' }}
      >
        <canvas
          ref={canvasRef}
          onWheel={handleWheel}
          onMouseDown={handleMouseDown}
          onMouseMove={handleMouseMove}
          onMouseUp={handleMouseUp}
          onMouseLeave={() => { handleMouseUp(); setHoverInfo(null); }}
          onClick={handleClick}
          className="w-full h-full"
        />
      </div>
    </div>
  );
}
