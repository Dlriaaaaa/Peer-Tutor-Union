import { Button } from "@/components/ui/button";
import { ChevronDown, ChevronUp } from "lucide-react";
import { useState } from "react";

interface MathKeyboardProps {
  onInsert: (text: string) => void;
  variables?: string[];
}

const SECTIONS = [
  {
    label: "变量 / 运算",
    buttons: [
      { label: "x", insert: "x" },
      { label: "y", insert: "y" },
      { label: "π", insert: "pi" },
      { label: "e", insert: "e" },
      { label: "aᵇ", insert: "^" },
      { label: "(", insert: "(" },
      { label: ")", insert: ")" },
      { label: "|a|", insert: "abs(" },
      { label: "√", insert: "sqrt(" },
      { label: "∛", insert: "cbrt(" },
      { label: "+", insert: "+" },
      { label: "−", insert: "-" },
      { label: "×", insert: "*" },
      { label: "÷", insert: "/" },
      { label: "=", insert: "=" },
      { label: "⌫", insert: "__BACKSPACE__" },
    ],
  },
  {
    label: "三角函数",
    buttons: [
      { label: "sin", insert: "sin(" },
      { label: "cos", insert: "cos(" },
      { label: "tan", insert: "tan(" },
      { label: "csc", insert: "csc(" },
      { label: "sec", insert: "sec(" },
      { label: "cot", insert: "cot(" },
    ],
  },
  {
    label: "反三角函数",
    buttons: [
      { label: "sin⁻¹", insert: "asin(" },
      { label: "cos⁻¹", insert: "acos(" },
      { label: "tan⁻¹", insert: "atan(" },
      { label: "csc⁻¹", insert: "acsc(" },
      { label: "sec⁻¹", insert: "asec(" },
      { label: "cot⁻¹", insert: "acot(" },
    ],
  },
  {
    label: "双曲函数",
    buttons: [
      { label: "sinh", insert: "sinh(" },
      { label: "cosh", insert: "cosh(" },
      { label: "tanh", insert: "tanh(" },
      { label: "csch", insert: "csch(" },
      { label: "sech", insert: "sech(" },
      { label: "coth", insert: "coth(" },
    ],
  },
  {
    label: "微积分 / 对数",
    buttons: [
      { label: "exp", insert: "exp(" },
      { label: "ln", insert: "ln(" },
      { label: "log", insert: "log(" },
      { label: "logₐ", insert: "log_" },
    ],
  },
  {
    label: "数字",
    buttons: [
      { label: "7", insert: "7" },
      { label: "8", insert: "8" },
      { label: "9", insert: "9" },
      { label: "4", insert: "4" },
      { label: "5", insert: "5" },
      { label: "6", insert: "6" },
      { label: "1", insert: "1" },
      { label: "2", insert: "2" },
      { label: "3", insert: "3" },
      { label: "0", insert: "0" },
      { label: ".", insert: "." },
      { label: ",", insert: "," },
    ],
  },
];

export default function MathKeyboard({ onInsert, variables }: MathKeyboardProps) {
  const [open, setOpen] = useState(false);

  const sections = SECTIONS.map(s => {
    if (s.label === "变量 / 运算" && variables) {
      return {
        ...s,
        buttons: s.buttons.filter(b => {
          if (b.insert === "y" && !variables.includes("y")) return false;
          return true;
        }),
      };
    }
    return s;
  });

  return (
    <div>
      <Button
        variant="outline"
        size="sm"
        className="text-xs h-7 gap-1"
        onClick={() => setOpen(!open)}
      >
        f(x) 键盘 {open ? <ChevronUp className="h-3 w-3" /> : <ChevronDown className="h-3 w-3" />}
      </Button>
      {open && (
        <div className="mt-2 p-2.5 rounded-lg border border-border/60 bg-card/80 backdrop-blur-sm space-y-2">
          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-6 gap-x-3 gap-y-2">
            {sections.map(section => (
              <div key={section.label}>
                <div className="text-[10px] text-muted-foreground mb-1 font-medium">{section.label}</div>
                <div className="grid grid-cols-3 gap-1">
                  {section.buttons.map(b => (
                    <button
                      key={b.label + b.insert}
                      className="h-7 rounded border border-border/40 bg-muted/30 hover:bg-muted text-xs font-mono transition-colors"
                      onClick={() => onInsert(b.insert)}
                    >
                      {b.label}
                    </button>
                  ))}
                </div>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}
