import { useState } from "react";
import { ArrowLeft } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import ScientificCalculator from "./ScientificCalculator";
import Graph2D from "./Graph2D";
import Graph3D from "./Graph3D";

interface Props {
  onBack: () => void;
}

export default function FunctionCalculator({ onBack }: Props) {
  const [tab, setTab] = useState("calc");

  return (
    <div className="flex flex-col h-[calc(100vh-8rem)] max-w-4xl mx-auto">
      <div className="flex items-center gap-3 mb-3">
        <Button variant="ghost" size="sm" onClick={onBack} className="gap-1">
          <ArrowLeft className="h-4 w-4" /> Back
        </Button>
        <h2 className="text-xl font-bold text-foreground">📐 Function Calculator</h2>
      </div>

      <Tabs value={tab} onValueChange={setTab} className="flex-1 flex flex-col min-h-0">
        <TabsList className="grid w-full grid-cols-3">
          <TabsTrigger value="calc">🔢 Calculator</TabsTrigger>
          <TabsTrigger value="2d">📈 2D Graph</TabsTrigger>
          <TabsTrigger value="3d">🧊 3D Graph</TabsTrigger>
        </TabsList>

        <TabsContent value="calc" className="flex-1 mt-4 overflow-auto">
          <ScientificCalculator />
        </TabsContent>

        <TabsContent value="2d" className="flex-1 mt-4 min-h-0">
          <Graph2D />
        </TabsContent>

        <TabsContent value="3d" className="flex-1 mt-4 min-h-0">
          <Graph3D />
        </TabsContent>
      </Tabs>
    </div>
  );
}
