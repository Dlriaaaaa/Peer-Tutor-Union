import { SidebarProvider, SidebarTrigger } from "@/components/ui/sidebar";
import { AppSidebar } from "@/components/AppSidebar";
import { Outlet, useLocation } from "react-router-dom";
import AnimatedPage from "@/components/AnimatedPage";

export default function AppLayout() {
  const location = useLocation();

  return (
    <SidebarProvider>
      <div className="app-ambient min-h-screen flex w-full bg-background">
        <AppSidebar />
        <div className="flex-1 flex flex-col min-w-0">
          <header className="sticky top-0 z-30 px-4 pt-3">
            <div className="glass-panel h-14 flex items-center gap-3 rounded-2xl px-3">
              <SidebarTrigger />
              <h1 className="text-[15px] font-semibold text-foreground tracking-tight">PTC Portal</h1>
            </div>
          </header>
          <main className="flex-1 p-4 sm:p-6 overflow-auto">
            <AnimatedPage key={location.pathname}>
              <div className="mx-auto w-full max-w-6xl">
                <Outlet />
              </div>
            </AnimatedPage>
          </main>
        </div>
      </div>
    </SidebarProvider>
  );
}
