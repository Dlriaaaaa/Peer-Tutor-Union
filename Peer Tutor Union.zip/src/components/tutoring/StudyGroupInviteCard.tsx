import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/contexts/AuthContext";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { toast } from "sonner";
import { Users, Check } from "lucide-react";
import { useNavigate } from "react-router-dom";

export const STUDY_GROUP_INVITE_RE = /^\[StudyGroup:([a-f0-9-]+)\]\s*(.*)$/s;

export function parseStudyGroupInvite(content: string) {
  const m = content.match(STUDY_GROUP_INVITE_RE);
  if (!m) return null;
  return { groupId: m[1], text: m[2] };
}

type Group = {
  id: string;
  title: string;
  subject: string;
  meeting_time: string | null;
  frequency: string | null;
  location: string | null;
  max_members: number;
  content: string | null;
  is_public: boolean;
  status: string;
};

export default function StudyGroupInviteCard({ groupId }: { groupId: string }) {
  const { user } = useAuth();
  const navigate = useNavigate();
  const [group, setGroup] = useState<Group | null>(null);
  const [count, setCount] = useState(0);
  const [joined, setJoined] = useState(false);
  const [busy, setBusy] = useState(false);
  const [missing, setMissing] = useState(false);

  const load = async () => {
    const { data } = await (supabase as any).rpc("get_study_group_invite", { _group_id: groupId });
    const row = Array.isArray(data) ? data[0] : data;
    if (!row) return setMissing(true);
    setGroup(row as Group);
    setCount(row.member_count ?? 0);
    setJoined(!!row.is_member);
  };

  useEffect(() => { load(); }, [groupId, user?.id]);

  const join = async () => {
    if (!user) return;
    setBusy(true);
    const { error } = await supabase.from("study_group_members").insert({ group_id: groupId, user_id: user.id } as any);
    setBusy(false);
    if (error) return toast.error(error.message);
    toast.success("Joined the study group");
    load();
  };

  if (missing) {
    return (
      <div className="rounded-lg border border-border bg-card p-3 text-sm text-muted-foreground max-w-[280px]">
        This study group no longer exists.
      </div>
    );
  }
  if (!group) {
    return <div className="rounded-lg border border-border bg-card p-3 text-sm text-muted-foreground max-w-[280px]">Loading invite…</div>;
  }

  const full = count >= group.max_members;

  return (
    <div className="rounded-lg border border-border bg-card shadow-sm p-3 w-full max-w-[280px] space-y-2">
      <p className="text-xs text-muted-foreground flex items-center gap-1"><Users className="h-3 w-3" /> Study Group Invite</p>
      <p className="text-sm font-semibold text-foreground">{group.title}</p>
      <p className="text-xs text-muted-foreground">
        {group.subject}
        {group.meeting_time ? ` · ${group.meeting_time}` : ""}
        {group.frequency ? ` · ${group.frequency}` : ""}
        {group.location ? ` · ${group.location}` : ""}
      </p>
      {group.content && <p className="text-xs text-muted-foreground line-clamp-2">{group.content}</p>}
      <div className="flex items-center justify-between gap-2 pt-1">
        <Badge variant="secondary">{count}/{group.max_members}</Badge>
        {joined ? (
          <Button size="sm" variant="outline" onClick={() => navigate(`/tutoring?group=${group.id}`)}>
            <Check className="h-4 w-4 mr-1" /> Joined
          </Button>
        ) : (
          <Button size="sm" disabled={busy || full || group.status !== "active"} onClick={join}>
            {full ? "Full" : busy ? "Joining…" : "Join"}
          </Button>
        )}
      </div>
    </div>
  );
}
