import { useEffect, useMemo, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/contexts/AuthContext";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Switch } from "@/components/ui/switch";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { toast } from "sonner";
import { Users, Plus, LogOut, Trash2, Share2, MessageSquare, FileText } from "lucide-react";
import { useSubjectOptions } from "@/lib/subjectOptions";

type Group = {
  id: string;
  creator_id: string;
  title: string;
  subject: string;
  meeting_time: string | null;
  frequency: string | null;
  location: string | null;
  max_members: number;
  content: string | null;
  requirements: string | null;
  is_public: boolean;
  expires_at: string | null;
  status: string;
};

type Member = { group_id: string; user_id: string };
type Conversation = { id: string; name: string | null; is_group: boolean };
type Session = { id?: string; group_id?: string; session_date: string; start_time: string; end_time: string; location: string | null };

const emptyForm = {
  title: "",
  subject: "",
  meeting_time: "",
  frequency: "",
  location: "",
  max_members: 6,
  content: "",
  requirements: "",
  is_public: true,
  expires_at: "",
};

const emptySession = (): Session => ({ session_date: "", start_time: "16:00", end_time: "17:00", location: "" });

export default function StudyGroups() {
  const { user } = useAuth();
  const [groups, setGroups] = useState<Group[]>([]);
  const [members, setMembers] = useState<Member[]>([]);
  const [profiles, setProfiles] = useState<Record<string, string>>({});
  const [conversations, setConversations] = useState<Conversation[]>([]);
  const [form, setForm] = useState({ ...emptyForm });
  const [sessions, setSessions] = useState<Session[]>([emptySession()]);
  const [groupSessions, setGroupSessions] = useState<Record<string, Session[]>>({});
  const [open, setOpen] = useState(false);
  const { subjectNames } = useSubjectOptions();
  const [busy, setBusy] = useState<string | null>(null);
  const [inviteGroup, setInviteGroup] = useState<Group | null>(null);


  const load = async () => {
    const [{ data: g }, { data: m }, { data: p }, { data: s }] = await Promise.all([
      supabase.from("study_groups").select("*").eq("status", "active").order("created_at", { ascending: false }),
      supabase.from("study_group_members").select("group_id,user_id"),
      supabase.from("profiles").select("user_id,name"),
      supabase.from("study_group_sessions").select("*").order("session_date", { ascending: true }),
    ]);
    setGroups(((g as Group[]) || []).filter((x) => !x.expires_at || x.expires_at >= new Date().toISOString().slice(0, 10)));
    setMembers((m as Member[]) || []);
    const map: Record<string, string> = {};
    ((p as { user_id: string; name: string }[]) || []).forEach((x) => { map[x.user_id] = x.name; });
    setProfiles(map);
    const smap: Record<string, Session[]> = {};
    ((s as Session[]) || []).forEach((x) => {
      const gid = x.group_id as string;
      (smap[gid] = smap[gid] || []).push(x);
    });
    setGroupSessions(smap);
  };


  const loadConversations = async () => {
    if (!user) return;
    const { data: mine } = await supabase.from("conversation_members").select("conversation_id").eq("user_id", user.id);
    const ids = (mine || []).map((x: any) => x.conversation_id);
    if (ids.length === 0) { setConversations([]); return; }
    const { data } = await supabase.from("conversations").select("id,name,is_group").in("id", ids);
    const convs = (data as Conversation[]) || [];

    // Resolve display names for direct chats (other participant's name)
    const directIds = convs.filter((c) => !c.is_group).map((c) => c.id);
    let nameByConv: Record<string, string> = {};
    if (directIds.length > 0) {
      const { data: allMembers } = await supabase
        .from("conversation_members")
        .select("conversation_id,user_id")
        .in("conversation_id", directIds);
      const others = (allMembers || []).filter((m: any) => m.user_id !== user.id);
      const otherIds = [...new Set(others.map((m: any) => m.user_id))];
      if (otherIds.length > 0) {
        const { data: profs } = await supabase.from("profiles").select("user_id,name").in("user_id", otherIds);
        const pmap: Record<string, string> = {};
        ((profs as { user_id: string; name: string }[]) || []).forEach((p) => { pmap[p.user_id] = p.name; });
        others.forEach((m: any) => { if (pmap[m.user_id]) nameByConv[m.conversation_id] = pmap[m.user_id]; });
      }
    }

    setConversations(convs.map((c) => ({ ...c, name: c.name || nameByConv[c.id] || null })));
  };


  useEffect(() => { if (user) { load(); loadConversations(); } }, [user]);

  const countFor = (id: string) => members.filter((m) => m.group_id === id).length;
  const joined = (id: string) => members.some((m) => m.group_id === id && m.user_id === user?.id);

  const visibleGroups = useMemo(() => groups, [groups]);

  const create = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user) return;
    if (!form.title.trim() || !form.subject.trim()) return toast.error("Title and subject are required");
    setBusy("create");
    const { data, error } = await supabase.from("study_groups").insert({
      creator_id: user.id,
      title: form.title.trim(),
      subject: form.subject.trim(),
      meeting_time: form.meeting_time || null,
      frequency: form.frequency || null,
      location: form.location || null,
      max_members: Number(form.max_members) || 6,
      content: form.content || null,
      requirements: form.requirements || null,
      is_public: form.is_public,
      expires_at: form.expires_at || null,
    } as any).select().single();
    if (!error && data) {
      const gid = (data as Group).id;
      await supabase.from("study_group_members").insert({ group_id: gid, user_id: user.id } as any);
      const rows = sessions
        .filter((s) => s.session_date && s.start_time && s.end_time)
        .map((s) => ({ group_id: gid, session_date: s.session_date, start_time: s.start_time, end_time: s.end_time, location: s.location || form.location || null }));
      if (rows.length > 0) await supabase.from("study_group_sessions").insert(rows as any);
    }
    setBusy(null);
    if (error) return toast.error(error.message);
    toast.success("Study group created");
    setForm({ ...emptyForm });
    setSessions([emptySession()]);
    setOpen(false);
    load();

  };

  const join = async (g: Group) => {
    if (!user) return;
    setBusy(g.id);
    const { error } = await supabase.from("study_group_members").insert({ group_id: g.id, user_id: user.id } as any);
    setBusy(null);
    if (error) return toast.error(error.message);
    toast.success(`Joined ${g.title}`);
    load();
  };

  const leave = async (g: Group) => {
    if (!user) return;
    setBusy(g.id);
    const { error } = await supabase.from("study_group_members").delete().eq("group_id", g.id).eq("user_id", user.id);
    setBusy(null);
    if (error) return toast.error(error.message);
    toast.success("Left the group");
    load();
  };

  const disband = async (g: Group) => {
    if (!confirm(`Disband "${g.title}"?`)) return;
    setBusy(g.id);
    const { error } = await supabase.from("study_groups").delete().eq("id", g.id);
    setBusy(null);
    if (error) return toast.error(error.message);
    toast.success("Group disbanded");
    load();
  };

  const inviteText = (g: Group) =>
    `📚 Study Group Invite: ${g.title}\nSubject: ${g.subject}` +
    (g.meeting_time ? `\nTime: ${g.meeting_time}` : "") +
    (g.frequency ? `\nFrequency: ${g.frequency}` : "") +
    (g.location ? `\nLocation: ${g.location}` : "") +
    `\nSpots: ${countFor(g.id)}/${g.max_members}` +
    (g.content ? `\nFocus: ${g.content}` : "") +
    (g.requirements ? `\nRequirements: ${g.requirements}` : "") +
    `\nJoin from the Tutoring → Study Group page.`;

  const sendInvite = async (g: Group, conversationId: string) => {
    if (!user) return;
    setBusy(conversationId);
    const { error } = await supabase.from("messages").insert({
      conversation_id: conversationId,
      sender_id: user.id,
      content: `[StudyGroup:${g.id}] ${inviteText(g)}`,
    } as any);
    await supabase.from("conversations").update({ updated_at: new Date().toISOString() }).eq("id", conversationId);
    setBusy(null);
    if (error) return toast.error(error.message);
    toast.success("Invitation sent");
  };

  const postInvite = async (g: Group) => {
    if (!user) return;
    setBusy("post");
    const joinUrl = `${window.location.origin}/tutoring?group=${g.id}`;
    const { error } = await supabase.from("posts").insert({
      title: `Study Group: ${g.title}`,
      content: `<p>${inviteText(g).replace(/\n/g, "<br/>")}</p>` +
        `<p><a href="${joinUrl}">👉 Click here to join this study group</a></p>`,
      author_id: user.id,
    } as any);
    setBusy(null);
    if (error) return toast.error(error.message);
    toast.success("Posted to the feed");
    setInviteGroup(null);
  };

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-lg font-semibold text-foreground flex items-center gap-2">
            <Users className="h-5 w-5 text-primary" /> Study Groups
          </h2>
          <p className="text-sm text-muted-foreground">Create your own group or join an open one.</p>
        </div>
        <Dialog open={open} onOpenChange={setOpen}>
          <DialogTrigger asChild>
            <Button size="sm"><Plus className="h-4 w-4 mr-1" /> Create Group</Button>
          </DialogTrigger>
          <DialogContent className="sm:max-w-lg max-h-[85vh] overflow-y-auto">
            <DialogHeader><DialogTitle>Create a Study Group</DialogTitle></DialogHeader>
            <form onSubmit={create} className="space-y-3">
              <div><Label>Group name</Label><Input value={form.title} onChange={(e) => setForm({ ...form, title: e.target.value })} required /></div>
              <div>
                <Label>Subject (pick one or type your own)</Label>
                <Input
                  list="study-group-subjects"
                  value={form.subject}
                  onChange={(e) => setForm({ ...form, subject: e.target.value })}
                  placeholder="e.g. AP Calculus BC / SAT Reading"
                  required
                />
                <datalist id="study-group-subjects">
                  {subjectNames.map((s) => <option key={s} value={s} />)}
                </datalist>
              </div>
              <div className="grid grid-cols-2 gap-3">
                <div><Label>Recurring note (optional)</Label><Input value={form.meeting_time} onChange={(e) => setForm({ ...form, meeting_time: e.target.value })} placeholder="Tue 16:00–17:30" /></div>
                <div><Label>Frequency (optional)</Label><Input value={form.frequency} onChange={(e) => setForm({ ...form, frequency: e.target.value })} placeholder="Weekly" /></div>
                <div><Label>Default location</Label><Input value={form.location} onChange={(e) => setForm({ ...form, location: e.target.value })} placeholder="Library Room 2" /></div>
                <div><Label>Max members</Label><Input type="number" min={2} max={50} value={form.max_members} onChange={(e) => setForm({ ...form, max_members: Number(e.target.value) })} /></div>
              </div>

              <div className="space-y-2 rounded-lg border border-border/60 p-3">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium">Meeting times</p>
                    <p className="text-xs text-muted-foreground">Add each session separately — they don't have to be weekly</p>
                  </div>
                  <Button type="button" size="sm" variant="outline" onClick={() => setSessions([...sessions, emptySession()])}>
                    <Plus className="h-4 w-4 mr-1" /> Add
                  </Button>
                </div>
                {sessions.map((s, idx) => (
                  <div key={idx} className="grid grid-cols-[1fr_auto_auto_auto] gap-2 items-center">
                    <Input type="date" value={s.session_date} onChange={(e) => setSessions(sessions.map((x, i) => i === idx ? { ...x, session_date: e.target.value } : x))} />
                    <Input type="time" className="w-[110px]" value={s.start_time} onChange={(e) => setSessions(sessions.map((x, i) => i === idx ? { ...x, start_time: e.target.value } : x))} />
                    <Input type="time" className="w-[110px]" value={s.end_time} onChange={(e) => setSessions(sessions.map((x, i) => i === idx ? { ...x, end_time: e.target.value } : x))} />
                    <Button type="button" size="icon" variant="ghost" disabled={sessions.length === 1} onClick={() => setSessions(sessions.filter((_, i) => i !== idx))}>
                      <Trash2 className="h-4 w-4" />
                    </Button>
                    <Input
                      className="col-span-4"
                      placeholder="Location for this session (optional)"
                      value={s.location || ""}
                      onChange={(e) => setSessions(sessions.map((x, i) => i === idx ? { ...x, location: e.target.value } : x))}
                    />
                  </div>
                ))}
              </div>

              <div><Label>What you'll study</Label><Textarea rows={2} value={form.content} onChange={(e) => setForm({ ...form, content: e.target.value })} /></div>
              <div><Label>Requirements</Label><Textarea rows={2} value={form.requirements} onChange={(e) => setForm({ ...form, requirements: e.target.value })} placeholder="e.g. finished Unit 1–3" /></div>
              <div><Label>Ends on (optional)</Label><Input type="date" value={form.expires_at} onChange={(e) => setForm({ ...form, expires_at: e.target.value })} /></div>
              <div className="flex items-center justify-between rounded-lg border border-border/60 p-3">
                <div>
                  <p className="text-sm font-medium">Public group</p>
                  <p className="text-xs text-muted-foreground">Anyone can find and join it here</p>
                </div>
                <Switch checked={form.is_public} onCheckedChange={(v) => setForm({ ...form, is_public: v })} />
              </div>
              <Button type="submit" className="w-full" disabled={busy === "create"}>
                {busy === "create" ? "Creating..." : "Create Group"}
              </Button>
            </form>
          </DialogContent>
        </Dialog>
      </div>

      {visibleGroups.length === 0 ? (
        <Card className="glass-card"><CardContent className="py-10 text-center text-muted-foreground">No study groups yet — create the first one!</CardContent></Card>
      ) : (
        <div className="grid gap-3 md:grid-cols-2">
          {visibleGroups.map((g) => {
            const count = countFor(g.id);
            const full = count >= g.max_members;
            const mine = g.creator_id === user?.id;
            const isMember = joined(g.id);
            return (
              <Card key={g.id} className="glass-card">
                <CardHeader className="pb-2">
                  <div className="flex items-start justify-between gap-2">
                    <div>
                      <CardTitle className="text-base">{g.title}</CardTitle>
                      <CardDescription>{g.subject} · by {profiles[g.creator_id] || "Member"}</CardDescription>
                    </div>
                    <div className="flex flex-col items-end gap-1">
                      <Badge variant={full ? "destructive" : "secondary"}>{full ? "Full" : `${count}/${g.max_members}`}</Badge>
                      {!g.is_public && <Badge variant="outline">Private</Badge>}
                    </div>
                  </div>
                </CardHeader>
                <CardContent className="space-y-2 text-sm">
                  <p className="text-muted-foreground text-xs">
                    {[g.meeting_time, g.frequency, g.location].filter(Boolean).join(" · ") || "Time & place TBD"}
                    {g.expires_at ? ` · until ${g.expires_at}` : ""}
                  </p>
                  {(groupSessions[g.id] || []).length > 0 && (
                    <div className="rounded-lg border border-border/60 p-2 space-y-1">
                      <p className="text-[11px] uppercase tracking-wide text-muted-foreground">Sessions</p>
                      {(groupSessions[g.id] || []).map((s) => (
                        <p key={s.id} className="text-xs text-foreground">
                          {s.session_date} · {s.start_time}–{s.end_time}
                          {s.location ? ` · ${s.location}` : ""}
                        </p>
                      ))}
                    </div>
                  )}

                  {g.content && <p><span className="text-muted-foreground">Focus:</span> {g.content}</p>}
                  {g.requirements && <p><span className="text-muted-foreground">Requirements:</span> {g.requirements}</p>}
                  <div className="flex flex-wrap gap-2 pt-1">
                    {isMember ? (
                      mine ? (
                        <Button size="sm" variant="destructive" disabled={busy === g.id} onClick={() => disband(g)}>
                          <Trash2 className="h-4 w-4 mr-1" /> Disband
                        </Button>
                      ) : (
                        <Button size="sm" variant="outline" disabled={busy === g.id} onClick={() => leave(g)}>
                          <LogOut className="h-4 w-4 mr-1" /> Leave
                        </Button>
                      )
                    ) : (
                      <Button size="sm" disabled={full || busy === g.id || !g.is_public} onClick={() => join(g)}>
                        {full ? "Full" : g.is_public ? "Join" : "Invite only"}
                      </Button>
                    )}
                    <Button size="sm" variant="outline" onClick={() => setInviteGroup(g)}>
                      <Share2 className="h-4 w-4 mr-1" /> Invite
                    </Button>
                  </div>
                </CardContent>
              </Card>
            );
          })}
        </div>
      )}

      <Dialog open={!!inviteGroup} onOpenChange={(o) => !o && setInviteGroup(null)}>
        <DialogContent className="sm:max-w-md max-h-[80vh] overflow-y-auto">
          <DialogHeader><DialogTitle>Invite to {inviteGroup?.title}</DialogTitle></DialogHeader>
          {inviteGroup && (
            <div className="space-y-4">
              <div>
                <p className="text-sm font-medium flex items-center gap-1 mb-2"><MessageSquare className="h-4 w-4" /> Send in chat</p>
                {conversations.length === 0 ? (
                  <p className="text-sm text-muted-foreground">No chats yet.</p>
                ) : (
                  <div className="space-y-1">
                    {conversations.map((c) => (
                      <div key={c.id} className="flex items-center justify-between rounded-lg border border-border/60 px-3 py-2">
                        <span className="text-sm truncate">{c.name || (c.is_group ? "Group chat" : "Direct chat")}</span>
                        <Button size="sm" variant="outline" disabled={busy === c.id} onClick={() => sendInvite(inviteGroup, c.id)}>Send</Button>
                      </div>
                    ))}
                  </div>
                )}
              </div>
              <Button className="w-full" variant="secondary" disabled={busy === "post"} onClick={() => postInvite(inviteGroup)}>
                <FileText className="h-4 w-4 mr-1" /> Share as a post
              </Button>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}
