/**
 * CountdownScene3D — 3D rotating countdown number used inside MatchIntroOverlay.
 *
 * Renders the current number as a chunky extruded text mesh that pops in,
 * spins on its Y-axis, and pulses with an emissive glow. The parent component
 * controls which number is displayed (3 → 2 → 1) by changing the `num` prop.
 */
import { Canvas, useFrame } from "@react-three/fiber";
import { Suspense, useRef, useMemo } from "react";
import { CanvasTexture, type Mesh, type Texture } from "three";

interface Props {
  num: number;
  /** Tailwind/Tailwind-ish glow color for the number's emissive material. */
  isFinals?: boolean;
}

export default function CountdownScene3D({ num, isFinals = false }: Props) {
  return (
    <div className="h-full w-full">
      <Canvas
        camera={{ position: [0, 0, 6], fov: 45 }}
        gl={{ antialias: true, alpha: true }}
        dpr={[1, 2]}
      >
        <Suspense fallback={null}>
          <ambientLight intensity={0.5} />
          <directionalLight position={[5, 8, 6]} intensity={1.4} color="#ffffff" />
          <pointLight position={[-4, -3, 4]} intensity={1.0} color={isFinals ? "#fcd34d" : "#60a5fa"} />
          <pointLight position={[0, 0, 5]} intensity={1.5} color={isFinals ? "#fbbf24" : "#3b82f6"} />
          <SpinningNumber num={num} isFinals={isFinals} />
        </Suspense>
      </Canvas>
    </div>
  );
}

function SpinningNumber({ num, isFinals }: { num: number; isFinals: boolean }) {
  const meshRef = useRef<Mesh>(null);
  const startRef = useRef<number>(performance.now());
  const texture = useMemo(() => makeDigitTexture(num, isFinals), [num, isFinals]);

  useFrame(() => {
    if (!meshRef.current) return;
    const t = (performance.now() - startRef.current) / 1000;
    // Pop-in scale: starts big (1.6) and settles to 1 over 0.4s
    const pop = t < 0.4 ? 1 + (1 - t / 0.4) * 0.6 : 1;
    // Continuous Y-spin
    meshRef.current.rotation.y = t * 2.6;
    // Subtle wobble on X
    meshRef.current.rotation.x = Math.sin(t * 3) * 0.08;
    meshRef.current.scale.setScalar(pop);
  });

  return (
    <mesh ref={meshRef} key={num} castShadow>
      <boxGeometry args={[2.6, 3.4, 0.6]} />
      <meshStandardMaterial
        map={texture}
        emissiveMap={texture}
        emissive={isFinals ? "#facc15" : "#3b82f6"}
        emissiveIntensity={0.9}
        metalness={0.5}
        roughness={0.25}
      />
    </mesh>
  );
}

/** Build a CanvasTexture displaying the digit on a transparent background. */
function makeDigitTexture(num: number, isFinals: boolean): Texture {
  const size = 512;
  const canvas = document.createElement("canvas");
  canvas.width = size;
  canvas.height = size;
  const ctx = canvas.getContext("2d")!;
  // Background — soft radial so the digit pops against the dim arena
  const bg = ctx.createRadialGradient(size / 2, size / 2, 50, size / 2, size / 2, size / 2);
  bg.addColorStop(0, isFinals ? "rgba(120,80,5,0.95)" : "rgba(15,30,80,0.95)");
  bg.addColorStop(1, "rgba(5,5,15,0.92)");
  ctx.fillStyle = bg;
  ctx.fillRect(0, 0, size, size);

  // Digit
  ctx.fillStyle = isFinals ? "#fde68a" : "#dbeafe";
  ctx.strokeStyle = isFinals ? "#f59e0b" : "#1d4ed8";
  ctx.lineWidth = 14;
  ctx.font = "bold 380px system-ui, -apple-system, sans-serif";
  ctx.textAlign = "center";
  ctx.textBaseline = "middle";
  ctx.shadowColor = isFinals ? "rgba(251,191,36,0.9)" : "rgba(59,130,246,0.9)";
  ctx.shadowBlur = 40;
  ctx.fillText(String(num), size / 2, size / 2 + 18);
  ctx.strokeText(String(num), size / 2, size / 2 + 18);

  const tex = new CanvasTexture(canvas);
  tex.needsUpdate = true;
  tex.anisotropy = 8;
  return tex;
}
