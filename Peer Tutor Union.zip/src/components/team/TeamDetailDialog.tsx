/**
 * TeamDetailDialog — Read-only inspector for any team on the leaderboard.
 * Shows honors (Tour Champion titles), finances (coins, league progress),
 * the full owned roster and the active starting lineup.
 *
 * Pure UI — receives all data already loaded by the parent (LeaderboardDialog).
 */
import { useEffect, useState } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from "@/components/ui/dialog";
import { Card } from "@/components/ui/card";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Badge } from "@/components/ui/badge";
import { Trophy, Crown, Wallet, Users, Star, DollarSign } from "lucide-react";
import TourChampionBadge from "./TourChampionBadge";
import PlayerAvatar from "./PlayerAvatar";
import {
  LEAGUE_META,
  LEAGUE_ORDER,
  RARITY_META,
  getEffectiveStats,
  isEvolved,
  getEvolutionTier,
  loadOwnedCards,
  type League,
  type PlayerCard,
  type PlayerTemplate,
  type TeamManager,
} from "@/lib/teamManager";

/** Returns the animated text class for a card's name based on rarity / evolved state.
 *  Evolved (black-gold) cards use a WHITE name with gold glow so it stays
 *  readable against the dark+gold surface (gold-on-gold becomes invisible). */
function nameFxClass(card: PlayerCard, template: PlayerTemplate): string {
  if (isEvolved(card)) return "evolved-name";
  if (template.rarity === "legendary") return "legendary-text";
  if (template.rarity === "epic") return "epic-text";
  return "";
}

interface Props {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  team: TeamManager;
  profileName: string;
  /** Starting lineup (already resolved by parent). */
  lineup: { card: PlayerCard; template: PlayerTemplate }[];
}


export default function TeamDetailDialog({ open, onOpenChange, team, profileName, lineup }: Props) {
  const [allCards, setAllCards] = useState<{ card: PlayerCard; template: PlayerTemplate }[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!open) return;
    let cancelled = false;
    setLoading(true);
    loadOwnedCards(team.user_id).then(cards => {
      if (cancelled) return;
      setAllCards(cards);
      setLoading(false);
    });
    return () => { cancelled = true; };
  }, [open, team.user_id]);

  const rawLeague = team.current_league as League;
  const safeLeague: League = LEAGUE_META[rawLeague] ? rawLeague : "nba";
  const meta = LEAGUE_META[safeLeague];
  const wcTitles = team.wc_titles ?? 0;
  const lineupIds = new Set(lineup.map(l => l.card.id));
  const lineupOvr = lineup.reduce((s, { card, template }) => s + getEffectiveStats(card, template).total, 0);

  // Per-season World Tour history: [{year, medal}]. Newest year shown first.
  const tourTitles = (((team as any).world_tour_titles ?? []) as Array<{ year: number; medal: string }>)
    .slice()
    .sort((a, b) => b.year - a.year);
  const currentTourSeason = (team as any).current_tour_season ?? 26;
  // Show "Currently in N World Tour" ONLY when this team has never won a World Tour title
  // (no gold). Champions display their title instead.
  const hasGold = tourTitles.some(t => t.medal === "gold");
  const showCurrentlyTour = !hasGold;

  const medalIcon = (m: string) => m === "gold" ? "🏆" : m === "silver" ? "🥈" : m === "bronze" ? "🥉" : "🏅";
  const medalLabel = (m: string) => m === "gold" ? "World Tour Champion" : m === "silver" ? "World Tour 2nd Place" : m === "bronze" ? "World Tour 3rd Place" : "World Tour Finalist";
  const medalRing = (m: string) => m === "gold"
    ? "from-amber-500/30 via-yellow-400/30 to-amber-500/30 ring-amber-400/60 text-amber-100"
    : m === "silver"
    ? "from-slate-400/30 via-slate-200/30 to-slate-400/30 ring-slate-300/60 text-slate-100"
    : "from-orange-700/30 via-orange-500/30 to-orange-700/30 ring-orange-500/60 text-orange-100";

  // Derive league championships from progression. A team has "championed" a
  // league when they've moved past it. The current top league (NBA Masters)
  // counts as championed only after the player has cleared its promotion
  // wins (which unlocks World Tour but doesn't bump current_league).
  const leagueChampionships: League[] = (() => {
    const idx = LEAGUE_ORDER.indexOf(safeLeague);
    if (idx < 0) return [];
    const cleared = LEAGUE_ORDER.slice(0, idx); // every league before current
    const top = LEAGUE_META[safeLeague];
    if (top.next === null && (team.league_wins ?? 0) >= top.promotionWins) {
      return [...cleared, safeLeague]; // also cleared the top league
    }
    return cleared;
  })();

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-2xl h-[85vh] !grid-cols-none !flex flex-col gap-3 overflow-hidden">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-3 flex-wrap">
            {team.team_logo_url ? (
              <img src={team.team_logo_url} alt={team.team_name} className="h-10 w-10 rounded-full object-cover ring-1 ring-border" />
            ) : (
              <span className="text-2xl">{team.team_emoji}</span>
            )}
            <span className="truncate">{team.team_name}</span>
            {tourTitles.filter(t => t.medal === "gold").length > 0 && (
              <TourChampionBadge count={tourTitles.filter(t => t.medal === "gold").length} size="md" />
            )}
          </DialogTitle>
          <DialogDescription>
            Manager: <span className="text-foreground font-medium">{profileName}</span>
          </DialogDescription>
        </DialogHeader>

        <ScrollArea className="flex-1 -mx-2 px-2">
          <div className="space-y-4 pb-2">

            {/* ── Honors ── */}
            <section>
              <h3 className="text-sm font-bold mb-2 flex items-center gap-1.5">
                <Crown className="h-4 w-4 text-amber-500" /> Honors
              </h3>
              <div className="flex flex-wrap gap-2">
                {/* Per-season World Tour podium finishes (newest first) */}
                {tourTitles.map((t, idx) => (
                  <span
                    key={`${t.year}-${idx}`}
                    title={`${t.year} World Tour · ${medalLabel(t.medal)}`}
                    className={`inline-flex items-center gap-1 rounded-full px-2 py-0.5 text-xs font-bold ring-1 bg-gradient-to-r ${medalRing(t.medal)} shrink-0`}
                  >
                    <span>{medalIcon(t.medal)}</span>
                    <span className="tracking-wide">{t.year} {medalLabel(t.medal)}</span>
                  </span>
                ))}
                {/* League ladder championships */}
                {leagueChampionships.slice().reverse().map(l => {
                  const m = LEAGUE_META[l];
                  return (
                    <span
                      key={l}
                      title={`${m.label} Champion`}
                      className="inline-flex items-center gap-1 rounded-full px-2 py-0.5 text-xs font-bold ring-1 ring-border bg-gradient-to-r from-yellow-500/20 via-amber-400/20 to-yellow-500/20 text-foreground shrink-0"
                    >
                      <span>{m.emoji}</span>
                      <span className="tracking-wide">{m.label.replace(" League", "")} Champion</span>
                    </span>
                  );
                })}
                {/* Currently in {N} World Tour — only if no Tour gold yet */}
                {showCurrentlyTour && (
                  <Badge variant="outline" className="gap-1">
                    🌍 {currentTourSeason} World Tour
                  </Badge>
                )}
                <Badge variant="outline" className="gap-1">
                  <Trophy className="h-3 w-3 text-yellow-500" /> {team.total_wins}W – {team.total_losses}L
                </Badge>
                {tourTitles.length === 0 && leagueChampionships.length === 0 && !showCurrentlyTour && (
                  <span className="text-xs text-muted-foreground self-center">No championships yet</span>
                )}
              </div>
            </section>

            {/* ── Finance ── */}
            <section>
              <h3 className="text-sm font-bold mb-2 flex items-center gap-1.5">
                <Wallet className="h-4 w-4 text-emerald-500" /> Finance
              </h3>
              <Card className="p-3 flex items-center gap-4 flex-wrap">
                <div className="flex items-center gap-1.5">
                  <DollarSign className="h-4 w-4 text-emerald-500" />
                  <span className="text-lg font-bold tabular-nums">{(team.coins ?? 0).toLocaleString()}</span>
                  <span className="text-xs text-muted-foreground">coins</span>
                </div>
                <div className="text-xs text-muted-foreground">
                  League progress: <span className="text-foreground font-semibold">{team.league_wins ?? 0}</span> wins
                </div>
              </Card>
            </section>

            {/* ── Starting Lineup ── */}
            <section>
              <h3 className="text-sm font-bold mb-2 flex items-center gap-1.5">
                <Star className="h-4 w-4 text-yellow-500" /> Starting Lineup
                {lineup.length > 0 && (
                  <span className="text-xs font-normal text-muted-foreground ml-1">
                    · OVR <span className="text-foreground font-semibold">{lineupOvr}</span>
                  </span>
                )}
              </h3>
              {lineup.length === 0 ? (
                <Card className="p-4 text-center text-xs text-muted-foreground">No starting lineup set</Card>
              ) : (
                <div className="grid grid-cols-3 sm:grid-cols-3 gap-2">
                  {lineup.map(({ card, template }) => {
                    const eff = getEffectiveStats(card, template);
                    const rmeta = RARITY_META[template.rarity as keyof typeof RARITY_META];
                    const evolved = isEvolved(card);
                    const evoTier = getEvolutionTier(card);
                    const fx = nameFxClass(card, template);
                    return (
                      <Card
                        key={card.id}
                        className={`relative p-2 flex flex-col items-center gap-1.5 text-center ${evolved ? "evolved-card" : `bg-gradient-to-br ${rmeta?.bg ?? ""}`} ring-2 ring-yellow-500/60 overflow-hidden`}
                      >
                        <div className={evolved ? "evolved-stripe absolute top-0 left-0 right-0" : "hidden"} />
                        <Star className="absolute -top-1 -right-1 h-4 w-4 text-yellow-500 fill-yellow-500 z-10" />
                        <PlayerAvatar template={template} size="lg" />
                        <div className={`text-xs font-bold truncate w-full ${fx}`}>
                          {template.name}
                          {evolved && <span className="ml-1 evolved-text">✨{evoTier > 1 ? `×${evoTier}` : ""}</span>}
                        </div>
                        <div className={`text-[10px] font-semibold ${evolved ? "evolved-text" : (fx || rmeta?.color || "")}`}>{rmeta?.label ?? template.rarity}</div>
                        <div className="text-[10px] text-muted-foreground">
                          OVR <span className="text-foreground font-bold">{eff.total}</span> · Lv {card.level}
                        </div>
                      </Card>
                    );
                  })}
                </div>
              )}
            </section>

            {/* ── Full Roster ── */}
            <section>
              <h3 className="text-sm font-bold mb-2 flex items-center gap-1.5">
                <Users className="h-4 w-4 text-blue-500" /> All Players
                <span className="text-xs font-normal text-muted-foreground ml-1">
                  · {loading ? "…" : allCards.length}
                </span>
              </h3>
              {loading ? (
                <p className="text-center text-xs text-muted-foreground py-4">Loading roster…</p>
              ) : allCards.length === 0 ? (
                <Card className="p-4 text-center text-xs text-muted-foreground">No players</Card>
              ) : (
                <div className="grid grid-cols-3 sm:grid-cols-4 md:grid-cols-5 gap-2">
                  {allCards
                    .slice()
                    .sort((a, b) => getEffectiveStats(b.card, b.template).total - getEffectiveStats(a.card, a.template).total)
                    .map(({ card, template }) => {
                      const eff = getEffectiveStats(card, template);
                      const isStarter = lineupIds.has(card.id);
                      const rmeta = RARITY_META[template.rarity as keyof typeof RARITY_META];
                      const evolved = isEvolved(card);
                      const evoTier = getEvolutionTier(card);
                      // Shimmer effects only apply for starters (per request).
                      const fx = isStarter ? nameFxClass(card, template) : "";
                      const useEvolvedSurface = evolved && isStarter;
                      return (
                        <Card
                          key={card.id}
                          className={`relative p-2 flex flex-col items-center gap-1 text-center overflow-hidden ${useEvolvedSurface ? "evolved-card" : `bg-gradient-to-br ${rmeta?.bg ?? ""}`} ${isStarter ? "ring-2 ring-yellow-500/60" : ""}`}
                        >
                          {useEvolvedSurface && <div className="evolved-stripe absolute top-0 left-0 right-0" />}
                          {isStarter && (
                            <Star className="absolute -top-1 -right-1 h-4 w-4 text-yellow-500 fill-yellow-500 z-10" />
                          )}
                          <PlayerAvatar template={template} size="md" />
                          <div className={`text-[11px] font-semibold truncate w-full ${fx}`}>
                            {template.name}
                            {evolved && isStarter && <span className="ml-0.5 evolved-text">✨{evoTier > 1 ? `×${evoTier}` : ""}</span>}
                          </div>
                          <div className={`text-[10px] font-semibold ${useEvolvedSurface ? "evolved-text" : (fx || rmeta?.color || "")}`}>{rmeta?.label ?? template.rarity}</div>
                          <div className="text-[10px] text-muted-foreground">
                            OVR <span className="text-foreground font-bold">{eff.total}</span>
                          </div>
                        </Card>
                      );
                    })}
                </div>
              )}
            </section>

          </div>
        </ScrollArea>
      </DialogContent>
    </Dialog>
  );
}
