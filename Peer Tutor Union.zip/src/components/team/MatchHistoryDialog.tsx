/**
 * MatchHistoryDialog — Recent league matches table.
 */
import { useEffect, useState } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { ScrollArea } from "@/components/ui/scroll-area";
import { LEAGUE_META, loadMatchHistory, type MatchHistory } from "@/lib/teamManager";
import { formatDistanceToNow } from "date-fns";

interface Props {
  open: boolean;
  onOpenChange: (o: boolean) => void;
  userId: string | null;
}

export default function MatchHistoryDialog({ open, onOpenChange, userId }: Props) {
  const [rows, setRows] = useState<MatchHistory[]>([]);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    if (!open || !userId) return;
    setLoading(true);
    loadMatchHistory(userId).then(r => { setRows(r); setLoading(false); });
  }, [open, userId]);

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-2xl max-h-[80vh] flex flex-col">
        <DialogHeader><DialogTitle>📜 Match History</DialogTitle></DialogHeader>
        <ScrollArea className="flex-1">
          {loading ? (
            <p className="text-center py-8 text-sm text-muted-foreground">Loading…</p>
          ) : rows.length === 0 ? (
            <p className="text-center py-8 text-sm text-muted-foreground">No matches yet — go play some league games!</p>
          ) : (
            <div className="space-y-1.5">
              {rows.map(r => {
                const meta = LEAGUE_META[r.league as keyof typeof LEAGUE_META];
                return (
                  <div key={r.id} className="flex items-center gap-3 p-2 rounded bg-card/50 border border-border/40">
                    <div className="text-2xl">{meta?.emoji ?? "🏀"}</div>
                    <div className="flex-1 min-w-0">
                      <div className="font-semibold text-sm">{meta?.label ?? r.league}</div>
                      <div className="text-[11px] text-muted-foreground">
                        {formatDistanceToNow(new Date(r.created_at), { addSuffix: true })}
                      </div>
                    </div>
                    <div className="text-center">
                      <div className="text-xs text-muted-foreground">Score</div>
                      <div className="font-mono font-bold">{r.player_score} : {r.ai_score}</div>
                    </div>
                    <div className={`font-bold text-sm w-12 text-right ${r.won ? "text-green-400" : "text-red-400"}`}>
                      {r.won ? "W" : "L"}
                    </div>
                    <div className={`font-mono text-sm w-20 text-right ${r.coins_change >= 0 ? "text-yellow-400" : "text-red-400"}`}>
                      {r.coins_change >= 0 ? "+$" : "-$"}{Math.abs(r.coins_change).toLocaleString()}
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </ScrollArea>
      </DialogContent>
    </Dialog>
  );
}
