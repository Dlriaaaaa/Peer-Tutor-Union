/**
 * ChampionVictoryOverlay — Cinematic full-screen victory celebration
 * shown after a player WINS the World Tour Final (gold medal).
 *
 * Sequence (~9s):
 *   1. Spotlight + confetti burst
 *   2. 3D rotating trophy rises onto a 1st-place podium
 *   3. "WORLD CHAMPION" banner sweeps in
 *   4. Prize counter rolls from 0 → 1,000,000,000 coins
 *   5. "Continue" button appears
 *
 * Pure presentation — no backend writes happen here. The parent
 * is responsible for persisting the reward.
 */
import { Suspense, lazy, useEffect, useMemo, useRef, useState } from "react";
import { createPortal } from "react-dom";
import { Button } from "@/components/ui/button";
import { Trophy, Sparkles } from "lucide-react";

const TrophyScene3D = lazy(() => import("./TrophyScene3D"));

interface Props {
  championName: string;
  championEmoji: string;
  championLogoUrl: string | null;
  finalScore: { you: number; them: number };
  prizeCoins: number;
  onContinue: () => void;
}

export default function ChampionVictoryOverlay({
  championName,
  championEmoji,
  championLogoUrl,
  finalScore,
  prizeCoins,
  onContinue,
}: Props) {
  const [phase, setPhase] = useState<"intro" | "trophy" | "banner" | "prize" | "done">("intro");

  useEffect(() => {
    const t1 = setTimeout(() => setPhase("trophy"), 800);
    const t2 = setTimeout(() => setPhase("banner"), 2200);
    const t3 = setTimeout(() => setPhase("prize"), 3600);
    const t4 = setTimeout(() => setPhase("done"), 7800);
    return () => { [t1, t2, t3, t4].forEach(clearTimeout); };
  }, []);

  // Animated rolling counter for the prize amount
  const animatedPrize = useRollingCounter(phase === "prize" || phase === "done" ? prizeCoins : 0, 2200);

  // Pre-built confetti list (deterministic across re-renders)
  const confetti = useMemo(() => buildConfetti(120), []);

  return createPortal(
    <div className="fixed inset-0 z-[9999] flex items-center justify-center bg-gradient-to-b from-black via-amber-950/40 to-black overflow-hidden">
      {/* ── Radial spotlight ── */}
      <div className="pointer-events-none absolute inset-0 bg-[radial-gradient(ellipse_at_center,rgba(250,204,21,0.25)_0%,rgba(0,0,0,0.95)_70%)]" />

      {/* ── God rays ── */}
      <div className="pointer-events-none absolute inset-0 opacity-60 mix-blend-screen">
        {Array.from({ length: 14 }).map((_, i) => (
          <div
            key={i}
            className="absolute left-1/2 top-1/2 origin-top h-[140vh] w-[3vw] bg-gradient-to-b from-amber-300/40 via-amber-200/10 to-transparent blur-md animate-[ray-spin_18s_linear_infinite]"
            style={{ transform: `translate(-50%,-10%) rotate(${(360 / 14) * i}deg)`, animationDelay: `${i * 0.1}s` }}
          />
        ))}
      </div>

      {/* ── Confetti ── */}
      <div className="pointer-events-none absolute inset-0 overflow-hidden">
        {confetti.map((c, i) => (
          <span
            key={i}
            className="absolute block rounded-sm"
            style={{
              left: `${c.left}%`,
              top: `-10%`,
              width: c.size,
              height: c.size * 0.4,
              background: c.color,
              transform: `rotate(${c.rot}deg)`,
              animation: `confetti-fall ${c.dur}s linear ${c.delay}s infinite`,
              opacity: 0.9,
            }}
          />
        ))}
      </div>

      {/* ── Center stage ── */}
      <div className="relative w-full max-w-3xl mx-auto px-6 flex flex-col items-center gap-4">
        {/* Top label */}
        <div
          className={`text-[10px] sm:text-xs uppercase tracking-[0.5em] text-amber-300 font-bold drop-shadow-[0_0_12px_rgba(250,204,21,0.9)] transition-all duration-700 ${
            phase === "intro" ? "opacity-0 -translate-y-4" : "opacity-100 translate-y-0"
          }`}
        >
          ✦ World Tour Finals · Shanghai ✦
        </div>

        {/* Trophy stage */}
        <div className="relative h-[260px] sm:h-[320px] w-[280px] sm:w-[360px] flex items-end justify-center">
          {/* Trophy rises into view */}
          <div
            className={`absolute inset-0 transition-all duration-1000 ease-out ${
              phase === "intro"
                ? "opacity-0 translate-y-24 scale-75"
                : "opacity-100 translate-y-0 scale-100"
            }`}
          >
            <Suspense fallback={<div className="h-full w-full flex items-center justify-center text-7xl">🏆</div>}>
              <TrophyScene3D />
            </Suspense>
          </div>
          {/* Glow halo behind trophy */}
          <div className="pointer-events-none absolute -inset-8 rounded-full bg-amber-400/30 blur-3xl animate-pulse" />
        </div>

        {/* Banner */}
        <div
          className={`relative transition-all duration-700 ${
            phase === "intro" || phase === "trophy"
              ? "opacity-0 translate-y-6 scale-90"
              : "opacity-100 translate-y-0 scale-100"
          }`}
        >
          <div className="text-3xl sm:text-6xl font-black text-transparent bg-clip-text bg-gradient-to-r from-yellow-200 via-amber-300 to-orange-300 drop-shadow-[0_0_28px_rgba(250,204,21,0.7)] tracking-wider">
            WORLD CHAMPION
          </div>
          <div className="mt-2 flex items-center justify-center gap-3 text-sm sm:text-base text-amber-100/90 font-semibold">
            {championLogoUrl ? (
              <img src={championLogoUrl} alt={championName} className="h-8 w-8 rounded-full ring-2 ring-amber-300 object-cover" />
            ) : (
              <span className="text-2xl">{championEmoji}</span>
            )}
            <span className="truncate max-w-[14rem]">{championName}</span>
            <span className="px-2 py-0.5 rounded bg-amber-500/20 ring-1 ring-amber-400/40 text-amber-200 text-xs font-bold">
              Final {finalScore.you}–{finalScore.them}
            </span>
          </div>
        </div>

        {/* Podium */}
        <div className="mt-2 flex items-end justify-center gap-2 sm:gap-3 w-full max-w-md">
          <PodiumStep place={2} height={48} delay={0.2} show={phase !== "intro"} />
          <PodiumStep place={1} height={84} delay={0} show={phase !== "intro"} highlight />
          <PodiumStep place={3} height={36} delay={0.35} show={phase !== "intro"} />
        </div>

        {/* Prize */}
        <div
          className={`relative mt-2 transition-all duration-700 ${
            phase === "prize" || phase === "done"
              ? "opacity-100 translate-y-0 scale-100"
              : "opacity-0 translate-y-4 scale-95"
          }`}
        >
          <div className="flex items-center gap-3 px-5 py-3 rounded-2xl bg-gradient-to-br from-amber-500/20 via-yellow-400/10 to-orange-500/20 ring-2 ring-amber-300/50 shadow-[0_0_40px_rgba(250,204,21,0.4)]">
            <Sparkles className="h-6 w-6 text-amber-300 animate-pulse" />
            <div className="flex flex-col items-center">
              <div className="text-[10px] uppercase tracking-[0.3em] text-amber-200/90 font-bold">Grand Prize</div>
              <div className="text-2xl sm:text-4xl font-black tabular-nums text-transparent bg-clip-text bg-gradient-to-r from-yellow-200 to-amber-400 drop-shadow-[0_0_18px_rgba(250,204,21,0.8)]">
                {animatedPrize.toLocaleString()} 🪙
              </div>
              <div className="text-[10px] uppercase tracking-[0.3em] text-amber-300/80 font-bold">
                ✦ One Billion Coins ✦
              </div>
            </div>
            <Trophy className="h-6 w-6 text-amber-300 animate-pulse" />
          </div>
        </div>

        {/* Continue */}
        <div
          className={`mt-4 transition-all duration-500 ${
            phase === "done" ? "opacity-100 translate-y-0" : "opacity-0 translate-y-4 pointer-events-none"
          }`}
        >
          <Button
            size="lg"
            onClick={onContinue}
            className="bg-gradient-to-r from-amber-500 via-yellow-500 to-amber-600 text-slate-900 font-extrabold px-8 shadow-[0_0_24px_rgba(250,204,21,0.6)] hover:shadow-[0_0_40px_rgba(250,204,21,0.9)] hover:scale-[1.03] transition-all"
          >
            🏆 Claim Your Crown
          </Button>
        </div>
      </div>

      {/* ── Local keyframes ── */}
      <style>{`
        @keyframes confetti-fall {
          0%   { transform: translateY(-10vh) rotate(0deg); }
          100% { transform: translateY(120vh) rotate(720deg); }
        }
        @keyframes ray-spin {
          from { transform: translate(-50%,-10%) rotate(0deg); }
          to   { transform: translate(-50%,-10%) rotate(360deg); }
        }
        @keyframes podium-rise {
          from { transform: translateY(60px) scaleY(0.4); opacity: 0; }
          to   { transform: translateY(0) scaleY(1); opacity: 1; }
        }
      `}</style>
    </div>,
    document.body
  );
}

// ─────────────────────────────────────────────
function PodiumStep({
  place,
  height,
  delay,
  show,
  highlight,
}: { place: 1 | 2 | 3; height: number; delay: number; show: boolean; highlight?: boolean }) {
  const colors: Record<number, string> = {
    1: "from-yellow-300 via-amber-400 to-orange-500",
    2: "from-slate-200 via-slate-300 to-slate-500",
    3: "from-amber-700 via-orange-700 to-amber-900",
  };
  const labels: Record<number, string> = { 1: "1st", 2: "2nd", 3: "3rd" };
  return (
    <div className="flex flex-col items-center" style={{ width: "30%" }}>
      <div
        className={`relative w-full rounded-t-md bg-gradient-to-b ${colors[place]} ring-2 ${
          highlight ? "ring-amber-200/70 shadow-[0_-6px_24px_rgba(250,204,21,0.6)]" : "ring-white/20"
        } origin-bottom`}
        style={{
          height: `${height * 1.6}px`,
          animation: show ? `podium-rise 0.7s ease-out ${delay}s backwards` : "none",
          opacity: show ? 1 : 0,
        }}
      >
        <div className="absolute inset-0 flex items-center justify-center">
          <span className={`text-lg sm:text-2xl font-black ${highlight ? "text-slate-900" : "text-white/90"} drop-shadow`}>
            {labels[place]}
          </span>
        </div>
        {highlight && (
          <div className="absolute -top-3 left-1/2 -translate-x-1/2 text-2xl">🏆</div>
        )}
      </div>
    </div>
  );
}

// ─────────────────────────────────────────────
function useRollingCounter(target: number, durationMs: number): number {
  const [val, setVal] = useState(0);
  const startedRef = useRef(false);
  const startTsRef = useRef(0);
  useEffect(() => {
    if (target === 0) { setVal(0); startedRef.current = false; return; }
    if (startedRef.current) return;
    startedRef.current = true;
    startTsRef.current = performance.now();
    let raf = 0;
    const tick = () => {
      const t = (performance.now() - startTsRef.current) / durationMs;
      if (t >= 1) { setVal(target); return; }
      // Ease-out cubic
      const eased = 1 - Math.pow(1 - t, 3);
      setVal(Math.floor(eased * target));
      raf = requestAnimationFrame(tick);
    };
    raf = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(raf);
  }, [target, durationMs]);
  return val;
}

// ─────────────────────────────────────────────
function buildConfetti(n: number) {
  const palette = ["#fbbf24", "#f59e0b", "#fde68a", "#fef3c7", "#facc15", "#f97316", "#ffffff"];
  return Array.from({ length: n }).map(() => ({
    left: Math.random() * 100,
    size: 6 + Math.random() * 10,
    color: palette[Math.floor(Math.random() * palette.length)],
    rot: Math.random() * 360,
    dur: 3 + Math.random() * 4,
    delay: Math.random() * 5,
  }));
}
