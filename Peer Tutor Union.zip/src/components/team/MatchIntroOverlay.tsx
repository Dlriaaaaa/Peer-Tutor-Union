/**
 * MatchIntroOverlay — Pre-match cinematic shown ON TOP of the live basketball court.
 *
 * The actual players are already rendered on the court behind this overlay
 * (the game is auto-started but paused). So this overlay only needs to show:
 *   1. "trophy" — (World Champion only) Big 3D rotating gold trophy + 'WORLD CHAMPION' banner ~3s
 *   2. "vs"     ~2.0s — Team-vs-team logo banner sliding in
 *   3. "countdown" — Big "3 · 2 · 1" countdown (or 10 → 1 for World Champion)
 * Total ≈ 5s normally, ≈ 15s for World Champion.
 */
import { useEffect, useState, Suspense, lazy } from "react";

interface TeamSide {
  name: string;
  emoji: string;
  logoUrl: string | null;
  jerseyColor: string;
  count: number;
  /** Optional country/region label shown under the team name (e.g. "🇺🇸 USA"). */
  country?: string;
}

interface Props {
  home: TeamSide;
  away: TeamSide;
  leagueLabel?: string;
  /** When true, show extra 3D trophy intro and use a 10-second countdown.
   *  Used for World Tour Finals (and any other "championship-tier" stage). */
  isFinals?: boolean;
  onComplete: () => void;
}

type Phase = "trophy" | "vs" | "countdown";

// Lazy-load the heavy three.js scenes only when they're actually needed.
const TrophyScene3D = lazy(() => import("./TrophyScene3D"));
const CountdownScene3D = lazy(() => import("./CountdownScene3D"));

export default function MatchIntroOverlay({ home, away, leagueLabel, isFinals, onComplete }: Props) {
  const [phase, setPhase] = useState<Phase>(isFinals ? "trophy" : "vs");
  const countdownStart = isFinals ? 10 : 3;
  const [countNum, setCountNum] = useState(countdownStart);

  useEffect(() => {
    if (phase === "trophy") {
      const t = setTimeout(() => setPhase("vs"), 3000);
      return () => clearTimeout(t);
    }
    if (phase === "vs") {
      const t = setTimeout(() => setPhase("countdown"), 2000);
      return () => clearTimeout(t);
    }
    // Countdown phase — tick once per second
    setCountNum(countdownStart);
    const timers: number[] = [];
    for (let i = 1; i < countdownStart; i++) {
      timers.push(window.setTimeout(() => setCountNum(countdownStart - i), i * 1000));
    }
    timers.push(window.setTimeout(() => onComplete(), countdownStart * 1000));
    return () => { timers.forEach(clearTimeout); };
  }, [phase, onComplete, countdownStart]);

  return (
    <div className="absolute inset-0 z-50 flex items-center justify-center pointer-events-none rounded-lg overflow-hidden">
      {/* Subtle court dim so text reads — but court + players still visible behind */}
      <div className={`absolute inset-0 ${phase === "trophy" ? "bg-black/70" : "bg-black/35"} transition-colors duration-500`} />

      <div className="relative w-full h-full flex items-center justify-center">
        {phase === "trophy" && <TrophyIntro />}
        {phase === "vs" && <VsBanner home={home} away={away} leagueLabel={leagueLabel} />}
        {phase === "countdown" && <CountdownBig num={countNum} isFinals={!!isFinals} />}
      </div>
    </div>
  );
}

// ─────────────────────────────────────────────
function TrophyIntro() {
  return (
    <div className="flex flex-col items-center gap-6 animate-fade-in w-full">
      <div className="text-xs sm:text-sm uppercase tracking-[0.4em] text-yellow-300 font-bold drop-shadow-[0_0_12px_rgba(250,204,21,0.9)] animate-[fade-in_0.4s_ease-out]">
        🏆 The Final Stage 🏆
      </div>
      <div className="h-[280px] w-[280px] sm:h-[360px] sm:w-[360px]">
        <Suspense fallback={<div className="h-full w-full flex items-center justify-center text-7xl">🏆</div>}>
          <TrophyScene3D />
        </Suspense>
      </div>
      <div className="text-3xl sm:text-5xl font-black text-transparent bg-clip-text bg-gradient-to-r from-yellow-300 via-amber-400 to-yellow-300 drop-shadow-[0_0_20px_rgba(250,204,21,0.7)] animate-[champion-rise_0.8s_ease-out_0.3s_backwards] tracking-wider">
        WORLD CHAMPION
      </div>
      <style>{`
        @keyframes champion-rise {
          from { opacity: 0; transform: translateY(40px) scale(0.7); letter-spacing: 0.05em; }
          to   { opacity: 1; transform: translateY(0) scale(1); letter-spacing: 0.1em; }
        }
      `}</style>
    </div>
  );
}

// ─────────────────────────────────────────────
function TeamLogoChip({ side, animClass }: { side: TeamSide; animClass: string }) {
  return (
    <div className={`flex flex-col items-center gap-2 ${animClass}`}>
      <div className="h-24 w-24 sm:h-28 sm:w-28 rounded-2xl overflow-hidden ring-4 ring-primary shadow-2xl bg-card flex items-center justify-center">
        {side.logoUrl ? (
          <img src={side.logoUrl} alt={side.name} className="h-full w-full object-cover" />
        ) : (
          <span className="text-6xl">{side.emoji}</span>
        )}
      </div>
      <div className="text-base sm:text-xl font-extrabold text-white text-center max-w-[8rem] truncate drop-shadow-[0_2px_4px_rgba(0,0,0,0.9)]">
        {side.name}
      </div>
      {side.country && (
        <div className="text-[10px] sm:text-xs font-bold uppercase tracking-[0.2em] text-amber-200/95 drop-shadow-[0_2px_4px_rgba(0,0,0,0.9)] max-w-[10rem] truncate">
          {side.country}
        </div>
      )}
    </div>
  );
}

function VsBanner({ home, away, leagueLabel }: { home: TeamSide; away: TeamSide; leagueLabel?: string }) {
  return (
    <div className="flex flex-col items-center gap-4 animate-fade-in">
      {leagueLabel && (
        <div className="text-xs sm:text-sm uppercase tracking-[0.3em] text-white/90 font-semibold drop-shadow-[0_2px_4px_rgba(0,0,0,0.9)]">
          {leagueLabel}
        </div>
      )}
      <div className="flex items-center gap-6 sm:gap-10">
        <TeamLogoChip side={home} animClass="animate-[slide-in-left_0.6s_ease-out]" />
        <div className="text-5xl sm:text-7xl font-black text-primary drop-shadow-[0_0_12px_hsl(var(--primary)/0.8)] animate-[scale-in_0.4s_ease-out_0.4s_backwards]">
          VS
        </div>
        <TeamLogoChip side={away} animClass="animate-[slide-in-right_0.6s_ease-out]" />
      </div>
      <style>{`
        @keyframes slide-in-left { from { opacity:0; transform: translateX(-80px); } to { opacity:1; transform: translateX(0); } }
        @keyframes slide-in-right { from { opacity:0; transform: translateX(80px); } to { opacity:1; transform: translateX(0); } }
      `}</style>
    </div>
  );
}

// ─────────────────────────────────────────────
function CountdownBig({ num, isFinals }: { num: number; isFinals: boolean }) {
  return (
    <div className="flex flex-col items-center gap-3 animate-fade-in">
      <div className="text-sm uppercase tracking-[0.3em] text-white/90 drop-shadow-[0_2px_4px_rgba(0,0,0,0.9)]">
        {isFinals ? "🏆 Tour Finals Tip-off in" : "Tip-off in"}
      </div>
      <div
        key={num}
        className="h-[260px] w-[260px] sm:h-[340px] sm:w-[340px] animate-[count-pop_1s_ease-out]"
      >
        <Suspense
          fallback={
            <div
              className={`h-full w-full flex items-center justify-center text-[8rem] sm:text-[12rem] leading-none font-black ${
                isFinals
                  ? "text-transparent bg-clip-text bg-gradient-to-b from-yellow-200 via-yellow-400 to-amber-600"
                  : "text-primary"
              }`}
            >
              {num}
            </div>
          }
        >
          <CountdownScene3D num={num} isFinals={isFinals} />
        </Suspense>
      </div>
      <style>{`
        @keyframes count-pop {
          0%   { opacity: 0; transform: scale(0.4); }
          30%  { opacity: 1; transform: scale(1.15); }
          70%  { opacity: 1; transform: scale(1); }
          100% { opacity: 0; transform: scale(0.9); }
        }
      `}</style>
    </div>
  );
}
