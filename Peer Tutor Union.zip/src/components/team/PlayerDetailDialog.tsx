/**
 * PlayerDetailDialog — Shows full player info: avatar, rarity, level, OVR,
 * 5 attribute bars, and career stats (games played, wins, points, MVP).
 */
import { useEffect, useState } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from "@/components/ui/dialog";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Button } from "@/components/ui/button";
import { Crown, Trophy, Award, Gamepad2, Target, Heart } from "lucide-react";
import { toast } from "sonner";
import PlayerAvatar from "./PlayerAvatar";
import {
  RARITY_META,
  getEffectiveStats,
  getStamina,
  needsRest,
  loadCardStats,
  isEvolved,
  getEvolutionTier,
  restCard,
  restCostPerPoint,
  type PlayerCard,
  type PlayerTemplate,
  type PlayerCardStats,
  type TeamManager,
} from "@/lib/teamManager";

interface Props {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  card: PlayerCard | null;
  template: PlayerTemplate | null;
  /** Optional — pass to enable the "Rest" action that costs coins. */
  team?: TeamManager | null;
  onTeamChange?: (t: TeamManager) => void;
  onCardChange?: (c: PlayerCard) => void;
}

const STAT_ROWS = [
  { key: "speed",       label: "Speed" },
  { key: "shooting",    label: "Shooting" },
  { key: "three_point", label: "3-Point" },
  { key: "defense",     label: "Defense" },
  { key: "dunk",        label: "Dunk" },
] as const;

export default function PlayerDetailDialog({ open, onOpenChange, card, template, team, onTeamChange, onCardChange }: Props) {
  const [stats, setStats] = useState<PlayerCardStats | null>(null);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    if (!open || !card) { setStats(null); return; }
    setLoading(true);
    loadCardStats(card.id).then(s => { setStats(s); setLoading(false); });
  }, [open, card]);

  if (!card || !template) return null;

  const meta = RARITY_META[template.rarity as keyof typeof RARITY_META];
  const eff = getEffectiveStats(card, template);
  const isLegendary = template.rarity === "legendary";
  const isEpic = template.rarity === "epic";
  const evolved = isEvolved(card);
  const evolveTier = getEvolutionTier(card);
  const labelClass = evolved
    ? "evolved-text"
    : isLegendary ? "legendary-text" : isEpic ? "epic-text" : meta.color;
  const isElite = eff.total >= 500;

  const winRate = stats && stats.games_played > 0
    ? Math.round((stats.wins / stats.games_played) * 100)
    : 0;
  const ppg = stats && stats.games_played > 0
    ? (stats.points_scored / stats.games_played).toFixed(1)
    : "0.0";

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-md max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="sr-only">{template.name} details</DialogTitle>
          <DialogDescription className="sr-only">Player attributes and career statistics</DialogDescription>
        </DialogHeader>

        {/* Header card */}
        <div className={`relative overflow-hidden rounded-lg p-4 ${evolved ? "evolved-card" : `bg-gradient-to-br ${meta.bg}`}`}>
          <div className={evolved ? "evolved-stripe absolute top-0 left-0 right-0" : `absolute top-0 left-0 right-0 h-1 ${meta.color.replace("text-", "bg-")}`} />
          <div className="flex items-start gap-3 relative z-[1]">
            <PlayerAvatar template={template} size="lg" />
            <div className="flex-1 min-w-0">
              <div className="flex items-center justify-between gap-2">
                <span className={`text-xs font-extrabold uppercase tracking-wider ${labelClass}`}>
                  {evolved ? `${meta.label} · ✨ Evolved${evolveTier > 1 ? ` ×${evolveTier}` : ""}` : meta.label}
                </span>
                <Badge variant="secondary" className="text-[11px] h-5 px-2">Lv.{card.level}</Badge>
              </div>
              <div className="font-bold text-lg truncate text-foreground">{template.name}</div>
              <div className="flex items-center gap-1.5 mt-1">
                <span className={[
                  "inline-flex items-center justify-center rounded px-2 py-0.5 text-xs font-extrabold tabular-nums",
                  eff.total >= 450 ? "bg-orange-500/20 text-orange-400 ring-1 ring-orange-500/40" :
                  eff.total >= 400 ? "bg-purple-500/20 text-purple-400 ring-1 ring-purple-500/40" :
                  eff.total >= 320 ? "bg-yellow-500/20 text-yellow-400 ring-1 ring-yellow-500/40" :
                  eff.total >= 240 ? "bg-zinc-400/20 text-zinc-300 ring-1 ring-zinc-400/40" :
                                     "bg-amber-700/20 text-amber-600 ring-1 ring-amber-700/40",
                ].join(" ")}>OVR {eff.total}</span>
                {isElite && <Crown className="h-4 w-4 text-yellow-400 drop-shadow-[0_0_4px_rgba(250,204,21,0.8)]" />}
              </div>
            </div>
          </div>
          {template.description && (
            <p className="text-xs text-muted-foreground mt-3 italic relative z-[1]">"{template.description}"</p>
          )}
        </div>

        {/* Stamina + Rest */}
        <StaminaPanel
          card={card}
          template={template}
          team={team ?? null}
          onTeamChange={onTeamChange}
          onCardChange={onCardChange}
        />

        <div className="space-y-2">
          <h4 className="text-sm font-semibold text-foreground">Attributes</h4>
          {STAT_ROWS.map(r => {
            const v = eff[r.key as keyof typeof eff] as number;
            const pct = Math.min(100, (v / 120) * 100);
            return (
              <div key={r.key}>
                <div className="flex justify-between text-xs mb-0.5">
                  <span className="text-muted-foreground">{r.label}</span>
                  <span className={`font-bold tabular-nums ${v >= 90 ? "text-orange-400" : v >= 75 ? "text-yellow-400" : "text-foreground"}`}>{v}</span>
                </div>
                <Progress value={pct} className="h-1.5" />
              </div>
            );
          })}
        </div>

        {/* Career stats */}
        <div className="space-y-2">
          <h4 className="text-sm font-semibold text-foreground">Career Stats</h4>
          {loading ? (
            <p className="text-xs text-muted-foreground">Loading…</p>
          ) : (
            <div className="grid grid-cols-2 gap-2">
              <StatTile icon={<Gamepad2 className="h-4 w-4" />} label="Games" value={stats?.games_played ?? 0} sub={stats ? `${stats.wins}W · ${stats.losses}L` : "—"} />
              <StatTile icon={<Trophy className="h-4 w-4 text-yellow-400" />} label="Win Rate" value={`${winRate}%`} sub={stats ? `${stats.wins} wins` : "—"} />
              <StatTile icon={<Target className="h-4 w-4 text-orange-400" />} label="Total Pts" value={stats?.points_scored ?? 0} sub={`${ppg} PPG`} />
              <StatTile icon={<Award className="h-4 w-4 text-purple-400" />} label="MVPs" value={stats?.mvp_count ?? 0} sub="career awards" />
            </div>
          )}
          {stats && stats.games_played === 0 && (
            <p className="text-xs text-muted-foreground italic text-center pt-1">
              Play a league match with this player in the lineup to start tracking.
            </p>
          )}
        </div>
      </DialogContent>
    </Dialog>
  );
}

function StatTile({ icon, label, value, sub }: { icon: React.ReactNode; label: string; value: string | number; sub: string }) {
  return (
    <div className="rounded-md border border-border bg-card/50 p-2.5">
      <div className="flex items-center gap-1.5 text-[11px] text-muted-foreground">
        {icon}
        <span>{label}</span>
      </div>
      <div className="text-xl font-extrabold tabular-nums text-foreground mt-0.5">{value}</div>
      <div className="text-[10px] text-muted-foreground">{sub}</div>
    </div>
  );
}

function StaminaPanel({
  card,
  template,
  team,
  onTeamChange,
  onCardChange,
}: {
  card: PlayerCard;
  template: PlayerTemplate;
  team: TeamManager | null;
  onTeamChange?: (t: TeamManager) => void;
  onCardChange?: (c: PlayerCard) => void;
}) {
  const [busy, setBusy] = useState(false);
  const sta = getStamina(card);
  const tired = needsRest(card);
  const missing = 100 - sta;
  const perPoint = restCostPerPoint(template);
  const fullCost = missing * perPoint;
  const canRest = !!team && missing > 0;
  const canAfford = !!team && team.coins >= fullCost;

  const handleRest = async () => {
    if (!team || !onTeamChange) return;
    setBusy(true);
    try {
      const points = Math.min(missing, Math.floor(team.coins / perPoint));
      if (points <= 0) { toast.error("Not enough $"); return; }
      const { team: updated, newStamina } = await restCard(team, card, template, points);
      onTeamChange(updated);
      onCardChange?.({ ...card, stamina: newStamina } as PlayerCard);
      toast.success(`💤 Rested · +${points} stamina (${newStamina}/100)`);
    } catch (e: any) {
      toast.error(e?.message ?? "Rest failed");
    } finally {
      setBusy(false);
    }
  };

  return (
    <div className="space-y-2 rounded-md border border-border bg-card/40 p-3">
      <div className="flex items-center justify-between">
        <h4 className="text-sm font-semibold text-foreground flex items-center gap-1.5">
          <Heart className={`h-4 w-4 ${tired ? "text-red-400" : "text-emerald-400"}`} />
          Stamina
        </h4>
        <span className={`text-sm font-extrabold tabular-nums ${tired ? "text-red-400" : sta >= 60 ? "text-emerald-400" : "text-yellow-400"}`}>
          {sta}/100
        </span>
      </div>
      <Progress value={sta} className="h-2" />
      {tired && (
        <p className="text-[11px] text-red-400">
          ⚠️ Too tired to start a match. Stats are reduced. Rest or rotate to the bench.
        </p>
      )}
      {!tired && sta < 60 && (
        <p className="text-[11px] text-muted-foreground">
          Stamina below 50 reduces stats. Bench players recover passively over time (1/30s).
        </p>
      )}
      {canRest && team && (
        <>
          <Button
            size="sm"
            variant={tired ? "default" : "outline"}
            className="w-full h-8"
            onClick={handleRest}
            disabled={busy || (!canAfford && team.coins < perPoint)}
          >
            {busy ? "Resting…" : canAfford
              ? `💤 Full Rest · $${fullCost.toLocaleString()}`
              : `💤 Rest +${Math.floor(team.coins / perPoint)} · $${(Math.floor(team.coins / perPoint) * perPoint).toLocaleString()}`}
          </Button>
          <p className="text-[10px] text-muted-foreground text-center">
            Rate: ${perPoint}/pt (OVR × 0.2)
          </p>
        </>
      )}
    </div>
  );
}
