/**
 * LeaderboardDialog — Top 10 teams globally, ranked by team OVR (sum of
 * starting lineup effective stats). Click any team to challenge them via a
 * LIVE 60-180s 3v3 AI court match (settled by parent).
 *
 * NEW: No coin betting. Winning instead DRAINS the opponent's lineup
 * stamina (server-side RPC). Self is excluded from the challenge action.
 * Players can challenge any team — higher or lower ranked.
 */
import { useEffect, useMemo, useState } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Swords, Trophy, Crown, Heart, Info } from "lucide-react";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";
import TourChampionBadge from "./TourChampionBadge";
import TeamDetailDialog from "./TeamDetailDialog";
import {
  getEffectiveStats,
  LEAGUE_META,
  LEAGUE_ORDER,
  loadOwnedCards,
  type League,
  type PlayerCard,
  type PlayerTemplate,
  type TeamManager,
} from "@/lib/teamManager";

interface Props {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  team: TeamManager;
  myLineup: { card: PlayerCard; template: PlayerTemplate }[];
  onTeamChange: (team: TeamManager) => void;
  onStartLiveMatch: (params: {
    bet: number;
    seconds: number;
    /** When true, settlement drains opponent stamina instead of moving coins. */
    drainOpponentStamina?: boolean;
    /** Stamina drained from opponent's lineup on win. */
    drainAmount?: number;
    opponent: {
      user_id: string;
      team: TeamManager;
      profile: { name: string; avatar_url?: string | null };
      lineup: { card: PlayerCard; template: PlayerTemplate }[];
    };
  }) => void;
}

const TOP_N = 10;
const TIME_OPTIONS = [90, 120, 180] as const;
const DEFAULT_SECONDS: (typeof TIME_OPTIONS)[number] = 90;
/** Per-card stamina drained from opponent's starting lineup on win. */
const STAMINA_DRAIN_ON_WIN = 25;

interface LeaderRow {
  user_id: string;
  team: TeamManager;
  profile: { name: string };
  lineup: { card: PlayerCard; template: PlayerTemplate }[];
  rank: number;
}

const RANK_COLOR = ["text-yellow-400", "text-slate-300", "text-amber-700"];

export default function LeaderboardDialog({ open, onOpenChange, team, myLineup, onStartLiveMatch }: Props) {
  const [rows, setRows] = useState<LeaderRow[]>([]);
  const [loading, setLoading] = useState(true);
  const [challenging, setChallenging] = useState<string | null>(null);
  const [seconds, setSeconds] = useState<number>(DEFAULT_SECONDS);
  const [detailRow, setDetailRow] = useState<LeaderRow | null>(null);

  const fetchAll = async () => {
    setLoading(true);
    const { data: teams } = await supabase
      .from("team_managers")
      .select("*")
      .limit(100);

    const pool = teams ?? [];
    if (pool.length === 0) { setRows([]); setLoading(false); return; }

    const userIds = pool.map(t => t.user_id);
    const { data: profs } = await supabase.from("profiles").select("user_id, name").in("user_id", userIds);
    const profMap = new Map((profs ?? []).map(p => [p.user_id, p.name]));

    const withOvr = await Promise.all(
      pool.map(async (t) => {
        const allCards = await loadOwnedCards(t.user_id);
        const lineup = (t.starting_lineup ?? [])
          .map(id => allCards.find(c => c.card.id === id))
          .filter((x): x is { card: PlayerCard; template: PlayerTemplate } => !!x);
        const ovr = lineup.reduce(
          (s, { card, template }) => s + getEffectiveStats(card, template).total, 0,
        );
        return { t, lineup, ovr };
      }),
    );

    withOvr.sort((a, b) => {
      if (b.ovr !== a.ovr) return b.ovr - a.ovr;
      if (b.t.total_wins !== a.t.total_wins) return b.t.total_wins - a.t.total_wins;
      return LEAGUE_ORDER.indexOf(b.t.current_league as League) - LEAGUE_ORDER.indexOf(a.t.current_league as League);
    });

    const built: LeaderRow[] = withOvr.slice(0, TOP_N).map((row, i) => ({
      user_id: row.t.user_id,
      team: row.t as TeamManager,
      profile: { name: profMap.get(row.t.user_id) ?? "Unknown" },
      lineup: row.lineup,
      rank: i + 1,
    }));
    setRows(built);
    setLoading(false);
  };

  useEffect(() => { if (open) fetchAll(); }, [open]);

  const myStats = useMemo(
    () => myLineup.map(({ card, template }) => getEffectiveStats(card, template)),
    [myLineup],
  );
  const myTotal = myStats.reduce((s, x) => s + x.total, 0);

  const challenge = (row: LeaderRow) => {
    if (myLineup.length === 0) { toast.error("Set your own starting lineup first"); return; }
    if (row.lineup.length === 0) { toast.error("Opponent has no lineup yet"); return; }
    setChallenging(row.user_id);
    onStartLiveMatch({
      bet: 0,
      seconds,
      drainOpponentStamina: true,
      drainAmount: STAMINA_DRAIN_ON_WIN,
      opponent: {
        user_id: row.user_id,
        team: row.team,
        profile: row.profile,
        lineup: row.lineup,
      },
    });
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-2xl h-[85vh] !grid-cols-none !flex flex-col gap-4 overflow-hidden">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2"><Crown className="h-5 w-5 text-yellow-400" /> Global Top {TOP_N}</DialogTitle>
          <DialogDescription>
            Ranked by team OVR (sum of starting lineup effective stats). Live 3v3 AI court match — pick time, then tap "Challenge".
            <span className="block mt-1 text-foreground/80">
              <Heart className="inline h-3 w-3 mr-1 text-red-400" />
              <strong>No coins on the line.</strong> Win and you drain <strong>−{STAMINA_DRAIN_ON_WIN}</strong> stamina from each of the opponent's starting players. Lose and your own lineup pays the usual stamina cost.
            </span>
          </DialogDescription>
        </DialogHeader>

        <div className="flex items-center gap-2 px-1 flex-wrap">
          <span className="text-sm font-medium shrink-0">Match Time</span>
          <div className="flex gap-1">
            {TIME_OPTIONS.map(s => (
              <Button key={s} size="sm" variant={seconds === s ? "default" : "outline"} type="button"
                onClick={() => setSeconds(s)}>
                {s}s
              </Button>
            ))}
          </div>
        </div>

        <ScrollArea className="flex-1 -mx-2 px-2">
          {loading ? (
            <p className="text-center py-12 text-sm text-muted-foreground">Loading leaderboard…</p>
          ) : rows.length === 0 ? (
            <Card className="p-6 text-center text-sm text-muted-foreground">No teams yet</Card>
          ) : (
            <div className="space-y-1.5">
              {rows.map(row => {
                const isSelf = row.user_id === team.user_id;
                const rawLeague = row.team.current_league as League;
                const safeLeague: League = LEAGUE_META[rawLeague] ? rawLeague : "nba";
                const meta = LEAGUE_META[safeLeague];
                const oppTotal = row.lineup.reduce(
                  (s, { card, template }) => s + getEffectiveStats(card, template).total, 0,
                );
                const diff = oppTotal - myTotal;
                const rankStyle = RANK_COLOR[row.rank - 1] ?? "text-muted-foreground";
                return (
                  <Card
                    key={row.user_id}
                    onClick={() => setDetailRow(row)}
                    className={`p-3 flex items-center gap-3 flex-wrap cursor-pointer transition hover:bg-accent/40 ${isSelf ? "ring-1 ring-primary bg-primary/5" : ""}`}
                  >
                    <div className={`text-lg font-black w-8 text-center tabular-nums ${rankStyle}`}>
                      #{row.rank}
                    </div>
                    {row.team.team_logo_url ? (
                      <img
                        src={row.team.team_logo_url}
                        alt={row.team.team_name}
                        className="h-9 w-9 rounded-full object-cover ring-1 ring-border shrink-0"
                      />
                    ) : (
                      <div className="text-2xl">{row.team.team_emoji}</div>
                    )}
                    <div className="flex-1 min-w-0">
                      <div className="font-bold truncate flex items-center gap-1.5 flex-wrap">
                        <span className="truncate">{row.team.team_name}</span>
                        {(row.team.wc_titles ?? 0) > 0 && (
                          <TourChampionBadge count={row.team.wc_titles ?? 0} size="sm" />
                        )}
                        {isSelf && <span className="text-[10px] text-primary">(you)</span>}
                      </div>
                      <div className="text-xs text-muted-foreground truncate flex flex-wrap items-center gap-x-2">
                        <span>{row.profile.name}</span>
                        <span>·</span>
                        <span title={meta.label}>{meta.emoji} {meta.label}</span>
                        <span>·</span>
                        <span className="flex items-center gap-0.5">
                          <Trophy className="h-3 w-3 text-yellow-400" />
                          {row.team.total_wins}
                          <span className="opacity-60">-{row.team.total_losses}</span>
                        </span>
                        {row.lineup.length > 0 && <span>· OVR <span className="text-foreground font-semibold">{oppTotal}</span></span>}
                      </div>
                    </div>
                    <Button
                      size="icon"
                      variant="ghost"
                      className="h-8 w-8 shrink-0"
                      title="View team details"
                      onClick={(e) => { e.stopPropagation(); setDetailRow(row); }}
                    >
                      <Info className="h-4 w-4" />
                    </Button>
                    {!isSelf && (
                      <Button
                        size="sm"
                        className="gap-1"
                        disabled={!!challenging || row.lineup.length === 0 || myLineup.length === 0}
                        onClick={(e) => { e.stopPropagation(); challenge(row); }}
                        title={
                          row.lineup.length === 0 ? "Opponent has no lineup"
                          : myLineup.length === 0 ? "You have no lineup"
                          : `Win → drain −${STAMINA_DRAIN_ON_WIN} stamina from opponent's lineup`
                        }
                      >
                        <Swords className="h-4 w-4" />
                        {challenging === row.user_id ? "Playing…" : "Challenge"}
                        {row.lineup.length > 0 && myLineup.length > 0 && (
                          <span className={`text-[10px] ${diff > 0 ? "text-red-200" : diff < 0 ? "text-green-200" : "opacity-80"}`}>
                            ({diff > 0 ? `+${diff}` : diff})
                          </span>
                        )}
                      </Button>
                    )}
                  </Card>
                );
              })}
            </div>
          )}
        </ScrollArea>
      </DialogContent>

      {detailRow && (
        <TeamDetailDialog
          open={!!detailRow}
          onOpenChange={(o) => !o && setDetailRow(null)}
          team={detailRow.team}
          profileName={detailRow.profile.name}
          lineup={detailRow.lineup}
        />
      )}
    </Dialog>
  );
}
