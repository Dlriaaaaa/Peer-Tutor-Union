/**
 * RechargeDialog — Shown when a user wants to top up their team coins.
 * Displays a WeChat Pay QR code with a "Scan the QR code" instruction.
 * Actual coin crediting is handled manually by an admin via Admin → Coins.
 */
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from "@/components/ui/dialog";
import wechatQR from "@/assets/wechat-pay-qr.jpg.asset.json";

interface RechargeDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
}

export default function RechargeDialog({ open, onOpenChange }: RechargeDialogProps) {
  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-sm">
        <DialogHeader>
          <DialogTitle className="text-center">💰 Recharge Coins</DialogTitle>
          <DialogDescription className="text-center">
            Scan the QR code with WeChat to top up. Send your team name in the payment note — an admin will credit your balance shortly.
          </DialogDescription>
        </DialogHeader>
        <div className="flex flex-col items-center gap-3">
          <div className="text-sm font-semibold text-primary">Scan the QR code</div>
          <img
            src={wechatQR.url}
            alt="WeChat Pay QR Code"
            className="w-full max-w-[280px] rounded-lg border border-border shadow-md"
          />
          <p className="text-xs text-muted-foreground text-center">
            微信支付 · PTC 缴费
          </p>
        </div>
      </DialogContent>
    </Dialog>
  );
}
