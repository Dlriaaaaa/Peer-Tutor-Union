/**
 * LotteryDialog — Spin Wheel + Scratch Cards.
 *
 * Two tabs:
 *   🎡 Wheel    — animated rotating wheel, 1× ($100) or 10× ($1000) spin.
 *                 The 10× spin guarantees at least one ≥$100 reward.
 *   🎟️ Scratch — buy a $100 / $1k / $10k ticket and scratch open 3 panels;
 *                 admin-configurable prize pool per face value.
 */
import { useEffect, useMemo, useRef, useState } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Badge } from "@/components/ui/badge";
import { DollarSign, Loader2 } from "lucide-react";
import { toast } from "sonner";
import {
  WHEEL_SLICES,
  SPIN_COST,
  SPIN_X10_COST,
  GOLDEN_SLICES,
  GOLDEN_COST,
  GOLDEN_X10_COST,
  GOLDEN_X100_COST,
  SCRATCH_FACE_VALUES,
  spinWheel,
  pullGoldenGacha,
  buyScratchTicket,
  loadScratchConfigs,
  describeScratchPrize,
  type ScratchConfig,
  type ScratchFace,
  type ScratchPanelResult,
  type WheelSlice,
} from "@/lib/lotteryManager";
import { getConsumableDef, type TeamManager } from "@/lib/teamManager";

interface LotteryDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  team: TeamManager;
  onTeamChange: (team: TeamManager) => void;
}

export default function LotteryDialog({ open, onOpenChange, team, onTeamChange }: LotteryDialogProps) {
  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-3xl h-[88vh] !grid-cols-none !flex flex-col gap-4 overflow-hidden">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            🎰 Lottery
            <span className="ml-auto inline-flex items-center gap-1 text-yellow-400 font-mono text-base">
              <DollarSign className="h-4 w-4" /> {team.coins.toLocaleString()}
            </span>
          </DialogTitle>
        </DialogHeader>

        <Tabs defaultValue="wheel" className="flex-1 min-h-0 flex flex-col overflow-hidden">
          <TabsList className="self-start">
            <TabsTrigger value="wheel">🎡 Wheel</TabsTrigger>
            <TabsTrigger value="golden">🥇 Golden</TabsTrigger>
            <TabsTrigger value="scratch">🎟️ Scratch</TabsTrigger>
          </TabsList>

          <TabsContent value="wheel" className="flex-1 min-h-0 mt-3 overflow-hidden">
            <ScrollArea className="h-full pr-2">
              <WheelTab team={team} onTeamChange={onTeamChange} variant="standard" />
            </ScrollArea>
          </TabsContent>

          <TabsContent value="golden" className="flex-1 min-h-0 mt-3 overflow-hidden">
            <ScrollArea className="h-full pr-2">
              <WheelTab team={team} onTeamChange={onTeamChange} variant="golden" />
            </ScrollArea>
          </TabsContent>

          <TabsContent value="scratch" className="flex-1 min-h-0 mt-3 overflow-hidden">
            <ScrollArea className="h-full pr-2">
              <ScratchTab team={team} onTeamChange={onTeamChange} />
            </ScrollArea>
          </TabsContent>
        </Tabs>
      </DialogContent>
    </Dialog>
  );
}

// ═══════════════════════════════════════════════════════════════
// Wheel Tab
// ═══════════════════════════════════════════════════════════════

function WheelTab({
  team,
  onTeamChange,
  variant,
}: {
  team: TeamManager;
  onTeamChange: (t: TeamManager) => void;
  variant: "standard" | "golden";
}) {
  const isGolden = variant === "golden";
  const slicesData = isGolden ? GOLDEN_SLICES : WHEEL_SLICES;
  const cost1 = isGolden ? GOLDEN_COST : SPIN_COST;
  const costX10 = isGolden ? GOLDEN_X10_COST : SPIN_X10_COST;
  const costX100 = GOLDEN_X100_COST;

  const [busy, setBusy] = useState(false);
  const [rotation, setRotation] = useState(0);
  const [resultSlices, setResultSlices] = useState<WheelSlice[] | null>(null);
  const [resultCoins, setResultCoins] = useState(0);
  const [bulkResult, setBulkResult] = useState(false);

  const sliceAngle = 360 / slicesData.length;
  const gradPrefix = isGolden ? "ggrad" : "grad";

  const handleSpin = async (n: 1 | 10 | 100) => {
    if (busy) return;
    const cost = n === 1 ? cost1 : n === 10 ? costX10 : costX100;
    if (team.coins < cost) {
      toast.error(`Need $${cost.toLocaleString()}`);
      return;
    }
    setBusy(true);
    setResultSlices(null);
    try {
      const { updatedTeam, slices, totalCoins } = isGolden
        ? await pullGoldenGacha(team, n)
        : await spinWheel(team, n as 1 | 10);
      onTeamChange(updatedTeam);

      if (n === 1) {
        const idx = slicesData.findIndex(s => s.key === slices[0].key);
        const center = idx * sliceAngle + sliceAngle / 2;
        const turns = 5;
        const target = turns * 360 - center;
        setRotation(prev => prev + (target - (prev % 360)) + 360);
        setBulkResult(false);
        setTimeout(() => {
          setResultSlices(slices);
          setResultCoins(totalCoins);
          showRewardToast(slices, totalCoins, cost);
          setBusy(false);
        }, 4200);
      } else {
        setBulkResult(true);
        setResultSlices(slices);
        setResultCoins(totalCoins);
        showRewardToast(slices, totalCoins, cost);
        setBusy(false);
      }
    } catch (e: any) {
      toast.error(e.message ?? "Spin failed");
      setBusy(false);
    }
  };

  return (
    <div className="space-y-4 pb-2">
      <div className="flex flex-col items-center gap-3">
        <div className="relative w-[280px] h-[280px] sm:w-[340px] sm:h-[340px]">
          <div className="absolute top-0 left-1/2 -translate-x-1/2 -translate-y-1 z-10">
            <div className="w-0 h-0 border-l-[14px] border-r-[14px] border-t-[24px] border-l-transparent border-r-transparent border-t-yellow-400 drop-shadow-[0_2px_6px_rgba(0,0,0,0.6)]" />
          </div>
          <svg
            viewBox="-110 -110 220 220"
            className="w-full h-full drop-shadow-2xl"
            style={{
              transform: `rotate(${rotation}deg)`,
              transition: busy && !bulkResult ? "transform 4s cubic-bezier(0.17, 0.67, 0.16, 0.99)" : "none",
              filter: isGolden ? "drop-shadow(0 0 18px rgba(250,204,21,0.55))" : undefined,
            }}
          >
            <defs>
              {slicesData.map((s, i) => (
                <linearGradient key={i} id={`${gradPrefix}-${i}`} x1="0" y1="0" x2="1" y2="1">
                  <stop offset="0%" stopColor={getGradientStart(s.color)} />
                  <stop offset="100%" stopColor={getGradientEnd(s.color)} />
                </linearGradient>
              ))}
            </defs>
            {slicesData.map((s, i) => {
              const startA = i * sliceAngle - 90;
              const endA = (i + 1) * sliceAngle - 90;
              const path = describeArc(0, 0, 100, startA, endA);
              const midA = (startA + endA) / 2;
              const labelR = 65;
              const lx = labelR * Math.cos((midA * Math.PI) / 180);
              const ly = labelR * Math.sin((midA * Math.PI) / 180);
              return (
                <g key={i}>
                  <path d={path} fill={`url(#${gradPrefix}-${i})`} stroke={isGolden ? "#facc15" : "hsl(var(--background))"} strokeWidth="1.5" />
                  <g transform={`translate(${lx} ${ly}) rotate(${midA + 90})`}>
                    <text
                      textAnchor="middle"
                      dominantBaseline="middle"
                      fontSize="11"
                      fontWeight="700"
                      fill="white"
                      style={{ paintOrder: "stroke", stroke: "rgba(0,0,0,0.5)", strokeWidth: 2 }}
                    >
                      {s.emoji}
                    </text>
                    <text
                      y="12"
                      textAnchor="middle"
                      dominantBaseline="middle"
                      fontSize="6.5"
                      fontWeight="700"
                      fill="white"
                      style={{ paintOrder: "stroke", stroke: "rgba(0,0,0,0.5)", strokeWidth: 1.5 }}
                    >
                      {s.label}
                    </text>
                  </g>
                </g>
              );
            })}
            <circle
              cx="0" cy="0" r="14"
              fill={isGolden ? "#facc15" : "hsl(var(--background))"}
              stroke={isGolden ? "#b45309" : "hsl(var(--primary))"}
              strokeWidth="2"
            />
          </svg>
        </div>

        {/* Spin buttons */}
        <div className={`flex gap-2 w-full max-w-md ${isGolden ? "flex-col sm:flex-row" : ""}`}>
          <Button
            className={`flex-1 h-12 ${isGolden ? "bg-gradient-to-r from-amber-400 to-yellow-600 text-amber-950" : "bg-gradient-to-r from-emerald-500 to-green-600 text-white"} font-bold hover:opacity-90`}
            disabled={busy || team.coins < cost1}
            onClick={() => handleSpin(1)}
          >
            {busy && !bulkResult ? <Loader2 className="h-4 w-4 animate-spin" /> : `${isGolden ? "Pull" : "Spin"} ×1 · $${cost1.toLocaleString()}`}
          </Button>
          <Button
            className={`flex-1 h-12 ${isGolden ? "bg-gradient-to-r from-yellow-500 to-orange-600 text-white" : "bg-gradient-to-r from-orange-500 to-red-600 text-white"} font-bold hover:opacity-90`}
            disabled={busy || team.coins < costX10}
            onClick={() => handleSpin(10)}
          >
            {busy && bulkResult ? <Loader2 className="h-4 w-4 animate-spin" /> : `${isGolden ? "Pull" : "Spin"} ×10 · $${costX10.toLocaleString()}`}
          </Button>
          {isGolden && (
            <Button
              className="flex-1 h-12 bg-gradient-to-r from-fuchsia-600 via-rose-600 to-orange-500 text-white font-bold hover:opacity-90 shadow-[0_0_18px_rgba(217,70,239,0.45)]"
              disabled={busy || team.coins < costX100}
              onClick={() => handleSpin(100)}
            >
              {busy && bulkResult ? <Loader2 className="h-4 w-4 animate-spin" /> : `Pull ×100 · $${costX100.toLocaleString()}`}
            </Button>
          )}
        </div>
        <p className="text-[10px] text-muted-foreground text-center">
          {isGolden
            ? "🥇 Golden Gacha · all rewards ×100. ×10 / ×100 guarantee at least one $10,000+ payout. Top prize: 💎 100,000,000 (0.01%)"
            : "×10 guarantees at least one $100+ reward · Top prizes: 💎 1M (0.01%) · 🎉 100k (0.1%) · 💰 10k (0.5%)"}
        </p>
      </div>

      {/* Result */}
      {resultSlices && (
        <Card className="p-3 space-y-2 animate-in fade-in slide-in-from-bottom-2">
          <div className="text-sm font-bold flex items-center gap-2">
            🎁 Result
            <span className="ml-auto text-yellow-400 font-mono">+${resultCoins.toLocaleString()}</span>
          </div>
          <div className={`grid gap-1.5 ${
            resultSlices.length > 20 ? "grid-cols-10" :
            resultSlices.length > 5 ? "grid-cols-5" :
            resultSlices.length > 1 ? "grid-cols-5" : "grid-cols-1"
          }`}>
            {resultSlices.map((s, i) => (
              <div
                key={i}
                className={`bg-gradient-to-br ${s.color} rounded-md p-1.5 text-center text-white shadow-md`}
              >
                <div className={resultSlices.length > 20 ? "text-base" : "text-xl"}>{s.emoji}</div>
                <div className="text-[9px] font-bold leading-tight mt-0.5 truncate">{s.label}</div>
              </div>
            ))}
          </div>
        </Card>
      )}

      {/* Odds table */}
      <details className="text-xs">
        <summary className="cursor-pointer text-muted-foreground hover:text-foreground">View full odds</summary>
        <div className="mt-2 grid grid-cols-2 sm:grid-cols-3 gap-1.5">
          {slicesData.map(s => (
            <div key={s.key} className={`bg-gradient-to-br ${s.color} rounded p-2 text-white text-[11px] flex items-center gap-1.5`}>
              <span className="text-base">{s.emoji}</span>
              <span className="flex-1 font-semibold truncate">{s.label}</span>
              <span className="font-mono opacity-90">{s.weight}%</span>
            </div>
          ))}
        </div>
      </details>
    </div>
  );
}

// ═══════════════════════════════════════════════════════════════
// Scratch Tab
// ═══════════════════════════════════════════════════════════════

function ScratchTab({ team, onTeamChange }: { team: TeamManager; onTeamChange: (t: TeamManager) => void }) {
  const [configs, setConfigs] = useState<ScratchConfig[]>([]);
  const [loading, setLoading] = useState(true);
  const [busy, setBusy] = useState(false);
  const [activeTicket, setActiveTicket] = useState<{ face: ScratchFace; result: ScratchPanelResult } | null>(null);
  const [revealed, setRevealed] = useState(false);

  useEffect(() => {
    loadScratchConfigs()
      .then(setConfigs)
      .finally(() => setLoading(false));
  }, []);

  const handleBuy = async (face: ScratchFace) => {
    if (busy || activeTicket) return;
    if (team.coins < face) {
      toast.error(`Need $${face.toLocaleString()}`);
      return;
    }
    setBusy(true);
    try {
      const { updatedTeam, result } = await buyScratchTicket(team, face);
      onTeamChange(updatedTeam);
      setActiveTicket({ face, result });
      setRevealed(false);
    } catch (e: any) {
      toast.error(e.message ?? "Purchase failed");
    } finally {
      setBusy(false);
    }
  };

  const handleRevealComplete = () => {
    if (!activeTicket || revealed) return;
    setRevealed(true);
    const prize = activeTicket.result.prize;
    const desc = describeScratchPrize(prize);
    const isWin = (prize.kind === "coins" && (prize.amount ?? 0) > 0) || prize.kind === "item";
    if (isWin) {
      toast.success(`🎉 You won ${desc}!`, { duration: 6000 });
    } else {
      toast(`${desc} — better luck next time`, { duration: 4000 });
    }
  };

  const closeTicket = () => {
    setActiveTicket(null);
    setRevealed(false);
  };

  if (loading) {
    return <div className="py-12 text-center text-sm text-muted-foreground">Loading…</div>;
  }

  return (
    <div className="space-y-4 pb-2">
      {/* Active scratch ticket */}
      {activeTicket && (
        <Card className="p-4 space-y-3 bg-gradient-to-br from-amber-500/20 to-orange-500/10 border-amber-500/40">
          <div className="flex items-center gap-2 text-sm font-bold">
            🎟️ ${activeTicket.face.toLocaleString()} Ticket
            <span className="text-[10px] text-muted-foreground font-normal ml-auto">
              {revealed ? "Revealed!" : "Scratch off the coating · match 3 to win"}
            </span>
          </div>
          <ScratchCard
            prize={activeTicket.result.prize}
            panels={activeTicket.result.panels}
            winningTiles={activeTicket.result.winningTiles}
            face={activeTicket.face}
            onRevealComplete={handleRevealComplete}
          />
          {revealed && (
            <Button variant="outline" size="sm" className="w-full" onClick={closeTicket}>
              Close
            </Button>
          )}
        </Card>
      )}

      {/* Buy buttons */}
      {!activeTicket && (
        <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-3">
          {SCRATCH_FACE_VALUES.map(face => {
            const config = configs.find(c => c.face_value === face);
            return (
              <Card
                key={face}
                className="p-3 space-y-2 bg-gradient-to-br from-amber-500/10 to-orange-500/5 border-amber-500/30"
              >
                <div className="flex items-center gap-2">
                  <div className="text-3xl">🎟️</div>
                  <div>
                    <div className="font-bold text-sm">${face.toLocaleString()}</div>
                    <div className="text-[10px] text-muted-foreground">{config?.prizes.length ?? 0} prizes</div>
                  </div>
                </div>
                <div className="text-[10px] text-muted-foreground space-y-0.5 max-h-20 overflow-hidden">
                  {(config?.prizes ?? [])
                    .slice()
                    .sort((a, b) => prizeValue(b) - prizeValue(a))
                    .slice(0, 3)
                    .map((p, i) => (
                      <div key={i} className="truncate">• {p.label}</div>
                    ))}
                </div>
                <Button
                  className="w-full gap-1"
                  size="sm"
                  disabled={busy || team.coins < face || !config || config.prizes.length === 0}
                  onClick={() => handleBuy(face)}
                >
                  <DollarSign className="h-3.5 w-3.5" /> Buy · {face.toLocaleString()}
                </Button>
              </Card>
            );
          })}
        </div>
      )}

      <p className="text-[10px] text-muted-foreground text-center">
        Scratch off the gray coating (click & drag) to reveal your prize. Prize pools editable by admins.
      </p>
    </div>
  );
}

/**
 * Smooth canvas scratch card. The prize sits underneath as DOM; a canvas
 * overlay holds the gray coating and is erased with `destination-out`
 * along the pointer path. Pointer samples are interpolated so fast drags
 * leave no gaps. Works for mouse, touch, and pen via Pointer Events with
 * `setPointerCapture` so drags continue even if the finger leaves the
 * canvas. Once ≥55% of the coating is erased the prize fully reveals.
 */
const SCRATCH_REVEAL_THRESHOLD = 0.55;
const SCRATCH_BRUSH_RADIUS = 22; // px in canvas backing-store space
const SCRATCH_PROGRESS_SAMPLE = 4; // sample every Nth pixel for perf

function ScratchCard({
  prize,
  panels,
  winningTiles,
  face,
  onRevealComplete,
}: {
  prize: import("@/lib/lotteryManager").ScratchPrize;
  panels: import("@/lib/lotteryManager").ScratchPrize[];
  winningTiles: number[];
  face: ScratchFace;
  onRevealComplete: () => void;
}) {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const lastPointRef = useRef<{ x: number; y: number } | null>(null);
  const isDraggingRef = useRef(false);
  const completedRef = useRef(false);
  const dprRef = useRef(1);
  const [progress, setProgress] = useState(0);
  const [fullyRevealed, setFullyRevealed] = useState(false);
  const [hasStarted, setHasStarted] = useState(false);

  const isWin = (prize.kind === "coins" && (prize.amount ?? 0) > 0) || prize.kind === "item";

  // Paint the gray coating onto the canvas (called on mount + resize)
  const paintCoating = (canvas: HTMLCanvasElement) => {
    const ctx = canvas.getContext("2d");
    if (!ctx) return;
    const { width, height } = canvas;
    ctx.globalCompositeOperation = "source-over";
    // Base gradient
    const grad = ctx.createLinearGradient(0, 0, width, height);
    grad.addColorStop(0, "#9ca3af");
    grad.addColorStop(0.5, "#6b7280");
    grad.addColorStop(1, "#4b5563");
    ctx.fillStyle = grad;
    ctx.fillRect(0, 0, width, height);
    // Diagonal hatching for "foil" texture
    ctx.strokeStyle = "rgba(255,255,255,0.08)";
    ctx.lineWidth = 2 * dprRef.current;
    const step = 10 * dprRef.current;
    for (let i = -height; i < width; i += step) {
      ctx.beginPath();
      ctx.moveTo(i, 0);
      ctx.lineTo(i + height, height);
      ctx.stroke();
    }
    // Subtle noise specks
    ctx.fillStyle = "rgba(0,0,0,0.12)";
    for (let i = 0; i < (width * height) / 800; i++) {
      const x = Math.random() * width;
      const y = Math.random() * height;
      ctx.fillRect(x, y, 1.5 * dprRef.current, 1.5 * dprRef.current);
    }
  };

  // Resize canvas backing store to match CSS size at devicePixelRatio
  const resizeCanvas = () => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const rect = canvas.getBoundingClientRect();
    const dpr = Math.min(window.devicePixelRatio || 1, 2);
    dprRef.current = dpr;
    canvas.width = Math.max(1, Math.floor(rect.width * dpr));
    canvas.height = Math.max(1, Math.floor(rect.height * dpr));
    paintCoating(canvas);
  };

  useEffect(() => {
    resizeCanvas();
    const handleResize = () => resizeCanvas();
    window.addEventListener("resize", handleResize);
    return () => window.removeEventListener("resize", handleResize);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  // Compute % erased by sampling alpha channel
  const computeProgress = (): number => {
    const canvas = canvasRef.current;
    if (!canvas) return 0;
    const ctx = canvas.getContext("2d");
    if (!ctx) return 0;
    const { width, height } = canvas;
    if (width === 0 || height === 0) return 0;
    try {
      const data = ctx.getImageData(0, 0, width, height).data;
      let cleared = 0;
      let counted = 0;
      // Sample every Nth pixel for performance
      for (let i = 3; i < data.length; i += 4 * SCRATCH_PROGRESS_SAMPLE) {
        if (data[i] < 32) cleared++;
        counted++;
      }
      return counted > 0 ? cleared / counted : 0;
    } catch {
      return 0;
    }
  };

  const eraseAt = (x: number, y: number) => {
    const canvas = canvasRef.current;
    if (!canvas || fullyRevealed) return;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;
    const dpr = dprRef.current;
    const radius = SCRATCH_BRUSH_RADIUS * dpr;
    ctx.globalCompositeOperation = "destination-out";
    ctx.fillStyle = "rgba(0,0,0,1)";

    const last = lastPointRef.current;
    if (last) {
      // Interpolate between last point and current to avoid gaps on fast drags
      const dx = x - last.x;
      const dy = y - last.y;
      const dist = Math.hypot(dx, dy);
      const stepSize = Math.max(radius * 0.4, 2);
      const steps = Math.max(1, Math.ceil(dist / stepSize));
      for (let i = 1; i <= steps; i++) {
        const px = last.x + (dx * i) / steps;
        const py = last.y + (dy * i) / steps;
        ctx.beginPath();
        ctx.arc(px, py, radius, 0, Math.PI * 2);
        ctx.fill();
      }
    } else {
      ctx.beginPath();
      ctx.arc(x, y, radius, 0, Math.PI * 2);
      ctx.fill();
    }

    lastPointRef.current = { x, y };
  };

  const checkProgress = () => {
    if (completedRef.current) return;
    const p = computeProgress();
    setProgress(p);
    if (p >= SCRATCH_REVEAL_THRESHOLD) {
      completedRef.current = true;
      // Smoothly fade out the remaining coating
      const canvas = canvasRef.current;
      if (canvas) {
        canvas.style.transition = "opacity 400ms ease-out";
        canvas.style.opacity = "0";
      }
      setTimeout(() => {
        setFullyRevealed(true);
        onRevealComplete();
      }, 420);
    }
  };

  const getCanvasPoint = (e: React.PointerEvent<HTMLCanvasElement>) => {
    const canvas = canvasRef.current!;
    const rect = canvas.getBoundingClientRect();
    const dpr = dprRef.current;
    return {
      x: (e.clientX - rect.left) * dpr,
      y: (e.clientY - rect.top) * dpr,
    };
  };

  const handlePointerDown = (e: React.PointerEvent<HTMLCanvasElement>) => {
    if (fullyRevealed) return;
    e.preventDefault();
    const canvas = canvasRef.current;
    if (!canvas) return;
    canvas.setPointerCapture?.(e.pointerId);
    isDraggingRef.current = true;
    lastPointRef.current = null;
    if (!hasStarted) setHasStarted(true);
    const { x, y } = getCanvasPoint(e);
    eraseAt(x, y);
    checkProgress();
  };

  const handlePointerMove = (e: React.PointerEvent<HTMLCanvasElement>) => {
    if (!isDraggingRef.current || fullyRevealed) return;
    e.preventDefault();
    // Use coalesced events when available for ultra-smooth strokes
    const events = (e.nativeEvent as PointerEvent).getCoalescedEvents?.() ?? [e.nativeEvent as PointerEvent];
    const canvas = canvasRef.current!;
    const rect = canvas.getBoundingClientRect();
    const dpr = dprRef.current;
    for (const ev of events) {
      eraseAt((ev.clientX - rect.left) * dpr, (ev.clientY - rect.top) * dpr);
    }
    checkProgress();
  };

  const endStroke = (e?: React.PointerEvent<HTMLCanvasElement>) => {
    isDraggingRef.current = false;
    lastPointRef.current = null;
    if (e) {
      const canvas = canvasRef.current;
      canvas?.releasePointerCapture?.(e.pointerId);
    }
    checkProgress();
  };

  const winningSet = new Set(winningTiles);

  return (
    <div className="space-y-2">
      <div className="relative aspect-square w-full max-w-md mx-auto rounded-xl overflow-hidden border-2 border-amber-400/60 shadow-lg select-none">
        {/* Prize layer underneath — 4×4 grid of 16 tiles */}
        <div
          className={`absolute inset-0 grid grid-cols-4 grid-rows-4 gap-1 p-1.5 ${
            isWin
              ? "bg-gradient-to-br from-yellow-500/30 via-amber-500/20 to-orange-500/30"
              : "bg-gradient-to-br from-muted to-muted/60"
          }`}
        >
          {panels.map((tile, i) => {
            const isWinning = winningSet.has(i);
            const tileEmoji = getPrizeEmoji(tile as any);
            const tileLabel = describeScratchPrize(tile);
            return (
              <div
                key={i}
                className={`relative rounded-md flex flex-col items-center justify-center text-center p-1 overflow-hidden ${
                  isWinning
                    ? "bg-gradient-to-br from-yellow-400/60 to-amber-500/60 ring-2 ring-yellow-300/80 shadow-[0_0_8px_rgba(250,204,21,0.4)]"
                    : "bg-background/50"
                }`}
              >
                <div className="text-xl sm:text-2xl leading-none">{tileEmoji}</div>
                <div className={`text-[8px] sm:text-[9px] font-bold leading-tight mt-0.5 line-clamp-2 ${
                  isWinning ? "text-yellow-950" : "text-muted-foreground"
                }`}>
                  {tileLabel}
                </div>
              </div>
            );
          })}
        </div>

        {/* Winner banner overlay (only shown after reveal) */}
        {fullyRevealed && isWin && (
          <div className="absolute top-1.5 left-1/2 -translate-x-1/2 px-3 py-1 rounded-full bg-yellow-400 text-yellow-950 text-[10px] font-extrabold tracking-widest shadow-lg animate-in fade-in zoom-in">
            🎉 MATCH 3 · WINNER 🎉
          </div>
        )}
        {fullyRevealed && !isWin && (
          <div className="absolute top-1.5 left-1/2 -translate-x-1/2 px-3 py-1 rounded-full bg-muted text-muted-foreground text-[10px] font-bold tracking-widest shadow-lg">
            BETTER LUCK NEXT TIME
          </div>
        )}

        {/* Canvas coating */}
        {!fullyRevealed && (
          <canvas
            ref={canvasRef}
            className="absolute inset-0 w-full h-full touch-none cursor-grab active:cursor-grabbing"
            onPointerDown={handlePointerDown}
            onPointerMove={handlePointerMove}
            onPointerUp={endStroke}
            onPointerCancel={endStroke}
            onPointerLeave={(e) => {
              // Don't end the stroke on leave — pointer capture keeps it going.
              // Only end if the button is no longer pressed.
              if (e.buttons === 0) endStroke(e);
            }}
          />
        )}

        {/* "SCRATCH HERE" hint */}
        {!fullyRevealed && !hasStarted && (
          <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
            <div className="px-3 py-1.5 rounded-md bg-background/80 backdrop-blur text-xs font-bold tracking-widest text-foreground/80 shadow-md animate-pulse">
              ✋ SCRATCH HERE
            </div>
          </div>
        )}
      </div>

      {/* Progress bar */}
      {!fullyRevealed && (
        <div className="max-w-md mx-auto space-y-1">
          <div className="h-1.5 rounded-full bg-muted overflow-hidden">
            <div
              className="h-full bg-gradient-to-r from-amber-400 to-orange-500 transition-all duration-150"
              style={{ width: `${Math.min(100, (progress / SCRATCH_REVEAL_THRESHOLD) * 100)}%` }}
            />
          </div>
          <div className="text-[10px] text-center text-muted-foreground">
            {Math.round(progress * 100)}% scratched · auto-reveal at {Math.round(SCRATCH_REVEAL_THRESHOLD * 100)}%
          </div>
        </div>
      )}
    </div>
  );
}

// ═══════════════════════════════════════════════════════════════
// Helpers
// ═══════════════════════════════════════════════════════════════

function prizeValue(p: { kind: string; amount?: number }): number {
  return p.kind === "coins" ? (p.amount ?? 0) : 1;
}

function getPrizeEmoji(p: { kind: string; item_key?: string; label?: string }): string {
  if (p.kind === "item") {
    return getConsumableDef(p.item_key ?? "")?.emoji ?? "🎁";
  }
  // Try to extract leading emoji from label
  const m = (p.label ?? "").match(/^(\p{Emoji_Presentation}|\p{Extended_Pictographic})/u);
  return m?.[0] ?? "💰";
}

function showRewardToast(slices: WheelSlice[], totalCoins: number, cost: number): void {
  const top = slices.slice().sort((a, b) => b.coins - a.coins)[0];
  const net = totalCoins - cost;
  const items = slices.filter(s => s.item).map(s => `${s.emoji}×${s.item!.qty}`).join(" ");
  const sign = net >= 0 ? "+" : "";
  const headline = top.coins >= 10_000 ? `🎉 ${top.emoji} ${top.label}!` : "🎰 Spin complete";
  toast.success(`${headline}  Net ${sign}$${net.toLocaleString()}${items ? ` · ${items}` : ""}`, {
    duration: 5000,
  });
}

// ─── SVG arc + gradient helpers ────────────────────────────────

function polarToCartesian(cx: number, cy: number, r: number, angleDeg: number) {
  const a = (angleDeg * Math.PI) / 180;
  return { x: cx + r * Math.cos(a), y: cy + r * Math.sin(a) };
}

function describeArc(cx: number, cy: number, r: number, startA: number, endA: number): string {
  const start = polarToCartesian(cx, cy, r, endA);
  const end = polarToCartesian(cx, cy, r, startA);
  const large = endA - startA <= 180 ? "0" : "1";
  return [`M ${cx} ${cy}`, `L ${start.x} ${start.y}`, `A ${r} ${r} 0 ${large} 0 ${end.x} ${end.y}`, "Z"].join(" ");
}

/** Map the Tailwind gradient name to a hex color for SVG. Keep in sync with WHEEL_SLICES. */
const COLOR_MAP: Record<string, [string, string]> = {
  "from-fuchsia-600 to-purple-700": ["#c026d3", "#7e22ce"],
  "from-orange-500 to-red-600":     ["#f97316", "#dc2626"],
  "from-yellow-400 to-amber-500":   ["#facc15", "#f59e0b"],
  "from-emerald-500 to-green-600":  ["#10b981", "#16a34a"],
  "from-sky-500 to-blue-600":       ["#0ea5e9", "#2563eb"],
  "from-indigo-500 to-violet-600":  ["#6366f1", "#7c3aed"],
  "from-slate-500 to-slate-700":    ["#64748b", "#334155"],
  "from-cyan-400 to-sky-600":       ["#22d3ee", "#0284c7"],
  "from-yellow-300 to-yellow-500":  ["#fde047", "#eab308"],
  "from-pink-400 to-rose-600":      ["#f472b6", "#e11d48"],
  "from-zinc-700 to-zinc-900":      ["#3f3f46", "#18181b"],
};
function getGradientStart(g: string): string { return COLOR_MAP[g]?.[0] ?? "#888"; }
function getGradientEnd(g: string): string   { return COLOR_MAP[g]?.[1] ?? "#444"; }
