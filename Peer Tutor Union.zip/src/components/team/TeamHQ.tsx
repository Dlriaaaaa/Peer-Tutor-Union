/**
 * TeamHQ — The basketball team management hub. Shows the user's team
 * overview, current league progress, and entry points to roster/shop/history.
 * Triggers a league match by building the player roster from the starting
 * lineup and an AI roster sized to match.
 */
import { useEffect, useState, useMemo, lazy, Suspense } from "react";
import { supabase } from "@/integrations/supabase/client";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { DollarSign, Trophy, Store, Users, History, Play, BookOpen, Pencil, Swords, Crown, Wallet, Info, Tag, Banknote } from "lucide-react";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import TourChampionBadge from "./TourChampionBadge";
import { Link } from "react-router-dom";
import { Globe2 } from "lucide-react";
import PlayerCardView from "./PlayerCardView";
import {
  LEAGUE_META,
  LEAGUE_ORDER,
  getCoachDef,
  computeCoachBoost,
  type TeamManager,
  type PlayerCard,
  type PlayerTemplate,
  type League,
} from "@/lib/teamManager";
import { canAccessWorldTour } from "@/lib/worldTour";

// Lazy-load every dialog so initial HQ paint isn't blocked by ~9 dialog modules.
const PlayerDetailDialog    = lazy(() => import("./PlayerDetailDialog"));
const RosterDialog          = lazy(() => import("./RosterDialog"));
const ShopDialog            = lazy(() => import("./ShopDialog"));
const MatchHistoryDialog    = lazy(() => import("./MatchHistoryDialog"));
const PlayerCodexDialog     = lazy(() => import("./PlayerCodexDialog"));
const EditTeamDialog        = lazy(() => import("./EditTeamDialog"));

const LeaderboardDialog     = lazy(() => import("./LeaderboardDialog"));
const FriendDuelDialog      = lazy(() => import("./FriendDuelDialog"));
const RechargeDialog        = lazy(() => import("./RechargeDialog"));
const MarketplaceDialog     = lazy(() => import("./MarketplaceDialog"));
const LoanDialog            = lazy(() => import("./LoanDialog"));

interface TeamHQProps {
  /** Called when user starts a league match. Tools.tsx wires this up to BasketballGame. */
  onStartLeagueMatch: (params: {
    league: League;
    lineup: { card: PlayerCard; template: PlayerTemplate }[];
  }) => void;
  /** Called when user accepts a friend / leaderboard challenge. Triggers a live 60s 3v3 AI match. */
  onStartFriendMatch: (params: {
    bet: number;
    seconds?: number;
    drainOpponentStamina?: boolean;
    drainAmount?: number;
    opponent: {
      user_id: string;
      team: TeamManager;
      profile: { name: string; avatar_url?: string | null };
      lineup: { card: PlayerCard; template: PlayerTemplate }[];
    };
  }) => void;
}

export default function TeamHQ({ onStartLeagueMatch, onStartFriendMatch }: TeamHQProps) {
  const [team, setTeam] = useState<TeamManager | null>(null);
  const [cards, setCards] = useState<{ card: PlayerCard; template: PlayerTemplate }[]>([]);
  const [loading, setLoading] = useState(true);
  const [rosterOpen, setRosterOpen] = useState(false);
  const [shopOpen, setShopOpen] = useState(false);
  const [historyOpen, setHistoryOpen] = useState(false);
  const [codexOpen, setCodexOpen] = useState(false);
  const [editOpen, setEditOpen] = useState(false);
  
  const [leaderboardOpen, setLeaderboardOpen] = useState(false);
  const [duelOpen, setDuelOpen] = useState(false);
  const [rechargeOpen, setRechargeOpen] = useState(false);
  const [marketOpen, setMarketOpen] = useState(false);
  const [loanOpen, setLoanOpen] = useState(false);
  const [detail, setDetail] = useState<{ card: PlayerCard; template: PlayerTemplate } | null>(null);
  /** Aggregated coin flow from match_history for the balance breakdown popover. */
  const [balanceStats, setBalanceStats] = useState<{ earned: number; lost: number; matches: number } | null>(null);
  /** League the user has selected to play (defaults to current). Lets them grind unlocked leagues. */
  const [selectedLeague, setSelectedLeague] = useState<League | null>(null);
  /** Active loans (just principal + rate + taken_at) so we can compute live total owed. */
  const [activeLoans, setActiveLoans] = useState<{ principal: number; daily_rate: number; taken_at: string }[]>([]);
  /** Total currently owed across all active loans, recomputed every second. */
  const [totalOwed, setTotalOwed] = useState(0);

  const refreshAll = async () => {
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) { setLoading(false); return; }

    // Fire team + cards queries in parallel — both only need user.id.
    const [teamRes, cardsRes] = await Promise.all([
      supabase.from("team_managers").select("*").eq("user_id", user.id).maybeSingle(),
      supabase.from("player_cards")
        .select("*, template:player_templates(*)")
        .eq("user_id", user.id)
        .order("acquired_at", { ascending: false }),
    ]);

    let t = teamRes.data as TeamManager | null;
    if (!t) {
      // First-time user — initialize then re-fetch.
      await supabase.rpc("initialize_team_for_user", { _user_id: user.id });
      const r = await supabase.from("team_managers").select("*").eq("user_id", user.id).maybeSingle();
      t = r.data as TeamManager | null;
    }
    // Apply passive idle-stamina recovery for bench players (server-side, time-based).
    if (t) {
      try {
        await supabase.rpc("recover_idle_stamina" as any, {
          _lineup_ids: (t.starting_lineup ?? []) as string[],
        });
        // Re-fetch cards after recovery so UI shows the latest stamina values.
        const { data: refreshed } = await supabase.from("player_cards")
          .select("*, template:player_templates(*)")
          .eq("user_id", user.id)
          .order("acquired_at", { ascending: false });
        setCards(((refreshed ?? []) as any[]).map(row => ({ card: row, template: row.template })));
      } catch {
        setCards(((cardsRes.data ?? []) as any[]).map(row => ({ card: row, template: row.template })));
      }
    } else {
      setCards(((cardsRes.data ?? []) as any[]).map(row => ({ card: row, template: row.template })));
    }
    setTeam(t);
    setLoading(false);
  };

  useEffect(() => { refreshAll(); }, []);

  /** Mirror of server `principal_rate_surcharge` + `get_loan_balance` (1-min compounding). */
  const refreshLoans = async () => {
    const { data } = await supabase
      .from("loans")
      .select("principal, daily_rate, taken_at")
      .eq("status", "active");
    setActiveLoans((data ?? []) as any[]);
  };

  // Load loans whenever team changes, then poll every 30s for new/repaid loans.
  useEffect(() => {
    if (!team) return;
    refreshLoans();
    const id = setInterval(refreshLoans, 30000);
    return () => clearInterval(id);
  }, [team?.user_id]);

  // Recompute total owed every second so interest ticks live.
  useEffect(() => {
    const principalSurcharge = (p: number) =>
      p <= 30_000_000 ? 0 : p <= 50_000_000 ? 0.002 : p <= 90_000_000 ? 0.005 : 0.015;
    const tick = () => {
      let sum = 0;
      const now = Date.now();
      for (const l of activeLoans) {
        const periods = (now - new Date(l.taken_at).getTime()) / 86_400_000;
        const eff = l.daily_rate + principalSurcharge(l.principal);
        sum += Math.ceil(l.principal * Math.pow(1 + eff, periods));
      }
      setTotalOwed(sum);
    };
    tick();
    const id = setInterval(tick, 1000);
    return () => clearInterval(id);
  }, [activeLoans]);

  const netWorth = (team?.coins ?? 0) - totalOwed;

  const refreshCards = async () => {
    if (!team) return;
    const { data } = await supabase.from("player_cards")
      .select("*, template:player_templates(*)")
      .eq("user_id", team.user_id)
      .order("acquired_at", { ascending: false });
    setCards(((data ?? []) as any[]).map(row => ({ card: row, template: row.template })));
  };

  /** Loaded lazily when the user opens the balance popover — aggregates lifetime $ flow from matches. */
  const loadBalanceStats = async () => {
    if (!team || balanceStats) return;
    const { data } = await supabase
      .from("match_history")
      .select("coins_change")
      .eq("user_id", team.user_id);
    const rows = (data ?? []) as { coins_change: number }[];
    let earned = 0, lost = 0;
    for (const r of rows) {
      if (r.coins_change >= 0) earned += r.coins_change;
      else lost += -r.coins_change;
    }
    setBalanceStats({ earned, lost, matches: rows.length });
  };

  const lineup = useMemo(
    () =>
      (team?.starting_lineup ?? [])
        .map(id => cards.find(c => c.card.id === id))
        .filter((x): x is { card: PlayerCard; template: PlayerTemplate } => !!x),
    [team, cards],
  );

  if (loading) {
    return <p className="text-center py-12 text-sm text-muted-foreground">Loading team…</p>;
  }
  if (!team) {
    return (
      <Card className="p-6 text-center">
        <p>Please sign in to manage your team.</p>
      </Card>
    );
  }

  // Migrate legacy `worldchampion` league (now retired) to top-tier `nba`.
  const rawLeague = team.current_league as League;
  const currentLeague: League = LEAGUE_META[rawLeague] ? rawLeague : "nba";
  const currentIdx = LEAGUE_ORDER.indexOf(currentLeague);
  const playLeague = (selectedLeague && LEAGUE_ORDER.indexOf(selectedLeague) <= currentIdx) ? selectedLeague : currentLeague;
  const meta = LEAGUE_META[playLeague];
  const isReplay = playLeague !== currentLeague;
  // NBA Masters rematch (already cleared the 5-win promotion): high-stakes mode
  // — $10k entry, $300k win, no extra loss penalty. Mirrors applyMatchResult.
  const isNbaRematch = playLeague === "nba" && (team.league_wins ?? 0) >= LEAGUE_META.nba.promotionWins;
  const effEntryFee    = isNbaRematch ? 10000  : meta.entryFee;
  const effWinReward   = isNbaRematch ? 300000 : meta.winReward;
  const effLossPenalty = isNbaRematch ? 0      : meta.lossPenalty;
  const promotionPct = meta.next ? (team.league_wins / meta.promotionWins) * 100 : 100;
  const canPlay = lineup.length > 0 && team.coins >= effEntryFee;
  const coach = getCoachDef((team as any).coach_key);
  const coachMatchesLeft = ((team as any).coach_matches_left ?? 0) as number;
  const coachActive = !!coach && coachMatchesLeft > 0;
  const coachBoostPct = Math.round(computeCoachBoost(team) * 100);

  return (
    <div className="space-y-4">
      {/* ── Team Header ── */}
      <Card className="overflow-hidden">
        <div className="bg-gradient-to-r from-primary/20 via-primary/10 to-transparent p-4">
          <div className="flex items-center gap-4 flex-wrap">
            <button
              onClick={() => setEditOpen(true)}
              className="h-16 w-16 rounded-xl overflow-hidden ring-2 ring-primary/40 hover:scale-110 transition-transform flex items-center justify-center bg-muted/40 shrink-0"
              title="Edit team"
            >
              {team.team_logo_url ? (
                <img src={team.team_logo_url} alt={team.team_name} className="h-full w-full object-cover" />
              ) : (
                <span className="text-5xl">{team.team_emoji}</span>
              )}
            </button>
            <div className="flex-1 min-w-0">
              <div className="flex items-center gap-2 flex-wrap">
                <h2 className="text-xl font-bold truncate">{team.team_name}</h2>
                <TourChampionBadge count={team.wc_titles ?? 0} />
                <Button size="icon" variant="ghost" className="h-7 w-7" onClick={() => setEditOpen(true)} title="Edit">
                  <Pencil className="h-3.5 w-3.5" />
                </Button>
              </div>
              <div className="text-sm text-muted-foreground flex flex-wrap items-center gap-x-3 gap-y-0.5">
                <span>Record <span className="font-semibold text-foreground">{team.total_wins}</span>W {team.total_losses}L</span>
                <span>|</span>
                <span>Players <span className="font-semibold text-foreground">{new Set(cards.map(c => c.template.id)).size}</span></span>
              </div>
              {/* Coach badge — clickable to open Shop's Coach tab. Shows "Hire Coach" CTA if none. */}
              <button
                type="button"
                onClick={() => setShopOpen(true)}
                className={`mt-1.5 inline-flex items-center gap-1.5 rounded-full px-2 py-0.5 text-[11px] font-medium transition-colors ${
                  coach
                    ? "bg-gradient-to-r from-amber-500/20 to-yellow-400/20 text-amber-300 ring-1 ring-amber-400/40 hover:from-amber-500/30 hover:to-yellow-400/30"
                    : "bg-muted/60 text-muted-foreground ring-1 ring-border hover:bg-muted"
                }`}
                title={coach ? `Coach: ${coach.name} (+${coachBoostPct}% all stats)` : "No coach hired — tap to hire"}
              >
                <span>{coach ? coach.emoji : "📋"}</span>
                <span className="truncate max-w-[140px]">
                  {coach ? coach.name : "No Coach"}
                </span>
                {coach && (
                  <span className="font-bold tabular-nums text-emerald-400">
                    +{coachBoostPct}%
                  </span>
                )}
              </button>
            </div>
            <div className="text-right">
              <Popover onOpenChange={(o) => o && loadBalanceStats()}>
                <PopoverTrigger asChild>
                  <button
                    type="button"
                    className="group text-right rounded-md px-1 -mx-1 hover:bg-muted/40 transition-colors"
                    title="Click for balance breakdown"
                  >
                    <div className="text-[10px] uppercase tracking-wider text-muted-foreground flex items-center justify-end gap-1">
                      Balance <Info className="h-3 w-3 opacity-60 group-hover:opacity-100" />
                    </div>
                    <div className="text-2xl font-bold text-yellow-400 tabular-nums flex items-center gap-1.5">
                      <DollarSign className="h-5 w-5" /> {team.coins.toLocaleString()}
                    </div>
                    {totalOwed > 0 && (
                      <div className="text-[11px] tabular-nums mt-0.5 flex items-center justify-end gap-1">
                        <span className="text-muted-foreground">Net:</span>
                        <span className={`font-bold ${netWorth >= 0 ? "text-emerald-400" : "text-red-400"}`}>
                          {netWorth >= 0 ? "" : "-"}${Math.abs(netWorth).toLocaleString()}
                        </span>
                      </div>
                    )}
                  </button>
                </PopoverTrigger>
                <PopoverContent align="end" className="w-64 p-3 text-xs space-y-2">
                  <div className="font-semibold text-sm flex items-center gap-1.5">
                    <Wallet className="h-4 w-4" /> Balance Breakdown
                  </div>
                  <div className="space-y-1.5 border-t border-border pt-2">
                    <div className="flex justify-between">
                      <span className="text-muted-foreground">Current Balance</span>
                      <span className="font-bold text-yellow-400 tabular-nums">${team.coins.toLocaleString()}</span>
                    </div>
                    {balanceStats ? (
                      <>
                        <div className="flex justify-between">
                          <span className="text-muted-foreground">Match $ Earned</span>
                          <span className="font-semibold text-emerald-400 tabular-nums">+${balanceStats.earned.toLocaleString()}</span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-muted-foreground">Match $ Lost</span>
                          <span className="font-semibold text-red-400 tabular-nums">-${balanceStats.lost.toLocaleString()}</span>
                        </div>
                        <div className="flex justify-between border-t border-border pt-1.5">
                          <span className="text-muted-foreground">Net from Matches</span>
                          <span className={`font-bold tabular-nums ${balanceStats.earned - balanceStats.lost >= 0 ? "text-emerald-400" : "text-red-400"}`}>
                            {balanceStats.earned - balanceStats.lost >= 0 ? "+" : "-"}${Math.abs(balanceStats.earned - balanceStats.lost).toLocaleString()}
                          </span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-muted-foreground">Total Matches</span>
                          <span className="tabular-nums">{balanceStats.matches}</span>
                        </div>
                      </>
                    ) : (
                      <div className="text-muted-foreground italic">Loading match history…</div>
                    )}
                    {coach && (
                      <div className="flex justify-between border-t border-border pt-1.5">
                        <span className="text-muted-foreground">Active Coach</span>
                        <span className="font-semibold text-amber-300">{coach.emoji} +{coachBoostPct}%</span>
                      </div>
                    )}
                  </div>
                  <div className="text-[10px] text-muted-foreground italic pt-1">
                    Excludes shop purchases & pack draws.
                  </div>
                </PopoverContent>
              </Popover>
              <div className="mt-1.5 flex gap-1.5">
                <Button
                  size="sm"
                  variant="outline"
                  className="h-7 gap-1 text-xs border-green-500/40 text-green-400 hover:bg-green-500/10 hover:text-green-300"
                  onClick={() => setRechargeOpen(true)}
                >
                  <Wallet className="h-3 w-3" /> Recharge
                </Button>
                <Button
                  size="sm"
                  variant="outline"
                  className="h-7 gap-1 text-xs border-emerald-500/40 text-emerald-400 hover:bg-emerald-500/10 hover:text-emerald-300"
                  onClick={() => setLoanOpen(true)}
                >
                  <Banknote className="h-3 w-3" /> Loan
                </Button>
              </div>
            </div>
          </div>
        </div>
      </Card>

      {/* ── League Progress + Action ── */}
      <Card>
        <CardContent className="p-4 space-y-3">
          <div className="flex items-center justify-between flex-wrap gap-2">
            <div className="flex items-center gap-2">
              <Trophy className="h-5 w-5 text-yellow-400" />
              <div>
                <div className="font-bold flex items-center gap-2 flex-wrap">
                  {meta.emoji} {meta.label}
                  <Badge variant="secondary" className="text-[10px]">AI: {meta.difficulty}</Badge>
                  {isReplay && (
                    <Badge variant="outline" className="text-[10px] border-amber-500/60 text-amber-400">
                      Replay · No promotion
                    </Badge>
                  )}
                  {isNbaRematch && (
                    <Badge variant="outline" className="text-[10px] border-yellow-500/60 text-yellow-400">
                      👑 Rematch · High Stakes
                    </Badge>
                  )}
                </div>
                <div className="text-xs text-muted-foreground">
                  Entry <span className="text-amber-400">${effEntryFee.toLocaleString()}</span> ·
                  Win <span className="text-green-400">+${effWinReward.toLocaleString()}</span> ·
                  Loss <span className="text-red-400">-${effLossPenalty.toLocaleString()}</span>
                </div>
              </div>
            </div>
            <Button
              size="lg"
              className="gap-2 shadow-none hover:shadow-none hover:translate-y-0"
              disabled={!canPlay}
              onClick={() => onStartLeagueMatch({ league: playLeague, lineup })}
            >
              <Play className="h-4 w-4" /> {isReplay ? "Replay Match" : "Start League Match"}
            </Button>
          </div>

          {!isReplay && meta.next && (
            <div className="space-y-1">
              <div className="flex justify-between text-[11px] text-muted-foreground">
                <span>Promotion ({team.league_wins}/{meta.promotionWins} wins)</span>
                <span>Next: {LEAGUE_META[meta.next].emoji} {LEAGUE_META[meta.next].label}</span>
              </div>
              <Progress value={promotionPct} className="h-2" />
            </div>
          )}

          {/* NBA Masters has no `next` league, but still needs 5 wins to unlock World Tour. */}
          {!isReplay && !meta.next && (
            <div className="space-y-1">
              <div className="flex justify-between text-[11px] text-muted-foreground">
                <span>
                  Masters Wins ({Math.min(team.league_wins, meta.promotionWins)}/{meta.promotionWins})
                  {team.league_wins >= meta.promotionWins && (
                    <span className="ml-2 text-emerald-500 font-semibold">✓ Cleared</span>
                  )}
                </span>
                <span>Unlocks: 🌍 World Tour</span>
              </div>
              <Progress value={Math.min(100, (team.league_wins / meta.promotionWins) * 100)} className="h-2" />
              {team.league_wins >= meta.promotionWins && (
                <p className="text-[11px] text-emerald-500/90">
                  🏆 NBA Masters cleared — keep replaying for coins, or head to 🌍 World Tour below for new challenges.
                </p>
              )}
            </div>
          )}

          {!canPlay && (
            <p className="text-xs text-amber-500">
              {lineup.length === 0 ? "⚠️ Set your starting lineup first" : `⚠️ Not enough $ (need $${effEntryFee.toLocaleString()})`}
            </p>
          )}
        </CardContent>
      </Card>

      {/* ── World Tour entry — unlocked once player has reached NBA Masters. ── */}
      {canAccessWorldTour(team) && (
        <Card className="overflow-hidden border-amber-500/40 bg-gradient-to-r from-amber-500/10 via-yellow-500/5 to-transparent">
          <CardContent className="p-4 flex items-center justify-between gap-3 flex-wrap">
            <div className="flex items-center gap-3 min-w-0">
              <div className="h-12 w-12 rounded-xl bg-gradient-to-br from-amber-500 to-yellow-600 flex items-center justify-center shadow-lg shrink-0">
                <Globe2 className="h-6 w-6 text-amber-950" />
              </div>
              <div className="min-w-0">
                <div className="font-bold text-amber-300 flex items-center gap-2 flex-wrap">
                  🌍 World Tour Unlocked
                </div>
                <div className="text-xs text-muted-foreground">
                  30-stop global circuit · Road to the Finals · earn Tour Champion titles
                </div>
              </div>
            </div>
            <Button asChild size="sm" className="gap-2 bg-gradient-to-r from-amber-500 to-yellow-500 hover:from-amber-600 hover:to-yellow-600 text-amber-950">
              <Link to="/world-tour">
                <Globe2 className="h-4 w-4" /> Enter World Tour
              </Link>
            </Button>
          </CardContent>
        </Card>
      )}

      {/* ── Lineup Preview ── */}
      <Card>
        <CardContent className="p-4 space-y-3">
          <div className="flex items-center justify-between">
            <div className="font-semibold flex items-center gap-2">
              <Users className="h-4 w-4" /> Starting Lineup ({lineup.length}/3)
            </div>
            <Button size="sm" variant="outline" onClick={() => setRosterOpen(true)}>Edit Lineup</Button>
          </div>
          {lineup.length === 0 ? (
            <p className="text-sm text-muted-foreground text-center py-6">
              No lineup yet — tap "Edit Lineup" to pick 1-3 starters from your collection
            </p>
          ) : (
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-2">
              {lineup.map(({ card, template }) => (
                <PlayerCardView key={card.id} card={card} template={template} onInfoClick={() => setDetail({ card, template })} />
              ))}
            </div>
          )}
        </CardContent>
      </Card>

      {/* ── Other Actions ── */}
      <div className="grid grid-cols-2 sm:grid-cols-6 gap-2">
        <Button variant="outline" className="h-14 gap-2" onClick={() => setShopOpen(true)}>
          <Store className="h-4 w-4" /> Shop
        </Button>
        <Button variant="outline" className="h-14 gap-2" onClick={() => setMarketOpen(true)}>
          <Tag className="h-4 w-4" /> Market
        </Button>
        <Button variant="outline" className="h-14 gap-2" onClick={() => setCodexOpen(true)}>
          <BookOpen className="h-4 w-4" /> Player Codex
        </Button>
        <Button variant="outline" className="h-14 gap-2" onClick={() => setLeaderboardOpen(true)}>
          <Crown className="h-4 w-4" /> Leaderboard
        </Button>
        <Button variant="outline" className="h-14 gap-2 ring-1 ring-amber-400/30 hover:bg-amber-500/10" onClick={() => setDuelOpen(true)}>
          <Swords className="h-4 w-4 text-amber-400" /> Duel
        </Button>
        <Button variant="outline" className="h-14 gap-2" onClick={() => setHistoryOpen(true)}>
          <History className="h-4 w-4" /> Match History
        </Button>
      </div>

      {/* ── League Tier Roadmap (click to replay any unlocked league) ── */}
      <Card>
        <CardContent className="p-3">
          <div className="flex items-center justify-between mb-2">
            <div className="text-xs text-muted-foreground">League Ladder</div>
            {isReplay && (
              <button
                className="text-[10px] text-primary hover:underline"
                onClick={() => setSelectedLeague(null)}
              >
                ← Back to current league
              </button>
            )}
          </div>
          <div className="flex items-center justify-between gap-1 overflow-x-auto">
            {LEAGUE_ORDER.map(l => {
              const m = LEAGUE_META[l];
              const idx = LEAGUE_ORDER.indexOf(l);
              const isCurrent = l === currentLeague;
              const isSelected = l === playLeague;
              const reached = idx <= currentIdx;
              return (
                <button
                  key={l}
                  type="button"
                  disabled={!reached}
                  onClick={() => setSelectedLeague(l === currentLeague ? null : l)}
                  className={`flex flex-col items-center px-2 py-1.5 rounded text-[10px] flex-1 min-w-[60px] transition-all ${
                    isSelected ? "bg-primary/30 ring-2 ring-primary scale-105" :
                    isCurrent ? "bg-primary/15 ring-1 ring-primary/60" :
                    reached ? "opacity-100 hover:bg-muted/60 cursor-pointer" : "opacity-40 cursor-not-allowed"
                  }`}
                  title={reached ? (isCurrent ? "Current league" : "Click to replay") : "Locked"}
                >
                  <div className="text-xl">{m.emoji}</div>
                  <div className={`font-semibold ${isSelected ? "text-primary" : ""}`}>{m.label}</div>
                </button>
              );
            })}
          </div>
        </CardContent>
      </Card>

      {/* Lazy dialogs — only load the chunk after the user opens it once. */}
      <Suspense fallback={null}>
        {rosterOpen && (
          <RosterDialog
            open={rosterOpen}
            onOpenChange={setRosterOpen}
            team={team}
            ownedCards={cards}
            onSaved={setTeam}
            onTeamChange={setTeam}
            onCardChange={(c) => setCards(prev => prev.map(p => p.card.id === c.id ? { ...p, card: c } : p))}
          />
        )}
        {shopOpen && (
          <ShopDialog
            open={shopOpen}
            onOpenChange={setShopOpen}
            team={team}
            ownedCards={cards}
            onTeamChange={setTeam}
            onCardsChange={refreshCards}
          />
        )}
        {historyOpen && (
          <MatchHistoryDialog
            open={historyOpen}
            onOpenChange={setHistoryOpen}
            userId={team.user_id}
          />
        )}
        {codexOpen && (
          <PlayerCodexDialog
            open={codexOpen}
            onOpenChange={setCodexOpen}
            ownedCards={cards}
          />
        )}
        {editOpen && (
          <EditTeamDialog
            open={editOpen}
            onOpenChange={setEditOpen}
            team={team}
            onSaved={setTeam}
          />
        )}
        {leaderboardOpen && (
          <LeaderboardDialog
            open={leaderboardOpen}
            onOpenChange={setLeaderboardOpen}
            team={team}
            myLineup={lineup}
            onTeamChange={setTeam}
            onStartLiveMatch={(p) => { setLeaderboardOpen(false); onStartFriendMatch(p); }}
          />
        )}
        {duelOpen && (
          <FriendDuelDialog
            open={duelOpen}
            onOpenChange={setDuelOpen}
            team={team}
            myLineup={lineup}
            onTeamChange={setTeam}
          />
        )}
        {detail && (
          <PlayerDetailDialog
            open={!!detail}
            onOpenChange={(o) => !o && setDetail(null)}
            card={detail.card}
            template={detail.template}
            team={team}
            onTeamChange={setTeam}
            onCardChange={(c) => {
              setCards(prev => prev.map(p => p.card.id === c.id ? { ...p, card: c } : p));
              setDetail(d => d ? { ...d, card: c } : d);
            }}
          />
        )}
        {rechargeOpen && (
          <RechargeDialog open={rechargeOpen} onOpenChange={setRechargeOpen} />
        )}
        {marketOpen && (
          <MarketplaceDialog
            open={marketOpen}
            onOpenChange={setMarketOpen}
            team={team}
            ownedCards={cards}
            onTeamChange={setTeam}
            onCardsChange={refreshCards}
          />
        )}
        {loanOpen && team && (
          <LoanDialog
            open={loanOpen}
            onOpenChange={(o) => { setLoanOpen(o); if (!o) refreshLoans(); }}
            team={team}
            onTeamChange={(t) => { setTeam(t); refreshLoans(); }}
          />
        )}
      </Suspense>
    </div>
  );
}
