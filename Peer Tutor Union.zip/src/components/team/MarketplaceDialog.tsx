/**
 * MarketplaceDialog — Buy/sell player cards. Two tabs:
 *   • Browse: live listings from other teams (RPC-purchased).
 *   • Sell:   user's own roster, each card has Quick-sell or List buttons.
 *
 * Listings cannot be cancelled once posted (per product spec).
 */
import { useEffect, useState, useMemo, useCallback } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from "@/components/ui/dialog";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Checkbox } from "@/components/ui/checkbox";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Badge } from "@/components/ui/badge";
import { DollarSign, Store, Tag, Zap, AlertTriangle, ShoppingCart, CheckSquare, Square } from "lucide-react";
import { toast } from "sonner";
import PlayerAvatar from "./PlayerAvatar";
import {
  buyListing,
  getEffectiveStats,
  getQuickSellPrice,
  listCardForSale,
  loadActiveListings,
  loadMyListings,
  loadOrInitTeam,
  quickSellCard,
  RARITY_META,
  type MarketplaceListing,
  type PlayerCard,
  type PlayerTemplate,
  type TeamManager,
} from "@/lib/teamManager";

interface Props {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  team: TeamManager;
  ownedCards: { card: PlayerCard; template: PlayerTemplate }[];
  onTeamChange: (t: TeamManager) => void;
  onCardsChange: () => Promise<void> | void;
}

export default function MarketplaceDialog({ open, onOpenChange, team, ownedCards, onTeamChange, onCardsChange }: Props) {
  const [tab, setTab] = useState<"browse" | "sell">("browse");
  const [listings, setListings] = useState<MarketplaceListing[]>([]);
  const [myListings, setMyListings] = useState<MarketplaceListing[]>([]);
  const [loading, setLoading] = useState(false);
  const [busyId, setBusyId] = useState<string | null>(null);
  const [selectedIds, setSelectedIds] = useState<Set<string>>(new Set());
  const [bulkBuying, setBulkBuying] = useState(false);

  const refresh = useCallback(async () => {
    setLoading(true);
    const [all, mine] = await Promise.all([loadActiveListings(), loadMyListings(team.user_id)]);
    setListings(all.filter(l => l.seller_id !== team.user_id));
    setMyListings(mine);
    setLoading(false);
  }, [team.user_id]);

  useEffect(() => { if (open) refresh(); }, [open, refresh]);
  // Clear selection whenever the listings refresh
  useEffect(() => { setSelectedIds(new Set()); }, [listings]);

  const myListedCardIds = useMemo(() => new Set(myListings.map(l => l.card_id)), [myListings]);

  const selectedListings = useMemo(
    () => listings.filter(l => selectedIds.has(l.id)),
    [listings, selectedIds],
  );
  const selectedTotal = useMemo(
    () => selectedListings.reduce((sum, l) => sum + l.price, 0),
    [selectedListings],
  );

  const toggleSelect = (id: string) => {
    setSelectedIds(prev => {
      const next = new Set(prev);
      if (next.has(id)) next.delete(id); else next.add(id);
      return next;
    });
  };

  /** Toggle: if any selected, clear; else select max affordable subset (cheapest first). */
  const handleSelectAll = () => {
    if (selectedIds.size > 0) { setSelectedIds(new Set()); return; }
    const sorted = [...listings].sort((a, b) => a.price - b.price);
    const next = new Set<string>();
    let remaining = team.coins;
    for (const l of sorted) {
      if (l.price <= remaining) { next.add(l.id); remaining -= l.price; }
    }
    setSelectedIds(next);
  };

  const handleBulkBuy = async () => {
    if (selectedListings.length === 0) return;
    if (team.coins < selectedTotal) { toast.error("Not enough $ for selected"); return; }
    if (!confirm(`Buy ${selectedListings.length} card${selectedListings.length === 1 ? "" : "s"} for $${selectedTotal.toLocaleString()}?`)) return;
    setBulkBuying(true);
    let bought = 0; let failed = 0;
    const queue = [...selectedListings].sort((a, b) => a.price - b.price);
    for (const l of queue) {
      try { await buyListing(l.id); bought++; }
      catch { failed++; }
    }
    const updated = await loadOrInitTeam();
    if (updated) onTeamChange(updated);
    await onCardsChange();
    await refresh();
    setBulkBuying(false);
    if (bought > 0) toast.success(`Bought ${bought} card${bought === 1 ? "" : "s"}${failed ? ` · ${failed} failed` : ""}`);
    else toast.error("No cards purchased");
  };

  const handleBuy = async (l: MarketplaceListing) => {
    if (team.coins < l.price) { toast.error("Not enough $"); return; }
    setBusyId(l.id);
    try {
      await buyListing(l.id);
      const updated = await loadOrInitTeam();
      if (updated) onTeamChange(updated);
      await onCardsChange();
      await refresh();
      toast.success(`Bought ${l.template.name} for $${l.price.toLocaleString()}!`);
    } catch (e: any) {
      toast.error(e.message ?? "Purchase failed");
    } finally {
      setBusyId(null);
    }
  };

  const handleQuickSell = async (card: PlayerCard, template: PlayerTemplate) => {
    if (myListedCardIds.has(card.id)) { toast.error("Already listed — wait for it to sell"); return; }
    if (team.starting_lineup?.includes(card.id)) {
      if (!confirm(`${template.name} is in your starting lineup. Quick-sell anyway?`)) return;
    } else {
      if (!confirm(`Quick-sell ${template.name} for $${getQuickSellPrice(card, template).toLocaleString()}?`)) return;
    }
    setBusyId(card.id);
    try {
      const updated = await quickSellCard(team, card, template);
      onTeamChange(updated);
      await onCardsChange();
      toast.success(`+$${getQuickSellPrice(card, template).toLocaleString()}`);
    } catch (e: any) {
      toast.error(e.message ?? "Sell failed");
    } finally {
      setBusyId(null);
    }
  };

  const handleList = async (card: PlayerCard, template: PlayerTemplate, price: number) => {
    if (!Number.isFinite(price) || price < 1) { toast.error("Enter a valid price"); return; }
    setBusyId(card.id);
    try {
      await listCardForSale(card, price);
      await refresh();
      toast.success(`Listed ${template.name} for $${price.toLocaleString()}!`);
    } catch (e: any) {
      toast.error(e.message ?? "Listing failed");
    } finally {
      setBusyId(null);
    }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-3xl h-[85vh] overflow-hidden flex flex-col">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Store className="h-5 w-5" /> Player Marketplace
          </DialogTitle>
          <DialogDescription>
            Buy cards from other teams or sell your own. <span className="text-amber-400 font-medium">Once listed, cards cannot be unlisted.</span>
          </DialogDescription>
        </DialogHeader>

        <Tabs value={tab} onValueChange={(v) => setTab(v as any)} className="flex-1 flex flex-col overflow-hidden">
          <TabsList className="grid w-full grid-cols-2">
            <TabsTrigger value="browse">🛒 Browse ({listings.length})</TabsTrigger>
            <TabsTrigger value="sell">🏷️ Sell ({ownedCards.length})</TabsTrigger>
          </TabsList>

          {/* ── BROWSE ── */}
          <TabsContent value="browse" className="flex-1 overflow-hidden m-0 mt-3 flex flex-col">
            {/* Bulk-select toolbar (always shown when there are listings) */}
            {!loading && listings.length > 0 && (
              <div className="flex items-center gap-2 px-1 pb-2 flex-wrap border-b border-border/40 mb-2">
                <Button
                  size="sm"
                  variant="outline"
                  className="h-8 gap-1.5 text-xs"
                  onClick={handleSelectAll}
                  disabled={bulkBuying}
                >
                  {selectedIds.size > 0
                    ? <CheckSquare className="h-3.5 w-3.5" />
                    : <Square className="h-3.5 w-3.5" />}
                  {selectedIds.size > 0 ? `Clear (${selectedIds.size})` : "Select all affordable"}
                </Button>
                <span className="text-xs text-muted-foreground">
                  {selectedIds.size > 0
                    ? <>{selectedIds.size} selected · <span className="text-yellow-400 font-mono">${selectedTotal.toLocaleString()}</span></>
                    : <>Tap cards or use “Select all affordable”</>}
                </span>
                <Button
                  size="sm"
                  className="h-8 gap-1.5 text-xs ml-auto"
                  disabled={bulkBuying || selectedIds.size === 0 || team.coins < selectedTotal}
                  onClick={handleBulkBuy}
                >
                  <ShoppingCart className="h-3.5 w-3.5" />
                  {bulkBuying
                    ? "Buying…"
                    : selectedIds.size === 0
                      ? "Buy selected"
                      : team.coins < selectedTotal
                        ? "Need $"
                        : `Buy ${selectedIds.size}`}
                </Button>
              </div>
            )}
            <ScrollArea className="flex-1 h-full pr-2">
              {loading ? (
                <p className="text-center py-12 text-sm text-muted-foreground">Loading marketplace…</p>
              ) : listings.length === 0 ? (
                <p className="text-center py-12 text-sm text-muted-foreground">
                  No listings right now. Check back soon!
                </p>
              ) : (
                <div className="space-y-2 pb-2">
                  {listings.map((l) => (
                    <BrowseRow
                      key={l.id}
                      listing={l}
                      canAfford={team.coins >= l.price}
                      busy={busyId === l.id || bulkBuying}
                      selected={selectedIds.has(l.id)}
                      onToggleSelect={() => toggleSelect(l.id)}
                      onBuy={() => handleBuy(l)}
                    />
                  ))}
                </div>
              )}
            </ScrollArea>
          </TabsContent>


          {/* ── SELL ── */}
          <TabsContent value="sell" className="flex-1 overflow-hidden m-0 mt-3">
            <ScrollArea className="h-full pr-2">
              {ownedCards.length === 0 ? (
                <p className="text-center py-12 text-sm text-muted-foreground">No cards to sell.</p>
              ) : (
                <div className="space-y-2 pb-2">
                  {ownedCards.map(({ card, template }) => (
                    <SellRow
                      key={card.id}
                      card={card}
                      template={template}
                      inLineup={team.starting_lineup?.includes(card.id) ?? false}
                      isListed={myListedCardIds.has(card.id)}
                      listedPrice={myListings.find(m => m.card_id === card.id)?.price}
                      busy={busyId === card.id}
                      onQuickSell={() => handleQuickSell(card, template)}
                      onList={(p) => handleList(card, template, p)}
                    />
                  ))}
                </div>
              )}
            </ScrollArea>
          </TabsContent>
        </Tabs>
      </DialogContent>
    </Dialog>
  );
}

function BrowseRow({ listing, canAfford, busy, selected, onToggleSelect, onBuy }: {
  listing: MarketplaceListing;
  canAfford: boolean;
  busy: boolean;
  selected: boolean;
  onToggleSelect: () => void;
  onBuy: () => void;
}) {
  const meta = RARITY_META[listing.template.rarity as keyof typeof RARITY_META];
  const eff = getEffectiveStats(listing.card, listing.template);
  const selectDisabled = !canAfford || busy;

  const handleToggle = () => {
    if (selectDisabled) return;
    onToggleSelect();
  };

  return (
    <div
      className={`flex items-center gap-3 p-2.5 rounded-lg border bg-gradient-to-r ${meta.bg} ${selected ? "border-primary ring-2 ring-primary/40" : "border-border/40"} ${selectDisabled ? "opacity-70" : "cursor-pointer"}`}
      onClick={handleToggle}
      role="button"
      tabIndex={selectDisabled ? -1 : 0}
      onKeyDown={(e) => {
        if ((e.key === "Enter" || e.key === " ") && !selectDisabled) {
          e.preventDefault();
          onToggleSelect();
        }
      }}
      aria-pressed={selected}
      aria-label={`Select ${listing.template.name}`}
    >
      <div
        onClick={(e) => e.stopPropagation()}
        onKeyDown={(e) => e.stopPropagation()}
      >
        <Checkbox
          checked={selected}
          disabled={selectDisabled}
          onCheckedChange={() => onToggleSelect()}
          aria-label={`Select ${listing.template.name}`}
        />
      </div>
      <PlayerAvatar template={listing.template} size="md" />
      <div className="flex-1 min-w-0">
        <div className="flex items-center gap-2 flex-wrap">
          <span className="font-bold truncate">{listing.template.name}</span>
          <Badge variant="secondary" className={`text-[10px] ${meta.color}`}>{meta.label}</Badge>
          <Badge variant="outline" className="text-[10px]">Lv.{listing.card.level}</Badge>
          <Badge variant="outline" className="text-[10px] tabular-nums">OVR {eff.total}</Badge>
        </div>
        <div className="text-[11px] text-muted-foreground truncate">
          Sold by {listing.seller?.team_emoji} <span className="font-medium text-foreground/80">{listing.seller?.team_name ?? "Unknown"}</span>
        </div>
      </div>
      <div className="text-right shrink-0">
        <div className="text-yellow-400 font-bold tabular-nums flex items-center justify-end gap-0.5">
          <DollarSign className="h-3.5 w-3.5" /> {listing.price.toLocaleString()}
        </div>
        <Button
          size="sm"
          className="mt-1 h-7"
          disabled={!canAfford || busy}
          onClick={(e) => {
            e.stopPropagation();
            onBuy();
          }}
        >
          {busy ? "…" : canAfford ? "Buy" : "Need $"}
        </Button>
      </div>
    </div>
  );
}

function SellRow({ card, template, inLineup, isListed, listedPrice, busy, onQuickSell, onList }: {
  card: PlayerCard;
  template: PlayerTemplate;
  inLineup: boolean;
  isListed: boolean;
  listedPrice?: number;
  busy: boolean;
  onQuickSell: () => void;
  onList: (price: number) => void;
}) {
  const meta = RARITY_META[template.rarity as keyof typeof RARITY_META];
  const eff = getEffectiveStats(card, template);
  const quickPrice = getQuickSellPrice(card, template);
  const [price, setPrice] = useState<string>(String(quickPrice * 4));
  const [showListInput, setShowListInput] = useState(false);

  return (
    <div className={`p-2.5 rounded-lg border bg-gradient-to-r ${meta.bg} border-border/40 space-y-2`}>
      <div className="flex items-center gap-3">
        <PlayerAvatar template={template} size="md" />
        <div className="flex-1 min-w-0">
          <div className="flex items-center gap-2 flex-wrap">
            <span className="font-bold truncate">{template.name}</span>
            <Badge variant="secondary" className={`text-[10px] ${meta.color}`}>{meta.label}</Badge>
            <Badge variant="outline" className="text-[10px]">Lv.{card.level}</Badge>
            <Badge variant="outline" className="text-[10px] tabular-nums">OVR {eff.total}</Badge>
            {inLineup && <Badge className="text-[10px] bg-blue-500/20 text-blue-300 border-blue-500/40">In lineup</Badge>}
            {isListed && <Badge className="text-[10px] bg-amber-500/20 text-amber-300 border-amber-500/40">Listed ${listedPrice?.toLocaleString()}</Badge>}
          </div>
        </div>
      </div>

      {isListed ? (
        <div className="flex items-center gap-1.5 text-[11px] text-amber-400/90 px-1">
          <AlertTriangle className="h-3 w-3" /> Already on the marketplace · waiting for a buyer
        </div>
      ) : (
        <div className="flex flex-wrap gap-2">
          <Button
            size="sm"
            variant="outline"
            className="h-8 gap-1.5 text-xs"
            disabled={busy}
            onClick={onQuickSell}
          >
            <Zap className="h-3 w-3" /> Quick-sell <span className="text-yellow-400 font-bold">${quickPrice.toLocaleString()}</span>
          </Button>
          {!showListInput ? (
            <Button
              size="sm"
              variant="outline"
              className="h-8 gap-1.5 text-xs"
              disabled={busy}
              onClick={() => setShowListInput(true)}
            >
              <Tag className="h-3 w-3" /> List for sale…
            </Button>
          ) : (
            <div className="flex items-center gap-1.5">
              <DollarSign className="h-3.5 w-3.5 text-yellow-400" />
              <Input
                type="number"
                inputMode="numeric"
                min={1}
                max={10000000}
                value={price}
                onChange={(e) => setPrice(e.target.value)}
                className="h-8 w-28 text-sm"
                placeholder="Price"
              />
              <Button size="sm" className="h-8" disabled={busy} onClick={() => onList(Number(price))}>
                List
              </Button>
              <Button size="sm" variant="ghost" className="h-8" onClick={() => setShowListInput(false)}>Cancel</Button>
            </div>
          )}
        </div>
      )}
    </div>
  );
}
