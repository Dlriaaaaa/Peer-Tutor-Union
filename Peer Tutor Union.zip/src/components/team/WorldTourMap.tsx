/**
 * WorldTourMap — Interactive world map with clickable city markers.
 *
 * Each marker corresponds to a TourStop. Markers are positioned in
 * percentage coordinates derived from the original 1672×941 background
 * image, so they re-project correctly at any container width.
 *
 * Visual states:
 *   - locked     → faint grey dot, no pointer
 *   - upcoming   → blue glow, hoverable
 *   - current    → bright orange pulse, pulse ring (next playable)
 *   - completed  → gold dot with check
 *
 * Clicking a non-locked stop calls `onStopClick(stopId)`.
 */
import { useMemo, useRef, useState } from "react";
import {
  TOUR_STOPS,
  MAP_IMAGE_W,
  MAP_IMAGE_H,
  type TourStop,
  type TourState,
  type TourStatus,
  formatShortDate,
  entryFeeForStop,
  coinsRewardForStop,
} from "@/lib/worldTour";
import mapBg from "@/assets/world-tour-map.jpg";
import { CheckCircle2, Lock, MapPin, Trophy } from "lucide-react";

interface Props {
  state: TourState;
  onStopClick: (stop: TourStop) => void;
  /** Optional callback when user hovers — used to show external detail panel. */
  onStopHover?: (stop: TourStop | null) => void;
}

export default function WorldTourMap({ state, onStopClick, onStopHover }: Props) {
  const containerRef = useRef<HTMLDivElement | null>(null);
  const [hoverId, setHoverId] = useState<number | null>(null);

  /** Path connecting all stops in tour order — drawn as a glowing route line. */
  const routePath = useMemo(() => {
    return TOUR_STOPS
      .map((s, i) => `${i === 0 ? "M" : "L"} ${(s.x / MAP_IMAGE_W) * 100} ${(s.y / MAP_IMAGE_H) * 100}`)
      .join(" ");
  }, []);

  const statusFor = (stopId: number): TourStatus =>
    state.progress.find(p => p.stopId === stopId)?.status ?? "locked";

  return (
    <div
      ref={containerRef}
      className="relative w-full overflow-hidden rounded-xl ring-1 ring-amber-500/20 bg-[#03101e] select-none"
      style={{ aspectRatio: `${MAP_IMAGE_W} / ${MAP_IMAGE_H}` }}
    >
      {/* Background map */}
      <img
        src={mapBg}
        alt="World tour map"
        className="absolute inset-0 h-full w-full object-cover opacity-90 pointer-events-none"
        loading="eager"
        // @ts-ignore — fetchpriority is a valid HTML attribute (React 18 lower-cases it)
        fetchpriority="high"
        decoding="async"
        draggable={false}
        width={MAP_IMAGE_W}
        height={MAP_IMAGE_H}
      />
      {/* Subtle vignette */}
      <div
        className="absolute inset-0 pointer-events-none"
        style={{
          background:
            "radial-gradient(ellipse at center, transparent 40%, rgba(0,0,0,0.55) 100%)",
        }}
      />

      {/* Tour route line — dashed glowing path through all stops */}
      <svg
        className="absolute inset-0 h-full w-full pointer-events-none"
        viewBox="0 0 100 100"
        preserveAspectRatio="none"
        aria-hidden
      >
        <path
          d={routePath}
          stroke="rgba(251, 191, 36, 0.35)"
          strokeWidth="0.18"
          strokeDasharray="0.5 0.6"
          fill="none"
          vectorEffect="non-scaling-stroke"
          style={{ filter: "drop-shadow(0 0 2px rgba(251,191,36,0.6))" }}
        />
      </svg>

      {/* Markers */}
      {TOUR_STOPS.map(stop => {
        const status = statusFor(stop.id);
        const xPct = (stop.x / MAP_IMAGE_W) * 100;
        const yPct = (stop.y / MAP_IMAGE_H) * 100;
        const isHover = hoverId === stop.id;
        const clickable = status !== "locked";
        return (
          <button
            key={stop.id}
            type="button"
            onClick={() => clickable && onStopClick(stop)}
            onMouseEnter={() => { setHoverId(stop.id); onStopHover?.(stop); }}
            onMouseLeave={() => { setHoverId(null);  onStopHover?.(null); }}
            disabled={!clickable}
            className={`absolute -translate-x-1/2 -translate-y-1/2 group ${clickable ? "cursor-pointer" : "cursor-not-allowed"}`}
            style={{ left: `${xPct}%`, top: `${yPct}%` }}
            aria-label={`${stop.eventName} (${stop.city})`}
          >
            <Marker status={status} isFinals={stop.id === TOUR_STOPS[TOUR_STOPS.length - 1].id} />
            {/* Hover tooltip */}
            {isHover && (
              <div className="absolute left-1/2 -translate-x-1/2 -top-2 -translate-y-full z-30 pointer-events-none whitespace-nowrap">
                <div className="rounded-lg bg-slate-950/95 ring-1 ring-amber-400/40 px-2.5 py-1.5 shadow-xl text-left">
                  <div className="text-[10px] font-bold text-amber-300 uppercase tracking-wider">
                    {`#${stop.id} · ${formatShortDate(stop.startDate)}`}
                    {stop.pointsWeight >= 2 && <span className="ml-1 text-yellow-300">★ FINALS</span>}
                    {stop.pointsWeight === 1.5 && <span className="ml-1 text-orange-300">★ MAJOR</span>}
                  </div>
                  <div className="text-xs font-bold text-white">{stop.eventName}</div>
                  <div className="text-[10px] text-slate-400">{stop.city} · {stop.country}</div>
                  <div className="text-[10px] text-slate-500 italic">{stop.venue}</div>
                  <div className="mt-1 flex items-center gap-2 text-[10px]">
                    <span className="text-rose-300">💸 ${entryFeeForStop(stop.id).toLocaleString()}</span>
                    {coinsRewardForStop(stop.id) > 0 && (
                      <span className="text-emerald-300">🏆 +${coinsRewardForStop(stop.id).toLocaleString()}</span>
                    )}
                  </div>
                  <StatusChip status={status} />
                </div>
              </div>
            )}
          </button>
        );
      })}

      {/* Map legend */}
      <div className="absolute bottom-2 left-2 right-2 flex flex-wrap gap-2 text-[10px] text-white/80 pointer-events-none">
        <Legend swatch="bg-amber-400 ring-amber-300/60" label="Current" />
        <Legend swatch="bg-emerald-400 ring-emerald-300/60" label="Completed" />
        <Legend swatch="bg-sky-400 ring-sky-300/60" label="Upcoming" />
        <Legend swatch="bg-slate-600 ring-slate-500/60" label="Locked" />
        <div className="ml-auto rounded-md bg-slate-950/80 ring-1 ring-white/10 px-2 py-0.5 flex items-center gap-1">
          <Trophy className="h-3 w-3 text-yellow-300" /> World Final · Shanghai
        </div>
      </div>
    </div>
  );
}

function Marker({ status, isFinals }: { status: TourStatus; isFinals: boolean }) {
  if (status === "locked") {
    return (
      <span className="relative flex items-center justify-center">
        <span className="block h-2 w-2 rounded-full bg-slate-600 ring-1 ring-slate-500/60" />
        <Lock className="absolute h-2.5 w-2.5 text-slate-700 -top-0.5 -right-2 opacity-70" />
      </span>
    );
  }
  if (status === "completed") {
    return (
      <span className="relative flex items-center justify-center">
        <span className="block h-3 w-3 rounded-full bg-emerald-400 ring-2 ring-emerald-300/70 shadow-[0_0_8px_2px_rgba(52,211,153,0.6)]" />
        <CheckCircle2 className="absolute h-3 w-3 text-emerald-100" />
      </span>
    );
  }
  if (status === "current") {
    return (
      <span className="relative flex items-center justify-center">
        <span className="absolute inline-flex h-6 w-6 rounded-full bg-amber-400/40 animate-ping" />
        <span className={`relative block ${isFinals ? "h-4 w-4" : "h-3 w-3"} rounded-full bg-amber-400 ring-2 ring-amber-200 shadow-[0_0_12px_3px_rgba(251,191,36,0.85)]`}>
          {isFinals && <Trophy className="absolute inset-0 m-auto h-2.5 w-2.5 text-amber-900" />}
        </span>
      </span>
    );
  }
  // upcoming
  return (
    <span className="relative flex items-center justify-center group-hover:scale-125 transition-transform">
      <span className={`block ${isFinals ? "h-4 w-4" : "h-2.5 w-2.5"} rounded-full bg-sky-400 ring-2 ring-sky-200/70 shadow-[0_0_8px_2px_rgba(56,189,248,0.6)]`}>
        {isFinals && <Trophy className="absolute inset-0 m-auto h-2.5 w-2.5 text-sky-900" />}
      </span>
    </span>
  );
}

function StatusChip({ status }: { status: TourStatus }) {
  const map: Record<TourStatus, { label: string; cls: string }> = {
    locked:    { label: "🔒 Locked",      cls: "bg-slate-700/70 text-slate-300" },
    upcoming:  { label: "⏳ Upcoming",    cls: "bg-sky-500/30 text-sky-200" },
    current:   { label: "🔥 Up Next",     cls: "bg-amber-500/40 text-amber-100" },
    completed: { label: "✓ Completed",    cls: "bg-emerald-500/30 text-emerald-200" },
  };
  const m = map[status];
  return (
    <div className={`mt-1 inline-flex items-center rounded-full px-2 py-0.5 text-[10px] font-bold ${m.cls}`}>
      <MapPin className="h-2.5 w-2.5 mr-1" /> {m.label}
    </div>
  );
}

function Legend({ swatch, label }: { swatch: string; label: string }) {
  return (
    <div className="flex items-center gap-1 rounded-md bg-slate-950/70 ring-1 ring-white/10 px-1.5 py-0.5">
      <span className={`h-2 w-2 rounded-full ${swatch} ring-1`} />
      <span>{label}</span>
    </div>
  );
}
