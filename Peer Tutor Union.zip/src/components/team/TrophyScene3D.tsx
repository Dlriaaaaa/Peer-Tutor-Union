/**
 * TrophyScene3D — A rotating golden championship trophy for the
 * World Champion match intro. Used inside MatchIntroOverlay.
 *
 * Built with @react-three/fiber primitives only — no external GLTF assets,
 * so it's instantly available without network fetches.
 */
import { Canvas, useFrame } from "@react-three/fiber";
import { useRef } from "react";
import type { Mesh, Group } from "three";

function Trophy() {
  const groupRef = useRef<Group>(null);
  const cupRef = useRef<Mesh>(null);

  useFrame((_, delta) => {
    if (groupRef.current) groupRef.current.rotation.y += delta * 0.7;
    if (cupRef.current) {
      // Gentle bobbing for added life
      cupRef.current.position.y = 0.3 + Math.sin(performance.now() / 500) * 0.05;
    }
  });

  // Gold material via emissive + metal-ish shading (basic mesh standard)
  const goldColor = "#fbbf24";
  const goldEmissive = "#f59e0b";

  return (
    <group ref={groupRef}>
      {/* ── Base (square pedestal) ── */}
      <mesh position={[0, -1.6, 0]}>
        <boxGeometry args={[1.6, 0.25, 1.6]} />
        <meshStandardMaterial color="#7c2d12" roughness={0.35} metalness={0.4} />
      </mesh>
      <mesh position={[0, -1.4, 0]}>
        <boxGeometry args={[1.3, 0.15, 1.3]} />
        <meshStandardMaterial color={goldColor} emissive={goldEmissive} emissiveIntensity={0.25} metalness={0.95} roughness={0.15} />
      </mesh>

      {/* ── Stem ── */}
      <mesh position={[0, -1.0, 0]}>
        <cylinderGeometry args={[0.18, 0.28, 0.55, 24]} />
        <meshStandardMaterial color={goldColor} emissive={goldEmissive} emissiveIntensity={0.35} metalness={0.95} roughness={0.1} />
      </mesh>

      {/* ── Cup body ── */}
      <mesh ref={cupRef} position={[0, 0.3, 0]}>
        <cylinderGeometry args={[0.85, 0.45, 1.4, 32]} />
        <meshStandardMaterial color={goldColor} emissive={goldEmissive} emissiveIntensity={0.4} metalness={1} roughness={0.08} />
      </mesh>

      {/* ── Cup rim (slightly wider torus on top) ── */}
      <mesh position={[0, 1.0, 0]} rotation={[Math.PI / 2, 0, 0]}>
        <torusGeometry args={[0.85, 0.08, 16, 48]} />
        <meshStandardMaterial color={goldColor} emissive={goldEmissive} emissiveIntensity={0.5} metalness={1} roughness={0.05} />
      </mesh>

      {/* ── Handles (torus on each side) ── */}
      {[-1, 1].map((side) => (
        <mesh key={side} position={[side * 0.95, 0.3, 0]} rotation={[0, 0, side * 0.4]}>
          <torusGeometry args={[0.32, 0.06, 12, 32]} />
          <meshStandardMaterial color={goldColor} emissive={goldEmissive} emissiveIntensity={0.4} metalness={1} roughness={0.1} />
        </mesh>
      ))}

      {/* ── Star on the front ── */}
      <mesh position={[0, 0.4, 0.86]} rotation={[0, 0, 0]}>
        <sphereGeometry args={[0.18, 16, 16]} />
        <meshStandardMaterial color="#fef3c7" emissive="#facc15" emissiveIntensity={0.9} metalness={0.6} roughness={0.2} />
      </mesh>

      {/* ── Sparkle particles ── */}
      {Array.from({ length: 8 }).map((_, i) => {
        const angle = (i / 8) * Math.PI * 2;
        const r = 1.6;
        return (
          <mesh key={i} position={[Math.cos(angle) * r, 0.4 + Math.sin(angle) * 0.5, Math.sin(angle) * r]}>
            <sphereGeometry args={[0.04, 8, 8]} />
            <meshStandardMaterial color="#fde68a" emissive="#fbbf24" emissiveIntensity={1.5} />
          </mesh>
        );
      })}
    </group>
  );
}

export default function TrophyScene3D() {
  return (
    <Canvas camera={{ position: [0, 0.5, 5], fov: 35 }} dpr={[1, 2]}>
      <ambientLight intensity={0.4} />
      <pointLight position={[5, 5, 5]} intensity={1.5} color="#fff7ed" />
      <pointLight position={[-3, 2, 4]} intensity={1} color="#fbbf24" />
      <pointLight position={[0, -3, 3]} intensity={0.5} color="#f97316" />
      <Trophy />
    </Canvas>
  );
}
