/**
 * RosterDialog — Pick the 3 starting lineup cards from owned roster.
 */
import { useEffect, useMemo, useState } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { ScrollArea } from "@/components/ui/scroll-area";
import { toast } from "sonner";
import PlayerCardView from "./PlayerCardView";
import PlayerDetailDialog from "./PlayerDetailDialog";
import { setStartingLineup, needsRest, getStamina, type PlayerCard, type PlayerTemplate, type TeamManager } from "@/lib/teamManager";

interface RosterDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  team: TeamManager;
  ownedCards: { card: PlayerCard; template: PlayerTemplate }[];
  onSaved: (team: TeamManager) => void;
  /** Optional — pass to enable the "Rest" action inside the player detail popup. */
  onTeamChange?: (team: TeamManager) => void;
  onCardChange?: (card: PlayerCard) => void;
}

const LINEUP_SIZE = 3;

export default function RosterDialog({ open, onOpenChange, team, ownedCards, onSaved, onTeamChange, onCardChange }: RosterDialogProps) {
  const [selected, setSelected] = useState<string[]>([]);
  const [saving, setSaving] = useState(false);
  const [detail, setDetail] = useState<{ card: PlayerCard; template: PlayerTemplate } | null>(null);

  useEffect(() => {
    if (open) setSelected(team.starting_lineup ?? []);
  }, [open, team.starting_lineup]);

  const sortedCards = useMemo(() => {
    const rarityRank = { legendary: 5, epic: 4, gold: 3, silver: 2, bronze: 1 } as const;
    return [...ownedCards].sort((a, b) =>
      (rarityRank[b.template.rarity as keyof typeof rarityRank] ?? 0) -
      (rarityRank[a.template.rarity as keyof typeof rarityRank] ?? 0),
    );
  }, [ownedCards]);

  const toggle = (cardId: string) => {
    setSelected(prev => {
      if (prev.includes(cardId)) return prev.filter(id => id !== cardId);
      const card = ownedCards.find(c => c.card.id === cardId)?.card;
      if (card && needsRest(card)) {
        toast.error(`${ownedCards.find(c => c.card.id === cardId)?.template.name ?? "Player"} is too tired (${getStamina(card)}/100). Let them rest first.`);
        return prev;
      }
      if (prev.length >= LINEUP_SIZE) {
        toast.error(`Max ${LINEUP_SIZE} starting slots`);
        return prev;
      }
      return [...prev, cardId];
    });
  };

  const handleSave = async () => {
    if (selected.length === 0) {
      toast.error("Pick at least 1 starter");
      return;
    }
    setSaving(true);
    try {
      const updated = await setStartingLineup(team, selected);
      toast.success("Lineup saved");
      onSaved(updated);
      onOpenChange(false);
    } catch (e: any) {
      toast.error(e.message ?? "Save failed");
    } finally {
      setSaving(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-3xl h-[85vh] overflow-hidden flex flex-col">
        <DialogHeader>
          <DialogTitle>Set Starting Lineup</DialogTitle>
          <DialogDescription>
            Pick up to {LINEUP_SIZE} starters. Selected <span className="font-bold text-foreground">{selected.length}/{LINEUP_SIZE}</span>
          </DialogDescription>
        </DialogHeader>

        <ScrollArea className="flex-1 h-0 min-h-0 -mx-2 px-2">
          {sortedCards.length === 0 ? (
            <p className="text-center text-sm text-muted-foreground py-12">
              You don't have any player cards yet — visit the shop to open packs!
            </p>
          ) : (
            <div className="grid grid-cols-2 sm:grid-cols-3 gap-3 pb-2">
              {sortedCards.map(({ card, template }) => (
                <PlayerCardView
                  key={card.id}
                  card={card}
                  template={template}
                  selected={selected.includes(card.id)}
                  onClick={() => toggle(card.id)}
                  onInfoClick={() => setDetail({ card, template })}
                />
              ))}
            </div>
          )}
        </ScrollArea>

        <div className="flex justify-end gap-2 pt-2 border-t border-border/40">
          <Button variant="ghost" onClick={() => onOpenChange(false)}>Cancel</Button>
          <Button onClick={handleSave} disabled={saving || selected.length === 0}>Save Lineup</Button>
        </div>
      </DialogContent>
      <PlayerDetailDialog
        open={!!detail}
        onOpenChange={(o) => !o && setDetail(null)}
        card={detail?.card ?? null}
        template={detail?.template ?? null}
        team={team}
        onTeamChange={onTeamChange}
        onCardChange={(c) => {
          onCardChange?.(c);
          setDetail(d => d ? { ...d, card: c } : d);
        }}
      />
    </Dialog>
  );
}
