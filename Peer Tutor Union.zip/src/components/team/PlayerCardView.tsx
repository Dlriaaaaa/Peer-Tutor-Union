/**
 * PlayerCardView — Reusable card display showing real-person headshot,
 * name, rarity color, level, OVR, and a small radar of the 5 stats.
 * Cards with OVR ≥ 500 get a crown icon next to the OVR badge.
 */
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Crown, Info } from "lucide-react";
import PlayerAvatar from "./PlayerAvatar";
import {
  RARITY_META,
  getEffectiveStats,
  getStamina,
  needsRest,
  isEvolved,
  getEvolutionTier,
  type PlayerCard,
  type PlayerTemplate,
} from "@/lib/teamManager";

interface PlayerCardViewProps {
  card: PlayerCard;
  template: PlayerTemplate;
  selected?: boolean;
  compact?: boolean;
  onClick?: () => void;
  /** Optional info button handler (renders an "i" overlay icon) */
  onInfoClick?: () => void;
  /** Optional badge shown in the top-right (e.g. "👑 You") */
  badgeRight?: string;
}

const STAT_LABELS = [
  { key: "speed",       cn: "Speed",   short: "SPD" },
  { key: "shooting",    cn: "Shoot",   short: "SHT" },
  { key: "three_point", cn: "3PT",     short: "3PT" },
  { key: "defense",     cn: "Defense", short: "DEF" },
  { key: "dunk",        cn: "Dunk",    short: "DNK" },
] as const;

export default function PlayerCardView({ card, template, selected, compact, onClick, onInfoClick, badgeRight }: PlayerCardViewProps) {
  const meta = RARITY_META[template.rarity as keyof typeof RARITY_META];
  const stats = getEffectiveStats(card, template);
  const evolved = isEvolved(card);
  const evolveTier = getEvolutionTier(card);

  const isLegendary = template.rarity === "legendary";
  const isEpic = template.rarity === "epic";
  const labelClass = evolved
    ? "evolved-text"
    : isLegendary ? "legendary-text" : isEpic ? "epic-text" : meta.color;

  return (
    <Card
      onClick={onClick}
      className={[
        "relative overflow-hidden transition-all",
        evolved ? "evolved-card" : `bg-gradient-to-br ${meta.bg}`,
        selected
          ? `ring-4 ring-primary ring-offset-2 ring-offset-background scale-[1.04] shadow-2xl shadow-primary/40 brightness-110`
          : "",
        compact ? "p-2" : "p-3",
        onClick ? "cursor-pointer hover:scale-[1.03]" : "",
      ].join(" ")}
    >
      {/* Rarity stripe — gold sheen for evolved cards */}
      <div className={evolved ? "evolved-stripe absolute top-0 left-0 right-0" : `absolute top-0 left-0 right-0 h-1 ${meta.color.replace("text-", "bg-")}`} />
      {selected && (
        <div className="absolute top-1.5 left-1.5 z-10 h-6 w-6 rounded-full bg-primary text-primary-foreground flex items-center justify-center text-xs font-bold shadow-lg">
          ✓
        </div>
      )}
      {badgeRight && (
        <div className="absolute top-1.5 right-1.5 z-10">
          <Badge className="text-[9px] h-5 bg-primary text-primary-foreground">{badgeRight}</Badge>
        </div>
      )}
      {onInfoClick && !badgeRight && (
        <button
          type="button"
          onClick={(e) => { e.stopPropagation(); onInfoClick(); }}
          className="absolute top-1.5 right-1.5 z-20 h-6 w-6 rounded-full bg-background/80 hover:bg-background backdrop-blur-sm border border-border flex items-center justify-center text-muted-foreground hover:text-foreground transition-colors shadow-sm"
          aria-label="View player details"
        >
          <Info className="h-3.5 w-3.5" />
        </button>
      )}

      <div className="flex items-start gap-2 relative z-[1]">
        <PlayerAvatar template={template} size={compact ? "md" : "lg"} />
        <div className="flex-1 min-w-0">
          <div className="flex items-center justify-between gap-1">
            <span className={`text-xs font-extrabold uppercase tracking-wider ${labelClass}`}>{meta.label}</span>
            <Badge variant="secondary" className="text-[10px] h-4 px-1.5">Lv.{card.level}</Badge>
          </div>
          <div className="font-semibold text-sm truncate">{template.name}</div>
          <div className="flex items-center gap-1.5 mt-0.5">
            <span className={[
              "inline-flex items-center justify-center rounded px-1.5 py-0.5 text-[10px] font-extrabold tabular-nums",
              stats.total >= 450 ? "bg-orange-500/20 text-orange-400 ring-1 ring-orange-500/40" :
              stats.total >= 400 ? "bg-purple-500/20 text-purple-400 ring-1 ring-purple-500/40" :
              stats.total >= 320 ? "bg-yellow-500/20 text-yellow-400 ring-1 ring-yellow-500/40" :
              stats.total >= 240 ? "bg-zinc-400/20 text-zinc-300 ring-1 ring-zinc-400/40" :
                                   "bg-amber-700/20 text-amber-600 ring-1 ring-amber-700/40",
            ].join(" ")}>OVR {stats.total}</span>
            {stats.total >= 500 && (
              <Crown
                className="h-3.5 w-3.5 text-yellow-400 drop-shadow-[0_0_4px_rgba(250,204,21,0.85)]"
                aria-label="Elite player (OVR 500+)"
              />
            )}
            {evolved && (
              <span
                className="inline-flex items-center rounded px-1 py-0 text-[9px] font-extrabold evolved-text leading-tight"
                title={`Super Evolved ×${evolveTier}`}
              >
                ✨{evolveTier > 1 ? `×${evolveTier}` : ""}
              </span>
            )}
          </div>
        </div>
      </div>

      {/* Stamina bar */}
      {(() => {
        const sta = getStamina(card);
        const tired = needsRest(card);
        const barColor = sta >= 60 ? "bg-emerald-500" : sta >= 30 ? "bg-yellow-500" : "bg-red-500";
        return (
          <div className={compact ? "mt-1.5" : "mt-2"} title={`Stamina ${sta}/100${tired ? " · needs rest" : ""}`}>
            <div className="flex items-center justify-between text-[9px] mb-0.5">
              <span className={tired ? "text-red-400 font-bold" : "text-muted-foreground"}>
                {tired ? "🛌 Tired" : "❤️ Stamina"}
              </span>
              <span className={`tabular-nums font-bold ${tired ? "text-red-400" : "text-muted-foreground"}`}>{sta}</span>
            </div>
            <div className="h-1 w-full rounded-full bg-background/60 overflow-hidden">
              <div className={`h-full ${barColor} transition-all`} style={{ width: `${sta}%` }} />
            </div>
          </div>
        );
      })()}

      {!compact && (
        <div className="grid grid-cols-5 gap-1 mt-2">
          {STAT_LABELS.map(s => {
            const v = stats[s.key as keyof typeof stats] as number;
            return (
              <div key={s.key} className="text-center">
                <div className="text-[9px] text-muted-foreground">{s.short}</div>
                <div className={`text-xs font-bold ${v >= 90 ? "text-orange-400" : v >= 75 ? "text-yellow-400" : v >= 55 ? "text-foreground" : "text-muted-foreground"}`}>{v}</div>
              </div>
            );
          })}
        </div>
      )}
    </Card>
  );
}
