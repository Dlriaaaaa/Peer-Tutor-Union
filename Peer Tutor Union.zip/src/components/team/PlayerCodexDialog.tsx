/**
 * PlayerCodexDialog — "Pokédex" of all player templates.
 * Owned templates show full color + count, unowned are grayscaled and locked.
 */
import { useEffect, useMemo, useState } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from "@/components/ui/dialog";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Lock } from "lucide-react";
import PlayerAvatar from "./PlayerAvatar";
import {
  loadAllTemplates,
  RARITY_META,
  RARITY_ORDER,
  type PlayerCard,
  type PlayerTemplate,
} from "@/lib/teamManager";

interface Props {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  ownedCards: { card: PlayerCard; template: PlayerTemplate }[];
}

export default function PlayerCodexDialog({ open, onOpenChange, ownedCards }: Props) {
  const [templates, setTemplates] = useState<PlayerTemplate[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!open) return;
    setLoading(true);
    loadAllTemplates().then(t => {
      setTemplates(t);
      setLoading(false);
    });
  }, [open]);

  const ownedCounts = useMemo(() => {
    const m = new Map<string, number>();
    for (const { template } of ownedCards) m.set(template.id, (m.get(template.id) ?? 0) + 1);
    return m;
  }, [ownedCards]);

  const grouped = useMemo(() => {
    const g: Record<string, PlayerTemplate[]> = {};
    for (const t of templates) (g[t.rarity] ??= []).push(t);
    return g;
  }, [templates]);

  const ownedTotal = ownedCounts.size;
  const total = templates.length;

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-4xl h-[85vh] !grid-cols-none !flex flex-col gap-4 overflow-hidden">
        <DialogHeader>
          <DialogTitle>Player Codex</DialogTitle>
          <DialogDescription>
            Collected <span className="font-bold text-foreground">{ownedTotal}/{total}</span> · Greyed = locked, try the shop's card packs to unlock more
          </DialogDescription>
        </DialogHeader>

        <ScrollArea className="flex-1 min-h-0 -mx-2 px-2">
          {loading ? (
            <p className="text-center py-12 text-sm text-muted-foreground">Loading…</p>
          ) : (
            <div className="space-y-4 pb-2">
              {RARITY_ORDER.slice().reverse().map(rarity => {
                const list = grouped[rarity] ?? [];
                if (list.length === 0) return null;
                const meta = RARITY_META[rarity];
                const ownedInTier = list.filter(t => ownedCounts.has(t.id)).length;
                return (
                  <div key={rarity}>
                    <div className="flex items-center gap-2 mb-2">
                      <span className={`font-bold ${meta.color}`}>{meta.label}</span>
                      <Badge variant="secondary" className="text-[10px]">{ownedInTier}/{list.length}</Badge>
                    </div>
                    <div className="grid grid-cols-3 sm:grid-cols-4 md:grid-cols-5 gap-2">
                      {list.map(t => {
                        const owned = ownedCounts.get(t.id) ?? 0;
                        const total = t.speed + t.shooting + t.three_point + t.defense + t.dunk;
                        return (
                          <Card
                            key={t.id}
                            className={[
                              "relative p-2 flex flex-col items-center gap-1.5 text-center transition-all",
                              `bg-gradient-to-br ${meta.bg}`,
                              owned ? "" : "opacity-40 grayscale",
                            ].join(" ")}
                          >
                            <div className="relative">
                              <PlayerAvatar template={t} size="lg" grayscale={owned === 0} />
                              {owned === 0 && (
                                <div className="absolute inset-0 flex items-center justify-center">
                                  <Lock className="h-5 w-5 text-foreground/80" />
                                </div>
                              )}
                              {owned > 1 && (
                                <Badge className="absolute -top-1 -right-1 h-5 w-5 p-0 flex items-center justify-center text-[10px]">
                                  ×{owned}
                                </Badge>
                              )}
                            </div>
                            <div className={`text-xs font-semibold truncate w-full ${owned ? "" : "text-muted-foreground"}`}>
                              {t.name}
                            </div>
                            <div className="text-[10px] text-muted-foreground">OVR {total}</div>
                          </Card>
                        );
                      })}
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </ScrollArea>
      </DialogContent>
    </Dialog>
  );
}
