/**
 * FriendDuelDialog — Bet-based asynchronous friend duel.
 *
 * Workflow:
 *  1. You pick a friend, set a bet amount → server escrows your stake and
 *     creates a `pending` row in `friend_challenges`.
 *  2. The opponent sees the challenge in their "Incoming" tab and either
 *     Accepts (server debits their stake, auto-resolves the duel using
 *     lineup OVR + level/bonus + ±15% random luck, transfers the pot to
 *     the winner) or Declines (refunds your stake, marks cancelled).
 *  3. History tab shows recent settled / cancelled duels.
 *
 * No live court match — purely server-side roll. Pure money game.
 */
import { useEffect, useMemo, useState } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Coins, Swords, Trophy, History as HistoryIcon, X, Check, Inbox, Send } from "lucide-react";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";
import {
  getEffectiveStats,
  loadOwnedCards,
  type PlayerCard,
  type PlayerTemplate,
  type TeamManager,
} from "@/lib/teamManager";

interface Props {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  team: TeamManager;
  myLineup: { card: PlayerCard; template: PlayerTemplate }[];
  onTeamChange: (team: TeamManager) => void;
}

interface FriendTeam {
  user_id: string;
  team: TeamManager;
  profile: { name: string; avatar_url: string | null };
  lineup: { card: PlayerCard; template: PlayerTemplate }[];
}

interface DuelRow {
  id: string;
  challenger_id: string;
  opponent_id: string;
  challenger_score: number | null;
  opponent_score: number | null;
  winner_id: string | null;
  bet_amount: number;
  status: string;
  created_at: string;
}

const DEFAULT_BET = 100;
const MIN_BET = 1;
const MAX_BET = 1_000_000_000;

export default function FriendDuelDialog({ open, onOpenChange, team, myLineup, onTeamChange }: Props) {
  const [friendTeams, setFriendTeams] = useState<FriendTeam[]>([]);
  const [pendingOut, setPendingOut] = useState<DuelRow[]>([]);
  const [pendingIn, setPendingIn] = useState<DuelRow[]>([]);
  const [history, setHistory] = useState<DuelRow[]>([]);
  const [profiles, setProfiles] = useState<Record<string, { name: string; avatar_url: string | null }>>({});
  const [loading, setLoading] = useState(true);
  const [busyId, setBusyId] = useState<string | null>(null);
  const [betInputs, setBetInputs] = useState<Record<string, string>>({});

  const fetchAll = async () => {
    setLoading(true);
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) { setLoading(false); return; }

    // Friend list → teams + lineups
    const { data: friendships } = await supabase
      .from("friendships").select("*").eq("status", "accepted");
    const friendIds = (friendships ?? []).map(f =>
      f.requester_id === user.id ? f.addressee_id : f.requester_id);

    if (friendIds.length === 0) {
      setFriendTeams([]);
    } else {
      const [{ data: teams }, { data: profs }] = await Promise.all([
        supabase.from("team_managers").select("*").in("user_id", friendIds),
        supabase.from("profiles").select("user_id, name, avatar_url").in("user_id", friendIds),
      ]);
      const profMap = new Map((profs ?? []).map(p => [p.user_id, p]));
      const built: FriendTeam[] = [];
      for (const t of teams ?? []) {
        const lineup = await loadOwnedCards(t.user_id);
        const lineupCards = (t.starting_lineup ?? [])
          .map(id => lineup.find(c => c.card.id === id))
          .filter((x): x is { card: PlayerCard; template: PlayerTemplate } => !!x);
        built.push({
          user_id: t.user_id,
          team: t as TeamManager,
          profile: profMap.get(t.user_id) ?? { name: "Unknown", avatar_url: null },
          lineup: lineupCards,
        });
      }
      setFriendTeams(built);
    }

    // Duel rows
    const { data: rows } = await supabase
      .from("friend_challenges")
      .select("*")
      .or(`challenger_id.eq.${user.id},opponent_id.eq.${user.id}`)
      .order("created_at", { ascending: false })
      .limit(50);
    const all = (rows ?? []) as DuelRow[];
    setPendingOut(all.filter(r => r.status === "pending" && r.challenger_id === user.id));
    setPendingIn(all.filter(r => r.status === "pending" && r.opponent_id === user.id));
    setHistory(all.filter(r => r.status !== "pending"));

    // Cache profiles for opponents in any of these rows
    const allIds = new Set<string>();
    all.forEach(r => { allIds.add(r.challenger_id); allIds.add(r.opponent_id); });
    if (allIds.size > 0) {
      const { data: prof2 } = await supabase
        .from("profiles").select("user_id, name, avatar_url")
        .in("user_id", Array.from(allIds));
      setProfiles(Object.fromEntries((prof2 ?? []).map(p =>
        [p.user_id, { name: p.name, avatar_url: p.avatar_url }])));
    }
    setLoading(false);
  };

  useEffect(() => { if (open) fetchAll(); }, [open]);

  // Realtime: refresh when any duel I'm part of changes
  useEffect(() => {
    if (!open) return;
    const ch = supabase
      .channel(`friend_duels_${team.user_id}`)
      .on("postgres_changes",
        { event: "*", schema: "public", table: "friend_challenges" },
        () => { fetchAll(); })
      .subscribe();
    return () => { supabase.removeChannel(ch); };
  }, [open, team.user_id]);

  const myStats = useMemo(
    () => myLineup.map(({ card, template }) => getEffectiveStats(card, template)),
    [myLineup],
  );
  const myTotal = myStats.reduce((s, x) => s + x.total, 0);

  const refreshMyTeam = async () => {
    const { data } = await supabase
      .from("team_managers").select("*").eq("user_id", team.user_id).single();
    if (data) onTeamChange(data as TeamManager);
    return (data as TeamManager | null) ?? null;
  };

  const getLiveCoinBalance = async () => {
    const { data, error } = await supabase
      .from("team_managers")
      .select("coins")
      .eq("user_id", team.user_id)
      .single();

    if (error) {
      toast.error(error.message);
      return null;
    }

    return Number(data?.coins ?? 0);
  };

  // ── Send a new duel challenge ────────────────────────────────────
  const sendChallenge = async (ft: FriendTeam) => {
    const raw = betInputs[ft.user_id] ?? String(DEFAULT_BET);
    const amount = Math.max(MIN_BET, Math.floor(Number(raw) || 0));
    if (!Number.isFinite(amount) || amount < MIN_BET) {
      toast.error(`Bet must be at least ${MIN_BET} coins`);
      return;
    }

    const liveCoins = await getLiveCoinBalance();
    if (liveCoins === null) return;

    if (amount > MAX_BET) {
      toast.error(`Max bet is ${MAX_BET.toLocaleString()} coins`);
      return;
    }

    if (amount > liveCoins) {
      toast.error(`You only have ${liveCoins.toLocaleString()} coins`);
      return;
    }
    setBusyId(ft.user_id);
    const { data, error } = await supabase.rpc("create_friend_duel" as never, {
      _opponent_id: ft.user_id, _amount: amount,
    } as never);
    setBusyId(null);
    if (error) {
      toast.error(error.message);
      await refreshMyTeam();
      return;
    }
    toast.success(`⚔️ Challenge sent — ${amount.toLocaleString()} coins escrowed. Awaiting ${ft.profile.name}'s response.`);
    await Promise.all([refreshMyTeam(), fetchAll()]);
  };

  // ── Accept an incoming duel (auto-resolve) ───────────────────────
  const acceptDuel = async (row: DuelRow) => {
    const liveCoins = await getLiveCoinBalance();
    if (liveCoins === null) return;
    if (liveCoins < row.bet_amount) {
      toast.error(`You only have ${liveCoins.toLocaleString()} coins`);
      await refreshMyTeam();
      return;
    }

    setBusyId(row.id);
    const { data, error } = await supabase.rpc("accept_friend_duel" as never, {
      _duel_id: row.id,
    } as never);
    setBusyId(null);
    if (error) {
      toast.error(error.message);
      await refreshMyTeam();
      return;
    }
    const r = data as any;
    const won = r?.winner === team.user_id;
    toast(won ? "🏆 You won the duel!" : "💸 You lost the duel.", {
      description: `Final ${r?.challenger_score ?? "?"} – ${r?.opponent_score ?? "?"} · ${won ? "+" : "-"}${row.bet_amount.toLocaleString()} coins`,
      duration: 6000,
    });
    await Promise.all([refreshMyTeam(), fetchAll()]);
  };

  // ── Decline / cancel a pending duel ──────────────────────────────
  const cancelDuel = async (row: DuelRow) => {
    setBusyId(row.id);
    const { error } = await supabase.rpc("cancel_friend_duel" as never, {
      _duel_id: row.id,
    } as never);
    setBusyId(null);
    if (error) { toast.error(error.message); return; }
    toast.success("Duel cancelled. Stake refunded to challenger.");
    await Promise.all([refreshMyTeam(), fetchAll()]);
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-3xl h-[85vh] !grid-cols-none !flex flex-col gap-4 overflow-hidden">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Swords className="h-5 w-5" /> Friend Duel
            <Badge variant="outline" className="ml-2 gap-1 text-amber-300 border-amber-400/40">
              <Coins className="h-3 w-3" /> Coin Match
            </Badge>
          </DialogTitle>
          <DialogDescription>
            Bet coins against a friend. Once they accept, the system auto-resolves the duel based on
            both lineups' overall rating, levels and bonuses, plus a ±15% random luck factor.
            Winner takes the entire pot.
            <span className="block mt-1 text-foreground/80">
              Your lineup OVR: <strong>{myTotal}</strong> · Coins: <strong className="text-amber-300">{team.coins.toLocaleString()}</strong>
            </span>
          </DialogDescription>
        </DialogHeader>

        <Tabs defaultValue="send" className="flex-1 flex flex-col min-h-0">
          <TabsList className="self-start">
            <TabsTrigger value="send" className="gap-1.5"><Send className="h-3.5 w-3.5" /> Challenge</TabsTrigger>
            <TabsTrigger value="incoming" className="gap-1.5">
              <Inbox className="h-3.5 w-3.5" /> Incoming
              {pendingIn.length > 0 && (
                <Badge className="ml-1 h-4 px-1 text-[10px] bg-red-500 hover:bg-red-500">{pendingIn.length}</Badge>
              )}
            </TabsTrigger>
            <TabsTrigger value="outgoing" className="gap-1.5">
              Outgoing
              {pendingOut.length > 0 && (
                <Badge variant="outline" className="ml-1 h-4 px-1 text-[10px]">{pendingOut.length}</Badge>
              )}
            </TabsTrigger>
            <TabsTrigger value="history" className="gap-1.5"><HistoryIcon className="h-3.5 w-3.5" /> History</TabsTrigger>
          </TabsList>

          {/* ── Challenge friends ─────────────────────────────────── */}
          <TabsContent value="send" className="flex-1 min-h-0 mt-2">
            <ScrollArea className="h-full -mx-2 px-2">
              {loading ? (
                <p className="text-center py-12 text-sm text-muted-foreground">Loading friend teams…</p>
              ) : friendTeams.length === 0 ? (
                <Card className="p-6 text-center text-sm text-muted-foreground">
                  No friend teams yet. Add friends from Contacts first.
                </Card>
              ) : (
                <div className="space-y-2">
                  {friendTeams.map(ft => {
                    const oppTotal = ft.lineup.reduce((s, { card, template }) =>
                      s + getEffectiveStats(card, template).total, 0);
                    const diff = oppTotal - myTotal;
                    const noLineup = ft.lineup.length === 0;
                    return (
                      <Card key={ft.user_id} className="overflow-hidden">
                        <CardContent className="p-3 space-y-2">
                          <div className="flex items-center gap-3 flex-wrap">
                            <div className="text-3xl">{ft.team.team_emoji}</div>
                            <div className="flex-1 min-w-0">
                              <div className="font-bold truncate">{ft.team.team_name}</div>
                              <div className="text-xs text-muted-foreground truncate">
                                {ft.profile.name} · {ft.team.total_wins}W-{ft.team.total_losses}L · {ft.team.coins.toLocaleString()} coins
                              </div>
                            </div>
                            <div className="text-right">
                              <div className="text-[10px] uppercase tracking-wider text-muted-foreground">Lineup OVR</div>
                              <div className="text-lg font-bold tabular-nums">
                                {oppTotal}
                                <span className={`ml-1 text-xs ${diff > 0 ? "text-red-400" : diff < 0 ? "text-green-400" : "text-muted-foreground"}`}>
                                  {diff > 0 ? `+${diff}` : diff}
                                </span>
                              </div>
                            </div>
                          </div>
                          <div className="flex items-center gap-2">
                            <Coins className="h-4 w-4 text-amber-400 shrink-0" />
                            <Input
                              type="number"
                              min={MIN_BET}
                              max={MAX_BET}
                              placeholder="Bet"
                              className="h-9"
                              value={betInputs[ft.user_id] ?? String(DEFAULT_BET)}
                              onChange={(e) => setBetInputs(prev => ({ ...prev, [ft.user_id]: e.target.value }))}
                              disabled={noLineup}
                            />
                            <Button
                              size="sm"
                              className="gap-1 shrink-0"
                              disabled={busyId === ft.user_id || noLineup || myLineup.length === 0}
                              onClick={() => sendChallenge(ft)}
                              title={noLineup ? "Opponent has no lineup yet"
                                : myLineup.length === 0 ? "Set your own lineup first" : "Send challenge"}
                            >
                              <Swords className="h-4 w-4" />
                              {busyId === ft.user_id ? "Sending…" : "Challenge"}
                            </Button>
                          </div>
                          {noLineup && (
                            <div className="text-[10px] text-muted-foreground">
                              Opponent hasn't set a starting lineup yet.
                            </div>
                          )}
                        </CardContent>
                      </Card>
                    );
                  })}
                </div>
              )}
            </ScrollArea>
          </TabsContent>

          {/* ── Incoming challenges (accept / decline) ────────────── */}
          <TabsContent value="incoming" className="flex-1 min-h-0 mt-2">
            <ScrollArea className="h-full -mx-2 px-2">
              {pendingIn.length === 0 ? (
                <Card className="p-6 text-center text-sm text-muted-foreground">
                  No incoming challenges. You're safe… for now.
                </Card>
              ) : (
                <div className="space-y-2">
                  {pendingIn.map(row => {
                    const challenger = profiles[row.challenger_id];
                    return (
                      <Card key={row.id} className="overflow-hidden ring-1 ring-amber-400/40">
                        <CardContent className="p-3 flex items-center gap-3 flex-wrap">
                          <Inbox className="h-5 w-5 text-amber-400 shrink-0" />
                          <div className="flex-1 min-w-0">
                            <div className="font-bold truncate">
                              {challenger?.name ?? "Unknown"} challenges you
                            </div>
                            <div className="text-xs text-muted-foreground truncate flex items-center gap-1">
                              <Coins className="h-3 w-3 text-amber-400" />
                              <strong className="text-amber-300">{row.bet_amount.toLocaleString()}</strong> coins on the line
                              · pot: <strong>{(row.bet_amount * 2).toLocaleString()}</strong>
                            </div>
                          </div>
                          <div className="flex gap-1.5 shrink-0">
                            <Button
                              size="sm"
                              variant="default"
                              className="gap-1 bg-emerald-600 hover:bg-emerald-500"
                              disabled={busyId === row.id || myLineup.length === 0}
                              onClick={() => acceptDuel(row)}
                              title={myLineup.length === 0 ? "Set your lineup first" : "Accept duel"}
                            >
                              <Check className="h-4 w-4" />
                              {busyId === row.id ? "…" : "Accept"}
                            </Button>
                            <Button
                              size="sm"
                              variant="outline"
                              className="gap-1"
                              disabled={busyId === row.id}
                              onClick={() => cancelDuel(row)}
                            >
                              <X className="h-4 w-4" /> Decline
                            </Button>
                          </div>
                        </CardContent>
                      </Card>
                    );
                  })}
                </div>
              )}
            </ScrollArea>
          </TabsContent>

          {/* ── Outgoing pending (cancel only) ────────────────────── */}
          <TabsContent value="outgoing" className="flex-1 min-h-0 mt-2">
            <ScrollArea className="h-full -mx-2 px-2">
              {pendingOut.length === 0 ? (
                <Card className="p-6 text-center text-sm text-muted-foreground">
                  No outgoing challenges.
                </Card>
              ) : (
                <div className="space-y-2">
                  {pendingOut.map(row => {
                    const opp = profiles[row.opponent_id];
                    return (
                      <Card key={row.id} className="overflow-hidden">
                        <CardContent className="p-3 flex items-center gap-3 flex-wrap">
                          <Send className="h-4 w-4 text-muted-foreground shrink-0" />
                          <div className="flex-1 min-w-0">
                            <div className="font-medium truncate">
                              Waiting on {opp?.name ?? "Unknown"}…
                            </div>
                            <div className="text-xs text-muted-foreground truncate flex items-center gap-1">
                              <Coins className="h-3 w-3 text-amber-400" />
                              {row.bet_amount.toLocaleString()} coins escrowed
                            </div>
                          </div>
                          <Button
                            size="sm"
                            variant="outline"
                            className="gap-1 shrink-0"
                            disabled={busyId === row.id}
                            onClick={() => cancelDuel(row)}
                          >
                            <X className="h-4 w-4" /> Cancel
                          </Button>
                        </CardContent>
                      </Card>
                    );
                  })}
                </div>
              )}
            </ScrollArea>
          </TabsContent>

          {/* ── History ───────────────────────────────────────────── */}
          <TabsContent value="history" className="flex-1 min-h-0 mt-2">
            <ScrollArea className="h-full -mx-2 px-2">
              {history.length === 0 ? (
                <Card className="p-6 text-center text-sm text-muted-foreground">
                  No completed duels yet.
                </Card>
              ) : (
                <div className="space-y-1">
                  {history.map(h => {
                    const myId = team.user_id;
                    const isChallenger = h.challenger_id === myId;
                    const oppId = isChallenger ? h.opponent_id : h.challenger_id;
                    const myScore = isChallenger ? h.challenger_score : h.opponent_score;
                    const oppScore = isChallenger ? h.opponent_score : h.challenger_score;
                    const won = h.winner_id === myId;
                    const cancelled = h.status === "cancelled";
                    const opp = profiles[oppId];
                    return (
                      <div key={h.id} className="flex items-center gap-2 text-xs p-2 rounded bg-muted/30">
                        <Trophy className={`h-3 w-3 shrink-0 ${won ? "text-yellow-400" : "text-muted-foreground"}`} />
                        <span className="flex-1 truncate">
                          vs {opp?.name ?? "?"}
                          {cancelled
                            ? <span className="text-muted-foreground"> · cancelled</span>
                            : <> · {myScore} : {oppScore}</>}
                        </span>
                        <Badge variant="outline" className="text-[10px] h-4 gap-1">
                          <Coins className="h-2.5 w-2.5 text-amber-400" />
                          {h.bet_amount.toLocaleString()}
                        </Badge>
                        {cancelled ? (
                          <Badge variant="outline" className="text-[10px] h-4">CANCELLED</Badge>
                        ) : (
                          <Badge variant={won ? "default" : "destructive"} className="text-[10px] h-4">
                            {won ? `+${h.bet_amount.toLocaleString()}` : `-${h.bet_amount.toLocaleString()}`}
                          </Badge>
                        )}
                      </div>
                    );
                  })}
                </div>
              )}
            </ScrollArea>
          </TabsContent>
        </Tabs>
      </DialogContent>
    </Dialog>
  );
}
