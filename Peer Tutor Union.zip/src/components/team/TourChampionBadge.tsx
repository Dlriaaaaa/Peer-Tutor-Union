/**
 * TourChampionBadge — Permanent achievement badge for players who have won
 * a World Tour Finals (or, legacy, the retired World Champion league).
 * Persisted in `team_managers.wc_titles` (column name kept for backwards
 * compatibility). Optionally shows "×N" for repeat winners.
 */
interface Props {
  /** Number of titles held (0 = no badge rendered). */
  count: number;
  /** Smaller variant for inline use next to a name. */
  size?: "sm" | "md";
}

export default function TourChampionBadge({ count, size = "sm" }: Props) {
  if (!count || count < 1) return null;
  const isSm = size === "sm";
  return (
    <span
      title={`Tour Champion ×${count}`}
      className={`inline-flex items-center gap-1 rounded-full font-bold shrink-0 ${
        isSm ? "px-1.5 py-0.5 text-[10px]" : "px-2 py-0.5 text-xs"
      } bg-gradient-to-r from-amber-500 via-yellow-400 to-amber-500 text-amber-950 ring-1 ring-amber-300/70 shadow-sm`}
    >
      <span>🏆</span>
      <span className="tracking-wide">Tour Champion ×{count}</span>
    </span>
  );
}
