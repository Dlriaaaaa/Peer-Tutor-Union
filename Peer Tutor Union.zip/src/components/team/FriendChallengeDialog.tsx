/**
 * FriendChallengeDialog — Browse friends' teams, challenge them.
 *
 * NEW: No coin betting at all. A friend challenge is now identical to a
 * leaderboard challenge — winning DRAINS the opponent's lineup stamina;
 * losing only costs your own (normal post-match drain). Pure pride match.
 *
 * Match itself is played LIVE on the basketball court (3 AI vs 3 AI from
 * each side's lineup) — same flow as a league match, settlement happens
 * after the live match ends in the parent PTC Star page.
 */
import { useEffect, useMemo, useState } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Swords, Trophy, History as HistoryIcon, Heart } from "lucide-react";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";
import {
  getEffectiveStats,
  loadOwnedCards,
  type PlayerCard,
  type PlayerTemplate,
  type TeamManager,
} from "@/lib/teamManager";

interface Props {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  team: TeamManager;
  myLineup: { card: PlayerCard; template: PlayerTemplate }[];
  onTeamChange: (team: TeamManager) => void;
  /** Hand off to parent to start a live 3v3 AI match. */
  onStartLiveMatch: (params: {
    bet: number;
    seconds: number;
    drainOpponentStamina?: boolean;
    drainAmount?: number;
    opponent: {
      user_id: string;
      team: TeamManager;
      profile: { name: string; avatar_url?: string | null };
      lineup: { card: PlayerCard; template: PlayerTemplate }[];
    };
  }) => void;
}

const TIME_OPTIONS = [90, 120, 180] as const;
const DEFAULT_SECONDS: (typeof TIME_OPTIONS)[number] = 90;
/** Per-card stamina drained from opponent's starting lineup on win. */
const STAMINA_DRAIN_ON_WIN = 25;

interface FriendTeam {
  user_id: string;
  team: TeamManager;
  profile: { name: string; avatar_url: string | null };
  lineup: { card: PlayerCard; template: PlayerTemplate }[];
}

interface ChallengeRow {
  id: string;
  challenger_id: string;
  opponent_id: string;
  challenger_score: number | null;
  opponent_score: number | null;
  winner_id: string | null;
  bet_amount: number;
  created_at: string;
}

export default function FriendChallengeDialog({ open, onOpenChange, team, myLineup, onStartLiveMatch }: Props) {
  const [friendTeams, setFriendTeams] = useState<FriendTeam[]>([]);
  const [history, setHistory] = useState<ChallengeRow[]>([]);
  const [profiles, setProfiles] = useState<Record<string, { name: string }>>({});
  const [loading, setLoading] = useState(true);
  const [challenging, setChallenging] = useState<string | null>(null);
  const [seconds, setSeconds] = useState<number>(DEFAULT_SECONDS);

  const fetchAll = async () => {
    setLoading(true);
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) { setLoading(false); return; }

    const { data: friendships } = await supabase.from("friendships").select("*").eq("status", "accepted");
    const friendIds = (friendships ?? []).map(f => f.requester_id === user.id ? f.addressee_id : f.requester_id);

    if (friendIds.length === 0) {
      setFriendTeams([]);
    } else {
      const [{ data: teams }, { data: profs }] = await Promise.all([
        supabase.from("team_managers").select("*").in("user_id", friendIds),
        supabase.from("profiles").select("user_id, name, avatar_url").in("user_id", friendIds),
      ]);
      const profMap = new Map((profs ?? []).map(p => [p.user_id, p]));
      const built: FriendTeam[] = [];
      for (const t of teams ?? []) {
        const lineup = await loadOwnedCards(t.user_id);
        const lineupCards = (t.starting_lineup ?? [])
          .map(id => lineup.find(c => c.card.id === id))
          .filter((x): x is { card: PlayerCard; template: PlayerTemplate } => !!x);
        if (lineupCards.length === 0) continue;
        built.push({
          user_id: t.user_id,
          team: t as TeamManager,
          profile: profMap.get(t.user_id) ?? { name: "Unknown", avatar_url: null },
          lineup: lineupCards,
        });
      }
      setFriendTeams(built);
    }

    const { data: hist } = await supabase
      .from("friend_challenges")
      .select("*")
      .or(`challenger_id.eq.${user.id},opponent_id.eq.${user.id}`)
      .order("created_at", { ascending: false })
      .limit(20);
    setHistory((hist ?? []) as ChallengeRow[]);

    const allIds = new Set<string>();
    (hist ?? []).forEach(h => { allIds.add(h.challenger_id); allIds.add(h.opponent_id); });
    if (allIds.size > 0) {
      const { data: prof2 } = await supabase
        .from("profiles")
        .select("user_id, name")
        .in("user_id", Array.from(allIds));
      setProfiles(Object.fromEntries((prof2 ?? []).map(p => [p.user_id, { name: p.name }])));
    }
    setLoading(false);
  };

  useEffect(() => { if (open) fetchAll(); }, [open]);

  const myStats = useMemo(
    () => myLineup.map(({ card, template }) => getEffectiveStats(card, template)),
    [myLineup],
  );
  const myTotal = myStats.reduce((s, x) => s + x.total, 0);

  // Head-to-head W-L record vs each friend (ignore bet field — pride only).
  const h2h = useMemo(() => {
    const myId = team.user_id;
    const map: Record<string, { wins: number; losses: number }> = {};
    for (const h of history) {
      const oppId = h.challenger_id === myId ? h.opponent_id : h.challenger_id;
      if (!map[oppId]) map[oppId] = { wins: 0, losses: 0 };
      if (h.winner_id === myId) map[oppId].wins += 1;
      else if (h.winner_id) map[oppId].losses += 1;
    }
    return map;
  }, [history, team.user_id]);

  const challenge = (ft: FriendTeam) => {
    if (myLineup.length === 0) { toast.error("Set your own starting lineup first"); return; }
    if (ft.lineup.length === 0) { toast.error("Opponent has no lineup yet"); return; }
    setChallenging(ft.user_id);
    onStartLiveMatch({
      bet: 0,
      seconds,
      drainOpponentStamina: true,
      drainAmount: STAMINA_DRAIN_ON_WIN,
      opponent: ft,
    });
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-3xl h-[85vh] !grid-cols-none !flex flex-col gap-4 overflow-hidden">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2"><Swords className="h-5 w-5" /> Friend Team Battle</DialogTitle>
          <DialogDescription>
            Live match — your 3 AI vs their 3 AI on the court.
            Your lineup OVR: <span className="font-bold text-foreground">{myTotal}</span>.
            <span className="block mt-1 text-foreground/80">
              <Heart className="inline h-3 w-3 mr-1 text-red-400" />
              <strong>No coins on the line.</strong> Win and you drain <strong>−{STAMINA_DRAIN_ON_WIN}</strong> stamina from each of your friend's starters. Lose and only your own lineup pays the usual stamina cost.
            </span>
          </DialogDescription>
        </DialogHeader>

        <div className="flex items-center gap-2 px-1 flex-wrap">
          <span className="text-sm font-medium shrink-0">Match Time</span>
          <div className="flex gap-1">
            {TIME_OPTIONS.map(s => (
              <Button key={s} size="sm" variant={seconds === s ? "default" : "outline"} type="button"
                onClick={() => setSeconds(s)}>
                {s}s
              </Button>
            ))}
          </div>
        </div>

        <ScrollArea className="flex-1 -mx-2 px-2">
          {loading ? (
            <p className="text-center py-12 text-sm text-muted-foreground">Loading friend teams…</p>
          ) : friendTeams.length === 0 ? (
            <Card className="p-6 text-center text-sm text-muted-foreground">
              No friend teams to challenge yet. Add friends from Contacts and wait for them to build a lineup!
            </Card>
          ) : (
            <div className="space-y-2">
              {friendTeams.map(ft => {
                const oppTotal = ft.lineup.reduce((s, { card, template }) => s + getEffectiveStats(card, template).total, 0);
                const diff = oppTotal - myTotal;
                return (
                  <Card key={ft.user_id} className="overflow-hidden">
                    <CardContent className="p-3 flex items-center gap-3 flex-wrap">
                      <div className="text-3xl">{ft.team.team_emoji}</div>
                      <div className="flex-1 min-w-0">
                        <div className="font-bold truncate">{ft.team.team_name}</div>
                        <div className="text-xs text-muted-foreground truncate">
                          {ft.profile.name} · {ft.lineup.length} players · {ft.team.total_wins}W-{ft.team.total_losses}L
                        </div>
                        {h2h[ft.user_id] && (h2h[ft.user_id].wins + h2h[ft.user_id].losses) > 0 && (
                          <div className="flex items-center gap-1.5 mt-1">
                            <Badge variant="outline" className="text-[10px] h-4 px-1.5 gap-1">
                              <span className="text-green-400">{h2h[ft.user_id].wins}W</span>
                              <span className="text-muted-foreground">-</span>
                              <span className="text-red-400">{h2h[ft.user_id].losses}L</span>
                            </Badge>
                          </div>
                        )}
                      </div>
                      <div className="text-right">
                        <div className="text-[10px] uppercase tracking-wider text-muted-foreground">OVR</div>
                        <div className="text-lg font-bold tabular-nums">
                          {oppTotal}
                          <span className={`ml-1 text-xs ${diff > 0 ? "text-red-400" : diff < 0 ? "text-green-400" : "text-muted-foreground"}`}>
                            {diff > 0 ? `+${diff}` : diff}
                          </span>
                        </div>
                      </div>
                      <Button
                        size="sm"
                        className="gap-1"
                        disabled={!!challenging}
                        onClick={() => challenge(ft)}
                        title={`Win → drain −${STAMINA_DRAIN_ON_WIN} stamina from opponent's lineup`}
                      >
                        <Swords className="h-4 w-4" />
                        {challenging === ft.user_id ? "Playing…" : "Challenge"}
                      </Button>
                    </CardContent>
                  </Card>
                );
              })}
            </div>
          )}

          {history.length > 0 && (
            <div className="mt-4">
              <div className="text-xs text-muted-foreground flex items-center gap-1 mb-2">
                <HistoryIcon className="h-3 w-3" /> Recent Challenges
              </div>
              <div className="space-y-1">
                {history.map(h => {
                  const myId = team.user_id;
                  const isChallenger = h.challenger_id === myId;
                  const myScore = isChallenger ? h.challenger_score : h.opponent_score;
                  const oppScore = isChallenger ? h.opponent_score : h.challenger_score;
                  const oppId = isChallenger ? h.opponent_id : h.challenger_id;
                  const won = h.winner_id === myId;
                  return (
                    <div key={h.id} className="flex items-center gap-2 text-xs p-2 rounded bg-muted/30">
                      <Trophy className={`h-3 w-3 ${won ? "text-yellow-400" : "text-muted-foreground"}`} />
                      <span className="flex-1 truncate">
                        vs {profiles[oppId]?.name ?? "?"} · {myScore} : {oppScore}
                      </span>
                      <Badge variant={won ? "default" : "destructive"} className="text-[10px] h-4">
                        {won ? "WIN" : "LOSS"}
                      </Badge>
                    </div>
                  );
                })}
              </div>
            </div>
          )}
        </ScrollArea>
      </DialogContent>
    </Dialog>
  );
}
