/**
 * LoanDialog — Player loan/credit system.
 *
 * Rules (mirrored on the server in `take_loan` / `repay_loan` /
 * `get_loan_balance` / `principal_rate_surcharge`):
 *   • Compound daily interest, tiered by loan slot:
 *        Loan 1–2  → 0.5%/day base
 *        Loan 3–5  → 0.8%/day base
 *        Loan 6–7  → 1.0%/day base
 *        Loan 8–10 → 1.5%/day base
 *   • Principal-tier surcharge stacked on top (applies live to existing loans):
 *        ≤ 30M           → +0.0%/day
 *        30M – 50M       → +0.2%/day
 *        50M – 90M       → +0.3%/day
 *        90M – 100M      → +1.0%/day
 *   • After day 7 → penalty rate doubles the EFFECTIVE daily rate
 *   • Max 10 active loans at once
 *   • Per-loan cap = $100,000,000 (flat for everyone)
 */
import { useEffect, useMemo, useState } from "react";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Banknote, AlertTriangle, Clock, Coins, TrendingUp, CheckCircle2 } from "lucide-react";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";
import { loadOrInitTeam, type TeamManager } from "@/lib/teamManager";

interface Loan {
  id: string;
  principal: number;
  daily_rate: number;
  penalty_rate: number;
  penalty_after_days: number;
  taken_at: string;
  total_repaid: number;
  /** Computed client-side mirror of the server's get_loan_balance() */
  currentBalance: number;
  daysElapsed: number;
}

interface Props {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  team: TeamManager;
  onTeamChange: (team: TeamManager) => void;
}

const MAX_ACTIVE_LOANS = 10;
const MAX_PER_LOAN = 100_000_000;

/** Tiered base daily rate by loan slot — must mirror server take_loan RPC. */
const RATE_TIERS: { slots: string; rate: string; tone: string }[] = [
  { slots: "Loan 1–2", rate: "0.5%/day", tone: "secondary" },
  { slots: "Loan 3–5", rate: "0.8%/day", tone: "secondary" },
  { slots: "Loan 6–7", rate: "1.0%/day", tone: "destructive" },
  { slots: "Loan 8–10", rate: "1.5%/day", tone: "destructive" },
];

/**
 * Principal-size surcharge — CUMULATIVE across tiers.
 * Must mirror server `principal_rate_surcharge`.
 *   ≤ 30M           → +0.0%/day
 *   30M – 50M       → +0.2%/day
 *   50M – 90M       → +0.5%/day  (0.2 + 0.3)
 *   90M – 100M      → +1.5%/day  (0.2 + 0.3 + 1.0)
 */
const PRINCIPAL_TIERS: { range: string; surcharge: string; tone: string }[] = [
  { range: "≤ $30M",        surcharge: "+0.0%/day", tone: "secondary" },
  { range: "$30M – $50M",   surcharge: "+0.2%/day", tone: "secondary" },
  { range: "$50M – $90M",   surcharge: "+0.5%/day", tone: "destructive" },
  { range: "$90M – $100M",  surcharge: "+1.5%/day", tone: "destructive" },
];

/** Mirror of server `principal_rate_surcharge(_principal)` (cumulative). */
function principalSurcharge(principal: number): number {
  if (principal <= 30_000_000) return 0;
  if (principal <= 50_000_000) return 0.002;
  if (principal <= 90_000_000) return 0.005;
  return 0.015;
}

/**
 * Pure client-side mirror of `get_loan_balance` so we can show live numbers
 * without round-tripping. Server is still source of truth on repayment.
 * Applies the principal-tier surcharge on top of the stored daily_rate so
 * the UI matches what the server will actually charge.
 */
function computeBalance(loan: {
  principal: number;
  daily_rate: number;
  penalty_rate: number;
  penalty_after_days: number;
  taken_at: string;
}): { balance: number; days: number } {
  // Compounding period = 1 day (24 hours). Interest compounds once per day
  // at the effective rate (no penalty rule — interest just keeps compounding).
  const PERIOD_MS = 24 * 60 * 60 * 1000;
  const periods = (Date.now() - new Date(loan.taken_at).getTime()) / PERIOD_MS;
  const days = periods; // 1 period == 1 day
  const surcharge = principalSurcharge(loan.principal);
  const effRate = loan.daily_rate + surcharge;
  const bal = loan.principal * Math.pow(1 + effRate, periods);
  return { balance: Math.ceil(bal), days };
}

export default function LoanDialog({ open, onOpenChange, team, onTeamChange }: Props) {
  const [loans, setLoans] = useState<Loan[]>([]);
  const [loading, setLoading] = useState(true);
  const [submitting, setSubmitting] = useState(false);
  const [borrowAmount, setBorrowAmount] = useState("");
  const maxPerLoan = MAX_PER_LOAN;

  // ── Load active loans + recompute the per-loan cap from current lineup ──
  const refresh = async () => {
    setLoading(true);
    const { data, error } = await supabase
      .from("loans")
      .select("*")
      .eq("status", "active")
      .order("taken_at", { ascending: true });

    if (error) {
      toast.error("Could not load loans");
      setLoading(false);
      return;
    }

    setLoans(
      (data || []).map((l) => {
        const { balance, days } = computeBalance(l);
        return { ...l, currentBalance: balance, daysElapsed: days };
      }),
    );

    // Per-loan cap is a flat $100M for everyone (see take_loan RPC).

    setLoading(false);
  };

  useEffect(() => {
    if (!open) return;
    refresh();
    // Recompute balances every 1s so the user sees interest tick up live
    const id = setInterval(() => {
      setLoans((prev) =>
        prev.map((l) => {
          const { balance, days } = computeBalance(l);
          return { ...l, currentBalance: balance, daysElapsed: days };
        }),
      );
    }, 1000);
    return () => clearInterval(id);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [open]);

  const totalOwed = useMemo(
    () => loans.reduce((sum, l) => sum + l.currentBalance, 0),
    [loans],
  );

  const handleBorrow = async () => {
    const amount = parseInt(borrowAmount, 10);
    if (!Number.isFinite(amount) || amount <= 0) {
      toast.error("Enter a valid amount");
      return;
    }
    if (amount > maxPerLoan) {
      toast.error(`Per-loan cap is ${maxPerLoan.toLocaleString()} 🪙`);
      return;
    }
    if (loans.length >= MAX_ACTIVE_LOANS) {
      toast.error(`Maximum ${MAX_ACTIVE_LOANS} active loans`);
      return;
    }

    setSubmitting(true);
    const { error } = await supabase.rpc("take_loan", { _amount: amount });
    if (error) {
      toast.error(error.message);
      setSubmitting(false);
      return;
    }
    toast.success(`💰 Borrowed ${amount.toLocaleString()} 🪙`);
    setBorrowAmount("");
    const t = await loadOrInitTeam();
    if (t) onTeamChange(t);
    await refresh();
    setSubmitting(false);
  };

  const handleRepay = async (loanId: string) => {
    setSubmitting(true);
    const { data, error } = await supabase.rpc("repay_loan", { _loan_id: loanId });
    if (error) {
      toast.error(error.message);
      setSubmitting(false);
      return;
    }
    const result = data as { paid: number; fully_paid: boolean; remaining: number };
    if (result.fully_paid) {
      toast.success(`✅ Loan repaid! Paid ${result.paid.toLocaleString()} 🪙`);
    } else {
      toast.warning(
        `Partial payment ${result.paid.toLocaleString()} 🪙 · ${result.remaining.toLocaleString()} 🪙 still owed`,
      );
    }
    const t = await loadOrInitTeam();
    if (t) onTeamChange(t);
    await refresh();
    setSubmitting(false);
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-lg max-h-[85vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Banknote className="h-5 w-5 text-emerald-400" />
            PTC Bank — Loans
          </DialogTitle>
          <DialogDescription className="text-xs">
            Borrow coins to fund roster upgrades. Compound daily interest applies.
          </DialogDescription>
        </DialogHeader>

        {/* ── Rate sheet ── */}
        <Card className="p-3 bg-muted/30 space-y-2 text-xs">
          <div className="font-bold text-sm flex items-center gap-1.5">
            <TrendingUp className="h-4 w-4 text-amber-400" />
            Rate Sheet — daily interest by loan slot
          </div>
          <div className="grid grid-cols-2 gap-1.5">
            {RATE_TIERS.map((tier, i) => {
              // Highlight the tier the *next* loan will fall into
              const nextSlot = loans.length + 1;
              const slotStart = [1, 3, 6, 8][i];
              const slotEnd = [2, 5, 7, 10][i];
              const isNext = nextSlot >= slotStart && nextSlot <= slotEnd && loans.length < MAX_ACTIVE_LOANS;
              return (
                <div
                  key={tier.slots}
                  className={`flex items-center justify-between gap-1 px-1.5 py-1 rounded ${isNext ? "ring-1 ring-emerald-400/60 bg-emerald-500/10" : ""}`}
                >
                  <span className="text-muted-foreground">{tier.slots}</span>
                  <Badge variant={tier.tone as "secondary" | "destructive"} className="text-[10px]">
                    {tier.rate}
                  </Badge>
                </div>
              );
            })}
          </div>
          <div className="pt-1 border-t border-border/40 space-y-1.5">
            <div className="font-bold text-xs flex items-center gap-1.5">
              <TrendingUp className="h-3.5 w-3.5 text-orange-400" />
              Principal surcharge — stacked on top
            </div>
            <div className="grid grid-cols-2 gap-1.5">
              {PRINCIPAL_TIERS.map((t) => (
                <div key={t.range} className="flex items-center justify-between gap-1 px-1.5 py-1 rounded">
                  <span className="text-muted-foreground">{t.range}</span>
                  <Badge variant={t.tone as "secondary" | "destructive"} className="text-[10px]">
                    {t.surcharge}
                  </Badge>
                </div>
              ))}
            </div>
          </div>
          <div className="grid grid-cols-2 gap-1.5 pt-1 border-t border-border/40">
            <div className="flex items-center gap-1">
              <span className="text-muted-foreground">Active loans:</span>
              <span className="font-semibold">{loans.length} / {MAX_ACTIVE_LOANS}</span>
            </div>
            <div className="flex items-center gap-1">
              <span className="text-muted-foreground">Per-loan cap:</span>
              <span className="font-semibold text-emerald-300">{maxPerLoan.toLocaleString()} 🪙</span>
            </div>
          </div>
          <div className="text-[10px] text-muted-foreground italic">
            Compound interest applied every minute. Principal surcharge applies live to existing loans.
          </div>
        </Card>

        {/* ── Borrow ── */}
        {loans.length < MAX_ACTIVE_LOANS && (
          <Card className="p-3 space-y-2 border-emerald-500/30">
            <div className="text-sm font-bold flex items-center gap-1.5">
              <Coins className="h-4 w-4 text-emerald-400" />
              Borrow Coins
            </div>
            <div className="flex gap-2">
              <Input
                type="number"
                placeholder={`Up to ${maxPerLoan.toLocaleString()}`}
                value={borrowAmount}
                onChange={(e) => setBorrowAmount(e.target.value)}
                disabled={submitting}
                min={1}
                max={maxPerLoan}
              />
              <Button
                onClick={handleBorrow}
                disabled={submitting || !borrowAmount}
                className="bg-emerald-600 hover:bg-emerald-700"
              >
                Borrow
              </Button>
            </div>
            <div className="flex gap-1.5 flex-wrap">
              {[1000, 5000, 10000, Math.min(maxPerLoan, 50000)].map((preset) => (
                <Button
                  key={preset}
                  variant="outline"
                  size="sm"
                  className="h-6 text-[10px]"
                  onClick={() => setBorrowAmount(String(preset))}
                  disabled={submitting || preset > maxPerLoan}
                >
                  {preset.toLocaleString()}
                </Button>
              ))}
            </div>
          </Card>
        )}

        {/* ── Active loans ── */}
        <div className="space-y-2">
          <div className="flex items-center justify-between">
            <div className="text-sm font-bold">Active Loans</div>
            {totalOwed > 0 && (
              <div className="text-xs">
                Total owed: <span className="font-bold text-red-400">{totalOwed.toLocaleString()} 🪙</span>
              </div>
            )}
          </div>

          {loading ? (
            <div className="text-xs text-muted-foreground italic text-center py-4">
              Loading…
            </div>
          ) : loans.length === 0 ? (
            <Card className="p-4 text-center">
              <CheckCircle2 className="h-8 w-8 text-emerald-400 mx-auto mb-1.5" />
              <div className="text-sm font-semibold">No active loans</div>
              <div className="text-[11px] text-muted-foreground">You're debt-free 🎉</div>
            </Card>
          ) : (
            loans.map((loan) => {
              const interest = loan.currentBalance - loan.principal;
              const canAfford = team.coins >= loan.currentBalance;
              return (
                <Card
                  key={loan.id}
                  className="p-3 space-y-2 border-amber-500/30"
                >
                  <div className="flex items-start justify-between gap-2">
                    <div className="space-y-0.5 flex-1 min-w-0">
                      <div className="flex items-center gap-1.5 flex-wrap">
                        <span className="text-sm font-bold">
                          Principal: {loan.principal.toLocaleString()} 🪙
                        </span>
                      </div>
                      <div className="text-[11px] text-muted-foreground flex items-center gap-1">
                        <Clock className="h-3 w-3" />
                        {loan.daysElapsed < 1
                          ? `${Math.floor(loan.daysElapsed * 24)}h ago`
                          : `${loan.daysElapsed.toFixed(1)} days ago`}
                        · interest <span className="font-semibold text-amber-400">+{interest.toLocaleString()}</span>
                      </div>
                    </div>
                  </div>

                  <div className="flex items-end justify-between gap-2">
                    <div>
                      <div className="text-[10px] text-muted-foreground uppercase tracking-wide">Owed Now</div>
                      <div className="text-lg font-black tabular-nums text-amber-300">
                        {loan.currentBalance.toLocaleString()} 🪙
                      </div>
                    </div>
                    <Button
                      size="sm"
                      onClick={() => handleRepay(loan.id)}
                      disabled={submitting || team.coins < 1}
                      variant={canAfford ? "default" : "outline"}
                    >
                      {canAfford ? "Repay in Full" : `Pay ${Math.min(team.coins, loan.currentBalance).toLocaleString()} 🪙`}
                    </Button>
                  </div>
                </Card>
              );
            })
          )}
        </div>
      </DialogContent>
    </Dialog>
  );
}
