/**
 * PackOpenDialog — Reveal animation for newly drawn cards.
 * Handles two outcome kinds:
 *  - "new"     → fresh card added to collection
 *  - "upgrade" → duplicate auto-upgraded one stat on the existing card
 */
import { useEffect, useState } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Sparkles, ArrowUp } from "lucide-react";
import PlayerCardView from "./PlayerCardView";
import type { DrawResult } from "@/lib/teamManager";

interface PackOpenDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  drawn: DrawResult[];
}

const STAT_LABEL: Record<string, string> = {
  speed: "SPD",
  shooting: "SHT",
  three_point: "3PT",
  defense: "DEF",
  dunk: "DNK",
};

export default function PackOpenDialog({ open, onOpenChange, drawn }: PackOpenDialogProps) {
  const [revealed, setRevealed] = useState<number>(0);

  useEffect(() => {
    if (open) {
      setRevealed(0);
      const timers = drawn.map((_, i) =>
        setTimeout(() => setRevealed(r => Math.max(r, i + 1)), 400 + i * 500),
      );
      return () => { timers.forEach(clearTimeout); };
    }
  }, [open, drawn]);

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-2xl">
        <DialogHeader>
          <DialogTitle>🎉 Pack Results</DialogTitle>
        </DialogHeader>
        <div className="grid gap-3" style={{ gridTemplateColumns: `repeat(${Math.min(drawn.length, 3)}, minmax(0, 1fr))` }}>
          {drawn.map((d, i) => (
            <div
              key={d.card.id + "-" + i}
              className="transition-all duration-500 space-y-2"
              style={{
                opacity: i < revealed ? 1 : 0,
                transform: i < revealed ? "scale(1) rotateY(0)" : "scale(0.8) rotateY(180deg)",
              }}
            >
              {i < revealed && (
                <>
                  <div className="text-center">
                    {d.kind === "new" ? (
                      <span className="inline-flex items-center gap-1 text-xs font-semibold text-emerald-400">
                        <Sparkles className="h-3 w-3" /> NEW
                      </span>
                    ) : d.kind === "upgrade" ? (
                      <span className="inline-flex items-center gap-1 text-xs font-semibold text-amber-400">
                        <ArrowUp className="h-3 w-3" /> Duplicate · +2 {STAT_LABEL[d.upgradedStat]}
                      </span>
                    ) : (
                      <span className="inline-flex items-center gap-1 text-xs font-semibold text-muted-foreground">
                        ⚡ MAX · duplicate wasted
                      </span>
                    )}
                  </div>
                  <PlayerCardView card={d.card} template={d.template} />
                </>
              )}
            </div>
          ))}
        </div>
        <Button onClick={() => onOpenChange(false)} className="mt-2 w-full">Collect</Button>
      </DialogContent>
    </Dialog>
  );
}
