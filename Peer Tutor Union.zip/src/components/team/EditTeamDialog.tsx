/**
 * EditTeamDialog — team name, emoji, custom logo, AND jersey designer
 * (primary + accent color, plus a pattern preset). Jersey config is
 * applied to all your players in matches via PTC Star's roster builders.
 */
import { useState, useEffect, useRef } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Upload, X, Loader2, Shirt } from "lucide-react";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";
import AvatarCropDialog from "@/components/AvatarCropDialog";
import { updateTeamMeta, type TeamManager } from "@/lib/teamManager";

interface Props {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  team: TeamManager;
  onSaved: (team: TeamManager) => void;
}

const EMOJI_PICKS = [
  "🏀","🔥","⚡","🌟","👑","🦅","🐉","🐺","🐻","🦁","🐯","🦈",
  "💎","🚀","⚔️","🛡️","🎯","🏆","💫","🎮","🌪️","☄️","🌊","⛰️",
];

const COLOR_PRESETS = [
  "#dc2626", "#ea580c", "#eab308", "#16a34a", "#0891b2",
  "#2563eb", "#7c3aed", "#db2777", "#0f172a", "#f8fafc",
];

type JerseyStyle = "solid" | "stripes-h" | "stripes-v" | "sash";
const STYLES: { key: JerseyStyle; label: string }[] = [
  { key: "solid",     label: "Solid" },
  { key: "stripes-h", label: "Horizontal" },
  { key: "stripes-v", label: "Vertical" },
  { key: "sash",      label: "Sash" },
];

/** Tiny SVG preview of the current jersey kit. Mirrors the in-game canvas overlay. */
function JerseyPreview({ primary, accent, style }: { primary: string; accent: string; style: JerseyStyle }) {
  return (
    <svg viewBox="0 0 60 80" className="h-20 w-16 drop-shadow">
      <defs>
        <clipPath id="torso">
          <path d="M10 12 Q5 40 18 70 L42 70 Q55 40 50 12 L40 8 Q30 14 20 8 Z" />
        </clipPath>
      </defs>
      <path d="M10 12 Q5 40 18 70 L42 70 Q55 40 50 12 L40 8 Q30 14 20 8 Z" fill={primary} />
      <g clipPath="url(#torso)">
        {style === "stripes-h" && (<>
          <rect x="0" y="25" width="60" height="8" fill={accent} />
          <rect x="0" y="45" width="60" height="8" fill={accent} />
        </>)}
        {style === "stripes-v" && (<>
          <rect x="14" y="0" width="6" height="80" fill={accent} />
          <rect x="40" y="0" width="6" height="80" fill={accent} />
        </>)}
        {style === "sash" && (
          <polygon points="6,18 16,10 56,62 46,70" fill={accent} />
        )}
      </g>
      <text x="30" y="46" textAnchor="middle" fontSize="14" fontWeight="bold" fill="rgba(255,255,255,0.9)">7</text>
    </svg>
  );
}

export default function EditTeamDialog({ open, onOpenChange, team, onSaved }: Props) {
  const [name, setName] = useState(team.team_name);
  const [emoji, setEmoji] = useState(team.team_emoji);
  const [logoUrl, setLogoUrl] = useState<string | null>(team.team_logo_url);
  const [jerseyPrimary, setJerseyPrimary] = useState<string>((team as any).jersey_primary ?? "#dc2626");
  const [jerseySecondary, setJerseySecondary] = useState<string>((team as any).jersey_secondary ?? "#fafafa");
  const [jerseyStyle, setJerseyStyle] = useState<JerseyStyle>(((team as any).jersey_style as JerseyStyle) ?? "solid");
  const [saving, setSaving] = useState(false);
  const [uploading, setUploading] = useState(false);
  const [cropSrc, setCropSrc] = useState<string | null>(null);
  const fileRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    if (open) {
      setName(team.team_name);
      setEmoji(team.team_emoji);
      setLogoUrl(team.team_logo_url);
      setJerseyPrimary((team as any).jersey_primary ?? "#dc2626");
      setJerseySecondary((team as any).jersey_secondary ?? "#fafafa");
      setJerseyStyle(((team as any).jersey_style as JerseyStyle) ?? "solid");
    }
  }, [open, team]);

  const handleFilePick = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    if (!file.type.startsWith("image/")) { toast.error("Please pick an image file"); return; }
    const reader = new FileReader();
    reader.onload = () => setCropSrc(reader.result as string);
    reader.readAsDataURL(file);
    e.target.value = "";
  };

  const handleCropComplete = async (blob: Blob) => {
    setCropSrc(null);
    setUploading(true);
    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) throw new Error("Not signed in");
      const path = `${user.id}/logo-${Date.now()}.jpg`;
      const { error: upErr } = await supabase.storage
        .from("team-logos")
        .upload(path, blob, { contentType: "image/jpeg", upsert: true });
      if (upErr) throw upErr;
      const { data: pub } = supabase.storage.from("team-logos").getPublicUrl(path);
      setLogoUrl(pub.publicUrl);
      toast.success("Logo uploaded");
    } catch (err: any) {
      toast.error(err.message ?? "Upload failed");
    } finally {
      setUploading(false);
    }
  };

  const handleSave = async () => {
    const trimmed = name.trim();
    if (!trimmed) { toast.error("Team name cannot be empty"); return; }
    if (trimmed.length > 24) { toast.error("Team name max 24 characters"); return; }
    setSaving(true);
    try {
      const updated = await updateTeamMeta(team, {
        team_name: trimmed,
        team_emoji: emoji,
        team_logo_url: logoUrl,
        jersey_primary: jerseyPrimary,
        jersey_secondary: jerseySecondary,
        jersey_style: jerseyStyle,
      });
      toast.success("Team updated");
      onSaved(updated);
      onOpenChange(false);
    } catch (e: any) {
      toast.error(e.message ?? "Save failed");
    } finally {
      setSaving(false);
    }
  };

  const ColorRow = ({ label, value, onChange }: { label: string; value: string; onChange: (v: string) => void }) => (
    <div className="space-y-1.5">
      <Label className="text-xs">{label}</Label>
      <div className="flex items-center gap-2 flex-wrap">
        <input
          type="color"
          value={value}
          onChange={e => onChange(e.target.value)}
          className="h-9 w-12 rounded cursor-pointer border border-border/40 bg-transparent"
        />
        <Input value={value} onChange={e => onChange(e.target.value)} className="h-9 w-24 font-mono text-xs" />
        <div className="flex gap-1 flex-wrap">
          {COLOR_PRESETS.map(c => (
            <button
              key={c}
              type="button"
              onClick={() => onChange(c)}
              className={`h-6 w-6 rounded-full border-2 transition-transform ${value.toLowerCase() === c.toLowerCase() ? "border-primary scale-110" : "border-border/40"}`}
              style={{ backgroundColor: c }}
              aria-label={c}
            />
          ))}
        </div>
      </div>
    </div>
  );

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-md max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>Edit Team Info</DialogTitle>
          <DialogDescription>Name, icon, logo, and your custom jersey kit.</DialogDescription>
        </DialogHeader>

        <div className="space-y-4 py-2">
          <div className="space-y-2">
            <Label>Team Name</Label>
            <Input value={name} maxLength={24} onChange={e => setName(e.target.value)} placeholder="e.g. Lightning Leopards" />
          </div>

          <div className="space-y-2">
            <Label>Team Logo</Label>
            <div className="flex items-center gap-3">
              <div className="h-20 w-20 rounded-md border border-border/40 bg-muted/40 flex items-center justify-center overflow-hidden shrink-0">
                {logoUrl ? (
                  <img src={logoUrl} alt="Team logo" className="h-full w-full object-cover" />
                ) : (
                  <span className="text-3xl">{emoji}</span>
                )}
              </div>
              <div className="flex flex-col gap-2 flex-1">
                <input ref={fileRef} type="file" accept="image/*" hidden onChange={handleFilePick} />
                <Button type="button" variant="outline" size="sm" disabled={uploading} onClick={() => fileRef.current?.click()} className="gap-2">
                  {uploading ? <Loader2 className="h-4 w-4 animate-spin" /> : <Upload className="h-4 w-4" />}
                  {logoUrl ? "Change Logo" : "Upload Logo"}
                </Button>
                {logoUrl && (
                  <Button type="button" variant="ghost" size="sm" onClick={() => setLogoUrl(null)} className="gap-2 text-destructive hover:text-destructive">
                    <X className="h-4 w-4" /> Remove
                  </Button>
                )}
              </div>
            </div>
          </div>

          <div className="space-y-2">
            <Label>Fallback Icon (used when no logo)</Label>
            <div className="flex flex-wrap gap-1.5">
              {EMOJI_PICKS.map(e => (
                <button
                  key={e}
                  type="button"
                  onClick={() => setEmoji(e)}
                  className={[
                    "h-10 w-10 rounded-md border text-2xl flex items-center justify-center transition-all",
                    emoji === e ? "border-primary bg-primary/15 scale-110" : "border-border/40 hover:bg-muted",
                  ].join(" ")}
                >
                  {e}
                </button>
              ))}
            </div>
          </div>

          {/* ── Jersey Designer ── */}
          <div className="space-y-3 p-3 rounded-md border border-border/40 bg-muted/20">
            <div className="flex items-center gap-2">
              <Shirt className="h-4 w-4 text-primary" />
              <Label className="font-semibold">Team Jersey</Label>
            </div>
            <div className="flex items-start gap-3">
              <div className="flex flex-col items-center gap-1 shrink-0">
                <JerseyPreview primary={jerseyPrimary} accent={jerseySecondary} style={jerseyStyle} />
                <span className="text-[10px] text-muted-foreground">Preview</span>
              </div>
              <div className="flex-1 space-y-2">
                <ColorRow label="Primary" value={jerseyPrimary} onChange={setJerseyPrimary} />
                <ColorRow label="Accent" value={jerseySecondary} onChange={setJerseySecondary} />
              </div>
            </div>
            <div className="space-y-1.5">
              <Label className="text-xs">Style</Label>
              <div className="grid grid-cols-4 gap-1.5">
                {STYLES.map(s => (
                  <button
                    key={s.key}
                    type="button"
                    onClick={() => setJerseyStyle(s.key)}
                    className={[
                      "p-2 rounded border text-xs flex flex-col items-center gap-1 transition-all",
                      jerseyStyle === s.key ? "border-primary bg-primary/15 scale-105" : "border-border/40 hover:bg-muted",
                    ].join(" ")}
                  >
                    <JerseyPreview primary={jerseyPrimary} accent={jerseySecondary} style={s.key} />
                    <span>{s.label}</span>
                  </button>
                ))}
              </div>
            </div>
            <p className="text-[11px] text-muted-foreground">All your players wear this kit during matches.</p>
          </div>
        </div>

        <DialogFooter>
          <Button variant="ghost" onClick={() => onOpenChange(false)}>Cancel</Button>
          <Button onClick={handleSave} disabled={saving || uploading}>Save</Button>
        </DialogFooter>

        {cropSrc && (
          <AvatarCropDialog
            open={!!cropSrc}
            imageSrc={cropSrc}
            onClose={() => setCropSrc(null)}
            onCropComplete={handleCropComplete}
          />
        )}
      </DialogContent>
    </Dialog>
  );
}
