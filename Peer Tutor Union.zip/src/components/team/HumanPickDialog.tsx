/**
 * HumanPickDialog — Before the league match, the player picks which star
 * they will personally control. Other lineup members run as AI driven by stats.
 *
 * Pre-match readiness banners:
 *   • Jeffrey Flying warning — he's a traitor when AI-controls him.
 *   • Coach / consumable boost reminder — easy to forget, costs you ~50% stats.
 *   • Low-stamina lineup warning — tired starters play weaker.
 *
 * Note: Thomas Wu's "迟到" (Late) skill always triggers when he is in the
 * lineup — no opt-in. He'll appear at a random 10–15s mark and a banner
 * announcement is shown in-match.
 */
import { useEffect, useState } from "react";
import { AlertTriangle, Sparkles, Battery, Zap } from "lucide-react";
import { toast } from "sonner";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import PlayerCardView from "./PlayerCardView";
import {
  loadOrInitTeam,
  computeCoachBoost,
  computeEquippedBoost,
  getCoachDef,
  getStamina,
  lineupRestCost,
  restLineup,
  STAMINA_REST_THRESHOLD,
  type PlayerCard,
  type PlayerTemplate,
  type TeamManager,
} from "@/lib/teamManager";

interface Props {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  lineup: { card: PlayerCard; template: PlayerTemplate }[];
  /**
   * Called with: index in `lineup` of the human-controlled player (or null for Auto Match)
   * AND a set of pre-match skill flags (currently always { thomasLate: true } —
   * Thomas's late skill is automatic when he's on the roster).
   */
  onConfirm: (humanIndex: number | null, skills: { thomasLate: boolean }) => void;
}

export default function HumanPickDialog({ open, onOpenChange, lineup, onConfirm }: Props) {
  const skills = { thomasLate: true };
  const [team, setTeam] = useState<TeamManager | null>(null);
  const [resting, setResting] = useState(false);

  useEffect(() => {
    if (open) loadOrInitTeam().then(setTeam);
  }, [open]);

  // ── Readiness checks ──
  const hasJeffreyFlying = lineup.some(({ template }) => template.name === "Jeffrey Flying");
  const equipped = ((team as any)?.equipped_consumables ?? []) as string[];
  const consumableBoost = team ? computeEquippedBoost(equipped) : 0;
  const coachBoost = team ? computeCoachBoost(team) : 0;
  const totalBoost = consumableBoost + coachBoost;
  const coachDef = team ? getCoachDef((team as any).coach_key) : null;
  const coachLeft = ((team as any)?.coach_matches_left ?? 0) as number;
  const tiredCards = lineup.filter(({ card }) => getStamina(card) < STAMINA_REST_THRESHOLD);
  const lowStaminaCards = lineup.filter(({ card }) => {
    const s = getStamina(card);
    return s >= STAMINA_REST_THRESHOLD && s < 60;
  });
  const lineupCards = lineup.map(l => l.card);
  const fullRestCost = lineupRestCost(lineup);
  const someoneNeedsRest = fullRestCost > 0;
  const canAffordFullRest = !!team && team.coins >= fullRestCost;

  const handleQuickRest = async () => {
    if (!team) return;
    setResting(true);
    try {
      const { team: updated, newStamina } = await restLineup(team, lineup);
      setTeam(updated);
      lineup.forEach(({ card }) => {
        if (newStamina[card.id] != null) {
          (card as any).stamina = newStamina[card.id];
          (card as any).stamina_updated_at = new Date().toISOString();
        }
      });
      toast.success(`⚡ Lineup refreshed · −$${fullRestCost.toLocaleString()}`);
    } catch (e: any) {
      toast.error(e?.message ?? "Quick rest failed");
    } finally {
      setResting(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>Pick Your Star to Control</DialogTitle>
          <DialogDescription>
            Other teammates run as AI based on their stats. Your star uses WASD + F (shoot) / G (steal) / R (sprint).
            Or hit Auto Match to let the computer play the whole game.
          </DialogDescription>
        </DialogHeader>

        {/* ─── Readiness banners ─── */}
        <div className="space-y-2">
          {hasJeffreyFlying && (
            <div className="flex items-start gap-2 rounded-md border border-destructive/50 bg-destructive/10 p-3 text-sm">
              <AlertTriangle className="h-4 w-4 mt-0.5 shrink-0 text-destructive" />
              <div className="text-foreground">
                <strong className="text-destructive">Jeffrey Flying ⚠️ Traitor alert</strong>
                <div className="text-muted-foreground text-xs mt-0.5">
                  He attacks his own basket when AI-controlled — pick him as your star,
                  or remove him from the lineup before high-stakes matches.
                </div>
              </div>
            </div>
          )}

          {totalBoost > 0 ? (
            <div className="flex items-start gap-2 rounded-md border border-primary/40 bg-primary/10 p-3 text-sm">
              <Sparkles className="h-4 w-4 mt-0.5 shrink-0 text-primary" />
              <div className="text-foreground">
                <strong className="text-primary">+{(totalBoost * 100).toFixed(1)}% all stats active</strong>
                <div className="text-muted-foreground text-xs mt-0.5">
                  {coachBoost > 0 && coachDef && (
                    <>{coachDef.emoji} {coachDef.name} +{(coachBoost * 100).toFixed(0)}% ({coachLeft} matches left)</>
                  )}
                  {coachBoost > 0 && consumableBoost > 0 && " · "}
                  {consumableBoost > 0 && (
                    <>🥤 {equipped.length} boost item{equipped.length > 1 ? "s" : ""} +{(consumableBoost * 100).toFixed(1)}%</>
                  )}
                </div>
              </div>
            </div>
          ) : (
            <div className="flex items-start gap-2 rounded-md border border-warning/40 bg-warning/10 p-3 text-sm">
              <Zap className="h-4 w-4 mt-0.5 shrink-0 text-warning" />
              <div className="text-foreground">
                <strong className="text-warning">No boost active</strong>
                <div className="text-muted-foreground text-xs mt-0.5">
                  Hire a coach or equip consumables in the Shop — late-game opponents already have a built-in boost.
                </div>
              </div>
            </div>
          )}

          {tiredCards.length > 0 && (
            <div className="flex items-start gap-2 rounded-md border border-destructive/50 bg-destructive/10 p-3 text-sm">
              <Battery className="h-4 w-4 mt-0.5 shrink-0 text-destructive" />
              <div className="text-foreground">
                <strong className="text-destructive">{tiredCards.length} player(s) exhausted</strong>
                <div className="text-muted-foreground text-xs mt-0.5">
                  {tiredCards.map(t => t.template.name).join(", ")} — rest them for full power.
                </div>
              </div>
            </div>
          )}

          {tiredCards.length === 0 && lowStaminaCards.length > 0 && (
            <div className="flex items-start gap-2 rounded-md border border-warning/40 bg-warning/10 p-3 text-sm">
              <Battery className="h-4 w-4 mt-0.5 shrink-0 text-warning" />
              <div className="text-foreground">
                <strong className="text-warning">{lowStaminaCards.length} player(s) low stamina</strong>
                <div className="text-muted-foreground text-xs mt-0.5">
                  Below 60 stamina — playing fine, but consider resting before the World Final bracket.
                </div>
              </div>
            </div>
          )}

          {someoneNeedsRest && team && (
            <Button
              size="sm"
              variant={tiredCards.length > 0 ? "default" : "outline"}
              className="w-full h-9"
              onClick={handleQuickRest}
              disabled={resting || !canAffordFullRest}
            >
              {resting
                ? "Refreshing lineup…"
                : canAffordFullRest
                  ? `⚡ Quick Rest All · $${fullRestCost.toLocaleString()} → 100/100`
                  : `⚡ Quick Rest All · need $${fullRestCost.toLocaleString()} (have $${team.coins.toLocaleString()})`}
            </Button>
          )}
        </div>

        <div className={`grid gap-2 ${lineup.length >= 3 ? "grid-cols-3" : "grid-cols-2"}`}>
          {lineup.map(({ card, template }, i) => (
            <PlayerCardView
              key={card.id}
              card={card}
              template={template}
              onClick={() => onConfirm(i, skills)}
            />
          ))}
        </div>

        <DialogFooter>
          <Button onClick={() => onConfirm(null, skills)}>🤖 Auto Match</Button>
          <Button variant="ghost" onClick={() => onOpenChange(false)}>Cancel</Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
