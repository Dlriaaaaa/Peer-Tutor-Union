/**
 * ShopDialog — Two tabs: Buy card packs & Upgrade existing players.
 */
import { useEffect, useState } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { ScrollArea } from "@/components/ui/scroll-area";
import { DollarSign } from "lucide-react";
import { toast } from "sonner";
import PlayerCardView from "./PlayerCardView";
import PackOpenDialog from "./PackOpenDialog";
import LotteryDialog from "./LotteryDialog";
import {
  SHOP_PACKS,
  RARITY_META,
  CONSUMABLES,
  COACHES,
  COACH_MATCHES_PER_HIRE,
  SPECIAL_BUNDLES,
  MAX_EQUIPPED_CONSUMABLES,
  MAX_EQUIPPED_STAFF,
  buyConsumable,
  buySpecialBundle,
  computeEquippedBoost,
  getCoachDef,
  getCoachHireCost,
  getConsumableDef,
  hireCoach,
  isStaffItem,
  loadInventory,
  openPack,
  setEquippedConsumables,
  upgradeCard,
  superEvolveCard,
  SUPER_EVOLVE_COST,
  SUPER_EVOLVE_BOOST,
  calcUpgradeCost,
  getEffectiveStats,
  type ConsumableInventoryRow,
  type PlayerCard,
  type PlayerTemplate,
  type TeamManager,
} from "@/lib/teamManager";

interface ShopDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  team: TeamManager;
  ownedCards: { card: PlayerCard; template: PlayerTemplate }[];
  onTeamChange: (team: TeamManager) => void;
  onCardsChange: () => Promise<void>;
}

const STATS = [
  { key: "speed",       cn: "Speed" },
  { key: "shooting",    cn: "Shoot" },
  { key: "three_point", cn: "3PT" },
  { key: "defense",     cn: "Defense" },
  { key: "dunk",        cn: "Dunk" },
] as const;

export default function ShopDialog({ open, onOpenChange, team, ownedCards, onTeamChange, onCardsChange }: ShopDialogProps) {
  const [busy, setBusy] = useState(false);
  const [drawn, setDrawn] = useState<import("@/lib/teamManager").DrawResult[] | null>(null);
  const [selectedCardId, setSelectedCardId] = useState<string | null>(null);
  const [inventory, setInventory] = useState<ConsumableInventoryRow[]>([]);
  const [lotteryOpen, setLotteryOpen] = useState(false);

  const selectedEntry = ownedCards.find(c => c.card.id === selectedCardId);
  const equipped = ((team as any).equipped_consumables ?? []) as string[];
  const equippedDrinks = equipped.filter(k => !isStaffItem(k));
  const equippedStaff  = equipped.filter(k =>  isStaffItem(k));
  const totalBoost = computeEquippedBoost(equipped);

  const refreshInventory = async () => {
    if (!team?.user_id) return;
    const inv = await loadInventory(team.user_id);
    setInventory(inv);
  };

  useEffect(() => {
    if (!open) return;
    refreshInventory();
    if (ownedCards.length === 0) {
      setSelectedCardId(null);
      return;
    }
    if (!selectedCardId || !ownedCards.some(entry => entry.card.id === selectedCardId)) {
      setSelectedCardId(ownedCards[0].card.id);
    }
  }, [open, ownedCards, selectedCardId]);

  const handleBuyPack = async (packKey: string) => {
    if (busy) return;
    setBusy(true);
    try {
      const { updatedTeam, drawn } = await openPack(team, packKey);
      onTeamChange(updatedTeam);
      await onCardsChange();
      setDrawn(drawn);
    } catch (e: any) {
      toast.error(e.message ?? "Purchase failed");
    } finally {
      setBusy(false);
    }
  };

  const handleUpgrade = async (stat: typeof STATS[number]["key"]) => {
    if (!selectedEntry || busy) return;
    setBusy(true);
    try {
      const { updatedTeam } = await upgradeCard(team, selectedEntry.card, stat);
      onTeamChange(updatedTeam);
      await onCardsChange();
      toast.success(`${selectedEntry.template.name} ${stat} +2 ✓`);
    } catch (e: any) {
      toast.error(e.message ?? "Upgrade failed");
    } finally {
      setBusy(false);
    }
  };

  const handleSuperEvolve = async () => {
    if (!selectedEntry || busy) return;
    if (!confirm(`Super Evolve ${selectedEntry.template.name}?\n\nCost: ${SUPER_EVOLVE_COST.toLocaleString()} coins\nReward: +${SUPER_EVOLVE_BOOST} to ALL stats (permanent)`)) return;
    setBusy(true);
    try {
      const { updatedTeam } = await superEvolveCard(team, selectedEntry.card);
      onTeamChange(updatedTeam);
      await onCardsChange();
      toast.success(`✨ ${selectedEntry.template.name} super-evolved! +${SUPER_EVOLVE_BOOST} all stats`);
    } catch (e: any) {
      toast.error(e.message ?? "Super Evolve failed");
    } finally {
      setBusy(false);
    }
  };

  const handleBuyConsumable = async (key: string) => {
    if (busy) return;
    setBusy(true);
    try {
      const updatedTeam = await buyConsumable(team, key);
      onTeamChange(updatedTeam);
      await refreshInventory();
      const def = getConsumableDef(key);
      toast.success(`${def?.emoji ?? ""} ${def?.name ?? key} ×1 acquired`);
    } catch (e: any) {
      toast.error(e.message ?? "Purchase failed");
    } finally {
      setBusy(false);
    }
  };

  const handleBuyBundle = async (bundleKey: string) => {
    if (busy) return;
    setBusy(true);
    try {
      const { updatedTeam, drawn: bundleDrawn } = await buySpecialBundle(team, bundleKey);
      onTeamChange(updatedTeam);
      await refreshInventory();
      await onCardsChange();
      toast.success(`🎁 Bundle unlocked!`);
      if (bundleDrawn.length > 0) setDrawn(bundleDrawn);
    } catch (e: any) {
      toast.error(e.message ?? "Purchase failed");
    } finally {
      setBusy(false);
    }
  };

  const handleHireCoach = async (coachKey: string) => {
    if (busy) return;
    const def = getCoachDef(coachKey);
    const current = (team as any).coach_key as string | undefined;
    const matchesLeft = ((team as any).coach_matches_left ?? 0) as number;
    const isRenew = current === coachKey && matchesLeft > 0;
    if (current && current !== coachKey && matchesLeft > 0) {
      if (!confirm(`Replace your current coach? You'll lose ${matchesLeft} remaining match${matchesLeft === 1 ? "" : "es"} and the previous fee won't be refunded.`)) return;
    }
    if (isRenew && !confirm(`Renew ${def?.name} at 20% off? Resets contract to ${COACH_MATCHES_PER_HIRE} matches (forfeits ${matchesLeft} unused).`)) return;
    setBusy(true);
    try {
      const updatedTeam = await hireCoach(team, coachKey);
      onTeamChange(updatedTeam);
      toast.success(`${def?.emoji ?? ""} ${def?.name ?? coachKey} ${isRenew ? "renewed" : "hired"}! (${COACH_MATCHES_PER_HIRE} matches)`);
    } catch (e: any) {
      toast.error(e.message ?? "Hire failed");
    } finally {
      setBusy(false);
    }
  };

  const handleToggleEquip = async (key: string) => {
    if (busy) return;
    const inv = inventory.find(r => r.item_key === key);
    const ownedQty = inv?.quantity ?? 0;
    const isStaff = isStaffItem(key);
    setBusy(true);
    try {
      let next: string[];
      if (isStaff) {
        // Staff: max 1 of each kind. Toggle on/off.
        if (equippedStaff.includes(key)) {
          next = equipped.filter(k => k !== key);
        } else {
          if (equippedStaff.length >= MAX_EQUIPPED_STAFF) { setBusy(false); return; }
          next = [...equipped, key];
        }
      } else {
        // Drinks: cycle 0 → 1 → ... → ownedQty (capped by free drink slots).
        const equippedCount = equippedDrinks.filter(k => k === key).length;
        const otherDrinks = equippedDrinks.filter(k => k !== key);
        const remainingSlots = MAX_EQUIPPED_CONSUMABLES - otherDrinks.length;
        const maxForThis = Math.min(ownedQty, remainingSlots);
        const newCount = equippedCount >= maxForThis ? 0 : equippedCount + 1;
        next = [...otherDrinks, ...Array(newCount).fill(key), ...equippedStaff];
      }
      const updatedTeam = await setEquippedConsumables(team, next);
      onTeamChange(updatedTeam);
    } catch (e: any) {
      toast.error(e.message ?? "Equip failed");
    } finally {
      setBusy(false);
    }
  };

  const handleClearEquipped = async () => {
    if (busy || equipped.length === 0) return;
    setBusy(true);
    try {
      const updatedTeam = await setEquippedConsumables(team, []);
      onTeamChange(updatedTeam);
    } catch (e: any) {
      toast.error(e.message ?? "Clear failed");
    } finally {
      setBusy(false);
    }
  };

  return (
    <>
      <Dialog open={open} onOpenChange={onOpenChange}>
        <DialogContent className="max-w-3xl h-[85vh] !grid-cols-none !flex flex-col gap-4 overflow-hidden">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              🛒 Shop
              <span className="ml-auto inline-flex items-center gap-1 text-yellow-400 font-mono text-base">
                <DollarSign className="h-4 w-4" /> {team.coins.toLocaleString()}
              </span>
            </DialogTitle>
          </DialogHeader>

          <Tabs defaultValue="packs" className="flex-1 min-h-0 flex flex-col overflow-hidden">
            <TabsList className="self-start flex-wrap h-auto">
              <TabsTrigger value="packs">🎁 Packs</TabsTrigger>
              <TabsTrigger value="upgrade">⬆️ Upgrade</TabsTrigger>
              <TabsTrigger value="boosts">🥤 Boosts</TabsTrigger>
              <TabsTrigger value="coach">📋 Coach</TabsTrigger>
              <TabsTrigger value="lottery">🎰 Lottery</TabsTrigger>
            </TabsList>

            <TabsContent value="packs" className="flex-1 min-h-0 mt-3 overflow-hidden">
              <ScrollArea className="flex-1 h-full min-h-0 pr-2">
                <div className="grid sm:grid-cols-2 gap-3">
                  {SHOP_PACKS.map(p => (
                    <Card key={p.key} className="p-4 space-y-2">
                      <div className="flex items-start gap-3">
                        <div className="text-4xl">{p.emoji}</div>
                        <div className="flex-1">
                          <div className="font-bold">{p.name}</div>
                          <div className="text-xs text-muted-foreground">{p.desc}</div>
                        </div>
                      </div>
                      <div className="text-[10px] text-muted-foreground space-x-1">
                        {(["bronze","silver","gold","epic","legendary"] as const).map(r => p.odds[r] > 0 && (
                          <span key={r} className={r === "legendary" ? "legendary-text font-bold" : r === "epic" ? "epic-text font-bold" : RARITY_META[r].color}>{RARITY_META[r].label} {p.odds[r]}%</span>
                        ))}
                      </div>
                      <Button
                        className="w-full gap-1"
                        disabled={busy || team.coins < p.cost}
                        onClick={() => handleBuyPack(p.key)}
                      >
                        <DollarSign className="h-3.5 w-3.5" /> {p.cost.toLocaleString()} · Draw {p.cards}
                      </Button>
                    </Card>
                  ))}
                </div>
              </ScrollArea>
            </TabsContent>

            <TabsContent value="upgrade" className="flex-1 min-h-0 mt-3 overflow-hidden">
              <div className="flex h-full min-h-0 flex-col gap-3 md:flex-row">
                <Card className="md:w-1/2 flex-1 min-h-0 overflow-hidden p-2">
                  <ScrollArea className="h-full w-full pr-2">
                    <div className="grid grid-cols-2 gap-2">
                      {[...ownedCards]
                        .sort((a, b) => {
                          const sa = getEffectiveStats(a.card, a.template);
                          const sb = getEffectiveStats(b.card, b.template);
                          const ovrA = sa.speed + sa.shooting + sa.three_point + sa.defense + sa.dunk;
                          const ovrB = sb.speed + sb.shooting + sb.three_point + sb.defense + sb.dunk;
                          return ovrB - ovrA;
                        })
                        .map(({ card, template }) => (
                          <PlayerCardView
                            key={card.id}
                            card={card}
                            template={template}
                            compact
                            selected={selectedCardId === card.id}
                            onClick={() => setSelectedCardId(card.id)}
                          />
                      ))}
                      {ownedCards.length === 0 && (
                        <p className="col-span-2 py-8 text-center text-sm text-muted-foreground">No player cards yet</p>
                      )}
                    </div>
                  </ScrollArea>
                </Card>

                <div className="md:w-1/2 flex-1 min-h-0">
                  {!selectedEntry ? (
                    <Card className="flex h-full items-center justify-center p-4">
                      <p className="text-center text-sm text-muted-foreground">← Pick a card to upgrade</p>
                    </Card>
                  ) : (
                    <Card className="h-full space-y-3 p-3">
                      <PlayerCardView card={selectedEntry.card} template={selectedEntry.template} />
                      <div className="text-xs text-muted-foreground">
                        Each upgrade <strong>+2 to one stat</strong>. Next cost:
                        <span className="text-yellow-400 font-mono ml-1">
                          {calcUpgradeCost(selectedEntry.card.level)}
                        </span>
                      </div>
                      <div className="grid grid-cols-5 gap-1">
                        {STATS.map(s => (
                          <Button
                            key={s.key} size="sm" variant="outline"
                            className="flex-col h-auto py-2 text-[10px]"
                            disabled={busy || selectedEntry.card.level >= 100 || team.coins < calcUpgradeCost(selectedEntry.card.level)}
                            onClick={() => handleUpgrade(s.key)}
                          >
                            <span>{s.cn}</span>
                            <span className="font-mono">+2</span>
                          </Button>
                        ))}
                      </div>
                      {selectedEntry.card.level >= 100 && (
                        <div className="space-y-1.5 pt-1 border-t border-border/40">
                          <p className="text-[11px] text-amber-500 text-center">Max level (100) reached</p>
                          <Button
                            size="sm"
                            className="w-full h-auto py-2 bg-gradient-to-r from-purple-600 via-fuchsia-500 to-orange-500 text-white font-bold hover:opacity-90 disabled:opacity-50"
                            disabled={busy || team.coins < SUPER_EVOLVE_COST}
                            onClick={handleSuperEvolve}
                          >
                            <span className="flex flex-col items-center leading-tight">
                              <span className="text-xs">✨ Super Evolve · +{SUPER_EVOLVE_BOOST} ALL STATS</span>
                              <span className="text-[10px] font-mono opacity-90">
                                {SUPER_EVOLVE_COST.toLocaleString()} 💰
                              </span>
                            </span>
                          </Button>
                          {team.coins < SUPER_EVOLVE_COST && (
                            <p className="text-[10px] text-muted-foreground text-center">
                              Need {(SUPER_EVOLVE_COST - team.coins).toLocaleString()} more coins
                            </p>
                          )}
                        </div>
                      )}
                    </Card>
                  )}
                </div>
              </div>
            </TabsContent>

            <TabsContent value="boosts" className="flex-1 min-h-0 mt-3 overflow-hidden">
              <ScrollArea className="h-full min-h-0 pr-2">
                <div className="space-y-3 pb-1">
                  {/* Equipped slots */}
                  <Card className="p-3 space-y-2">
                    <div className="flex items-center gap-2 text-xs">
                      <span className="font-bold">Equipped Loadout</span>
                      <span className="ml-auto text-emerald-400 font-mono">
                        +{(totalBoost * 100).toFixed(1)}% all stats
                      </span>
                      {equipped.length > 0 && (
                        <Button size="sm" variant="ghost" className="h-6 px-2 text-[10px]" onClick={handleClearEquipped} disabled={busy}>
                          Clear
                        </Button>
                      )}
                    </div>
                    {/* Drinks row (consumed per match) */}
                    <div>
                      <div className="text-[10px] text-muted-foreground mb-1">🥤 Drinks · max {MAX_EQUIPPED_CONSUMABLES} · consumed per match</div>
                      <div className="grid grid-cols-3 gap-2">
                        {Array.from({ length: MAX_EQUIPPED_CONSUMABLES }).map((_, i) => {
                          const key = equippedDrinks[i];
                          const def = key ? getConsumableDef(key) : null;
                          return (
                            <div
                              key={i}
                              className={`aspect-square rounded-lg border-2 flex flex-col items-center justify-center gap-0.5 ${
                                def ? "border-emerald-400/60 bg-emerald-400/10" : "border-dashed border-border/40 bg-muted/20"
                              }`}
                            >
                              {def ? (
                                <>
                                  <div className="text-2xl">{def.emoji}</div>
                                  <div className="text-[9px] text-emerald-400 font-mono">+{(def.boost * 100).toFixed(1)}%</div>
                                </>
                              ) : (
                                <div className="text-xs text-muted-foreground">Empty</div>
                              )}
                            </div>
                          );
                        })}
                      </div>
                    </div>
                    {/* Staff row (reusable) */}
                    <div>
                      <div className="text-[10px] text-muted-foreground mb-1">👥 Staff Support · max {MAX_EQUIPPED_STAFF} · reusable</div>
                      <div className="grid grid-cols-3 gap-2">
                        {Array.from({ length: MAX_EQUIPPED_STAFF }).map((_, i) => {
                          const key = equippedStaff[i];
                          const def = key ? getConsumableDef(key) : null;
                          return (
                            <div
                              key={i}
                              className={`aspect-square rounded-lg border-2 flex flex-col items-center justify-center gap-0.5 ${
                                def ? "border-blue-400/60 bg-blue-400/10" : "border-dashed border-border/40 bg-muted/20"
                              }`}
                            >
                              {def ? (
                                <>
                                  <div className="text-2xl">{def.emoji}</div>
                                  <div className="text-[9px] text-blue-400 font-mono">+{(def.boost * 100).toFixed(1)}%</div>
                                </>
                              ) : (
                                <div className="text-xs text-muted-foreground">Empty</div>
                              )}
                            </div>
                          );
                        })}
                      </div>
                    </div>
                  </Card>

                  {/* Special bundles (limited / featured) */}
                  {SPECIAL_BUNDLES.length > 0 && (
                    <div className="space-y-2">
                      <div className="text-[11px] font-bold text-amber-400 uppercase tracking-wide">⭐ Limited Bundles</div>
                      <div className="grid gap-2">
                        {SPECIAL_BUNDLES.map(b => (
                          <Card
                            key={b.key}
                            className="p-3 space-y-2 border-2 border-amber-400/40 bg-gradient-to-br from-amber-500/10 to-orange-500/5"
                          >
                            <div className="flex items-start gap-3">
                              <div className="text-3xl">{b.emoji}</div>
                              <div className="flex-1">
                                <div className="font-bold text-sm flex items-center gap-1">
                                  {b.name}
                                  <span className="text-[9px] px-1.5 py-0.5 rounded bg-amber-400/20 text-amber-300 font-mono">LIMITED</span>
                                </div>
                                <div className="text-[11px] text-muted-foreground">{b.desc}</div>
                              </div>
                            </div>
                            <Button
                              size="sm"
                              className="w-full gap-1 bg-gradient-to-r from-amber-500 to-orange-500 hover:from-amber-600 hover:to-orange-600"
                              disabled={busy || team.coins < b.cost}
                              onClick={() => handleBuyBundle(b.key)}
                            >
                              <DollarSign className="h-3 w-3" /> {b.cost.toLocaleString()} · Claim
                            </Button>
                          </Card>
                        ))}
                      </div>
                    </div>
                  )}

                  {/* Staff Support items */}
                  <div className="space-y-2">
                    <div className="text-[11px] font-bold text-blue-400 uppercase tracking-wide">👥 Staff Support · reusable</div>
                    <div className="grid sm:grid-cols-2 gap-2">
                      {CONSUMABLES.filter(i => i.category === "staff").map(item => {
                        const owned = inventory.find(r => r.item_key === item.key)?.quantity ?? 0;
                        const isEquipped = equippedStaff.includes(item.key);
                        const canEquip = owned > 0 && (isEquipped || equippedStaff.length < MAX_EQUIPPED_STAFF);
                        return (
                          <Card key={item.key} className="p-3 space-y-2 border-blue-400/30">
                            <div className="flex items-start gap-3">
                              <div className="text-3xl">{item.emoji}</div>
                              <div className="flex-1">
                                <div className="font-bold text-sm">{item.name}</div>
                                <div className="text-[11px] text-muted-foreground">{item.desc}</div>
                                <div className="text-[10px] mt-1">
                                  Owned: <span className="font-mono">{owned}</span>
                                  {isEquipped && <span className="ml-2 text-blue-400">Active</span>}
                                </div>
                              </div>
                            </div>
                            <div className="grid grid-cols-2 gap-1">
                              <Button
                                size="sm" variant="outline"
                                className="text-[11px] gap-1"
                                disabled={busy || team.coins < item.cost || owned >= 1}
                                onClick={() => handleBuyConsumable(item.key)}
                              >
                                <DollarSign className="h-3 w-3" /> {owned >= 1 ? "Owned" : item.cost.toLocaleString()}
                              </Button>
                              <Button
                                size="sm"
                                className="text-[11px]"
                                variant={isEquipped ? "default" : "secondary"}
                                disabled={busy || !canEquip}
                                onClick={() => handleToggleEquip(item.key)}
                              >
                                {isEquipped ? "Active ✓" : "Equip"}
                              </Button>
                            </div>
                          </Card>
                        );
                      })}
                    </div>
                  </div>

                  {/* Drinks (single-match consumables) */}
                  <div className="space-y-2">
                    <div className="text-[11px] font-bold text-emerald-400 uppercase tracking-wide">🥤 Drinks · single-use</div>
                    <div className="grid sm:grid-cols-2 gap-2">
                      {CONSUMABLES.filter(i => i.category !== "staff").map(item => {
                        const owned = inventory.find(r => r.item_key === item.key)?.quantity ?? 0;
                        const equippedCount = equippedDrinks.filter(k => k === item.key).length;
                        const canEquip = owned > equippedCount && equippedDrinks.length < MAX_EQUIPPED_CONSUMABLES;
                        return (
                          <Card key={item.key} className="p-3 space-y-2">
                            <div className="flex items-start gap-3">
                              <div className="text-3xl">{item.emoji}</div>
                              <div className="flex-1">
                                <div className="font-bold text-sm">{item.name}</div>
                                <div className="text-[11px] text-muted-foreground">{item.desc}</div>
                                <div className="text-[10px] mt-1">
                                  Owned: <span className="font-mono">{owned}</span>
                                  {equippedCount > 0 && (
                                    <span className="ml-2 text-emerald-400">Equipped: {equippedCount}</span>
                                  )}
                                </div>
                              </div>
                            </div>
                            <div className="grid grid-cols-2 gap-1">
                              <Button
                                size="sm" variant="outline"
                                className="text-[11px] gap-1"
                                disabled={busy || team.coins < item.cost}
                                onClick={() => handleBuyConsumable(item.key)}
                              >
                                <DollarSign className="h-3 w-3" /> {item.cost}
                              </Button>
                              <Button
                                size="sm"
                                className="text-[11px]"
                                variant={equippedCount > 0 ? "default" : "secondary"}
                                disabled={busy || (owned === 0) || (!canEquip && equippedCount === 0)}
                                onClick={() => handleToggleEquip(item.key)}
                              >
                                {equippedCount > 0 ? `Equipped ×${equippedCount}` : "Equip"}
                              </Button>
                            </div>
                          </Card>
                        );
                      })}
                    </div>
                  </div>
                </div>
              </ScrollArea>
            </TabsContent>

            <TabsContent value="coach" className="flex-1 min-h-0 mt-3 overflow-hidden">
              <div className="flex h-full min-h-0 flex-col gap-3">
                {(() => {
                  const currentCoach = getCoachDef((team as any).coach_key);
                  const matchesLeft = ((team as any).coach_matches_left ?? 0) as number;
                  const active = !!currentCoach && matchesLeft > 0;
                  return (
                    <Card className="p-3 flex items-center gap-3">
                      <div className="text-3xl">{active ? currentCoach!.emoji : "🚫"}</div>
                      <div className="flex-1">
                        <div className="text-[10px] text-muted-foreground uppercase tracking-wide">Current Head Coach</div>
                        <div className="font-bold text-sm">
                          {active ? currentCoach!.name : "No coach hired"}
                        </div>
                        {active && (
                          <div className="text-[11px] text-emerald-400 font-mono">
                            +{(currentCoach!.boost * 100).toFixed(0)}% all stats · {matchesLeft} match{matchesLeft === 1 ? "" : "es"} left
                          </div>
                        )}
                      </div>
                    </Card>
                  );
                })()}
                <p className="text-[10px] text-muted-foreground -mt-1">
                  Each coach hire lasts <strong>{COACH_MATCHES_PER_HIRE} matches</strong>, then expires. Boosts apply to every match (stacks with equipped boosts). Renewing the SAME coach while contract is active is <strong>20% off</strong>. Hiring a different coach replaces the old contract — no refunds.
                </p>
                <ScrollArea className="flex-1 h-full min-h-0 pr-2">
                  <div className="grid sm:grid-cols-2 gap-2">
                    {COACHES.map(c => {
                      const isCurrent = (team as any).coach_key === c.key;
                      const matchesLeft = ((team as any).coach_matches_left ?? 0) as number;
                      const isActive = isCurrent && matchesLeft > 0;
                      const hireCost = getCoachHireCost(team, c.key);
                      const isRenewDeal = isActive && hireCost < c.cost;
                      return (
                        <Card
                          key={c.key}
                          className={`p-3 space-y-2 ${isActive ? "border-2 border-emerald-400/60 bg-emerald-400/5" : ""}`}
                        >
                          <div className="flex items-start gap-3">
                            <div className="text-3xl">{c.emoji}</div>
                            <div className="flex-1">
                              <div className="font-bold text-sm flex items-center gap-1">
                                {c.name}
                                {isActive && (
                                  <span className="text-[9px] px-1.5 py-0.5 rounded bg-emerald-400/20 text-emerald-300 font-mono">
                                    {matchesLeft} LEFT
                                  </span>
                                )}
                              </div>
                              <div className="text-[11px] text-muted-foreground">{c.desc}</div>
                              <div className="text-[10px] text-emerald-400 font-mono mt-0.5">
                                +{(c.boost * 100).toFixed(0)}% all stats · {COACH_MATCHES_PER_HIRE} matches
                              </div>
                            </div>
                          </div>
                          <Button
                            size="sm"
                            variant={isActive ? "secondary" : "default"}
                            className="w-full gap-1 text-[11px]"
                            disabled={busy || team.coins < hireCost}
                            onClick={() => handleHireCoach(c.key)}
                          >
                            <DollarSign className="h-3 w-3" />
                            {isRenewDeal ? (
                              <>
                                <span className="line-through opacity-60 mr-1">{c.cost.toLocaleString()}</span>
                                {hireCost.toLocaleString()} · Renew −20%
                              </>
                            ) : isActive ? (
                              `${hireCost.toLocaleString()} · Renew`
                            ) : (
                              `${hireCost.toLocaleString()} · Hire`
                            )}
                          </Button>
                        </Card>
                      );
                    })}
                  </div>
                </ScrollArea>
              </div>
            </TabsContent>

            <TabsContent value="lottery" className="flex-1 min-h-0 mt-3 overflow-hidden">
              <ScrollArea className="h-full min-h-0 pr-2">
                <div className="space-y-3 pb-1">
                  <Card className="p-4 space-y-3 bg-gradient-to-br from-purple-500/10 via-fuchsia-500/10 to-orange-500/10 border-fuchsia-400/30">
                    <div className="flex items-center gap-3">
                      <div className="text-4xl">🎡</div>
                      <div className="flex-1">
                        <div className="font-bold">Big Wheel</div>
                        <div className="text-xs text-muted-foreground">
                          Spin for coins & boosts. $100/spin or $1,000 for 10 (guaranteed break-even).
                        </div>
                        <div className="text-[10px] text-muted-foreground mt-1">
                          Jackpot odds: 1M (0.01%) · 100k (0.1%) · 10k (0.5%) · break-even (20%)
                        </div>
                      </div>
                    </div>
                  </Card>

                  <Card className="p-4 space-y-3 bg-gradient-to-br from-amber-500/10 via-yellow-500/10 to-orange-500/10 border-amber-400/30">
                    <div className="flex items-center gap-3">
                      <div className="text-4xl">🎟️</div>
                      <div className="flex-1">
                        <div className="font-bold">Scratch-off Tickets</div>
                        <div className="text-xs text-muted-foreground">
                          Buy a ticket ($100 / $1,000 / $10,000) and scratch to reveal your prize.
                        </div>
                        <div className="text-[10px] text-muted-foreground mt-1">
                          Prizes can be coins or boost items — pools managed by admin.
                        </div>
                      </div>
                    </div>
                  </Card>

                  <Button
                    className="w-full gap-2 bg-gradient-to-r from-purple-600 via-fuchsia-500 to-orange-500 text-white font-bold hover:opacity-90"
                    onClick={() => setLotteryOpen(true)}
                  >
                    🎰 Open Lottery Hall
                  </Button>
                </div>
              </ScrollArea>
            </TabsContent>
          </Tabs>
        </DialogContent>
      </Dialog>

      {drawn && <PackOpenDialog open={!!drawn} onOpenChange={o => !o && setDrawn(null)} drawn={drawn} />}
      <LotteryDialog open={lotteryOpen} onOpenChange={setLotteryOpen} team={team} onTeamChange={onTeamChange} />
    </>
  );
}
