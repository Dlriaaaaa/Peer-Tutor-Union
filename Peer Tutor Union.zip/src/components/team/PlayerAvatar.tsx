/**
 * PlayerAvatar — Circular real-person-style headshot for a player template.
 * Uses DiceBear `personas` SVG (free, deterministic, distinct face per name).
 * Falls back to the rarity-tinted initials if image fails to load.
 */
import { useState } from "react";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { RARITY_META, getPlayerAvatarUrl, type PlayerTemplate } from "@/lib/teamManager";

interface Props {
  template: PlayerTemplate;
  size?: "sm" | "md" | "lg" | "xl";
  grayscale?: boolean;
  className?: string;
}

const SIZE_CLASSES = {
  sm: "h-8 w-8 text-[10px]",
  md: "h-12 w-12 text-xs",
  lg: "h-16 w-16 text-sm",
  xl: "h-24 w-24 text-base",
};

export default function PlayerAvatar({ template, size = "md", grayscale, className = "" }: Props) {
  const [errored, setErrored] = useState(false);
  const meta = RARITY_META[template.rarity as keyof typeof RARITY_META];
  const url = getPlayerAvatarUrl(template);
  const initials = template.name
    .split(" ")
    .map(s => s[0])
    .slice(0, 2)
    .join("")
    .toUpperCase();

  return (
    <Avatar
      className={[
        SIZE_CLASSES[size],
        "ring-2",
        meta.ring,
        grayscale ? "grayscale opacity-60" : "",
        "bg-gradient-to-br",
        meta.bg,
        className,
      ].join(" ")}
    >
      {!errored && (
        <AvatarImage
          src={url}
          alt={template.name}
          onError={() => setErrored(true)}
          className={grayscale ? "grayscale" : ""}
        />
      )}
      <AvatarFallback className={`bg-transparent font-bold ${meta.color}`}>{initials}</AvatarFallback>
    </Avatar>
  );
}
