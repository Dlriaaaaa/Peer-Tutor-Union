import { Canvas } from "@react-three/fiber";
import { Suspense } from "react";
import Field3D from "@/render/three/Field3D";
import Players3D from "@/render/three/Players3D";
import Ball3D from "@/render/three/Ball3D";
import Billboard3D from "@/render/three/Billboard3D";
import CameraRig from "@/render/three/CameraRig";
import { CAMERA_PRESETS } from "@/render/three/sceneTypes";
import type { SceneState } from "@/render/three/sceneTypes";

interface Props {
  state: SceneState;
}

export default function GameScene3D({ state }: Props) {
  const preset = CAMERA_PRESETS[state.cameraView];
  return (
    <div className="w-full h-full rounded-lg overflow-hidden border border-border bg-black">
      <Canvas
        shadows
        gl={{ antialias: true, toneMapping: 3 }}
        dpr={[1, 2]}
        camera={{ fov: preset.fov, near: 0.1, far: 200 }}
        style={{ width: "100%", height: "100%" }}
      >
        <Suspense fallback={null}>
          <CameraRig view={state.cameraView} />

          <mesh>
            <sphereGeometry args={[100, 32, 32]} />
            <meshBasicMaterial color="#5b9bd5" side={1} />
          </mesh>

          <ambientLight intensity={0.35} color="#b0c4de" />
          <directionalLight
            position={[15, 25, 10]}
            intensity={1.6}
            castShadow
            shadow-mapSize-width={2048}
            shadow-mapSize-height={2048}
            shadow-camera-left={-40}
            shadow-camera-right={40}
            shadow-camera-top={40}
            shadow-camera-bottom={-40}
            shadow-camera-near={0.5}
            shadow-camera-far={80}
            shadow-bias={-0.001}
            color="#fff8e7"
          />
          <directionalLight position={[-10, 12, -15]} intensity={0.4} color="#c0d8f0" />
          <hemisphereLight args={["#87ceeb", "#3a5a2a", 0.35]} />
          <pointLight position={[0, 8, 2]} intensity={0.3} color="#ffe8c0" distance={30} />

          <Field3D />
          <Players3D bases={state.bases} phase={state.phase} hitBall={state.hitBall} />
          <Ball3D
            ballProgress={state.ballProgress}
            currentPitch={state.currentPitch}
            hitBall={state.hitBall}
          />
          <Billboard3D config={state.billboard} />
        </Suspense>
      </Canvas>
    </div>
  );
}
