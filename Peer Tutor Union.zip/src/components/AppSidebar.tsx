import { useEffect } from "react";
import { Home, FileText, Target, FolderOpen, BarChart3, Users, UserPlus, Brain, User, LogOut, CalendarDays, CalendarClock, MessageCircle, UserCheck, Award, Settings, FunctionSquare, Languages, Sparkles, Train, Building2 } from "lucide-react";
import { NavLink } from "@/components/NavLink";
import { useLocation } from "react-router-dom";
import { useAuth } from "@/contexts/AuthContext";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { useUnreadMessages } from "@/hooks/useUnreadMessages";
import { getRoleBorderClass, canUseAI, canChat } from "@/lib/roleUtils";

import {
  Sidebar,
  SidebarContent,
  SidebarGroup,
  SidebarGroupContent,
  SidebarGroupLabel,
  SidebarMenu,
  SidebarMenuButton,
  SidebarMenuItem,
  SidebarFooter,
  SidebarHeader,
  useSidebar,
} from "@/components/ui/sidebar";

const mainItems = [
  { title: "Schedule", url: "/schedule", icon: CalendarClock },
  { title: "Resources", url: "/resources", icon: FolderOpen },
  { title: "Quizzes", url: "/quizzes", icon: Brain },
  { title: "Practice", url: "/practice", icon: Target },
  { title: "PTC AI", url: "/nanmo-ai", icon: Sparkles },
  { title: "Grades", url: "/grades", icon: BarChart3 },
  { title: "Members", url: "/members", icon: Users },
  { title: "Activities", url: "/events", icon: CalendarDays },
  { title: "Tutoring", url: "/tutoring", icon: CalendarClock },
  { title: "Study Groups", url: "/study-groups", icon: Users },
  { title: "Feed", url: "/dashboard", icon: Home },
  { title: "Chat", url: "/chat", icon: MessageCircle },
  
  { title: "Calculator", url: "/calculator", icon: FunctionSquare },
  { title: "Translate", url: "/translate", icon: Languages },
  { title: "Profile", url: "/profile", icon: User },
];

const presidentOnlyItems = [
  { title: "Approvals", url: "/admin/approvals", icon: UserCheck },
  { title: "Members", url: "/admin/members", icon: UserPlus },
  { title: "Tutoring", url: "/admin/tutoring", icon: CalendarClock },
  { title: "Grades", url: "/admin/grades", icon: BarChart3 },
  { title: "AI Training", url: "/admin/ai-training", icon: Sparkles },
  { title: "AI Credits", url: "/admin/ai-credits", icon: Sparkles },
];

const sharedAdminItems = [
  { title: "Resources", url: "/admin/resources", icon: FolderOpen },
  { title: "Quizzes", url: "/admin/quizzes", icon: Brain },
  { title: "Question Bank", url: "/admin/question-bank", icon: Target },
  { title: "Events", url: "/admin/events", icon: CalendarDays },
  { title: "Awards", url: "/admin/awards", icon: Award },

];

export function AppSidebar() {
  const { state } = useSidebar();
  const collapsed = state === "collapsed";
  const location = useLocation();
  const { isAdmin, profile, signOut, displayRole, isSuperAdmin } = useAuth();
  const { hasUnread, clearUnread } = useUnreadMessages();

  const isPresident = displayRole === "President";
  const isTeacher = displayRole === "Teacher";
  const canApprove = isPresident || displayRole === "GeneralSecretary";
  const hasAdminAccess = isAdmin || ["VicePresident", "Teacher", "GeneralSecretary"].includes(displayRole);
  const allowAI = canUseAI(displayRole);
  const allowChat = canChat(displayRole);
  const isAdminUser = isAdmin || isPresident;
  const visibleMainItems = mainItems.filter((item) => {
    if ((item.url === "/nanmo-ai" || item.url === "/translate") && !allowAI) return false;
    if (item.url === "/chat" && !allowChat) return false;
    // Members list is only for admins and teachers
    if (item.url === "/members" && !(isAdminUser || isTeacher || hasAdminAccess)) return false;
    // Admins manage tutoring from the admin area
    if (isAdminUser && item.url === "/tutoring") return false;
    return true;
  });

  const teacherItems = [
    { title: "Tutoring", url: "/admin/tutoring", icon: CalendarClock },
    { title: "Grades", url: "/admin/grades", icon: BarChart3 },
    { title: "Resources", url: "/admin/resources", icon: FolderOpen },
    { title: "Quizzes", url: "/admin/quizzes", icon: Brain },
    { title: "Question Bank", url: "/admin/question-bank", icon: Target },
    { title: "Members", url: "/admin/members", icon: UserPlus },
  ];
  const superAdminItems = [{ title: "Schools & Clubs", url: "/admin/schools", icon: Building2 }];
  const adminItems = isTeacher
    ? teacherItems
    : isPresident
      ? [...presidentOnlyItems, ...sharedAdminItems]
      : canApprove
        ? [presidentOnlyItems[0], presidentOnlyItems[2], ...sharedAdminItems]
        : [presidentOnlyItems[2], ...sharedAdminItems];
  const allAdminItems = isSuperAdmin ? [...superAdminItems, ...adminItems] : adminItems;

  // Clear unread when navigating to chat
  useEffect(() => {
    if (location.pathname.startsWith("/chat")) {
      clearUnread();
    }
  }, [location.pathname, clearUnread]);

  const isActive = (path: string) => location.pathname === path || location.pathname.startsWith(path + "/");

  return (
    <Sidebar collapsible="icon" className="glass-sidebar">
      <SidebarHeader className="p-4 border-b border-sidebar-border/40">
        <div className="flex items-center gap-3">
          {collapsed ? (
            <span className="mx-auto text-sm font-bold tracking-tight text-primary">P</span>
          ) : (
            <div className="flex flex-col">
              <span className="font-bold text-sm text-sidebar-foreground leading-tight tracking-tight">PTC</span>
              <span className="text-[11px] text-sidebar-foreground/50 font-medium">Peer Tutor Club</span>
            </div>
          )}
        </div>
      </SidebarHeader>

      <SidebarContent>
        <SidebarGroup>
          <SidebarGroupLabel className="text-[10px] uppercase tracking-widest text-sidebar-foreground/40 font-semibold">Navigation</SidebarGroupLabel>
          <SidebarGroupContent>
            <SidebarMenu>
              {visibleMainItems.map((item) => (
                <SidebarMenuItem key={item.title}>
                  <SidebarMenuButton asChild isActive={isActive(item.url)}>
                    <NavLink to={item.url} end={item.url === "/dashboard"}>
                      <div className="relative">
                        <item.icon className="h-4 w-4" />
                        {item.title === "Chat" && hasUnread && (
                          <span className="absolute -top-1.5 -right-1.5 h-3 w-3 rounded-full bg-destructive border-2 border-sidebar shadow-[0_0_6px_2px_hsl(var(--destructive)/0.5)] animate-pulse" />
                        )}
                      </div>
                      {!collapsed && <span className="font-medium">{item.title}</span>}
                    </NavLink>
                  </SidebarMenuButton>
                </SidebarMenuItem>
              ))}
            </SidebarMenu>
          </SidebarGroupContent>
        </SidebarGroup>

        {hasAdminAccess && (
          <SidebarGroup>
            <SidebarGroupLabel className="text-[10px] uppercase tracking-widest text-sidebar-foreground/40 font-semibold">Administration</SidebarGroupLabel>
            <SidebarGroupContent>
              <SidebarMenu>
                {allAdminItems.map((item) => (
                  <SidebarMenuItem key={item.title}>
                    <SidebarMenuButton asChild isActive={isActive(item.url)}>
                      <NavLink to={item.url}>
                        <item.icon className="h-4 w-4" />
                        {!collapsed && <span className="font-medium">{item.title}</span>}
                      </NavLink>
                    </SidebarMenuButton>
                  </SidebarMenuItem>
                ))}
              </SidebarMenu>
            </SidebarGroupContent>
          </SidebarGroup>
        )}
      </SidebarContent>

      <SidebarFooter className="p-3 border-t border-sidebar-border/50">
        <div className="flex items-center gap-3">
          <Avatar className={`h-8 w-8 ${getRoleBorderClass(displayRole)}`}>
            <AvatarImage src={profile?.avatar_url || undefined} />
            <AvatarFallback className="text-xs bg-sidebar-accent text-sidebar-accent-foreground font-medium">
              {profile?.name?.charAt(0)?.toUpperCase() || "U"}
            </AvatarFallback>
          </Avatar>
          {!collapsed && (
            <div className="flex-1 min-w-0">
              <p className="text-sm font-medium text-sidebar-foreground truncate">{profile?.name || "User"}</p>
            </div>
          )}
          {!collapsed && (
            <button onClick={signOut} className="text-sidebar-foreground/40 hover:text-sidebar-foreground transition-colors rounded-lg p-1.5 hover:bg-sidebar-accent/50">
              <LogOut className="h-4 w-4" />
            </button>
          )}
        </div>
      </SidebarFooter>
    </Sidebar>
  );
}
