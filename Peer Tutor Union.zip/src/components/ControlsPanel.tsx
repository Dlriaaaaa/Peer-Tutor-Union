/**
 * ControlsPanel — Game action buttons with phase-aware state.
 */

interface ControlsPanelProps {
  phase: "idle" | "pitching" | "deciding" | "result" | "game_over";
  onNextPitch: () => void;
  onSwing: () => void;
  onTake: () => void;
  onNewGame: () => void;
  decideTimeLeft?: number;
}

export default function ControlsPanel({
  phase,
  onNextPitch,
  onSwing,
  onTake,
  onNewGame,
  decideTimeLeft,
}: ControlsPanelProps) {
  return (
    <div className="flex items-center gap-2 w-full max-w-[800px]">
      {phase === "idle" && (
        <button
          onClick={onNextPitch}
          className="flex-1 py-2 rounded-lg font-bold text-xs bg-primary text-primary-foreground hover:bg-primary/90 transition-colors"
        >
          ⚾ Next Pitch (Space)
        </button>
      )}

      {phase === "pitching" && (
        <div className="flex-1 py-2 rounded-lg font-bold text-xs bg-muted text-muted-foreground text-center animate-pulse">
          Pitcher winding up…
        </div>
      )}

      {phase === "deciding" && (
        <>
          <button
            onClick={onSwing}
            className="flex-1 py-2 rounded-lg font-bold text-xs bg-red-600 text-white hover:bg-red-700 transition-colors"
          >
            🏏 SWING! (Space)
          </button>
          <button
            onClick={onTake}
            className="flex-1 py-2 rounded-lg font-bold text-xs bg-blue-600 text-white hover:bg-blue-700 transition-colors"
          >
            👀 Take (T)
          </button>
          {decideTimeLeft !== undefined && (
            <div className="text-xs text-muted-foreground font-mono w-12 text-right tabular-nums">
              {(decideTimeLeft / 1000).toFixed(1)}s
            </div>
          )}
        </>
      )}

      {phase === "result" && (
        <div className="flex-1 py-2 rounded-lg font-bold text-xs bg-muted text-muted-foreground text-center">
          ⏳ Resolving play…
        </div>
      )}

      {phase === "game_over" && (
        <button
          onClick={onNewGame}
          className="flex-1 py-2 rounded-lg font-bold text-xs bg-yellow-600 text-white hover:bg-yellow-700 transition-colors"
        >
          🔄 New Game
        </button>
      )}
    </div>
  );
}
