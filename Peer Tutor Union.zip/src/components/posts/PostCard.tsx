import { useState, useEffect, useCallback } from "react";
import { useNavigate, Link } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Button } from "@/components/ui/button";
import { formatDistanceToNow } from "date-fns";
import { Heart, MessageCircle, Send, MoreHorizontal, Trash2, Paperclip } from "lucide-react";
import { toast } from "sonner";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import PostDetailDialog from "./PostDetailDialog";
import CelebrityBadge from "./CelebrityBadge";
import { CelebrityInfo, getVirtualLikes, formatCount } from "@/lib/celebrityUtils";
import { getRoleBorderClass, roleLabel } from "@/lib/roleUtils";
import { Badge } from "@/components/ui/badge";

function parseTagsAndMentions(html: string, profiles: ProfileMap): string {
  const nameToUserId: Record<string, string> = {};
  Object.entries(profiles).forEach(([userId, p]) => {
    if (p.name) nameToUserId[p.name.toLowerCase()] = userId;
  });
  return html
    .replace(/#([\w\u4e00-\u9fff]+)/g, '<a class="hashtag-link" href="/tags/$1">#$1</a>')
    .replace(/@([\w\u4e00-\u9fff]+)/g, (_, name) => {
      const uid = nameToUserId[name.toLowerCase()];
      return uid
        ? `<a class="mention-link" href="/profile/${uid}">@${name}</a>`
        : `<span class="mention-unresolved">@${name}</span>`;
    });
}

type Post = {
  id: string;
  title: string;
  content: string;
  created_at: string;
  author_id: string;
  post_attachments: { id: string; file_url: string; file_name: string }[];
};

type ProfileMap = Record<string, { name: string; avatar_url: string | null; display_role?: string }>;

interface PostCardProps {
  post: Post;
  profiles: ProfileMap;
  userId: string;
  isAdmin: boolean;
  onDelete: (postId: string) => void;
  celebrityMap?: Record<string, CelebrityInfo>;
}

export default function PostCard({ post, profiles, userId, isAdmin, onDelete, celebrityMap = {} }: PostCardProps) {
  const navigate = useNavigate();
  const author = profiles[post.author_id];
  const canDelete = post.author_id === userId || isAdmin;
  const celebrity = celebrityMap[post.author_id];
  const virtualLikes = celebrity ? getVirtualLikes(post.id, post.created_at, celebrity.likes_multiplier || 1, celebrity.likes_multiplier_changed_at) : 0;

  const [liked, setLiked] = useState(false);
  const [likeCount, setLikeCount] = useState(0);
  const [commentCount, setCommentCount] = useState(0);
  const [likeAnimating, setLikeAnimating] = useState(false);
  const [doubleTapAnim, setDoubleTapAnim] = useState(false);
  const [showDetail, setShowDetail] = useState(false);

  useEffect(() => {
    fetchLikes();
    fetchCommentCount();
  }, [post.id]);

  const fetchLikes = async () => {
    const { data, count } = await supabase
      .from("post_likes")
      .select("*", { count: "exact" })
      .eq("post_id", post.id);
    setLikeCount(count || 0);
    setLiked(data?.some((l: any) => l.user_id === userId) || false);
  };

  const fetchCommentCount = async () => {
    const { count } = await supabase
      .from("post_comments")
      .select("*", { count: "exact", head: true })
      .eq("post_id", post.id);
    setCommentCount(count || 0);
  };

  const toggleLike = async () => {
    if (liked) {
      await supabase.from("post_likes").delete().eq("post_id", post.id).eq("user_id", userId);
    } else {
      await supabase.from("post_likes").insert({ post_id: post.id, user_id: userId });
      setLikeAnimating(true);
      setTimeout(() => setLikeAnimating(false), 600);
      if (post.author_id !== userId) {
        await supabase.from("notifications").insert({
          user_id: post.author_id, actor_id: userId, type: "like", post_id: post.id,
        });
      }
    }
    fetchLikes();
  };

  const handleDoubleTap = async () => {
    if (liked) return;
    setDoubleTapAnim(true);
    setTimeout(() => setDoubleTapAnim(false), 1000);
    await supabase.from("post_likes").insert({ post_id: post.id, user_id: userId });
    if (post.author_id !== userId) {
      await supabase.from("notifications").insert({
        user_id: post.author_id, actor_id: userId, type: "like", post_id: post.id,
      });
    }
    fetchLikes();
  };

  const [failedImages, setFailedImages] = useState<Set<string>>(new Set());
  const handleImageError = useCallback((attId: string) => {
    setFailedImages(prev => new Set(prev).add(attId));
  }, []);

  const imageAttachments = (post.post_attachments?.filter((att) =>
    /\.(jpg|jpeg|png|gif|webp|svg|heic|heif)$/i.test(att.file_name) && !failedImages.has(att.id)
  )) || [];
  const fileAttachments = post.post_attachments?.filter((att) =>
    !/\.(jpg|jpeg|png|gif|webp|svg|heic|heif)$/i.test(att.file_name)
  ) || [];

  return (
    <>
      <div className="border-b border-border bg-card">
        {/* Header */}
        <div className="flex items-center gap-3 px-4 py-3">
          <button onClick={() => navigate(`/profile/${post.author_id}`)}>
            <Avatar className={`h-8 w-8 ${getRoleBorderClass(author?.display_role)}`}>
              <AvatarImage src={author?.avatar_url || undefined} />
              <AvatarFallback className="text-xs">{author?.name?.charAt(0) || "A"}</AvatarFallback>
            </Avatar>
          </button>
          <div className="flex-1 min-w-0 flex items-center gap-2">
            <button
              onClick={() => navigate(`/profile/${post.author_id}`)}
              className="text-sm font-semibold text-foreground hover:opacity-70 transition-opacity"
            >
              {author?.name || "User"}
            </button>
            {author?.display_role && author.display_role !== "Student" && (
              <Badge variant="outline" className="text-[10px] px-1.5 py-0 h-4">
                {roleLabel[author.display_role] || author.display_role}
              </Badge>
            )}
            {celebrity && <CelebrityBadge celebrity={celebrity} className="ml-1" />}
          </div>
          {canDelete && (
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="ghost" size="icon" className="h-8 w-8">
                  <MoreHorizontal className="h-4 w-4" />
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end">
                <DropdownMenuItem onClick={() => onDelete(post.id)} className="text-destructive">
                  <Trash2 className="h-3.5 w-3.5 mr-2" /> Delete
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          )}
        </div>

        {/* Image area - click to open detail, double tap to like */}
        {imageAttachments.length > 0 ? (
          <div className="relative cursor-pointer" onDoubleClick={handleDoubleTap} onClick={() => setShowDetail(true)}>
            {imageAttachments.length === 1 ? (
              <img
                src={imageAttachments[0].file_url}
                alt={imageAttachments[0].file_name}
                className="w-full object-cover max-h-[500px]"
                loading="lazy"
                onError={() => handleImageError(imageAttachments[0].id)}
              />
            ) : (
              <div className="grid grid-cols-2 gap-0.5">
                {imageAttachments.map((att) => (
                  <img
                    key={att.id}
                    src={att.file_url}
                    alt={att.file_name}
                    className="w-full aspect-square object-cover"
                    loading="lazy"
                    onError={() => handleImageError(att.id)}
                  />
                ))}
              </div>
            )}
            {doubleTapAnim && (
              <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
                <Heart className="h-20 w-20 text-white fill-white animate-ping opacity-80" />
              </div>
            )}
          </div>
        ) : (
          /* Text-only post - click to open detail */
          <button className="w-full text-left px-4 pb-2" onClick={() => setShowDetail(true)}>
            <div className="text-sm text-foreground prose-sm prose dark:prose-invert max-w-none [&>*]:m-0 [&>*]:text-sm line-clamp-4 [&_.hashtag-link]:text-primary [&_.hashtag-link]:no-underline [&_.hashtag-link]:font-medium [&_.mention-link]:text-primary [&_.mention-link]:no-underline [&_.mention-link]:font-medium [&_.mention-unresolved]:text-primary/70"
              dangerouslySetInnerHTML={{ __html: parseTagsAndMentions(post.content, profiles) }}
              onClick={(e) => {
                const target = e.target as HTMLElement;
                if (target.classList.contains("hashtag-link") || target.classList.contains("mention-link")) {
                  e.stopPropagation();
                  e.preventDefault();
                  const href = target.getAttribute("href");
                  if (href) navigate(href);
                }
              }}
            />
          </button>
        )}

        {/* Action buttons */}
        <div className="px-4 pt-2">
          <div className="flex items-center gap-4">
            <button onClick={toggleLike} className="hover:opacity-60 transition-opacity">
              <Heart
                className={`h-5 w-5 transition-all duration-200 ${liked ? "fill-red-500 text-red-500" : "text-foreground"} ${likeAnimating ? "scale-125" : ""}`}
              />
            </button>
            <button onClick={() => setShowDetail(true)} className="hover:opacity-60 transition-opacity">
              <MessageCircle className="h-5 w-5 text-foreground" />
            </button>
            <button onClick={() => setShowDetail(true)} className="hover:opacity-60 transition-opacity">
              <Send className="h-5 w-5 text-foreground" />
            </button>
          </div>

          {(likeCount + virtualLikes) > 0 && (
            <p className="text-sm font-semibold text-foreground mt-1">
              {formatCount(likeCount + virtualLikes)} {(likeCount + virtualLikes) === 1 ? "like" : "likes"}
            </p>
          )}

          {/* Caption */}
          <div className="mt-1">
            <p className="text-sm">
              <span className="font-medium text-foreground">{post.title}</span>
            </p>
            {imageAttachments.length > 0 && (
              <div className="text-sm text-foreground mt-0.5 line-clamp-2 prose-sm prose dark:prose-invert max-w-none [&>*]:m-0 [&>*]:text-sm [&_.hashtag-link]:text-primary [&_.hashtag-link]:no-underline [&_.hashtag-link]:font-medium [&_.mention-link]:text-primary [&_.mention-link]:no-underline [&_.mention-link]:font-medium [&_.mention-unresolved]:text-primary/70"
                dangerouslySetInnerHTML={{ __html: parseTagsAndMentions(post.content, profiles) }}
                onClick={(e) => {
                  const target = e.target as HTMLElement;
                  if (target.classList.contains("hashtag-link") || target.classList.contains("mention-link")) {
                    e.stopPropagation();
                    e.preventDefault();
                    const href = target.getAttribute("href");
                    if (href) navigate(href);
                  }
                }}
              />
            )}
          </div>

          {fileAttachments.length > 0 && (
            <div className="mt-1.5 space-y-0.5">
              {fileAttachments.map((att) => (
                <a key={att.id} href={att.file_url} target="_blank" rel="noopener noreferrer"
                  className="flex items-center gap-1 text-xs text-primary hover:underline">
                  <Paperclip className="h-3 w-3" /> {att.file_name}
                </a>
              ))}
            </div>
          )}

          {commentCount > 0 && (
            <button onClick={() => setShowDetail(true)} className="text-sm text-muted-foreground mt-1 hover:opacity-70">
              View all {commentCount} comments
            </button>
          )}

          <p className="text-[10px] text-muted-foreground mt-1 mb-3 uppercase tracking-wide">
            {formatDistanceToNow(new Date(post.created_at), { addSuffix: true })}
          </p>
        </div>
      </div>

      {/* Detail dialog */}
      <PostDetailDialog
        post={showDetail ? post : null}
        profiles={profiles}
        userId={userId}
        isAdmin={isAdmin}
        onClose={() => { setShowDetail(false); fetchLikes(); fetchCommentCount(); }}
        onDelete={onDelete}
        celebrityMap={celebrityMap}
      />
    </>
  );
}
