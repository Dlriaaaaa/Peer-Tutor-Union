import { useState, useEffect, useCallback } from "react";
import { useNavigate } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import { Dialog, DialogContent } from "@/components/ui/dialog";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Input } from "@/components/ui/input";
import { ScrollArea } from "@/components/ui/scroll-area";
import { formatDistanceToNow } from "date-fns";
import { Heart, MessageCircle, Send, MoreHorizontal, Trash2, Paperclip } from "lucide-react";
import { Button } from "@/components/ui/button";
import CelebrityBadge from "./CelebrityBadge";
import { CelebrityInfo, getVirtualLikes, formatCount } from "@/lib/celebrityUtils";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { toast } from "sonner";

function parseTagsAndMentions(html: string, profiles: Record<string, { name: string; avatar_url: string | null }>): string {
  const nameToUserId: Record<string, string> = {};
  Object.entries(profiles).forEach(([userId, p]) => {
    if (p.name) nameToUserId[p.name.toLowerCase()] = userId;
  });
  return html
    .replace(/#([\w\u4e00-\u9fff]+)/g, '<a class="hashtag-link" href="/tags/$1">#$1</a>')
    .replace(/@([\w\u4e00-\u9fff]+)/g, (_, name) => {
      const uid = nameToUserId[name.toLowerCase()];
      return uid
        ? `<a class="mention-link" href="/profile/${uid}">@${name}</a>`
        : `<span class="mention-unresolved">@${name}</span>`;
    });
}

type Post = {
  id: string;
  title: string;
  content: string;
  created_at: string;
  author_id: string;
  post_attachments: { id: string; file_url: string; file_name: string }[];
};

type ProfileMap = Record<string, { name: string; avatar_url: string | null }>;

type Comment = {
  id: string;
  post_id: string;
  user_id: string;
  content: string;
  created_at: string;
};

interface PostDetailDialogProps {
  post: Post | null;
  profiles: ProfileMap;
  userId: string;
  isAdmin: boolean;
  onClose: () => void;
  onDelete?: (postId: string) => void;
  celebrityMap?: Record<string, CelebrityInfo>;
}

export default function PostDetailDialog({ post, profiles, userId, isAdmin, onClose, onDelete, celebrityMap = {} }: PostDetailDialogProps) {
  const navigate = useNavigate();
  const [liked, setLiked] = useState(false);
  const [likeCount, setLikeCount] = useState(0);
  const [comments, setComments] = useState<Comment[]>([]);
  const [newComment, setNewComment] = useState("");
  const [submitting, setSubmitting] = useState(false);
  const [showShareDialog, setShowShareDialog] = useState(false);
  const [failedImages, setFailedImages] = useState<Set<string>>(new Set());
  const handleImageError = useCallback((attId: string) => {
    setFailedImages(prev => new Set(prev).add(attId));
  }, []);
  const [conversations, setConversations] = useState<{ id: string; name: string; isGroup?: boolean; avatarUrl?: string | null }[]>([]);

  useEffect(() => {
    if (!post) return;
    fetchLikes();
    fetchComments();
  }, [post?.id]);

  const fetchLikes = async () => {
    if (!post) return;
    const { data, count } = await supabase
      .from("post_likes")
      .select("*", { count: "exact" })
      .eq("post_id", post.id);
    setLikeCount(count || 0);
    setLiked(data?.some((l: any) => l.user_id === userId) || false);
  };

  const fetchComments = async () => {
    if (!post) return;
    const { data } = await supabase
      .from("post_comments")
      .select("*")
      .eq("post_id", post.id)
      .order("created_at", { ascending: true });
    setComments((data as Comment[]) || []);
  };

  const toggleLike = async () => {
    if (!post) return;
    if (liked) {
      await supabase.from("post_likes").delete().eq("post_id", post.id).eq("user_id", userId);
    } else {
      await supabase.from("post_likes").insert({ post_id: post.id, user_id: userId });
      if (post.author_id !== userId) {
        await supabase.from("notifications").insert({
          user_id: post.author_id, actor_id: userId, type: "like", post_id: post.id,
        });
      }
    }
    fetchLikes();
  };

  const handleComment = async () => {
    if (!newComment.trim() || !post) return;
    setSubmitting(true);
    await supabase.from("post_comments").insert({
      post_id: post.id, user_id: userId, content: newComment.trim(),
    });
    if (post.author_id !== userId) {
      await supabase.from("notifications").insert({
        user_id: post.author_id, actor_id: userId, type: "comment", post_id: post.id,
        comment_content: newComment.trim().slice(0, 100),
      });
    }
    setNewComment("");
    setSubmitting(false);
    fetchComments();
  };

  const handleDeleteComment = async (commentId: string) => {
    await supabase.from("post_comments").delete().eq("id", commentId);
    fetchComments();
  };

  const handleShare = async () => {
    if (!post) return;
    const { data: members } = await supabase
      .from("conversation_members").select("conversation_id").eq("user_id", userId);
    if (members && members.length > 0) {
      const convIds = members.map((m: any) => m.conversation_id);
      const { data: convs } = await supabase
        .from("conversations").select("id, name, is_group").in("id", convIds);

      // For DMs, resolve the other person's name
      const dmConvs = (convs || []).filter((c: any) => !c.is_group && !c.name);
      let dmInfoMap: Record<string, { name: string; avatarUrl: string | null }> = {};
      if (dmConvs.length > 0) {
        const dmIds = dmConvs.map((c: any) => c.id);
        const { data: allMembers } = await supabase
          .from("conversation_members").select("conversation_id, user_id").in("conversation_id", dmIds);
        const otherUserIds = [...new Set((allMembers || []).filter((m: any) => m.user_id !== userId).map((m: any) => m.user_id))];
        if (otherUserIds.length > 0) {
          const { data: profs } = await supabase.from("profiles").select("user_id, name, avatar_url").in("user_id", otherUserIds);
          const profMap: Record<string, { name: string; avatarUrl: string | null }> = {};
          (profs || []).forEach((p: any) => { profMap[p.user_id] = { name: p.name, avatarUrl: p.avatar_url }; });
          (allMembers || []).filter((m: any) => m.user_id !== userId).forEach((m: any) => {
            dmInfoMap[m.conversation_id] = profMap[m.user_id] || { name: "Unknown", avatarUrl: null };
          });
        }
      }

      setConversations(
        (convs || []).map((c: any) => ({
          id: c.id,
          name: c.name || (c.is_group ? "Group Chat" : dmInfoMap[c.id]?.name || "Unknown"),
          isGroup: c.is_group,
          avatarUrl: c.is_group ? null : dmInfoMap[c.id]?.avatarUrl || null,
        }))
      );
    }
    setShowShareDialog(true);
  };

  const forwardToConversation = async (convId: string) => {
    if (!post) return;
    const thumb = post.post_attachments?.find((a) => /\.(jpg|jpeg|png|gif|webp|svg|heic|heif)$/i.test(a.file_name))?.file_url || "";
    const shareContent = `[SharedPost:${post.id}:${thumb}] ${post.title}`;
    await supabase.from("messages").insert({ conversation_id: convId, sender_id: userId, content: shareContent });
    await supabase.from("conversations").update({ updated_at: new Date().toISOString() }).eq("id", convId);
    toast.success("Forwarded to chat");
    setShowShareDialog(false);
  };

  if (!post) return null;

  const author = profiles[post.author_id];
  const canDelete = post.author_id === userId || isAdmin;
  const celebrity = celebrityMap[post.author_id];
  const virtualLikes = celebrity ? getVirtualLikes(post.id, post.created_at, celebrity.likes_multiplier || 1, celebrity.likes_multiplier_changed_at) : 0;
  const imageAttachments = post.post_attachments?.filter((att) =>
    /\.(jpg|jpeg|png|gif|webp|svg|heic|heif)$/i.test(att.file_name) && !failedImages.has(att.id)
  ) || [];
  const fileAttachments = post.post_attachments?.filter((att) =>
    !/\.(jpg|jpeg|png|gif|webp|svg|heic|heif)$/i.test(att.file_name)
  ) || [];

  return (
    <>
      <Dialog open={!!post} onOpenChange={() => onClose()}>
        <DialogContent className="sm:max-w-4xl max-h-[90vh] p-0 gap-0 overflow-hidden">
          <div className="flex flex-col sm:flex-row h-full max-h-[90vh]">
            {/* Left: Image */}
            {imageAttachments.length > 0 ? (
              <div className="sm:w-[55%] shrink-0 bg-black flex items-center justify-center max-h-[40vh] sm:max-h-[90vh] overflow-hidden">
                {imageAttachments.length === 1 ? (
                  <img src={imageAttachments[0].file_url} alt="" className="w-full h-full object-contain" onError={() => handleImageError(imageAttachments[0].id)} />
                ) : (
                  <div className="w-full h-full overflow-y-auto">
                    {imageAttachments.map((att) => (
                      <img key={att.id} src={att.file_url} alt={att.file_name} className="w-full object-contain" onError={() => handleImageError(att.id)} />
                    ))}
                  </div>
                )}
              </div>
            ) : (
              <div className="sm:w-[55%] shrink-0 bg-muted flex items-center justify-center p-8 max-h-[30vh] sm:max-h-[90vh]">
                <div className="text-center">
                  <p className="font-semibold text-foreground text-lg">{post.title}</p>
                  <div className="text-sm text-muted-foreground mt-2 prose prose-sm dark:prose-invert max-w-none [&_.hashtag-link]:text-primary [&_.hashtag-link]:no-underline [&_.hashtag-link]:font-medium [&_.mention-link]:text-primary [&_.mention-link]:no-underline [&_.mention-link]:font-medium"
                    dangerouslySetInnerHTML={{ __html: parseTagsAndMentions(post.content, profiles) }} />
                </div>
              </div>
            )}

            {/* Right: Comments */}
            <div className="flex-1 flex flex-col min-w-0 sm:w-[45%]">
              {/* Header */}
              <div className="flex items-center gap-3 px-4 py-3 border-b border-border">
                <button onClick={() => { onClose(); navigate(`/profile/${post.author_id}`); }}>
                  <Avatar className="h-8 w-8">
                    <AvatarImage src={author?.avatar_url || undefined} />
                    <AvatarFallback className="text-xs">{author?.name?.charAt(0) || "A"}</AvatarFallback>
                  </Avatar>
                </button>
                <button
                  onClick={() => { onClose(); navigate(`/profile/${post.author_id}`); }}
                  className="text-sm font-semibold text-foreground hover:opacity-70"
                >
                  {author?.name || "User"}
                </button>
                {celebrity && <CelebrityBadge celebrity={celebrity} />}
                <div className="flex-1" />
                {canDelete && (
                  <DropdownMenu>
                    <DropdownMenuTrigger asChild>
                      <Button variant="ghost" size="icon" className="h-8 w-8">
                        <MoreHorizontal className="h-4 w-4" />
                      </Button>
                    </DropdownMenuTrigger>
                    <DropdownMenuContent align="end">
                      <DropdownMenuItem onClick={() => { onDelete?.(post.id); onClose(); }} className="text-destructive">
                        <Trash2 className="h-3.5 w-3.5 mr-2" /> Delete
                      </DropdownMenuItem>
                    </DropdownMenuContent>
                  </DropdownMenu>
                )}
              </div>

              {/* Comments list */}
              <ScrollArea className="flex-1 min-h-0">
                <div className="px-4 py-3 space-y-3">
                  {/* Caption */}
                  <div className="flex gap-3">
                    <Avatar className="h-8 w-8 shrink-0 mt-0.5">
                      <AvatarImage src={author?.avatar_url || undefined} />
                      <AvatarFallback className="text-xs">{author?.name?.charAt(0) || "A"}</AvatarFallback>
                    </Avatar>
                    <div className="min-w-0">
                      <p className="text-sm">
                        <span className="font-semibold text-foreground">{author?.name || "User"}</span>{" "}
                        <span className="font-medium">{post.title}</span>
                      </p>
                      {imageAttachments.length > 0 && (
                        <div className="text-sm text-foreground mt-1 prose-sm prose dark:prose-invert max-w-none [&>*]:m-0 [&>*]:text-sm [&_.hashtag-link]:text-primary [&_.hashtag-link]:no-underline [&_.hashtag-link]:font-medium [&_.mention-link]:text-primary [&_.mention-link]:no-underline [&_.mention-link]:font-medium"
                          dangerouslySetInnerHTML={{ __html: parseTagsAndMentions(post.content, profiles) }} />
                      )}
                      {fileAttachments.length > 0 && (
                        <div className="mt-1 space-y-0.5">
                          {fileAttachments.map((att) => (
                            <a key={att.id} href={att.file_url} target="_blank" rel="noopener noreferrer"
                              className="flex items-center gap-1 text-xs text-primary hover:underline">
                              <Paperclip className="h-3 w-3" /> {att.file_name}
                            </a>
                          ))}
                        </div>
                      )}
                      <p className="text-[10px] text-muted-foreground mt-1">
                        {formatDistanceToNow(new Date(post.created_at), { addSuffix: true })}
                      </p>
                    </div>
                  </div>

                  {/* Comments */}
                  {comments.map((c) => {
                    const commenter = profiles[c.user_id];
                    const canDeleteComment = c.user_id === userId || isAdmin;
                    return (
                      <div key={c.id} className="flex gap-3 group">
                        <Avatar className="h-8 w-8 shrink-0 mt-0.5">
                          <AvatarImage src={commenter?.avatar_url || undefined} />
                          <AvatarFallback className="text-xs">{commenter?.name?.charAt(0) || "?"}</AvatarFallback>
                        </Avatar>
                        <div className="flex-1 min-w-0">
                          <p className="text-sm">
                            <span className="font-semibold text-foreground">{commenter?.name || "User"}</span>{" "}
                            <span className="text-foreground">{c.content}</span>
                          </p>
                          <div className="flex items-center gap-3">
                            <span className="text-[10px] text-muted-foreground">
                              {formatDistanceToNow(new Date(c.created_at), { addSuffix: true })}
                            </span>
                            {canDeleteComment && (
                              <button onClick={() => handleDeleteComment(c.id)}
                                className="text-[10px] text-muted-foreground hover:text-destructive opacity-0 group-hover:opacity-100 transition-opacity">
                                Delete
                              </button>
                            )}
                          </div>
                        </div>
                      </div>
                    );
                  })}
                </div>
              </ScrollArea>

              {/* Action buttons */}
              <div className="border-t border-border px-4 pt-2 pb-1">
                <div className="flex items-center gap-4">
                  <button onClick={toggleLike} className="hover:opacity-60 transition-opacity">
                    <Heart className={`h-5 w-5 transition-all ${liked ? "fill-red-500 text-red-500" : "text-foreground"}`} />
                  </button>
                  <button className="hover:opacity-60 transition-opacity">
                    <MessageCircle className="h-5 w-5 text-foreground" />
                  </button>
                  <button onClick={handleShare} className="hover:opacity-60 transition-opacity">
                    <Send className="h-5 w-5 text-foreground" />
                  </button>
                </div>
                {(likeCount + virtualLikes) > 0 && (
                  <p className="text-sm font-semibold text-foreground mt-1">
                    {formatCount(likeCount + virtualLikes)} {(likeCount + virtualLikes) === 1 ? "like" : "likes"}
                  </p>
                )}
                <p className="text-[10px] text-muted-foreground mt-0.5 uppercase tracking-wide mb-1">
                  {formatDistanceToNow(new Date(post.created_at), { addSuffix: true })}
                </p>
              </div>

              {/* Comment input */}
              <div className="flex items-center gap-3 px-4 py-3 border-t border-border">
                <Input
                  value={newComment}
                  onChange={(e) => setNewComment(e.target.value)}
                  placeholder="Add a comment..."
                  className="border-0 bg-transparent shadow-none text-sm h-8 px-0 focus-visible:ring-0"
                  onKeyDown={(e) => {
                    if (e.key === "Enter" && !e.shiftKey) { e.preventDefault(); handleComment(); }
                  }}
                />
                {newComment.trim() && (
                  <button onClick={handleComment} disabled={submitting}
                    className="text-sm font-semibold text-primary hover:opacity-70 transition-opacity whitespace-nowrap">
                    Post
                  </button>
                )}
              </div>
            </div>
          </div>
        </DialogContent>
      </Dialog>

      {/* Share sub-dialog */}
      <Dialog open={showShareDialog} onOpenChange={setShowShareDialog}>
        <DialogContent className="sm:max-w-sm">
          <div className="font-semibold text-foreground mb-2">Share to Chat</div>
          {conversations.length === 0 ? (
            <p className="text-sm text-muted-foreground text-center py-4">No chats available</p>
          ) : (
            <ScrollArea className="max-h-72">
              {(() => {
                const groups = conversations.filter(c => c.isGroup);
                const friends = conversations.filter(c => !c.isGroup);
                return (
                  <div className="space-y-3">
                    {friends.length > 0 && (
                      <div>
                        <p className="text-xs font-medium text-muted-foreground px-3 mb-1">Friends</p>
                        <div className="space-y-0.5">
                          {friends.map((conv) => (
                            <button key={conv.id}
                              className="w-full flex items-center gap-3 px-3 py-2.5 rounded-lg hover:bg-muted transition-colors text-left"
                              onClick={() => forwardToConversation(conv.id)}>
                              <Avatar className="h-8 w-8">
                                <AvatarImage src={conv.avatarUrl || undefined} />
                                <AvatarFallback className="text-xs">{conv.name.charAt(0)}</AvatarFallback>
                              </Avatar>
                              <span className="text-sm font-medium truncate">{conv.name}</span>
                            </button>
                          ))}
                        </div>
                      </div>
                    )}
                    {groups.length > 0 && (
                      <div>
                        <p className="text-xs font-medium text-muted-foreground px-3 mb-1">Group Chats</p>
                        <div className="space-y-0.5">
                          {groups.map((conv) => (
                            <button key={conv.id}
                              className="w-full flex items-center gap-3 px-3 py-2.5 rounded-lg hover:bg-muted transition-colors text-left"
                              onClick={() => forwardToConversation(conv.id)}>
                              <Avatar className="h-8 w-8">
                                <AvatarFallback className="text-xs">{conv.name.charAt(0)}</AvatarFallback>
                              </Avatar>
                              <span className="text-sm font-medium truncate">{conv.name}</span>
                            </button>
                          ))}
                        </div>
                      </div>
                    )}
                  </div>
                );
              })()}
            </ScrollArea>
          )}
        </DialogContent>
      </Dialog>
    </>
  );
}
