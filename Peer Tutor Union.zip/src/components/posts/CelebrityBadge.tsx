import { CelebrityInfo, getBadgeColorClass, getBadgeIconEmoji } from "@/lib/celebrityUtils";
import { cn } from "@/lib/utils";

interface CelebrityBadgeProps {
  celebrity: CelebrityInfo;
  className?: string;
}

export default function CelebrityBadge({ celebrity, className }: CelebrityBadgeProps) {
  const colorClass = getBadgeColorClass(celebrity.badge_color);
  const icon = getBadgeIconEmoji(celebrity.badge_icon);
  const isGlow = celebrity.badge_style === "glow";
  const isOutline = celebrity.badge_style === "outline";

  return (
    <span
      className={cn(
        "inline-flex items-center gap-0.5 text-[10px] font-semibold px-1.5 py-0.5 rounded-full border ml-1",
        colorClass,
        isGlow && "shadow-[0_0_8px_2px_currentColor]",
        isOutline && "bg-transparent",
        className
      )}
    >
      <span className="text-xs leading-none">{icon}</span>
      {celebrity.title}
    </span>
  );
}
