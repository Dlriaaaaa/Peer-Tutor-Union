import ReactMarkdown from "react-markdown";
import remarkMath from "remark-math";
import rehypeKatex from "rehype-katex";
import "katex/dist/katex.min.css";
import { Trash2 } from "lucide-react";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import nanmoLogo from "@/assets/nanmo-logo.png";

type Msg = { role: "user" | "assistant"; content: string };

export function ChatMessage({
  msg,
  avatarUrl,
  userName,
  botAvatar,
  botName,
  onDelete,
}: {
  msg: Msg;
  avatarUrl?: string | null;
  userName?: string;
  botAvatar?: string;
  botName?: string;
  onDelete?: () => void;
}) {
  const aiAvatar = botAvatar || nanmoLogo;
  const aiName = botName || "NanmoAI";
  const deleteBtn = onDelete && (
    <button
      onClick={() => { if (confirm("删除这条消息？")) onDelete(); }}
      className="self-center md:opacity-0 md:group-hover:opacity-100 opacity-60 transition-opacity text-muted-foreground hover:text-destructive p-1 shrink-0"
      aria-label="删除消息"
    >
      <Trash2 className="h-3.5 w-3.5" />
    </button>
  );
  return (
    <div className={`group flex gap-3 ${msg.role === "user" ? "justify-end" : "justify-start"}`}>
      {msg.role === "assistant" && (
        <Avatar className="h-7 w-7 shrink-0 mt-0.5">
          <AvatarImage src={aiAvatar} alt={aiName} className="object-contain bg-white p-0.5" />
          <AvatarFallback className="bg-primary/10 text-primary text-xs">AI</AvatarFallback>
        </Avatar>
      )}
      {msg.role === "user" && deleteBtn}
      <div
        className={`max-w-[75%] rounded-2xl px-4 py-2.5 text-sm leading-relaxed ${
          msg.role === "user"
            ? "bg-primary text-primary-foreground rounded-br-md whitespace-pre-wrap"
            : "bg-muted/50 text-foreground rounded-bl-md"
        }`}
      >
        {msg.role === "assistant" ? (
          <div className="prose prose-sm dark:prose-invert max-w-none prose-p:my-1.5 prose-ul:my-1 prose-ol:my-1 prose-li:my-0.5 prose-headings:my-2 prose-pre:my-2 prose-code:text-xs prose-blockquote:my-2">
            <ReactMarkdown remarkPlugins={[remarkMath]} rehypePlugins={[rehypeKatex]}>
              {msg.content}
            </ReactMarkdown>
          </div>
        ) : (
          msg.content
        )}
      </div>
      {msg.role === "assistant" && deleteBtn}
      {msg.role === "user" && (
        <Avatar className="h-7 w-7 shrink-0 mt-0.5">
          <AvatarImage src={avatarUrl || undefined} alt={userName || "User"} />
          <AvatarFallback className="bg-primary/20 text-primary text-xs">
            {userName?.charAt(0) || "U"}
          </AvatarFallback>
        </Avatar>
      )}
    </div>
  );
}
