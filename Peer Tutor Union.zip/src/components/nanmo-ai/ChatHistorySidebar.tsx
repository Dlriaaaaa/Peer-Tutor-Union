import { MessageSquare, Plus, Trash2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { ScrollArea } from "@/components/ui/scroll-area";
import { cn } from "@/lib/utils";

type ChatRecord = {
  id: string;
  title: string;
  updated_at: string;
};

export function ChatHistorySidebar({
  chats,
  activeChatId,
  onSelect,
  onNew,
  onDelete,
}: {
  chats: ChatRecord[];
  activeChatId: string | null;
  onSelect: (id: string) => void;
  onNew: () => void;
  onDelete: (id: string) => void;
}) {
  return (
    <div className="w-56 shrink-0 flex flex-col border-r border-border/40 bg-card/20">
      <div className="p-3">
        <Button onClick={onNew} variant="outline" size="sm" className="w-full gap-1.5 text-xs">
          <Plus className="h-3.5 w-3.5" /> 新对话
        </Button>
      </div>
      <ScrollArea className="flex-1 px-2 pb-2">
        <div className="space-y-0.5">
          {chats.map((c) => (
            <div
              key={c.id}
              className={cn(
                "group flex items-center gap-2 rounded-lg px-2.5 py-2 cursor-pointer text-xs transition-colors",
                activeChatId === c.id
                  ? "bg-primary/10 text-foreground"
                  : "text-muted-foreground hover:bg-muted/50 hover:text-foreground"
              )}
              onClick={() => onSelect(c.id)}
            >
              <MessageSquare className="h-3.5 w-3.5 shrink-0" />
              <span className="truncate flex-1">{c.title}</span>
              <button
                onClick={(e) => {
                  e.stopPropagation();
                  if (confirm(`删除对话 "${c.title}"？`)) onDelete(c.id);
                }}
                className="md:opacity-0 md:group-hover:opacity-100 opacity-60 transition-opacity text-muted-foreground hover:text-destructive p-1 -m-1"
                aria-label="删除对话"
              >
                <Trash2 className="h-3.5 w-3.5" />
              </button>
            </div>
          ))}
          {chats.length === 0 && (
            <p className="text-xs text-muted-foreground/60 text-center py-8">暂无对话记录</p>
          )}
        </div>
      </ScrollArea>
    </div>
  );
}
