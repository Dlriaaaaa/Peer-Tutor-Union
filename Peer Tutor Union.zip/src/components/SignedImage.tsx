import { useSignedUrl } from "@/hooks/useSignedUrl";

/**
 * Image component that auto-resolves storage paths to signed URLs.
 */
export default function SignedImage({
  storagePath,
  alt = "",
  className = "",
  loading,
}: {
  storagePath: string | null | undefined;
  alt?: string;
  className?: string;
  loading?: "lazy" | "eager";
}) {
  const url = useSignedUrl(storagePath);
  if (!url) return null;
  return <img src={url} alt={alt} className={className} loading={loading} />;
}
