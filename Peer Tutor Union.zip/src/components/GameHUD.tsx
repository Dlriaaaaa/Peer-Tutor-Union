/**
 * GameHUD — Displays game state info: inning, count, score, bases, log, pitch info.
 */

import type { GameState, Pitch, PitchType } from "@/game/types";

interface GameHUDProps {
  state: GameState;
  lastPitch: Pitch | null;
  /** Latest result description for commentary */
  lastResult?: string;
}

const PITCH_LABELS: Record<PitchType, { name: string; emoji: string }> = {
  fastball: { name: "Fastball", emoji: "🔥" },
  curveball: { name: "Curveball", emoji: "🌀" },
  slider: { name: "Slider", emoji: "💨" },
  changeup: { name: "Changeup", emoji: "🐢" },
};

export default function GameHUD({ state, lastPitch, lastResult }: GameHUDProps) {
  const halfLabel = state.half === "top" ? "▲" : "▼";
  const recentLogs = state.log.slice(-6);

  return (
    <div className="flex flex-col gap-1 w-full max-w-[800px] text-xs">
      {/* Top bar: Inning + Score */}
      <div className="flex items-center justify-between bg-card rounded px-3 py-1 border border-border">
        {/* Inning */}
        <div className="flex items-center gap-2">
          <span className="text-[10px] font-medium text-muted-foreground">INN</span>
          <span className="text-sm font-bold">
            {halfLabel} {state.inning}
          </span>
        </div>

        {/* Score */}
        <div className="flex gap-4 text-center">
          <div>
            <div className="text-[9px] text-muted-foreground font-semibold">AWAY</div>
            <div className="text-lg font-bold tabular-nums">{state.score.away}</div>
          </div>
          <div className="text-muted-foreground self-center text-lg">–</div>
          <div>
            <div className="text-[9px] text-muted-foreground font-semibold">HOME</div>
            <div className="text-lg font-bold tabular-nums">{state.score.home}</div>
          </div>
        </div>

        {/* Status */}
        <div className="text-xs">
          {state.status === "over" ? (
            <span className="text-yellow-400 font-bold">
              FINAL — {state.winner === "home" ? "Home" : "Away"} Wins!
            </span>
          ) : (
            <span className="text-green-400">● LIVE</span>
          )}
        </div>
      </div>

      {/* Count + Bases + Outs + Pitch Info */}
      <div className="flex items-center justify-between bg-card rounded px-3 py-1 border border-border">
        {/* Count */}
        <div className="flex gap-4">
          <CountDisplay label="B" count={state.count.balls} max={3} color="text-green-400" />
          <CountDisplay label="S" count={state.count.strikes} max={2} color="text-yellow-400" />
          <CountDisplay label="O" count={state.outs} max={2} color="text-red-400" />
        </div>

        {/* Diamond base indicator */}
        <BaseDiamond bases={state.bases} />

        {/* Last pitch info */}
        <div className="text-right text-xs min-w-[140px]">
          {lastPitch ? (
            <>
              <div className="font-semibold">
                {PITCH_LABELS[lastPitch.type].emoji} {PITCH_LABELS[lastPitch.type].name}
              </div>
              <div className="text-muted-foreground">
                {lastPitch.speed.toFixed(0)} mph · Zone ({lastPitch.location.x.toFixed(1)}, {lastPitch.location.y.toFixed(1)})
              </div>
            </>
          ) : (
            <span className="text-muted-foreground">Awaiting pitch…</span>
          )}
        </div>
      </div>

      {/* Latest result callout */}
      {lastResult && (
        <div className="bg-primary/10 border border-primary/30 rounded px-3 py-1 text-xs font-medium text-center">
          {lastResult}
        </div>
      )}

      {/* Play Log */}
      <div className="bg-card rounded px-3 py-1 border border-border max-h-[60px] overflow-y-auto">
        <div className="text-[9px] text-muted-foreground font-semibold mb-0.5">PLAY LOG</div>
        {recentLogs.length === 0 ? (
          <div className="text-xs text-muted-foreground italic">Game starting…</div>
        ) : (
          recentLogs.map((log, i) => (
            <div
              key={i}
              className={`text-xs py-0.5 ${
                i === recentLogs.length - 1 ? "text-foreground font-medium" : "text-muted-foreground"
              }`}
            >
              {log}
            </div>
          ))
        )}
      </div>
    </div>
  );
}

// ─── Sub-components ──────────────────────────────────────

function CountDisplay({
  label,
  count,
  max,
  color,
}: {
  label: string;
  count: number;
  max: number;
  color: string;
}) {
  return (
    <div className="flex items-center gap-1.5">
      <span className="text-xs font-bold text-muted-foreground">{label}</span>
      <div className="flex gap-0.5">
        {Array.from({ length: max + 1 }, (_, i) => (
          <div
            key={i}
            className={`w-2.5 h-2.5 rounded-full border ${
              i < count ? `${color} bg-current border-current` : "border-muted-foreground/40"
            }`}
          />
        ))}
      </div>
    </div>
  );
}

function BaseDiamond({ bases }: { bases: GameState["bases"] }) {
  const baseStyle = (occupied: boolean) =>
    `w-4 h-4 rotate-45 border-2 ${
      occupied
        ? "bg-yellow-400 border-yellow-500"
        : "bg-muted/30 border-muted-foreground/30"
    }`;

  return (
    <div className="relative w-12 h-12 flex-shrink-0">
      {/* 2nd base (top) */}
      <div className={`${baseStyle(bases[2])} absolute top-0 left-1/2 -translate-x-1/2`} />
      {/* 3rd base (left) */}
      <div className={`${baseStyle(bases[3])} absolute top-1/2 left-0 -translate-y-1/2`} />
      {/* 1st base (right) */}
      <div className={`${baseStyle(bases[1])} absolute top-1/2 right-0 -translate-y-1/2`} />
      {/* Home (bottom, smaller) */}
      <div className="w-3 h-3 rotate-45 border border-muted-foreground/50 bg-muted/20 absolute bottom-0 left-1/2 -translate-x-1/2" />
    </div>
  );
}
