import { useState, useEffect } from "react";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { toast } from "sonner";
import { Plus, Trash2, ImagePlus, X, Check } from "lucide-react";
import SignedImage from "@/components/SignedImage";

type Question = {
  id: string;
  quiz_id: string;
  question_text: string;
  question_type: string;
  image_url: string | null;
  points: number;
  sort_order: number;
  correct_answer: string | null;
};

type Option = {
  id: string;
  question_id: string;
  option_text: string;
  is_correct: boolean;
  sort_order: number;
};

export default function QuestionEditor({ quizId }: { quizId: string }) {
  const [questions, setQuestions] = useState<Question[]>([]);
  const [options, setOptions] = useState<Record<string, Option[]>>({});
  const [newType, setNewType] = useState("multiple_choice");
  const [newText, setNewText] = useState("");
  const [newPoints, setNewPoints] = useState("1");
  const [newCorrectAnswer, setNewCorrectAnswer] = useState("");
  const [uploading, setUploading] = useState(false);

  const fetchQuestions = async () => {
    const { data: qs } = await supabase.from("quiz_questions").select("*").eq("quiz_id", quizId).order("sort_order");
    setQuestions(qs || []);
    if (qs && qs.length > 0) {
      const { data: opts } = await supabase.from("quiz_options").select("*").in("question_id", qs.map(q => q.id)).order("sort_order");
      const grouped: Record<string, Option[]> = {};
      (opts || []).forEach(o => {
        if (!grouped[o.question_id]) grouped[o.question_id] = [];
        grouped[o.question_id].push(o);
      });
      setOptions(grouped);
    }
  };

  useEffect(() => { fetchQuestions(); }, [quizId]);

  const addQuestion = async () => {
    if (!newText.trim()) return;
    const { error } = await supabase.from("quiz_questions").insert({
      quiz_id: quizId,
      question_text: newText,
      question_type: newType,
      points: Number(newPoints) || 1,
      sort_order: questions.length,
      correct_answer: newType === "fill_blank" ? newCorrectAnswer : null,
    });
    if (error) { toast.error(error.message); return; }
    setNewText(""); setNewCorrectAnswer(""); setNewPoints("1");
    fetchQuestions();
  };

  const deleteQuestion = async (id: string) => {
    await supabase.from("quiz_questions").delete().eq("id", id);
    toast.success("Question deleted");
    fetchQuestions();
  };

  const uploadQuestionImage = async (questionId: string, file: File) => {
    setUploading(true);
    const path = `quizzes/${quizId}/${questionId}/${file.name}`;
    const { error } = await supabase.storage.from("attachments").upload(path, file, { upsert: true });
    if (error) { toast.error(error.message); setUploading(false); return; }
    await supabase.from("quiz_questions").update({ image_url: path }).eq("id", questionId);
    setUploading(false);
    fetchQuestions();
  };

  const removeQuestionImage = async (questionId: string) => {
    await supabase.from("quiz_questions").update({ image_url: null }).eq("id", questionId);
    fetchQuestions();
  };

  const typeLabel = (t: string) => {
    if (t === "multiple_choice") return "Multiple Choice";
    if (t === "multiple_select") return "Multiple Select";
    return "Fill in Blank";
  };

  return (
    <div className="space-y-4">
      {questions.map((q, idx) => (
        <div key={q.id} className="rounded-xl border bg-muted/20 p-4 space-y-3">
          <div className="flex items-start justify-between">
            <div className="flex-1">
              <div className="flex items-center gap-2 mb-1">
                <Badge variant="outline" className="text-xs">{typeLabel(q.question_type)}</Badge>
                <span className="text-xs text-muted-foreground">{q.points} pt{q.points > 1 ? "s" : ""}</span>
              </div>
              <p className="font-medium text-foreground">Q{idx + 1}. {q.question_text}</p>
            </div>
            <div className="flex items-center gap-1">
              <label className="cursor-pointer">
                <input type="file" accept="image/*" className="hidden" onChange={(e) => {
                  const f = e.target.files?.[0];
                  if (f) uploadQuestionImage(q.id, f);
                }} />
                <div className="h-8 w-8 flex items-center justify-center rounded-md hover:bg-accent text-muted-foreground">
                  <ImagePlus className="h-4 w-4" />
                </div>
              </label>
              <Button variant="ghost" size="icon" className="h-8 w-8" onClick={() => deleteQuestion(q.id)}>
                <Trash2 className="h-4 w-4 text-destructive" />
              </Button>
            </div>
          </div>

          {q.image_url && (
            <div className="relative inline-block">
              <SignedImage storagePath={q.image_url} alt="Question" className="max-h-40 rounded-lg border" />
              <button onClick={() => removeQuestionImage(q.id)} className="absolute -top-2 -right-2 bg-destructive text-destructive-foreground rounded-full p-0.5">
                <X className="h-3 w-3" />
              </button>
            </div>
          )}

          {(q.question_type === "multiple_choice" || q.question_type === "multiple_select") && (
            <OptionEditor questionId={q.id} options={options[q.id] || []} onRefresh={fetchQuestions} />
          )}
          {q.question_type === "fill_blank" && (
            <p className="text-sm text-muted-foreground">Correct answer: <span className="font-medium text-foreground">{q.correct_answer || "—"}</span></p>
          )}
        </div>
      ))}

      {/* Add new question */}
      <div className="rounded-xl border-2 border-dashed p-4 space-y-3">
        <div className="grid gap-3 md:grid-cols-3">
          <div>
            <Label className="text-xs">Type</Label>
            <Select value={newType} onValueChange={setNewType}>
              <SelectTrigger><SelectValue /></SelectTrigger>
              <SelectContent>
                <SelectItem value="multiple_choice">Multiple Choice</SelectItem>
                <SelectItem value="multiple_select">Multiple Select</SelectItem>
                <SelectItem value="fill_blank">Fill in Blank</SelectItem>
              </SelectContent>
            </Select>
          </div>
          <div className="md:col-span-2">
            <Label className="text-xs">Question</Label>
            <Input value={newText} onChange={(e) => setNewText(e.target.value)} placeholder="Enter question text..." />
          </div>
        </div>
        <div className="grid gap-3 md:grid-cols-3">
          <div>
            <Label className="text-xs">Points</Label>
            <Input type="number" value={newPoints} onChange={(e) => setNewPoints(e.target.value)} min="1" />
          </div>
          {newType === "fill_blank" && (
            <div className="md:col-span-2">
              <Label className="text-xs">Correct Answer</Label>
              <Input value={newCorrectAnswer} onChange={(e) => setNewCorrectAnswer(e.target.value)} placeholder="Expected answer" />
            </div>
          )}
        </div>
        <Button size="sm" onClick={addQuestion} disabled={!newText.trim()}>
          <Plus className="h-4 w-4 mr-1" /> Add Question
        </Button>
      </div>
    </div>
  );
}

function OptionEditor({ questionId, options, onRefresh }: { questionId: string; options: { id: string; option_text: string; is_correct: boolean; sort_order: number }[]; onRefresh: () => void }) {
  const [newOption, setNewOption] = useState("");
  const [newIsCorrect, setNewIsCorrect] = useState(false);

  const addOption = async () => {
    if (!newOption.trim()) return;
    const { error } = await supabase.from("quiz_options").insert({
      question_id: questionId,
      option_text: newOption,
      is_correct: newIsCorrect,
      sort_order: options.length,
    });
    if (error) { toast.error(error.message); return; }
    setNewOption(""); setNewIsCorrect(false);
    onRefresh();
  };

  const deleteOption = async (id: string) => {
    await supabase.from("quiz_options").delete().eq("id", id);
    onRefresh();
  };

  const toggleCorrect = async (opt: { id: string; is_correct: boolean }) => {
    await supabase.from("quiz_options").update({ is_correct: !opt.is_correct }).eq("id", opt.id);
    onRefresh();
  };

  return (
    <div className="space-y-2 pl-4">
      {options.map((opt, i) => (
        <div key={opt.id} className="flex items-center gap-2 text-sm">
          <button onClick={() => toggleCorrect(opt)} className={`h-5 w-5 rounded-full border-2 flex items-center justify-center transition-colors ${opt.is_correct ? 'border-primary bg-primary text-primary-foreground' : 'border-muted-foreground/40'}`}>
            {opt.is_correct && <Check className="h-3 w-3" />}
          </button>
          <span className={opt.is_correct ? "font-medium text-foreground" : "text-muted-foreground"}>
            {String.fromCharCode(65 + i)}. {opt.option_text}
          </span>
          <Button variant="ghost" size="icon" className="h-6 w-6 ml-auto" onClick={() => deleteOption(opt.id)}>
            <X className="h-3 w-3" />
          </Button>
        </div>
      ))}
      <div className="flex items-center gap-2">
        <input type="checkbox" checked={newIsCorrect} onChange={(e) => setNewIsCorrect(e.target.checked)} className="rounded border-muted-foreground/40" />
        <Input value={newOption} onChange={(e) => setNewOption(e.target.value)} placeholder="Add option..." className="h-8 text-sm flex-1"
          onKeyDown={(e) => { if (e.key === "Enter") { e.preventDefault(); addOption(); } }}
        />
        <Button size="sm" variant="ghost" onClick={addOption} disabled={!newOption.trim()}>
          <Plus className="h-3 w-3" />
        </Button>
      </div>
    </div>
  );
}
