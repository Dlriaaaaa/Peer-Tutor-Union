import { useState, useEffect } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/contexts/AuthContext";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Switch } from "@/components/ui/switch";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { toast } from "sonner";
import { Plus, Trash2, ImagePlus, X, Check, Eye, Users, RefreshCw, BarChart3, ArrowDownToLine } from "lucide-react";
import QuizAttemptsList from "./QuizAttemptsList";

type Quiz = {
  id: string;
  title: string;
  description: string;
  category: string;
  time_limit_minutes: number | null;
  is_published: boolean;
  allow_retake: boolean;
  results_published: boolean;
  created_at: string;
};

export default function QuizTab() {
  const { user } = useAuth();
  const [quizzes, setQuizzes] = useState<Quiz[]>([]);
  const [viewingAttempts, setViewingAttempts] = useState<string | null>(null);
  const [title, setTitle] = useState("");
  const [description, setDescription] = useState("");
  const [category, setCategory] = useState("General");
  const [timeLimit, setTimeLimit] = useState("");
  const [loading, setLoading] = useState(false);

  const fetchQuizzes = async () => {
    const { data } = await supabase.from("quizzes").select("*").order("created_at", { ascending: false });
    setQuizzes((data as Quiz[]) || []);
  };

  useEffect(() => { fetchQuizzes(); }, []);

  const handleCreate = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user) return;
    setLoading(true);
    const { error } = await supabase.from("quizzes").insert({
      title, description, category,
      time_limit_minutes: timeLimit ? Number(timeLimit) : null,
      created_by: user.id,
    });
    if (error) { toast.error(error.message); setLoading(false); return; }
    toast.success("Quiz created");
    setTitle(""); setDescription(""); setTimeLimit("");
    fetchQuizzes();
    setLoading(false);
  };

  const togglePublish = async (quiz: Quiz) => {
    await supabase.from("quizzes").update({ is_published: !quiz.is_published }).eq("id", quiz.id);
    toast.success(quiz.is_published ? "Quiz unpublished" : "Quiz published");
    fetchQuizzes();
  };

  const toggleRetake = async (quiz: Quiz) => {
    await supabase.from("quizzes").update({ allow_retake: !quiz.allow_retake }).eq("id", quiz.id);
    toast.success(quiz.allow_retake ? "Retake disabled" : "Retake enabled");
    fetchQuizzes();
  };

  const toggleResultsPublished = async (quiz: Quiz) => {
    await supabase.from("quizzes").update({ results_published: !quiz.results_published }).eq("id", quiz.id);
    toast.success(quiz.results_published ? "Results hidden" : "Results published");
    fetchQuizzes();
  };

  const deleteQuiz = async (id: string) => {
    await supabase.from("quizzes").delete().eq("id", id);
    toast.success("Quiz deleted");
    fetchQuizzes();
  };

  const syncToGrades = async (quiz: Quiz) => {
    try {
      // 1. Find or create "Quizzes" grade category
      let { data: cats } = await supabase.from("grade_categories").select("*").eq("name", "Quizzes").limit(1);
      let categoryId: string;
      if (cats && cats.length > 0) {
        categoryId = cats[0].id;
      } else {
        const { data: newCat, error: catErr } = await supabase.from("grade_categories").insert({ name: "Quizzes", weight: 20 }).select().single();
        if (catErr || !newCat) { toast.error("Failed to create category"); return; }
        categoryId = newCat.id;
      }

      // 2. Find or create assignment for this quiz
      const assignmentName = `Quiz: ${quiz.title}`;
      let { data: existingAss } = await supabase.from("assignments").select("*").eq("name", assignmentName).eq("category_id", categoryId).limit(1);
      let assignmentId: string;

      // Get total points from quiz questions
      const { data: qs } = await supabase.from("quiz_questions").select("points").eq("quiz_id", quiz.id);
      const totalPoints = (qs || []).reduce((sum, q) => sum + q.points, 0) || 100;

      if (existingAss && existingAss.length > 0) {
        assignmentId = existingAss[0].id;
        await supabase.from("assignments").update({ max_score: totalPoints }).eq("id", assignmentId);
      } else {
        const { data: newAss, error: assErr } = await supabase.from("assignments").insert({ name: assignmentName, max_score: totalPoints, category_id: categoryId }).select().single();
        if (assErr || !newAss) { toast.error("Failed to create assignment"); return; }
        assignmentId = newAss.id;
      }

      // 3. Sync all completed attempts as scores
      const { data: attempts } = await supabase.from("quiz_attempts").select("*").eq("quiz_id", quiz.id).not("completed_at", "is", null);
      if (!attempts || attempts.length === 0) { toast.info("No completed attempts to sync"); return; }

      let synced = 0;
      for (const att of attempts) {
        const { error } = await supabase.from("scores").upsert(
          { student_id: att.student_id, assignment_id: assignmentId, score: att.score ?? 0 },
          { onConflict: "student_id,assignment_id" }
        );
        if (!error) synced++;
      }
      toast.success(`Synced ${synced} scores to Grades`);
    } catch (err) {
      toast.error("Sync failed");
    }
  };

  return (
    <div className="space-y-6 mt-4">
      <Card className="glass-card">
        <CardHeader>
          <CardTitle>Create Quiz</CardTitle>
          <CardDescription>Create a new quiz for students to take</CardDescription>
        </CardHeader>
        <CardContent>
          <form onSubmit={handleCreate} className="grid gap-4 md:grid-cols-2">
            <div><Label>Title</Label><Input value={title} onChange={(e) => setTitle(e.target.value)} required placeholder="e.g. Business Ethics Quiz 1" /></div>
            <div><Label>Category</Label><Input value={category} onChange={(e) => setCategory(e.target.value)} placeholder="General" /></div>
            <div className="md:col-span-2"><Label>Description</Label><Textarea value={description} onChange={(e) => setDescription(e.target.value)} rows={2} placeholder="Brief description..." /></div>
            <div><Label>Time Limit (minutes, optional)</Label><Input type="number" value={timeLimit} onChange={(e) => setTimeLimit(e.target.value)} placeholder="No limit" /></div>
            <div className="flex items-end">
              <Button type="submit" disabled={loading}><Plus className="h-4 w-4 mr-1" /> {loading ? "Creating..." : "Create Quiz"}</Button>
            </div>
          </form>
        </CardContent>
      </Card>

      {quizzes.map((quiz) => (
        <Card key={quiz.id} className="glass-card overflow-hidden">
          <CardHeader className="flex flex-row items-start justify-between gap-4">
            <div className="flex-1 min-w-0">
              <CardTitle className="text-lg">{quiz.title}</CardTitle>
              <CardDescription className="mt-1">{quiz.description}</CardDescription>
              <div className="flex items-center gap-2 mt-3 flex-wrap">
                <Badge variant={quiz.is_published ? "default" : "secondary"}>
                  {quiz.is_published ? "Published" : "Draft"}
                </Badge>
                {quiz.allow_retake && <Badge variant="outline" className="text-xs">Retake Allowed</Badge>}
                {quiz.results_published && <Badge variant="outline" className="text-xs text-green-600">Results Visible</Badge>}
              </div>
            </div>
            <div className="flex items-center gap-1.5 shrink-0 flex-wrap">
              <Button variant="outline" size="sm" onClick={() => togglePublish(quiz)}>
                {quiz.is_published ? "Unpublish" : "Publish"}
              </Button>
              <Button variant="outline" size="sm" onClick={() => toggleResultsPublished(quiz)} title="Toggle results visibility">
                <Eye className="h-4 w-4 mr-1" /> {quiz.results_published ? "Hide Results" : "Show Results"}
              </Button>
              <Button variant="outline" size="sm" onClick={() => toggleRetake(quiz)} title="Toggle retake">
                <RefreshCw className="h-4 w-4 mr-1" /> {quiz.allow_retake ? "No Retake" : "Allow Retake"}
              </Button>
              <Button variant="outline" size="sm" onClick={() => setViewingAttempts(viewingAttempts === quiz.id ? null : quiz.id)}>
                <Users className="h-4 w-4 mr-1" /> Attempts
              </Button>
              <Button variant="outline" size="sm" onClick={() => syncToGrades(quiz)} title="Sync scores to Grades">
                <ArrowDownToLine className="h-4 w-4 mr-1" /> Sync Grades
              </Button>
              <Button variant="ghost" size="icon" onClick={() => deleteQuiz(quiz.id)}>
                <Trash2 className="h-4 w-4 text-destructive" />
              </Button>
            </div>
          </CardHeader>
          {viewingAttempts === quiz.id && (
            <CardContent className="border-t pt-4">
              <QuizAttemptsList quizId={quiz.id} />
            </CardContent>
          )}
        </Card>
      ))}
    </div>
  );
}
