import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { toast } from "sonner";
import { GripVertical, Trash2, Save } from "lucide-react";
import {
  DndContext, closestCenter, PointerSensor, useSensor, useSensors, DragEndEvent,
} from "@dnd-kit/core";
import { SortableContext, arrayMove, useSortable, verticalListSortingStrategy } from "@dnd-kit/sortable";
import { CSS } from "@dnd-kit/utilities";
import QuestionBankBrowser from "@/components/questions/QuestionBankBrowser";
import DifficultyStars from "@/components/questions/DifficultyStars";
import { Question, questionLabel, questionOptions } from "@/lib/questionBank";

type PaperItem = { question_id: string; section: string; question: Question | null };

function Row({ item, index, onSection, onRemove }: {
  item: PaperItem; index: number; onSection: (s: string) => void; onRemove: () => void;
}) {
  const { attributes, listeners, setNodeRef, transform, transition, isDragging } = useSortable({ id: item.question_id });
  return (
    <div ref={setNodeRef}
      style={{ transform: CSS.Transform.toString(transform), transition, opacity: isDragging ? 0.5 : 1 }}
      className="flex items-center gap-2 rounded-xl border bg-muted/10 p-2">
      <button {...attributes} {...listeners} className="cursor-grab text-muted-foreground"><GripVertical className="h-4 w-4" /></button>
      <span className="text-sm font-semibold w-6">{index + 1}</span>
      <div className="flex-1 min-w-0">
        <p className="truncate text-sm">{item.question ? questionLabel(item.question) : "Question"}</p>
        <div className="flex items-center gap-2">
          <Badge variant="outline" className="text-[10px]">{item.question?.question_type.toUpperCase()}</Badge>
          {item.question && <DifficultyStars level={item.question.difficulty} />}
        </div>
      </div>
      <Select value={item.section} onValueChange={onSection}>
        <SelectTrigger className="w-40 h-8 text-xs"><SelectValue /></SelectTrigger>
        <SelectContent>
          <SelectItem value="Section A">Section A</SelectItem>
          <SelectItem value="Section B">Section B</SelectItem>
          <SelectItem value="Section C">Section C</SelectItem>
        </SelectContent>
      </Select>
      <Button variant="ghost" size="icon" className="h-8 w-8" onClick={onRemove}><Trash2 className="h-4 w-4 text-destructive" /></Button>
    </div>
  );
}

export default function QuizAssembly() {
  const [quizzes, setQuizzes] = useState<any[]>([]);
  const [quizId, setQuizId] = useState("");
  const [items, setItems] = useState<PaperItem[]>([]);
  const [timeLimit, setTimeLimit] = useState("");
  const [passing, setPassing] = useState("");
  const [saving, setSaving] = useState(false);
  const sensors = useSensors(useSensor(PointerSensor, { activationConstraint: { distance: 4 } }));

  useEffect(() => {
    supabase.from("quizzes").select("id, title, time_limit_minutes, passing_score").order("created_at", { ascending: false })
      .then(({ data }) => setQuizzes(data || []));
  }, []);

  useEffect(() => {
    if (!quizId) { setItems([]); return; }
    const load = async () => {
      const quiz = quizzes.find((q) => q.id === quizId);
      setTimeLimit(quiz?.time_limit_minutes ? String(quiz.time_limit_minutes) : "");
      setPassing(quiz?.passing_score != null ? String(quiz.passing_score) : "");
      const { data } = await supabase.from("quiz_paper_questions").select("*").eq("quiz_id", quizId).order("sort_order");
      const rows = data || [];
      let qs: any[] = [];
      if (rows.length) {
        const res = await supabase.from("questions").select("*").in("id", rows.map((r: any) => r.question_id));
        qs = res.data || [];
      }
      setItems(rows.map((r: any) => ({ question_id: r.question_id, section: r.section, question: qs.find((q) => q.id === r.question_id) || null })));
    };
    load();
    // eslint-disable-next-line
  }, [quizId]);

  const toggle = (q: Question) => {
    setItems((prev) => prev.some((i) => i.question_id === q.id)
      ? prev.filter((i) => i.question_id !== q.id)
      : [...prev, { question_id: q.id, section: q.question_type === "frq" ? "Section B" : "Section A", question: q }]);
  };

  const onDragEnd = (e: DragEndEvent) => {
    const { active, over } = e;
    if (!over || active.id === over.id) return;
    setItems((prev) => arrayMove(prev, prev.findIndex((i) => i.question_id === active.id), prev.findIndex((i) => i.question_id === over.id)));
  };

  /**
   * Saves the paper and mirrors the chosen bank questions into the quiz so students
   * can take it with the existing quiz player. MCQ keeps its options and answer key;
   * FRQ becomes a written response that a teacher grades manually.
   */
  const save = async () => {
    if (!quizId) { toast.error("Select a quiz first"); return; }
    setSaving(true);
    await supabase.from("quiz_paper_questions").delete().eq("quiz_id", quizId);
    if (items.length) {
      const { error } = await supabase.from("quiz_paper_questions").insert(
        items.map((i, idx) => ({ quiz_id: quizId, question_id: i.question_id, section: i.section, sort_order: idx }))
      );
      if (error) { toast.error(error.message); setSaving(false); return; }
    }

    // Rebuild the playable question list from the bank selection
    await supabase.from("quiz_questions").delete().eq("quiz_id", quizId);
    for (let idx = 0; idx < items.length; idx++) {
      const q = items[idx].question;
      if (!q) continue;
      const isMcq = q.question_type === "mcq";
      const { data: inserted, error: qErr } = await supabase.from("quiz_questions").insert({
        quiz_id: quizId,
        question_text: questionLabel(q),
        question_type: isMcq ? "multiple_choice" : "short_answer",
        points: Math.round(Number(q.max_points) || 1),
        sort_order: idx,
        correct_answer: null,
      }).select("id").single();
      if (qErr || !inserted) { toast.error(qErr?.message || "Could not build the paper"); setSaving(false); return; }
      if (isMcq) {
        const rows = questionOptions(q).map(({ letter, text }, i) => ({
          question_id: inserted.id,
          option_text: text,
          is_correct: q.correct_option === letter,
          sort_order: i,
        })).filter((r) => !!r.option_text);
        if (rows.length) await supabase.from("quiz_options").insert(rows);
      }
    }

    await supabase.from("quizzes").update({
      time_limit_minutes: timeLimit ? Number(timeLimit) : null,
      passing_score: passing ? Number(passing) : null,
    }).eq("id", quizId);
    setSaving(false);
    toast.success("Quiz paper saved");
  };

  return (
    <div className="space-y-5">
      <div className="grid gap-3 sm:grid-cols-3">
        <div>
          <Label className="text-xs">Quiz</Label>
          <Select value={quizId} onValueChange={setQuizId}>
            <SelectTrigger><SelectValue placeholder="Select a quiz" /></SelectTrigger>
            <SelectContent>
              {quizzes.map((q) => <SelectItem key={q.id} value={q.id}>{q.title}</SelectItem>)}
            </SelectContent>
          </Select>
        </div>
        <div>
          <Label className="text-xs">Time limit (minutes)</Label>
          <Input type="number" min="1" value={timeLimit} onChange={(e) => setTimeLimit(e.target.value)} />
        </div>
        <div>
          <Label className="text-xs">Passing score</Label>
          <Input type="number" min="0" value={passing} onChange={(e) => setPassing(e.target.value)} />
        </div>
      </div>

      {quizId && (
        <>
          <div className="space-y-2">
            <p className="text-sm font-medium">Paper ({items.length} questions) — drag to reorder</p>
            <DndContext sensors={sensors} collisionDetection={closestCenter} onDragEnd={onDragEnd}>
              <SortableContext items={items.map((i) => i.question_id)} strategy={verticalListSortingStrategy}>
                <div className="space-y-2">
                  {items.map((item, i) => (
                    <Row key={item.question_id} item={item} index={i}
                      onSection={(s) => setItems(items.map((x) => x.question_id === item.question_id ? { ...x, section: s } : x))}
                      onRemove={() => setItems(items.filter((x) => x.question_id !== item.question_id))} />
                  ))}
                </div>
              </SortableContext>
            </DndContext>
            {items.length === 0 && <p className="text-sm text-muted-foreground">Pick questions from the bank below.</p>}
            <Button size="sm" className="gap-2" onClick={save} disabled={saving}><Save className="h-4 w-4" /> Save paper</Button>
          </div>

          <div className="pt-2 border-t">
            <p className="text-sm font-medium py-3">Question bank</p>
            <QuestionBankBrowser selectable selectedIds={items.map((i) => i.question_id)} onToggleSelect={toggle} />
          </div>
        </>
      )}
    </div>
  );
}
