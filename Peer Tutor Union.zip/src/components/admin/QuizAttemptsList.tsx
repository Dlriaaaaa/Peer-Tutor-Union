import { useState, useEffect } from "react";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { toast } from "sonner";
import { Eye, Check, X, BarChart3 } from "lucide-react";
import SignedImage from "@/components/SignedImage";
import { format } from "date-fns";

type Attempt = {
  id: string;
  student_id: string;
  quiz_id: string;
  score: number | null;
  total_points: number | null;
  completed_at: string | null;
  created_at: string;
  student_name?: string;
};

type Answer = {
  id: string;
  question_id: string;
  selected_option_id: string | null;
  selected_option_ids: string[] | null;
  text_answer: string | null;
  is_correct: boolean | null;
};

type Question = {
  id: string;
  question_text: string;
  question_type: string;
  correct_answer: string | null;
  points: number;
  image_url: string | null;
};

type Option = {
  id: string;
  question_id: string;
  option_text: string;
  is_correct: boolean;
};

export default function QuizAttemptsList({ quizId }: { quizId: string }) {
  const [attempts, setAttempts] = useState<Attempt[]>([]);
  const [viewingAttempt, setViewingAttempt] = useState<Attempt | null>(null);
  const [answers, setAnswers] = useState<Answer[]>([]);
  const [questions, setQuestions] = useState<Question[]>([]);
  const [options, setOptions] = useState<Record<string, Option[]>>({});
  const [loading, setLoading] = useState(true);

  const fetchAttempts = async () => {
    const { data: att } = await supabase
      .from("quiz_attempts")
      .select("*")
      .eq("quiz_id", quizId)
      .order("created_at", { ascending: false });

    if (att && att.length > 0) {
      const studentIds = [...new Set(att.map(a => a.student_id))];
      const { data: profiles } = await supabase
        .from("profiles")
        .select("user_id, name")
        .in("user_id", studentIds);
      const nameMap = new Map(profiles?.map(p => [p.user_id, p.name]) || []);
      setAttempts(att.map(a => ({ ...a, student_name: nameMap.get(a.student_id) || "Unknown" })));
    } else {
      setAttempts([]);
    }
    setLoading(false);
  };

  useEffect(() => { fetchAttempts(); }, [quizId]);

  const viewAttemptDetail = async (attempt: Attempt) => {
    setViewingAttempt(attempt);
    const [{ data: ans }, { data: qs }] = await Promise.all([
      supabase.from("quiz_answers").select("*").eq("attempt_id", attempt.id),
      supabase.from("quiz_questions").select("*").eq("quiz_id", quizId).order("sort_order"),
    ]);
    setAnswers((ans as Answer[]) || []);
    setQuestions(qs || []);
    if (qs && qs.length > 0) {
      const { data: opts } = await supabase.from("quiz_options").select("*").in("question_id", qs.map(q => q.id));
      const grouped: Record<string, Option[]> = {};
      (opts || []).forEach(o => {
        if (!grouped[o.question_id]) grouped[o.question_id] = [];
        grouped[o.question_id].push(o);
      });
      setOptions(grouped);
    }
  };

  const syncToGrades = async (attempt: Attempt) => {
    if (attempt.score === null) { toast.error("No score to sync"); return; }
    // We'll insert score info as a toast message for now — actual grade sync would need assignment mapping
    toast.success(`Score ${attempt.score}/${attempt.total_points} ready to sync. Create a grade assignment to map this quiz.`);
  };

  if (loading) return <p className="text-sm text-muted-foreground py-4">Loading attempts...</p>;

  return (
    <div className="space-y-4">
      <h4 className="text-sm font-semibold text-foreground flex items-center gap-2">
        <BarChart3 className="h-4 w-4" /> Student Attempts ({attempts.length})
      </h4>

      {attempts.length === 0 ? (
        <p className="text-sm text-muted-foreground">No attempts yet.</p>
      ) : (
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Student</TableHead>
              <TableHead>Status</TableHead>
              <TableHead>Score</TableHead>
              <TableHead>Started</TableHead>
              <TableHead className="w-24">Actions</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {attempts.map((att) => {
              const pct = att.score !== null && att.total_points ? Math.round((att.score / att.total_points) * 100) : null;
              return (
                <TableRow key={att.id}>
                  <TableCell className="font-medium">{att.student_name}</TableCell>
                  <TableCell>
                    {att.completed_at ? (
                      <Badge variant="default" className="text-xs">Completed</Badge>
                    ) : (
                      <Badge variant="secondary" className="text-xs">In Progress</Badge>
                    )}
                  </TableCell>
                  <TableCell>
                    {att.completed_at && pct !== null ? (
                      <span className={`font-semibold ${pct >= 80 ? 'text-green-600' : pct >= 60 ? 'text-yellow-600' : 'text-destructive'}`}>
                        {att.score}/{att.total_points} ({pct}%)
                      </span>
                    ) : "—"}
                  </TableCell>
                  <TableCell className="text-sm text-muted-foreground">
                    {format(new Date(att.created_at), "MMM d, HH:mm")}
                  </TableCell>
                  <TableCell>
                    <Button variant="outline" size="sm" onClick={() => viewAttemptDetail(att)}>
                      <Eye className="h-3.5 w-3.5 mr-1" /> View
                    </Button>
                  </TableCell>
                </TableRow>
              );
            })}
          </TableBody>
        </Table>
      )}

      {/* Detail Dialog */}
      <Dialog open={!!viewingAttempt} onOpenChange={() => setViewingAttempt(null)}>
        <DialogContent className="max-w-2xl max-h-[80vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>
              {viewingAttempt?.student_name}'s Answers
              {viewingAttempt?.score !== null && viewingAttempt?.total_points && (
                <Badge className="ml-2" variant="outline">
                  {viewingAttempt.score}/{viewingAttempt.total_points}
                </Badge>
              )}
            </DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            {questions.map((q, i) => {
              const ans = answers.find(a => a.question_id === q.id);
              const qOpts = options[q.id] || [];
              return (
                <div key={q.id} className="rounded-xl border p-4 space-y-2">
                  <div className="flex items-start justify-between">
                    <p className="font-medium text-sm">Q{i + 1}. {q.question_text} <span className="text-muted-foreground">({q.points}pts)</span></p>
                    {ans?.is_correct ? (
                      <Check className="h-5 w-5 text-green-500 shrink-0" />
                    ) : (
                      <X className="h-5 w-5 text-destructive shrink-0" />
                    )}
                  </div>
                  {q.image_url && <SignedImage storagePath={q.image_url} className="max-h-32 rounded-lg" />}
                  {(q.question_type === "multiple_choice" || q.question_type === "multiple_select") ? (
                    <div className="space-y-1">
                      {qOpts.map(o => {
                        const isSelected = ans?.selected_option_id === o.id ||
                          (ans?.selected_option_ids && ans.selected_option_ids.includes(o.id));
                        return (
                          <div key={o.id} className={`text-sm px-3 py-1.5 rounded-lg ${
                            o.is_correct ? 'bg-green-500/10 text-green-700 dark:text-green-400 font-medium' :
                            isSelected && !o.is_correct ? 'bg-destructive/10 text-destructive line-through' :
                            'text-muted-foreground'
                          }`}>
                            {isSelected && "→ "}{o.option_text}
                          </div>
                        );
                      })}
                    </div>
                  ) : (
                    <div className="text-sm">
                      <span className="text-muted-foreground">Answer: </span>
                      <span className={ans?.is_correct ? "text-green-600 font-medium" : "text-destructive"}>
                        {ans?.text_answer || "—"}
                      </span>
                      {!ans?.is_correct && q.correct_answer && (
                        <span className="text-muted-foreground"> → Correct: <span className="text-green-600">{q.correct_answer}</span></span>
                      )}
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}
