import { useEditor, EditorContent } from "@tiptap/react";
import StarterKit from "@tiptap/starter-kit";
import Link from "@tiptap/extension-link";
import { Bold, Italic, List, ListOrdered, Quote, Heading2, Link as LinkIcon, Undo, Redo, Hash, AtSign } from "lucide-react";
import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";
import { useState, useEffect, useRef, useCallback } from "react";
import { supabase } from "@/integrations/supabase/client";

interface RichTextEditorProps {
  content: string;
  onChange: (html: string) => void;
  placeholder?: string;
}

type UserSuggestion = { user_id: string; name: string; avatar_url: string | null };

export default function RichTextEditor({ content, onChange, placeholder }: RichTextEditorProps) {
  const [mentionQuery, setMentionQuery] = useState<string | null>(null);
  const [mentionUsers, setMentionUsers] = useState<UserSuggestion[]>([]);
  const [mentionIndex, setMentionIndex] = useState(0);
  const [allUsers, setAllUsers] = useState<UserSuggestion[]>([]);
  const [tagQuery, setTagQuery] = useState<string | null>(null);
  const [tagSuggestions, setTagSuggestions] = useState<string[]>([]);
  const [tagIndex, setTagIndex] = useState(0);
  const [popularTags, setPopularTags] = useState<string[]>([]);
  const mentionRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    supabase.from("profiles").select("user_id, name, avatar_url").then(({ data }) => {
      setAllUsers((data as UserSuggestion[]) || []);
    });
    // Fetch popular tags (most used recently, top 20 for filtering)
    supabase
      .from("post_tags")
      .select("tag")
      .order("created_at", { ascending: false })
      .limit(200)
      .then(({ data }) => {
        if (!data) return;
        const counts: Record<string, number> = {};
        data.forEach((r) => { counts[r.tag] = (counts[r.tag] || 0) + 1; });
        const sorted = Object.entries(counts)
          .sort((a, b) => b[1] - a[1])
          .map(([tag]) => tag);
        setPopularTags(sorted.slice(0, 20));
      });
  }, []);

  const editor = useEditor({
    extensions: [
      StarterKit,
      Link.configure({ openOnClick: false }),
    ],
    content,
    onUpdate: ({ editor }) => {
      const html = editor.getHTML();
      onChange(html);
      checkForMention(editor);
      checkForTag(editor);
    },
    editorProps: {
      attributes: {
        class: "tiptap",
        ...(placeholder ? { "data-placeholder": placeholder } : {}),
      },
      handleKeyDown: (_view, event) => {
        // Tag suggestions
        if (tagQuery !== null && tagSuggestions.length > 0) {
          if (event.key === "ArrowDown") {
            event.preventDefault();
            setTagIndex((prev) => Math.min(prev + 1, tagSuggestions.length - 1));
            return true;
          }
          if (event.key === "ArrowUp") {
            event.preventDefault();
            setTagIndex((prev) => Math.max(prev - 1, 0));
            return true;
          }
          if (event.key === "Enter" || event.key === "Tab") {
            event.preventDefault();
            insertTag(tagSuggestions[tagIndex]);
            return true;
          }
          if (event.key === "Escape") {
            setTagQuery(null);
            return true;
          }
        }
        if (mentionQuery !== null) {
          if (event.key === "ArrowDown") {
            event.preventDefault();
            setMentionIndex((prev) => Math.min(prev + 1, mentionUsers.length - 1));
            return true;
          }
          if (event.key === "ArrowUp") {
            event.preventDefault();
            setMentionIndex((prev) => Math.max(prev - 1, 0));
            return true;
          }
          if (event.key === "Enter" || event.key === "Tab") {
            if (mentionUsers.length > 0) {
              event.preventDefault();
              insertMention(mentionUsers[mentionIndex]);
              return true;
            }
          }
          if (event.key === "Escape") {
            setMentionQuery(null);
            return true;
          }
        }
        return false;
      },
    },
  });

  const checkForMention = useCallback((ed: any) => {
    const { state } = ed;
    const { from } = state.selection;
    const textBefore = state.doc.textBetween(Math.max(0, from - 30), from, " ");
    const atMatch = textBefore.match(/@([\w\u4e00-\u9fff]*)$/);
    if (atMatch) {
      const query = atMatch[1].toLowerCase();
      setMentionQuery(query);
      setMentionIndex(0);
      const filtered = allUsers
        .filter((u) => u.name.toLowerCase().includes(query))
        .slice(0, 6);
      setMentionUsers(filtered);
    } else {
      setMentionQuery(null);
    }
  }, [allUsers]);

  const checkForTag = useCallback((ed: any) => {
    const { state } = ed;
    const { from } = state.selection;
    const textBefore = state.doc.textBetween(Math.max(0, from - 30), from, " ");
    const hashMatch = textBefore.match(/#([\w\u4e00-\u9fff]*)$/);
    if (hashMatch) {
      const query = hashMatch[1].toLowerCase();
      setTagQuery(query);
      setTagIndex(0);
      const filtered = popularTags
        .filter((t) => t.toLowerCase().includes(query))
        .slice(0, 5);
      setTagSuggestions(filtered);
    } else {
      setTagQuery(null);
    }
  }, [popularTags]);

  const insertMention = useCallback((user: UserSuggestion) => {
    if (!editor) return;
    const { state } = editor;
    const { from } = state.selection;
    const textBefore = state.doc.textBetween(Math.max(0, from - 30), from, " ");
    const atMatch = textBefore.match(/@([\w\u4e00-\u9fff]*)$/);
    if (atMatch) {
      const deleteFrom = from - atMatch[0].length;
      editor.chain().focus()
        .deleteRange({ from: deleteFrom, to: from })
        .insertContent(`@${user.name} `)
        .run();
    }
    setMentionQuery(null);
  }, [editor]);

  const insertTag = useCallback((tag: string) => {
    if (!editor) return;
    const { state } = editor;
    const { from } = state.selection;
    const textBefore = state.doc.textBetween(Math.max(0, from - 30), from, " ");
    const hashMatch = textBefore.match(/#([\w\u4e00-\u9fff]*)$/);
    if (hashMatch) {
      const deleteFrom = from - hashMatch[0].length;
      editor.chain().focus()
        .deleteRange({ from: deleteFrom, to: from })
        .insertContent(`#${tag} `)
        .run();
    }
    setTagQuery(null);
  }, [editor]);

  if (!editor) return null;

  const ToolBtn = ({ onClick, active, children, title }: { onClick: () => void; active?: boolean; children: React.ReactNode; title?: string }) => (
    <Button type="button" variant="ghost" size="icon" className={cn("h-8 w-8", active && "bg-muted")} onClick={onClick} title={title}>
      {children}
    </Button>
  );

  const insertHashtag = () => {
    editor.chain().focus().insertContent("#").run();
  };

  const insertAt = () => {
    editor.chain().focus().insertContent("@").run();
    // Trigger mention check
    setTimeout(() => checkForMention(editor), 50);
  };

  return (
    <div className="border border-input rounded-md overflow-hidden relative">
      <div className="flex items-center gap-0.5 p-1 border-b bg-muted/30 flex-wrap">
        <ToolBtn onClick={() => editor.chain().focus().toggleBold().run()} active={editor.isActive("bold")}><Bold className="h-4 w-4" /></ToolBtn>
        <ToolBtn onClick={() => editor.chain().focus().toggleItalic().run()} active={editor.isActive("italic")}><Italic className="h-4 w-4" /></ToolBtn>
        <ToolBtn onClick={() => editor.chain().focus().toggleHeading({ level: 2 }).run()} active={editor.isActive("heading")}><Heading2 className="h-4 w-4" /></ToolBtn>
        <ToolBtn onClick={() => editor.chain().focus().toggleBulletList().run()} active={editor.isActive("bulletList")}><List className="h-4 w-4" /></ToolBtn>
        <ToolBtn onClick={() => editor.chain().focus().toggleOrderedList().run()} active={editor.isActive("orderedList")}><ListOrdered className="h-4 w-4" /></ToolBtn>
        <ToolBtn onClick={() => editor.chain().focus().toggleBlockquote().run()} active={editor.isActive("blockquote")}><Quote className="h-4 w-4" /></ToolBtn>
        <ToolBtn onClick={() => {
          const url = window.prompt("URL");
          if (url) editor.chain().focus().setLink({ href: url }).run();
        }} active={editor.isActive("link")}><LinkIcon className="h-4 w-4" /></ToolBtn>
        <div className="w-px h-5 bg-border mx-0.5" />
        <ToolBtn onClick={insertHashtag} title="Insert #hashtag"><Hash className="h-4 w-4 text-primary" /></ToolBtn>
        <ToolBtn onClick={insertAt} title="Insert @mention"><AtSign className="h-4 w-4 text-primary" /></ToolBtn>
        <div className="w-px h-5 bg-border mx-0.5" />
        <ToolBtn onClick={() => editor.chain().focus().undo().run()}><Undo className="h-4 w-4" /></ToolBtn>
        <ToolBtn onClick={() => editor.chain().focus().redo().run()}><Redo className="h-4 w-4" /></ToolBtn>
      </div>
      <EditorContent editor={editor} />

      {/* Mention suggestion dropdown */}
      {mentionQuery !== null && mentionUsers.length > 0 && (
        <div
          ref={mentionRef}
          className="absolute z-50 bg-popover border border-border rounded-lg shadow-lg py-1 w-56 max-h-48 overflow-y-auto"
          style={{ bottom: "100%", left: 8, marginBottom: 4 }}
        >
          {mentionUsers.map((user, idx) => (
            <button
              key={user.user_id}
              className={cn(
                "w-full flex items-center gap-2 px-3 py-2 text-sm text-left hover:bg-muted transition-colors",
                idx === mentionIndex && "bg-muted"
              )}
              onMouseDown={(e) => { e.preventDefault(); insertMention(user); }}
            >
              <div className="h-6 w-6 rounded-full bg-muted-foreground/20 flex items-center justify-center text-xs font-medium overflow-hidden shrink-0">
                {user.avatar_url ? (
                  <img src={user.avatar_url} className="h-full w-full object-cover" alt="" />
                ) : (
                  user.name.charAt(0)
                )}
              </div>
              <span className="truncate">{user.name}</span>
            </button>
          ))}
        </div>
      )}

      {/* Tag suggestion dropdown */}
      {tagQuery !== null && tagSuggestions.length > 0 && (
        <div
          className="absolute z-50 bg-popover border border-border rounded-lg shadow-lg py-1 w-48 max-h-48 overflow-y-auto"
          style={{ bottom: "100%", left: 8, marginBottom: 4 }}
        >
          {tagSuggestions.map((tag, idx) => (
            <button
              key={tag}
              className={cn(
                "w-full flex items-center gap-2 px-3 py-2 text-sm text-left hover:bg-muted transition-colors",
                idx === tagIndex && "bg-muted"
              )}
              onMouseDown={(e) => { e.preventDefault(); insertTag(tag); }}
            >
              <Hash className="h-3.5 w-3.5 text-primary shrink-0" />
              <span className="truncate">{tag}</span>
            </button>
          ))}
        </div>
      )}
    </div>
  );
}
