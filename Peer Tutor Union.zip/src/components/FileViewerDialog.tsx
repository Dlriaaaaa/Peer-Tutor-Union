import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { useSignedUrl } from "@/hooks/useSignedUrl";
import { Download, ExternalLink, FileX } from "lucide-react";

interface Props {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  fileUrl: string;
  fileName: string;
  title: string;
}

function getViewerType(fileName: string): "pdf" | "image" | "office" | "text" | "unsupported" {
  const ext = fileName.split(".").pop()?.toLowerCase() || "";
  if (ext === "pdf") return "pdf";
  if (["png", "jpg", "jpeg", "gif", "webp", "svg"].includes(ext)) return "image";
  if (["doc", "docx", "ppt", "pptx", "xls", "xlsx"].includes(ext)) return "office";
  if (["txt", "md", "csv", "json", "log"].includes(ext)) return "text";
  return "unsupported";
}

export default function FileViewerDialog({ open, onOpenChange, fileUrl, fileName, title }: Props) {
  const signedUrl = useSignedUrl(open ? fileUrl : null);
  const viewerType = getViewerType(fileName);

  // Office Online viewer requires a publicly-fetchable URL — signed URLs work
  const officeUrl = signedUrl
    ? `https://view.officeapps.live.com/op/embed.aspx?src=${encodeURIComponent(signedUrl)}`
    : "";

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-5xl w-[95vw] h-[90vh] flex flex-col p-0 gap-0">
        <DialogHeader className="px-6 py-4 border-b shrink-0">
          <div className="flex items-center justify-between gap-4">
            <DialogTitle className="truncate text-base">{title}</DialogTitle>
            <div className="flex items-center gap-2 shrink-0">
              {signedUrl && (
                <>
                  <Button asChild size="sm" variant="outline">
                    <a href={signedUrl} target="_blank" rel="noopener noreferrer">
                      <ExternalLink className="h-3.5 w-3.5 mr-1" /> Open
                    </a>
                  </Button>
                  <Button asChild size="sm" variant="outline">
                    <a href={signedUrl} download={fileName}>
                      <Download className="h-3.5 w-3.5 mr-1" /> Download
                    </a>
                  </Button>
                </>
              )}
            </div>
          </div>
        </DialogHeader>

        <div className="flex-1 overflow-hidden bg-muted/30">
          {!signedUrl ? (
            <div className="flex items-center justify-center h-full text-muted-foreground">Loading...</div>
          ) : viewerType === "pdf" ? (
            <iframe src={signedUrl} className="w-full h-full border-0" title={fileName} />
          ) : viewerType === "image" ? (
            <div className="flex items-center justify-center h-full p-4 overflow-auto">
              <img src={signedUrl} alt={fileName} className="max-w-full max-h-full object-contain" />
            </div>
          ) : viewerType === "office" ? (
            <iframe src={officeUrl} className="w-full h-full border-0" title={fileName} />
          ) : viewerType === "text" ? (
            <iframe src={signedUrl} className="w-full h-full border-0 bg-background" title={fileName} />
          ) : (
            <div className="flex flex-col items-center justify-center h-full text-muted-foreground gap-3">
              <FileX className="h-12 w-12 opacity-40" />
              <p>Preview not supported for this file type</p>
              <Button asChild variant="outline" size="sm">
                <a href={signedUrl} download={fileName}><Download className="h-4 w-4 mr-1" /> Download to view</a>
              </Button>
            </div>
          )}
        </div>
      </DialogContent>
    </Dialog>
  );
}
