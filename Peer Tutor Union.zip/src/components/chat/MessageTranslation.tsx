import { useState } from "react";
import { Languages, Loader2 } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";

interface Props {
  content: string;
  isMine: boolean;
}

export default function MessageTranslation({ content, isMine }: Props) {
  const [translation, setTranslation] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);
  const [visible, setVisible] = useState(false);

  const translate = async () => {
    if (translation) {
      setVisible(!visible);
      return;
    }
    setLoading(true);
    setVisible(true);
    try {
      // Detect: if mostly CJK → translate to English, else → translate to Chinese
      const cjkRatio = (content.match(/[\u4e00-\u9fff\u3400-\u4dbf\uac00-\ud7af\u3040-\u309f\u30a0-\u30ff]/g) || []).length / content.length;
      const direction = cjkRatio > 0.3 ? "zh2en" : "en2zh";

      const { data, error } = await supabase.functions.invoke("translate", {
        body: { text: content, direction },
      });
      if (error) throw error;
      setTranslation(data?.translation || "Translation failed");
    } catch {
      setTranslation("Translation failed");
    } finally {
      setLoading(false);
    }
  };

  return (
    <>
      <button
        onClick={translate}
        className={`flex items-center gap-1 text-[10px] mt-0.5 px-1 transition-colors ${
          isMine ? "text-primary-foreground/60 hover:text-primary-foreground/90" : "text-muted-foreground hover:text-foreground"
        }`}
      >
        <Languages className="h-3 w-3" />
        {visible ? "Hide" : "Translate"}
      </button>
      {visible && (
        <div className={`mt-1 pt-1 border-t border-dashed text-sm leading-relaxed ${
          isMine ? "border-primary-foreground/20 text-primary-foreground/80" : "border-border text-primary/80"
        }`}>
          {loading ? (
            <Loader2 className="h-3 w-3 animate-spin inline" />
          ) : (
            translation
          )}
        </div>
      )}
    </>
  );
}
