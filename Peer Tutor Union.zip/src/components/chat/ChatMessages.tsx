import { useRef, useEffect, useState } from "react";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Badge } from "@/components/ui/badge";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { ContextMenu, ContextMenuContent, ContextMenuItem, ContextMenuTrigger } from "@/components/ui/context-menu";
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu";
import { Send, Eye, MessageCircle, MoreHorizontal, Hand, AtSign, FileText, ExternalLink, Undo2, Bot } from "lucide-react";
import MessageTranslation from "./MessageTranslation";
import { format } from "date-fns";
import { useNavigate } from "react-router-dom";
import { Message, ProfileMap, Conversation } from "./types";
import { supabase } from "@/integrations/supabase/client";
import { resolvePostsAttachments } from "@/lib/attachmentUtils";
import SignedImage from "@/components/SignedImage";
import StickerPicker from "./StickerPicker";
import PostDetailDialog from "@/components/posts/PostDetailDialog";
import StudyGroupInviteCard, { parseStudyGroupInvite } from "@/components/tutoring/StudyGroupInviteCard";

type PostType = {
  id: string; title: string; content: string; created_at: string; author_id: string;
  post_attachments: { id: string; file_url: string; file_name: string }[];
};

interface ChatMessagesProps {
  conversation: Conversation | null;
  messages: Message[];
  profiles: ProfileMap;
  userId: string;
  isMonitoring: boolean;
  newMsg: string;
  setNewMsg: (v: string) => void;
  onSend: (content?: string) => void;
  onRecallMessage?: (messageId: string) => void;
  displayName: string;
  memberCount: number;
  onToggleInfo?: () => void;
  isGroup?: boolean;
  activeMembers?: { user_id: string; name: string }[];
  botEnabled?: boolean;
  onAddBot?: (personaId: string) => void;
  botPersonas?: { id: string; name: string; avatar_url: string | null }[];
  botPersonaMap?: Record<string, { name: string; avatar_url: string | null }>;
  convBotPersonas?: { name: string; avatar_url: string | null }[];
  convBotIds?: string[];
}

const BOT_USER_ID = "00000000-0000-0000-0000-00000000000b";

export default function ChatMessages({
  conversation, messages, profiles, userId,
  isMonitoring, newMsg, setNewMsg, onSend, onRecallMessage,
  displayName, memberCount, onToggleInfo, isGroup,
  activeMembers = [], onAddBot, botPersonas = [], botPersonaMap = {}, convBotPersonas = [], convBotIds = [],
}: ChatMessagesProps) {
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLInputElement>(null);
  const navigate = useNavigate();
  const [showMentions, setShowMentions] = useState(false);
  const [mentionFilter, setMentionFilter] = useState("");
  const [sharedPostDetail, setSharedPostDetail] = useState<PostType | null>(null);
  // Poke dialog
  const [pokeTarget, setPokeTarget] = useState<{ userId: string; name: string } | null>(null);
  const [pokeSuffix, setPokeSuffix] = useState("");

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages]);

  const parseSharedPost = (content: string) => {
    const match = content.match(/^\[SharedPost:([a-f0-9-]+):(.*?)\]\s*(.*)$/);
    if (match) return { postId: match[1], thumb: match[2], title: match[3] };
    const legacy = content.match(/^\[Shared Post\]\s*(.*)/s);
    if (legacy) return { postId: null, thumb: "", title: legacy[1].split("\n")[0] };
    return null;
  };

  const openSharedPost = async (postId: string) => {
    const { data } = await supabase.from("posts").select("*, post_attachments(*)").eq("id", postId).single();
    if (data) {
      const [resolvedPost] = await resolvePostsAttachments([data as unknown as PostType]);
      setSharedPostDetail(resolvedPost);
    }
  };

  const handleInputChange = (val: string) => {
    setNewMsg(val);
    const lastAt = val.lastIndexOf("@");
    if (lastAt >= 0) {
      const afterAt = val.slice(lastAt + 1);
      if (!afterAt.includes(" ") && afterAt.length <= 20) {
        setMentionFilter(afterAt.toLowerCase());
        setShowMentions(true);
        return;
      }
    }
    setShowMentions(false);
  };

  const insertMention = (name: string) => {
    const lastAt = newMsg.lastIndexOf("@");
    const before = newMsg.slice(0, lastAt);
    setNewMsg(`${before}@${name} `);
    setShowMentions(false);
    inputRef.current?.focus();
  };

  const filteredMentions = activeMembers.filter(m =>
    m.name.toLowerCase().includes(mentionFilter)
  );

  const openPokeDialog = (targetUserId: string) => {
    const targetName = profiles[targetUserId]?.name || "Unknown";
    setPokeTarget({ userId: targetUserId, name: targetName });
    setPokeSuffix("");
  };

  const sendPoke = () => {
    if (!pokeTarget) return;
    const myName = profiles[userId]?.name || "Me";
    const suffix = pokeSuffix.trim() ? ` ${pokeSuffix.trim()}` : "";
    onSend(`[Poke] ${myName} poked ${pokeTarget.name}${suffix}`);
    setPokeTarget(null);
    setPokeSuffix("");
  };

  const isPokeMessage = (content: string) => content.startsWith("[Poke]");
  const isStickerMessage = (content: string) => content.startsWith("[Sticker]");

  if (!conversation) {
    return (
      <div className="flex-1 flex items-center justify-center bg-muted/20">
        <div className="text-center text-muted-foreground animate-fade-in">
          <MessageCircle className="h-16 w-16 mx-auto mb-4 opacity-20" />
          <p className="text-lg">Select a chat</p>
          <p className="text-sm mt-1">or start a new conversation</p>
        </div>
      </div>
    );
  }

  const groupedByDate: { date: string; msgs: Message[] }[] = [];
  messages.forEach((msg) => {
    const dateStr = format(new Date(msg.created_at), "yyyy-MM-dd");
    const last = groupedByDate[groupedByDate.length - 1];
    if (last && last.date === dateStr) { last.msgs.push(msg); } else { groupedByDate.push({ date: dateStr, msgs: [msg] }); }
  });

  const renderContent = (content: string) => {
    const parts = content.split(/(@\S+)/g);
    return parts.map((part, i) => {
      if (part.startsWith("@")) return <span key={i} className="text-primary font-medium">{part}</span>;
      return part;
    });
  };

  return (
    <div className="flex-1 flex flex-col bg-[hsl(var(--muted)/0.3)] h-full">
      {/* Header */}
      <div className="px-4 py-3 border-b border-border bg-card flex items-center justify-between">
        <div>
          <h3 className="text-base font-semibold text-foreground">
            {displayName}
            {conversation.is_group && <span className="text-muted-foreground font-normal"> ({memberCount})</span>}
          </h3>
          {isMonitoring && (
            <Badge variant="secondary" className="text-[10px] mt-0.5"><Eye className="h-3 w-3 mr-1" />Monitor Mode</Badge>
          )}
        </div>
        <div className="flex items-center gap-1">
          {onAddBot && botPersonas.filter(p => !convBotIds.includes(p.id)).length > 0 && (
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button size="icon" variant="ghost" className="h-8 w-8" title="添加 Bot">
                  <Bot className="h-4 w-4" />
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end">
                  {botPersonas.filter(p => !convBotIds.includes(p.id)).map(p => (
                    <DropdownMenuItem key={p.id} onClick={() => onAddBot(p.id)}>
                      <Avatar className="h-5 w-5 mr-2">
                        <AvatarImage src={p.avatar_url || undefined} />
                        <AvatarFallback className="text-[8px]"><Bot className="h-3 w-3" /></AvatarFallback>
                      </Avatar>
                      {p.name}
                    </DropdownMenuItem>
                  ))}
              </DropdownMenuContent>
            </DropdownMenu>
          )}
          {onToggleInfo && (
            <Button size="icon" variant="ghost" className="h-8 w-8" onClick={onToggleInfo}><MoreHorizontal className="h-5 w-5" /></Button>
          )}
        </div>
      </div>

      {/* Messages */}
      <ScrollArea className="flex-1 px-4 py-2">
        {groupedByDate.map((group) => (
          <div key={group.date}>
            <div className="flex justify-center my-3">
              <span className="text-[11px] text-muted-foreground bg-muted/80 px-3 py-0.5 rounded-full">
                {format(new Date(group.date), "MMM dd, yyyy")}
              </span>
            </div>
            {group.msgs.map((msg, idx) => {
              const isBot = msg.sender_id === BOT_USER_ID;
              const isMine = msg.sender_id === userId;
              const botDisplay = isBot && (msg as any).bot_persona_id && botPersonaMap[(msg as any).bot_persona_id]
                ? botPersonaMap[(msg as any).bot_persona_id]
                : { name: "PTC Bot", avatar_url: null };
              const sender = isBot ? botDisplay : profiles[msg.sender_id];

              // Poke message
              if (isPokeMessage(msg.content)) {
                return (
                  <div key={msg.id} className="flex justify-center my-2 animate-fade-in" style={{ animationDelay: `${idx * 20}ms` }}>
                    <span className="text-xs text-muted-foreground bg-muted/50 px-3 py-1 rounded-full flex items-center gap-1">
                      <Hand className="h-3 w-3" />{msg.content.replace("[Poke] ", "")}
                    </span>
                  </div>
                );
              }

              // Sticker message
              if (isStickerMessage(msg.content)) {
                const stickerUrl = msg.content.replace("[Sticker]", "");
                return (
                  <div key={msg.id} className={`flex gap-2 mb-4 ${isMine ? "flex-row-reverse" : ""} animate-fade-in`}
                    style={{ animationDelay: `${idx * 20}ms` }}>
                    <Avatar className="h-9 w-9 shrink-0 mt-1 cursor-pointer" onClick={() => !isMine && navigate(`/profile/${msg.sender_id}`)}>
                      <AvatarImage src={sender?.avatar_url || undefined} />
                      <AvatarFallback className="text-xs">{sender?.name?.charAt(0) || "?"}</AvatarFallback>
                    </Avatar>
                    <div className={`max-w-[200px] ${isMine ? "items-end" : "items-start"} flex flex-col`}>
                      {!isMine && <p className="text-xs text-muted-foreground mb-1 px-1">{sender?.name || "Unknown"}</p>}
                      <img src={stickerUrl} alt="sticker" className="rounded-lg max-w-[150px] max-h-[150px] object-contain" />
                      <p className={`text-[10px] text-muted-foreground mt-1 px-1 ${isMine ? "text-right" : ""}`}>
                        {format(new Date(msg.created_at), "HH:mm")}
                      </p>
                    </div>
                  </div>
                );
              }

              const invite = parseStudyGroupInvite(msg.content);
              if (invite) {
                return (
                  <div key={msg.id} className={`flex gap-2 mb-4 ${isMine ? "flex-row-reverse" : ""} animate-fade-in`}
                    style={{ animationDelay: `${idx * 20}ms` }}>
                    <Avatar className="h-9 w-9 shrink-0 mt-1 cursor-pointer" onClick={() => !isMine && navigate(`/profile/${msg.sender_id}`)}>
                      <AvatarImage src={sender?.avatar_url || undefined} />
                      <AvatarFallback className="text-xs">{sender?.name?.charAt(0) || "?"}</AvatarFallback>
                    </Avatar>
                    <div className={`max-w-[65%] ${isMine ? "items-end" : "items-start"} flex flex-col`}>
                      {!isMine && <p className="text-xs text-muted-foreground mb-1 px-1">{sender?.name || "Unknown"}</p>}
                      <StudyGroupInviteCard groupId={invite.groupId} />
                      <p className={`text-[10px] text-muted-foreground mt-1 px-1 ${isMine ? "text-right" : ""}`}>
                        {format(new Date(msg.created_at), "HH:mm")}
                      </p>
                    </div>
                  </div>
                );
              }

              const shared = parseSharedPost(msg.content);
              if (shared) {
                return (
                  <div key={msg.id} className={`flex gap-2 mb-4 ${isMine ? "flex-row-reverse" : ""} animate-fade-in`}
                    style={{ animationDelay: `${idx * 20}ms` }}>
                    <Avatar className="h-9 w-9 shrink-0 mt-1 cursor-pointer" onClick={() => !isMine && navigate(`/profile/${msg.sender_id}`)}>
                      <AvatarImage src={sender?.avatar_url || undefined} />
                      <AvatarFallback className="text-xs">{sender?.name?.charAt(0) || "?"}</AvatarFallback>
                    </Avatar>
                    <div className={`max-w-[65%] ${isMine ? "items-end" : "items-start"} flex flex-col`}>
                      {!isMine && <p className="text-xs text-muted-foreground mb-1 px-1">{sender?.name || "Unknown"}</p>}
                      <button onClick={() => shared.postId && openSharedPost(shared.postId)}
                        className="rounded-lg overflow-hidden border border-border bg-card shadow-sm hover:shadow-md transition-shadow text-left w-full max-w-[240px]">
                         {shared.thumb && <SignedImage storagePath={shared.thumb} alt="Shared post" className="w-full h-32 object-cover" loading="lazy" />}
                        <div className="p-2.5">
                          <p className="text-xs text-muted-foreground flex items-center gap-1 mb-1"><ExternalLink className="h-3 w-3" /> Shared Post</p>
                          <p className="text-sm font-medium text-foreground line-clamp-2">{shared.title}</p>
                        </div>
                      </button>
                      <p className={`text-[10px] text-muted-foreground mt-1 px-1 ${isMine ? "text-right" : ""}`}>
                        {format(new Date(msg.created_at), "HH:mm")}
                      </p>
                    </div>
                  </div>
                );
              }

              return (
                <div key={msg.id} className={`flex gap-2 mb-4 ${isMine ? "flex-row-reverse" : ""} animate-fade-in`}
                  style={{ animationDelay: `${idx * 20}ms` }}>
                  {isBot ? (
                    <Avatar className="h-9 w-9 shrink-0 mt-1">
                      <AvatarImage src={botDisplay.avatar_url || undefined} />
                      <AvatarFallback className="text-xs bg-primary/20 text-primary"><Bot className="h-4 w-4" /></AvatarFallback>
                    </Avatar>
                  ) : (
                    <ContextMenu>
                      <ContextMenuTrigger>
                        <Avatar className="h-9 w-9 shrink-0 mt-1 cursor-pointer transition-transform duration-200 hover:scale-105"
                          onClick={() => navigate(`/profile/${msg.sender_id}`)}>
                          <AvatarImage src={sender?.avatar_url || undefined} />
                          <AvatarFallback className="text-xs">{sender?.name?.charAt(0) || "?"}</AvatarFallback>
                        </Avatar>
                      </ContextMenuTrigger>
                      <ContextMenuContent>
                        {!isMine && (
                          <>
                            <ContextMenuItem onClick={() => openPokeDialog(msg.sender_id)}>
                              <Hand className="h-4 w-4 mr-2" /> Poke
                            </ContextMenuItem>
                            <ContextMenuItem onClick={() => {
                              setNewMsg(`${newMsg}@${sender?.name || "Unknown"} `);
                              inputRef.current?.focus();
                            }}>
                              <AtSign className="h-4 w-4 mr-2" /> @{sender?.name}
                            </ContextMenuItem>
                          </>
                        )}
                        {isMine && onRecallMessage && (
                          <ContextMenuItem onClick={() => onRecallMessage(msg.id)}>
                            <Undo2 className="h-4 w-4 mr-2" /> Recall
                          </ContextMenuItem>
                        )}
                      </ContextMenuContent>
                    </ContextMenu>
                  )}
                  <div className={`max-w-[65%] ${isMine ? "items-end" : "items-start"} flex flex-col`}>
                    {!isMine && <p className="text-xs text-muted-foreground mb-1 px-1">{isBot ? botDisplay.name : (sender?.name || "Unknown")}</p>}
                    <ContextMenu>
                      <ContextMenuTrigger>
                        <div className={`px-3 py-2 rounded-lg text-sm leading-relaxed break-all overflow-hidden transition-all duration-200
                          ${isMine
                            ? "bg-[hsl(var(--success))] text-[hsl(var(--success-foreground))] rounded-tr-sm"
                            : isBot
                              ? "bg-primary/10 text-foreground rounded-tl-sm shadow-sm border border-primary/20"
                              : "bg-card text-foreground rounded-tl-sm shadow-sm"
                          }`}>
                          {renderContent(msg.content)}
                          <MessageTranslation content={msg.content} isMine={isMine} />
                        </div>
                      </ContextMenuTrigger>
                      <ContextMenuContent>
                        {isMine && onRecallMessage && (
                          <ContextMenuItem onClick={() => onRecallMessage(msg.id)}><Undo2 className="h-4 w-4 mr-2" /> Recall</ContextMenuItem>
                        )}
                        {!isMine && !isBot && (
                          <>
                            <ContextMenuItem onClick={() => openPokeDialog(msg.sender_id)}><Hand className="h-4 w-4 mr-2" /> Poke</ContextMenuItem>
                            <ContextMenuItem onClick={() => {
                              setNewMsg(`${newMsg}@${sender?.name || "Unknown"} `);
                              inputRef.current?.focus();
                            }}><AtSign className="h-4 w-4 mr-2" /> @{sender?.name}</ContextMenuItem>
                          </>
                        )}
                      </ContextMenuContent>
                    </ContextMenu>
                    <p className={`text-[10px] text-muted-foreground mt-1 px-1 ${isMine ? "text-right" : ""}`}>
                      {format(new Date(msg.created_at), "HH:mm")}
                    </p>
                  </div>
                </div>
              );
            })}
          </div>
        ))}
        <div ref={messagesEndRef} />
      </ScrollArea>

      {/* Input */}
      {isMonitoring ? (
        <div className="p-3 border-t border-border text-center text-sm text-muted-foreground bg-muted/30">
          <Eye className="h-4 w-4 inline mr-1" /> Monitor Mode — view only
        </div>
      ) : (
        <div className="border-t border-border bg-card p-3 relative">
          {showMentions && filteredMentions.length > 0 && (
            <div className="absolute bottom-full left-3 right-3 mb-1 bg-card border border-border rounded-lg shadow-lg overflow-hidden animate-fade-in z-10">
              {filteredMentions.slice(0, 6).map((m) => (
                <button key={m.user_id} className="flex items-center gap-2 w-full px-3 py-2 text-sm hover:bg-muted transition-colors text-left"
                  onMouseDown={(e) => { e.preventDefault(); insertMention(m.name); }}>
                  <Avatar className="h-6 w-6"><AvatarImage src={profiles[m.user_id]?.avatar_url || undefined} /><AvatarFallback className="text-[10px]">{m.name.charAt(0)}</AvatarFallback></Avatar>
                  <span>{m.name}</span>
                </button>
              ))}
            </div>
          )}
          <div className="flex items-end gap-2">
            <StickerPicker userId={userId} onSendSticker={(url) => onSend(url)} />
            <div className="flex-1 relative">
              <Input ref={inputRef} value={newMsg} onChange={(e) => handleInputChange(e.target.value)}
                placeholder="Type a message... @ to mention" className="pr-10 bg-card border-border"
                onKeyDown={(e) => {
                  if (e.key === "Enter" && !e.shiftKey && !showMentions) { e.preventDefault(); onSend(); }
                  if (e.key === "Escape") setShowMentions(false);
                }}
                onBlur={() => setTimeout(() => setShowMentions(false), 200)} />
            </div>
            <Button size="icon" onClick={() => onSend()} disabled={!newMsg.trim()}
              className="bg-[hsl(var(--success))] hover:bg-[hsl(var(--success))]/90 text-[hsl(var(--success-foreground))] h-9 w-9">
              <Send className="h-4 w-4" />
            </Button>
          </div>
        </div>
      )}

      {/* Poke dialog */}
      <Dialog open={!!pokeTarget} onOpenChange={(v) => !v && setPokeTarget(null)}>
        <DialogContent className="max-w-sm">
          <DialogHeader><DialogTitle className="flex items-center gap-2"><Hand className="h-5 w-5" /> Poke {pokeTarget?.name}</DialogTitle></DialogHeader>
          <div className="space-y-2">
            <p className="text-sm text-muted-foreground">
              {profiles[userId]?.name || "You"} poked {pokeTarget?.name}
              {pokeSuffix.trim() ? ` ${pokeSuffix.trim()}` : ""}
            </p>
            <Input value={pokeSuffix} onChange={(e) => setPokeSuffix(e.target.value.slice(0, 10))}
              placeholder="Add custom text (max 10 chars)" maxLength={10} />
            <p className="text-[11px] text-muted-foreground text-right">{pokeSuffix.length}/10</p>
          </div>
          <DialogFooter>
            <Button variant="ghost" onClick={() => setPokeTarget(null)}>Cancel</Button>
            <Button onClick={sendPoke}>Send Poke</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      <PostDetailDialog post={sharedPostDetail} profiles={profiles} userId={userId} isAdmin={false} onClose={() => setSharedPostDetail(null)} />
    </div>
  );
}
