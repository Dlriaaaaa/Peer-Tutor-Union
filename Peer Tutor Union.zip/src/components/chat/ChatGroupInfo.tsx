import { useState, useRef } from "react";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Separator } from "@/components/ui/separator";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter, DialogDescription } from "@/components/ui/dialog";
import { AlertDialog, AlertDialogContent, AlertDialogHeader, AlertDialogTitle, AlertDialogDescription, AlertDialogFooter, AlertDialogCancel, AlertDialogAction } from "@/components/ui/alert-dialog";
import { Checkbox } from "@/components/ui/checkbox";
import { Label } from "@/components/ui/label";
import { X, Plus, Pencil, UserMinus, Trash2, Camera, Bot, Power } from "lucide-react";
import { Switch } from "@/components/ui/switch";
import { Conversation, ProfileMap, Member } from "./types";
import { useNavigate } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";
import AvatarCropDialog from "@/components/AvatarCropDialog";

interface ChatGroupInfoProps {
  conversation: Conversation;
  profiles: ProfileMap;
  convMembers: Member[];
  userId: string;
  onClose: () => void;
  onRefresh: () => void;
  onDissolveGroup?: () => void;
  friendUsers: { user_id: string; name: string }[];
  onFetchFriends: () => void;
  botPersonas?: { id: string; name: string; avatar_url: string | null }[];
  convBotIds?: string[];
  botPersonaMap?: Record<string, { name: string; avatar_url: string | null }>;
  onAddBot?: (personaId: string) => void;
  onRemoveBot?: (personaId: string) => void;
  isAdmin?: boolean;
}

export default function ChatGroupInfo({
  conversation, profiles, convMembers, userId,
  onClose, onRefresh, onDissolveGroup, friendUsers, onFetchFriends,
  botPersonas = [], convBotIds = [], botPersonaMap = {}, onAddBot, onRemoveBot,
  isAdmin = false,
}: ChatGroupInfoProps) {
  const navigate = useNavigate();
  const members = convMembers.filter((m) => m.conversation_id === conversation.id);
  const isCreator = conversation.created_by === userId;

  const [editingName, setEditingName] = useState(false);
  const [newName, setNewName] = useState(conversation.name || "");
  const [addOpen, setAddOpen] = useState(false);
  const [selectedUsers, setSelectedUsers] = useState<string[]>([]);
  // Group avatar
  const [cropSrc, setCropSrc] = useState<string | null>(null);
  const [kickTarget, setKickTarget] = useState<{ id: string; name: string } | null>(null);
  const fileRef = useRef<HTMLInputElement>(null);

  const availableBots = botPersonas.filter(p => !convBotIds.includes(p.id));

  const memberUserIds = members.map((m) => m.user_id);
  const availableFriends = friendUsers.filter((f) => !memberUserIds.includes(f.user_id));

  const updateName = async () => {
    if (!newName.trim()) return;
    const { error } = await supabase.from("conversations").update({ name: newName.trim() }).eq("id", conversation.id);
    if (error) { toast.error("Failed to update"); return; }
    toast.success("Group name updated");
    setEditingName(false);
    onRefresh();
  };

  const removeMember = async (memberId: string) => {
    const { error } = await supabase.from("conversation_members")
      .delete().eq("conversation_id", conversation.id).eq("user_id", memberId);
    if (error) { toast.error("Failed to remove"); return; }
    toast.success("Member removed");
    onRefresh();
  };

  const addMembers = async () => {
    if (selectedUsers.length === 0) return;
    const rows = selectedUsers.map((uid) => ({ conversation_id: conversation.id, user_id: uid }));
    const { error } = await supabase.from("conversation_members").insert(rows);
    if (error) { toast.error("Failed to add"); return; }
    toast.success("Members added");
    setAddOpen(false);
    setSelectedUsers([]);
    onRefresh();
  };

  // Group avatar handling
  const handleAvatarFile = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = () => setCropSrc(reader.result as string);
    reader.readAsDataURL(file);
    e.target.value = "";
  };

  const handleAvatarCrop = async (blob: Blob) => {
    setCropSrc(null);
    const path = `group-avatars/${conversation.id}/${Date.now()}.jpg`;
    const { error: uploadErr } = await supabase.storage.from("avatars").upload(path, blob, { contentType: "image/jpeg", upsert: true });
    if (uploadErr) { toast.error("Upload failed"); return; }
    const { data: urlData } = supabase.storage.from("avatars").getPublicUrl(path);
    const { error } = await supabase.from("conversations").update({ avatar_url: urlData.publicUrl }).eq("id", conversation.id);
    if (error) { toast.error("Failed to update avatar"); return; }
    toast.success("Group avatar updated");
    onRefresh();
  };

  return (
    <div className="w-[260px] shrink-0 border-l border-border bg-card h-full flex flex-col">
      <div className="flex items-center justify-between px-4 py-3 border-b border-border">
        <span className="text-sm font-medium text-foreground">Chat Info</span>
        <Button size="icon" variant="ghost" className="h-7 w-7" onClick={onClose}><X className="h-4 w-4" /></Button>
      </div>

      <ScrollArea className="flex-1 p-4">
        {/* Group Avatar (creator can change) */}
        <div className="flex flex-col items-center mb-4">
          <div className="relative group">
            <Avatar className="h-16 w-16">
              {(conversation as any).avatar_url ? (
                <AvatarImage src={(conversation as any).avatar_url} />
              ) : (
                <AvatarFallback className="text-lg bg-primary/10 text-primary">
                  {conversation.name?.charAt(0) || "G"}
                </AvatarFallback>
              )}
            </Avatar>
            {isCreator && (
              <button
                onClick={() => fileRef.current?.click()}
                className="absolute inset-0 rounded-full bg-black/40 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity"
              >
                <Camera className="h-5 w-5 text-white" />
              </button>
            )}
          </div>
          <input ref={fileRef} type="file" accept="image/*" className="hidden" onChange={handleAvatarFile} />
        </div>

        {/* Members grid */}
        <div className="mb-4">
          <div className="grid grid-cols-4 gap-3">
            {members.map((m) => {
              const p = profiles[m.user_id];
              return (
                <div key={m.user_id} className="relative group flex flex-col items-center gap-1">
                  <button className="hover:opacity-80 transition-opacity" onClick={() => navigate(`/profile/${m.user_id}`)}>
                    <Avatar className="h-11 w-11">
                      <AvatarImage src={p?.avatar_url || undefined} />
                      <AvatarFallback className="text-xs">{p?.name?.charAt(0) || "?"}</AvatarFallback>
                    </Avatar>
                  </button>
                  <span className="text-[11px] text-muted-foreground truncate w-full text-center">
                    {m.user_id === userId ? "Me" : (p?.name || "Unknown")}
                  </span>
                  {(isCreator || isAdmin) && m.user_id !== userId && (
                    <button className="absolute -top-1 -right-1 h-4 w-4 rounded-full bg-destructive text-destructive-foreground items-center justify-center text-[10px] hidden group-hover:flex"
                      onClick={() => setKickTarget({ id: m.user_id, name: p?.name || "Unknown" })}>
                      <X className="h-3 w-3" />
                    </button>
                  )}
                </div>
              );
            })}
            <button className="flex flex-col items-center gap-1" onClick={() => { setAddOpen(true); onFetchFriends(); }}>
              <div className="h-11 w-11 rounded-full border-2 border-dashed border-muted-foreground/30 flex items-center justify-center hover:border-primary transition-colors">
                <Plus className="h-5 w-5 text-muted-foreground/50" />
              </div>
              <span className="text-[11px] text-muted-foreground">Add</span>
            </button>
          </div>
        </div>

        <Separator className="my-3" />

        {/* Bots section */}
        <div className="mb-4">
          <div className="flex items-center justify-between mb-2">
            <p className="text-xs text-muted-foreground font-medium">智能体</p>
            {(isCreator || isAdmin) && (
              <div className="flex items-center gap-1.5">
                <span className="text-[10px] text-muted-foreground">{conversation.bot_enabled !== false ? "已开启" : "已关闭"}</span>
                <Switch
                  checked={conversation.bot_enabled !== false}
                  onCheckedChange={async (v) => {
                    await supabase.from("conversations").update({ bot_enabled: v }).eq("id", conversation.id);
                    toast.success(v ? "AI 已开启" : "AI 已关闭");
                    onRefresh();
                  }}
                  className="scale-75"
                />
              </div>
            )}
          </div>
          <div className="space-y-2">
            {convBotIds.map(bid => {
              const bp = botPersonaMap[bid];
              if (!bp) return null;
              return (
                <div key={bid} className="flex items-center gap-2 group">
                  <Avatar className="h-8 w-8">
                    <AvatarImage src={bp.avatar_url || undefined} />
                    <AvatarFallback className="bg-primary/10 text-primary text-xs"><Bot className="h-3 w-3" /></AvatarFallback>
                  </Avatar>
                  <span className="text-sm flex-1 truncate">{bp.name}</span>
                  {isCreator && onRemoveBot && (
                    <button className="opacity-0 group-hover:opacity-100 transition-opacity" onClick={() => onRemoveBot(bid)}>
                      <UserMinus className="h-3.5 w-3.5 text-destructive" />
                    </button>
                  )}
                </div>
              );
            })}
            {convBotIds.length === 0 && <p className="text-xs text-muted-foreground/60">暂无智能体</p>}
          </div>
          {isCreator && availableBots.length > 0 && onAddBot && (
            <div className="mt-2 space-y-1">
              {availableBots.map(p => (
                <button key={p.id} onClick={() => onAddBot(p.id)}
                  className="flex items-center gap-2 w-full p-1.5 rounded hover:bg-muted transition-colors text-left">
                  <Avatar className="h-7 w-7">
                    <AvatarImage src={p.avatar_url || undefined} />
                    <AvatarFallback className="text-[8px] bg-primary/10"><Bot className="h-3 w-3" /></AvatarFallback>
                  </Avatar>
                  <span className="text-xs text-muted-foreground">+ {p.name}</span>
                </button>
              ))}
            </div>
          )}
        </div>

        <Separator className="my-3" />

        <div className="space-y-4">
          <div>
            <div className="flex items-center gap-1 mb-1">
              <p className="text-xs text-muted-foreground">Group Name</p>
              {isCreator && !editingName && (
                <button onClick={() => { setEditingName(true); setNewName(conversation.name || ""); }}>
                  <Pencil className="h-3 w-3 text-muted-foreground hover:text-foreground" />
                </button>
              )}
            </div>
            {editingName ? (
              <div className="flex gap-1">
                <Input value={newName} onChange={(e) => setNewName(e.target.value)} className="h-7 text-sm" onKeyDown={(e) => e.key === "Enter" && updateName()} autoFocus />
                <Button size="sm" className="h-7 px-2" onClick={updateName}>Save</Button>
                <Button size="sm" variant="ghost" className="h-7 px-2" onClick={() => setEditingName(false)}>Cancel</Button>
              </div>
            ) : (
              <p className="text-sm font-medium text-foreground">{conversation.name || "Unnamed Group"}</p>
            )}
          </div>
          <div>
            <p className="text-xs text-muted-foreground mb-1">Members</p>
            <p className="text-sm text-foreground">{members.length}</p>
          </div>
          <div>
            <p className="text-xs text-muted-foreground mb-1">Created By</p>
            <p className="text-sm text-foreground">
              {conversation.created_by === userId ? "Me" : (profiles[conversation.created_by]?.name || "Unknown")}
            </p>
          </div>
        </div>
      </ScrollArea>

      {isCreator && onDissolveGroup && (
        <div className="p-3 border-t border-border">
          <Button variant="destructive" size="sm" className="w-full"
            onClick={() => { if (confirm("Are you sure you want to dissolve this group?")) onDissolveGroup(); }}>
            <Trash2 className="h-4 w-4 mr-1" /> Dissolve Group
          </Button>
        </div>
      )}

      <Dialog open={addOpen} onOpenChange={setAddOpen}>
        <DialogContent>
          <DialogHeader><DialogTitle>Add Members</DialogTitle></DialogHeader>
          <ScrollArea className="h-48 border rounded-md p-2">
            {availableFriends.length === 0 ? (
              <p className="text-sm text-muted-foreground p-2">No friends to add</p>
            ) : availableFriends.map((u) => (
              <label key={u.user_id} className="flex items-center gap-2 p-1.5 hover:bg-muted rounded cursor-pointer">
                <Checkbox checked={selectedUsers.includes(u.user_id)}
                  onCheckedChange={(c) => setSelectedUsers((p) => c ? [...p, u.user_id] : p.filter((id) => id !== u.user_id))} />
                <span className="text-sm">{u.name}</span>
              </label>
            ))}
          </ScrollArea>
          <DialogFooter><Button onClick={addMembers} disabled={selectedUsers.length === 0}>Add</Button></DialogFooter>
        </DialogContent>
      </Dialog>

      {cropSrc && (
        <AvatarCropDialog open={!!cropSrc} imageSrc={cropSrc} onClose={() => setCropSrc(null)} onCropComplete={handleAvatarCrop} />
      )}

      <AlertDialog open={!!kickTarget} onOpenChange={(o) => !o && setKickTarget(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>移除成员</AlertDialogTitle>
            <AlertDialogDescription>
              确定要将 <span className="font-semibold">{kickTarget?.name}</span> 移出群聊吗？移除后对方将无法再查看群消息。
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>取消</AlertDialogCancel>
            <AlertDialogAction
              className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
              onClick={() => {
                if (kickTarget) {
                  removeMember(kickTarget.id);
                  setKickTarget(null);
                }
              }}
            >
              确认移除
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}
