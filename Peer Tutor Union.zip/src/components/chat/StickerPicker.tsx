import { useState, useEffect, useRef } from "react";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Smile, Plus, X, Loader2 } from "lucide-react";
import { toast } from "sonner";
import AvatarCropDialog from "@/components/AvatarCropDialog";

type Sticker = { id: string; image_path: string; signedUrl?: string };

interface StickerPickerProps {
  userId: string;
  onSendSticker: (stickerUrl: string) => void;
}

export default function StickerPicker({ userId, onSendSticker }: StickerPickerProps) {
  const [open, setOpen] = useState(false);
  const [stickers, setStickers] = useState<Sticker[]>([]);
  const [loading, setLoading] = useState(false);
  const [uploading, setUploading] = useState(false);
  const [cropSrc, setCropSrc] = useState<string | null>(null);
  const [managing, setManaging] = useState(false);
  const fileRef = useRef<HTMLInputElement>(null);

  const loadStickers = async () => {
    setLoading(true);
    const { data } = await supabase.from("sticker_packs").select("*").eq("user_id", userId).order("created_at", { ascending: false });
    if (data) {
      // Generate signed URLs
      const withUrls = await Promise.all(data.map(async (s) => {
        const { data: urlData } = await supabase.storage.from("chat-stickers").createSignedUrl(s.image_path, 3600);
        return { ...s, signedUrl: urlData?.signedUrl || "" };
      }));
      setStickers(withUrls);
    }
    setLoading(false);
  };

  useEffect(() => {
    if (open) loadStickers();
  }, [open]);

  const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    if (!file.type.startsWith("image/")) { toast.error("Please select an image"); return; }
    const reader = new FileReader();
    reader.onload = () => setCropSrc(reader.result as string);
    reader.readAsDataURL(file);
    e.target.value = "";
  };

  const handleCropComplete = async (blob: Blob) => {
    setCropSrc(null);
    setUploading(true);
    const path = `${userId}/${Date.now()}.jpg`;
    const { error: uploadErr } = await supabase.storage.from("chat-stickers").upload(path, blob, { contentType: "image/jpeg" });
    if (uploadErr) { toast.error("Upload failed"); setUploading(false); return; }
    const { error: insertErr } = await supabase.from("sticker_packs").insert({ user_id: userId, image_path: path });
    if (insertErr) { toast.error("Save failed"); setUploading(false); return; }
    toast.success("Sticker added!");
    setUploading(false);
    loadStickers();
  };

  const deleteSticker = async (sticker: Sticker) => {
    await supabase.storage.from("chat-stickers").remove([sticker.image_path]);
    await supabase.from("sticker_packs").delete().eq("id", sticker.id);
    setStickers(prev => prev.filter(s => s.id !== sticker.id));
    toast.success("Sticker removed");
  };

  const sendSticker = (sticker: Sticker) => {
    if (sticker.signedUrl) {
      onSendSticker(`[Sticker]${sticker.signedUrl}`);
      setOpen(false);
    }
  };

  return (
    <>
      <Popover open={open} onOpenChange={setOpen}>
        <PopoverTrigger asChild>
          <Button size="icon" variant="ghost" className="h-9 w-9 shrink-0">
            <Smile className="h-5 w-5" />
          </Button>
        </PopoverTrigger>
        <PopoverContent className="w-72 p-2" side="top" align="start">
          <div className="flex items-center justify-between mb-2">
            <span className="text-xs font-medium text-muted-foreground">My Stickers</span>
            <div className="flex gap-1">
              <Button size="icon" variant="ghost" className="h-6 w-6" onClick={() => setManaging(m => !m)}>
                {managing ? <X className="h-3 w-3" /> : <span className="text-[10px]">Edit</span>}
              </Button>
              <Button size="icon" variant="ghost" className="h-6 w-6" onClick={() => fileRef.current?.click()} disabled={uploading}>
                {uploading ? <Loader2 className="h-3 w-3 animate-spin" /> : <Plus className="h-3 w-3" />}
              </Button>
            </div>
          </div>
          <input ref={fileRef} type="file" accept="image/*" className="hidden" onChange={handleFileSelect} />
          <ScrollArea className="h-48">
            {loading ? (
              <div className="flex justify-center py-8"><Loader2 className="h-5 w-5 animate-spin text-muted-foreground" /></div>
            ) : stickers.length === 0 ? (
              <p className="text-xs text-muted-foreground text-center py-8">No stickers yet. Click + to add!</p>
            ) : (
              <div className="grid grid-cols-4 gap-1.5">
                {stickers.map(s => (
                  <div key={s.id} className="relative group">
                    <button onClick={() => !managing && sendSticker(s)}
                      className="w-full aspect-square rounded-md overflow-hidden border border-border hover:border-primary transition-colors">
                      <img src={s.signedUrl} alt="sticker" className="w-full h-full object-cover" />
                    </button>
                    {managing && (
                      <button onClick={() => deleteSticker(s)}
                        className="absolute -top-1 -right-1 h-4 w-4 bg-destructive text-destructive-foreground rounded-full flex items-center justify-center text-[10px]">
                        <X className="h-3 w-3" />
                      </button>
                    )}
                  </div>
                ))}
              </div>
            )}
          </ScrollArea>
        </PopoverContent>
      </Popover>

      {cropSrc && (
        <AvatarCropDialog open={!!cropSrc} imageSrc={cropSrc} onClose={() => setCropSrc(null)} onCropComplete={handleCropComplete} />
      )}
    </>
  );
}
