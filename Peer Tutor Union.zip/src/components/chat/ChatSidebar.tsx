import { useState, useEffect } from "react";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger, DialogFooter } from "@/components/ui/dialog";
import { Checkbox } from "@/components/ui/checkbox";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { ContextMenu, ContextMenuContent, ContextMenuItem, ContextMenuTrigger } from "@/components/ui/context-menu";
import { Search, Plus, Users, MessageCircle, Eye, Pin, PinOff, UserPlus, UserCheck, UserX, Contact } from "lucide-react";
import { format, isToday, isYesterday } from "date-fns";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";
import { useNavigate } from "react-router-dom";
import { Conversation, ProfileMap, Member, Message } from "./types";

interface ChatSidebarProps {
  conversations: Conversation[];
  activeConv: string | null;
  setActiveConv: (id: string) => void;
  profiles: ProfileMap;
  convMembers: Member[];
  lastMessages: Record<string, Message>;
  userId: string;
  isAdmin: boolean;
  friendUsers: { user_id: string; name: string }[];
  onCreateGroup: (name: string, members: string[]) => void;
  onStartDM: (userId: string) => void;
  onFetchFriends: () => void;
  pinnedIds: Set<string>;
  onTogglePin: (convId: string) => void;
  unreadCounts?: Record<string, number>;
}

type Friendship = { id: string; requester_id: string; addressee_id: string; status: string };

function formatTime(dateStr: string) {
  const d = new Date(dateStr);
  if (isToday(d)) return format(d, "HH:mm");
  if (isYesterday(d)) return "Yesterday";
  return format(d, "MM/dd");
}

export default function ChatSidebar({
  conversations, activeConv, setActiveConv, profiles, convMembers,
  lastMessages, userId, isAdmin, friendUsers,
  onCreateGroup, onStartDM, onFetchFriends, pinnedIds, onTogglePin, unreadCounts = {},
}: ChatSidebarProps) {
  const [search, setSearch] = useState("");
  const [tab, setTab] = useState<"chat" | "contacts">("chat");
  const [groupOpen, setGroupOpen] = useState(false);
  const [dmOpen, setDmOpen] = useState(false);
  const [groupName, setGroupName] = useState("");
  const [selectedUsers, setSelectedUsers] = useState<string[]>([]);

  // Contacts state
  const [allProfiles, setAllProfiles] = useState<{ user_id: string; name: string; avatar_url: string | null }[]>([]);
  const [friendships, setFriendships] = useState<Friendship[]>([]);
  const [contactsLoading, setContactsLoading] = useState(false);
  const navigate = useNavigate();

  const fetchContacts = async () => {
    setContactsLoading(true);
    const [profRes, friendRes] = await Promise.all([
      supabase.from("profiles").select("user_id, name, avatar_url").order("name"),
      supabase.from("friendships").select("*"),
    ]);
    setAllProfiles((profRes.data || []).filter(p => p.user_id !== userId));
    setFriendships(friendRes.data || []);
    setContactsLoading(false);
  };

  useEffect(() => {
    if (tab === "contacts") fetchContacts();
  }, [tab]);

  const getFriendship = (otherUserId: string) =>
    friendships.find(f =>
      (f.requester_id === userId && f.addressee_id === otherUserId) ||
      (f.addressee_id === userId && f.requester_id === otherUserId)
    );

  const sendRequest = async (otherUserId: string) => {
    const { error } = await supabase.from("friendships").insert({ requester_id: userId, addressee_id: otherUserId });
    if (error) { toast.error(error.message); return; }
    toast.success("Friend request sent");
    fetchContacts();
  };

  const acceptRequest = async (friendshipId: string) => {
    await supabase.from("friendships").update({ status: "accepted" }).eq("id", friendshipId);
    toast.success("Friend request accepted");
    fetchContacts();
  };

  const removeFriend = async (friendshipId: string) => {
    await supabase.from("friendships").delete().eq("id", friendshipId);
    toast.success("Removed");
    fetchContacts();
  };

  const pendingRequests = friendships.filter(f => f.addressee_id === userId && f.status === "pending");
  const friends = friendships.filter(f => f.status === "accepted");
  const friendIdsList = friends.map(f => f.requester_id === userId ? f.addressee_id : f.requester_id);

  // Chat tab helpers
  const getConvDisplayName = (conv: Conversation) => {
    if (conv.is_group && conv.name) return conv.name;
    const members = convMembers.filter((m) => m.conversation_id === conv.id && m.user_id !== userId);
    return members.map((m) => profiles[m.user_id]?.name || "Unknown").join(", ") || "Chat";
  };

  const getConvAvatar = (conv: Conversation) => {
    if (conv.is_group) return conv.avatar_url || null;
    const other = convMembers.find((m) => m.conversation_id === conv.id && m.user_id !== userId);
    return other ? profiles[other.user_id]?.avatar_url : null;
  };

  const getMemberCount = (convId: string) => convMembers.filter((m) => m.conversation_id === convId).length;

  const filtered = conversations.filter((c) => {
    if (!search.trim()) return true;
    return getConvDisplayName(c).toLowerCase().includes(search.toLowerCase());
  });

  const filteredContacts = allProfiles.filter(p =>
    !search.trim() || p.name.toLowerCase().includes(search.toLowerCase())
  );

  const handleCreateGroup = () => {
    onCreateGroup(groupName, selectedUsers);
    setGroupOpen(false);
    setGroupName("");
    setSelectedUsers([]);
  };

  return (
    <div className="w-[280px] shrink-0 flex flex-col border-r border-border bg-card h-full">
      {/* Tabs */}
      <div className="flex border-b border-border">
        <button
          onClick={() => setTab("chat")}
          className={`flex-1 py-2.5 text-sm font-medium transition-colors ${tab === "chat" ? "text-primary border-b-2 border-primary" : "text-muted-foreground hover:text-foreground"}`}
        >
          <MessageCircle className="h-4 w-4 inline mr-1" />Chat
        </button>
        <button
          onClick={() => setTab("contacts")}
          className={`flex-1 py-2.5 text-sm font-medium transition-colors relative ${tab === "contacts" ? "text-primary border-b-2 border-primary" : "text-muted-foreground hover:text-foreground"}`}
        >
          <Contact className="h-4 w-4 inline mr-1" />Contacts
          {pendingRequests.length > 0 && tab !== "contacts" && (
            <span className="absolute top-1.5 right-4 h-2 w-2 bg-destructive rounded-full" />
          )}
        </button>
      </div>

      {/* Search */}
      <div className="p-3 flex items-center gap-2">
        <div className="relative flex-1">
          <Search className="absolute left-2.5 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <Input
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder={tab === "chat" ? "Search chats" : "Search contacts"}
            className="pl-8 h-8 bg-muted/50 border-0 text-sm"
          />
        </div>
        {tab === "chat" && (
          <Dialog open={groupOpen} onOpenChange={(v) => { setGroupOpen(v); if (v) onFetchFriends(); }}>
            <DialogTrigger asChild>
              <Button size="icon" variant="ghost" className="h-8 w-8 shrink-0">
                <Plus className="h-5 w-5" />
              </Button>
            </DialogTrigger>
            <DialogContent>
              <DialogHeader><DialogTitle>Create Group</DialogTitle></DialogHeader>
              <div className="space-y-4">
                <div><Label>Group Name</Label><Input value={groupName} onChange={(e) => setGroupName(e.target.value)} placeholder="Enter group name" /></div>
                <div>
                  <Label>Select Friends</Label>
                  <ScrollArea className="h-48 border rounded-md p-2 mt-1">
                    {friendUsers.length === 0 ? (
                      <p className="text-sm text-muted-foreground p-2">No friends yet. Add some from Contacts first!</p>
                    ) : friendUsers.map((u) => (
                      <label key={u.user_id} className="flex items-center gap-2 p-1.5 hover:bg-muted rounded cursor-pointer">
                        <Checkbox checked={selectedUsers.includes(u.user_id)}
                          onCheckedChange={(c) => setSelectedUsers((p) => c ? [...p, u.user_id] : p.filter((id) => id !== u.user_id))} />
                        <span className="text-sm">{u.name}</span>
                      </label>
                    ))}
                  </ScrollArea>
                </div>
              </div>
              <DialogFooter>
                <Button onClick={handleCreateGroup} disabled={!groupName.trim() || selectedUsers.length === 0}>Create</Button>
              </DialogFooter>
            </DialogContent>
          </Dialog>
        )}
      </div>

      {/* Chat tab: DM button + conversation list */}
      {tab === "chat" && (
        <>
          {(
            <Dialog open={dmOpen} onOpenChange={(v) => { setDmOpen(v); if (v) onFetchFriends(); }}>
              <DialogTrigger asChild>
                <button className="mx-3 mb-2 flex items-center gap-2 px-3 py-1.5 rounded text-sm text-muted-foreground hover:bg-muted transition-colors">
                  <MessageCircle className="h-4 w-4" /> Start DM
                </button>
              </DialogTrigger>
              <DialogContent>
                <DialogHeader><DialogTitle>Select Friend</DialogTitle></DialogHeader>
                <ScrollArea className="h-64">
                  {friendUsers.length === 0 ? (
                    <p className="text-sm text-muted-foreground p-4">No friends yet. Add some from Contacts first!</p>
                  ) : friendUsers.map((u) => (
                    <button key={u.user_id} className="flex items-center gap-3 w-full p-2 hover:bg-muted rounded transition-colors"
                      onClick={() => { onStartDM(u.user_id); setDmOpen(false); }}>
                      <Avatar className="h-9 w-9">
                        <AvatarImage src={profiles[u.user_id]?.avatar_url || undefined} />
                        <AvatarFallback>{u.name.charAt(0)}</AvatarFallback>
                      </Avatar>
                      <span className="text-sm">{u.name}</span>
                    </button>
                  ))}
                </ScrollArea>
              </DialogContent>
            </Dialog>
          )}

          <ScrollArea className="flex-1">
            {filtered.map((conv, idx) => {
              const isActive = activeConv === conv.id;
              const isPinned = pinnedIds.has(conv.id);
              const isMember = convMembers.some((m) => m.conversation_id === conv.id && m.user_id === userId);
              const lastMsg = lastMessages[conv.id];
              const displayName = getConvDisplayName(conv);
              const avatarUrl = getConvAvatar(conv);
              const memberCount = getMemberCount(conv.id);
              const unread = unreadCounts[conv.id] || 0;

              let previewText = "No messages";
              if (lastMsg) {
                const senderName = profiles[lastMsg.sender_id]?.name || "Unknown";
                if (lastMsg.content.startsWith("[Poke]")) {
                  previewText = lastMsg.content;
                } else if (lastMsg.content.startsWith("[Sticker]")) {
                  previewText = `${senderName}: [Sticker]`;
                } else if (lastMsg.content.startsWith("[SharedPost:")) {
                  const title = lastMsg.content.replace(/^\[SharedPost:[^\]]*\]\s*/, "");
                  previewText = `${senderName}: [Post] ${title}`;
                } else if (lastMsg.content.startsWith("[Shared Post]")) {
                  previewText = `${senderName}: [Post]`;
                } else if (lastMsg.content.startsWith("[StudyGroup:")) {
                  previewText = `${senderName}: [Study Group Invite]`;
                } else {
                  previewText = `${senderName}: ${lastMsg.content}`;
                }
              }

              return (
                <ContextMenu key={conv.id}>
                  <ContextMenuTrigger>
                    <button
                      className={`w-full text-left px-3 py-3 flex items-center gap-3 transition-all duration-200 border-b border-border/30
                        ${isActive ? "bg-primary/10" : isPinned ? "bg-muted/60" : "hover:bg-muted/50"}`}
                      onClick={() => setActiveConv(conv.id)}
                    >
                      <div className="relative">
                        <Avatar className="h-11 w-11 shrink-0">
                          {conv.is_group ? (
                            avatarUrl ? (
                              <><AvatarImage src={avatarUrl} /><AvatarFallback className="bg-primary/10 text-primary"><Users className="h-5 w-5" /></AvatarFallback></>
                            ) : (
                              <AvatarFallback className="bg-primary/10 text-primary"><Users className="h-5 w-5" /></AvatarFallback>
                            )
                          ) : (
                            <><AvatarImage src={avatarUrl || undefined} /><AvatarFallback>{displayName.charAt(0)}</AvatarFallback></>
                          )}
                        </Avatar>
                        {unread > 0 && (
                          <span className="absolute -top-1 -right-1 min-w-[18px] h-[18px] flex items-center justify-center rounded-full bg-destructive text-destructive-foreground text-[10px] font-bold border-2 border-card shadow-[0_0_6px_2px_hsl(var(--destructive)/0.4)]">
                            {unread > 99 ? "99+" : unread}
                          </span>
                        )}
                      </div>
                      <div className="min-w-0 flex-1">
                        <div className="flex items-center gap-2 min-w-0">
                          <span className="text-sm font-medium truncate flex items-center gap-1 min-w-0">
                            {isPinned && <Pin className="h-3 w-3 text-primary shrink-0" />}
                            <span className="truncate">{displayName}</span>
                            {conv.is_group && <span className="text-muted-foreground shrink-0"> ({memberCount})</span>}
                          </span>
                          <span className="text-[11px] text-muted-foreground shrink-0 whitespace-nowrap tabular-nums">
                            {lastMsg ? formatTime(lastMsg.created_at) : formatTime(conv.updated_at)}
                          </span>
                        </div>
                        <div className="flex items-center gap-1 mt-0.5 overflow-hidden">
                          {isAdmin && !isMember && <Eye className="h-3 w-3 text-muted-foreground shrink-0" />}
                          <p className="text-xs text-muted-foreground truncate max-w-full">{previewText}</p>
                        </div>
                      </div>
                    </button>
                  </ContextMenuTrigger>
                  <ContextMenuContent>
                    <ContextMenuItem onClick={() => onTogglePin(conv.id)}>
                      {isPinned ? <><PinOff className="h-4 w-4 mr-2" /> Unpin</> : <><Pin className="h-4 w-4 mr-2" /> Pin Chat</>}
                    </ContextMenuItem>
                  </ContextMenuContent>
                </ContextMenu>
              );
            })}
          </ScrollArea>
        </>
      )}

      {/* Contacts tab */}
      {tab === "contacts" && (
        <ScrollArea className="flex-1">
          {contactsLoading ? (
            <div className="p-4 text-center text-sm text-muted-foreground">Loading...</div>
          ) : (
            <div className="px-2 pb-2">
              {/* Pending requests */}
              {pendingRequests.length > 0 && (
                <div className="mb-3">
                  <p className="text-[10px] uppercase tracking-wider text-muted-foreground font-semibold px-2 py-1.5">Pending Requests</p>
                  {pendingRequests.map(req => {
                    const p = allProfiles.find(pr => pr.user_id === req.requester_id);
                    return (
                      <div key={req.id} className="flex items-center gap-2 p-2 rounded-lg hover:bg-muted">
                        <Avatar className="h-9 w-9">
                          <AvatarImage src={p?.avatar_url || undefined} />
                          <AvatarFallback>{p?.name?.charAt(0) || "?"}</AvatarFallback>
                        </Avatar>
                        <span className="flex-1 text-sm font-medium truncate">{p?.name || "Unknown"}</span>
                        <Button size="icon" variant="ghost" className="h-7 w-7" onClick={() => acceptRequest(req.id)}><UserCheck className="h-4 w-4 text-primary" /></Button>
                        <Button size="icon" variant="ghost" className="h-7 w-7" onClick={() => removeFriend(req.id)}><UserX className="h-4 w-4 text-destructive" /></Button>
                      </div>
                    );
                  })}
                </div>
              )}

              {/* Friends */}
              <p className="text-[10px] uppercase tracking-wider text-muted-foreground font-semibold px-2 py-1.5">Friends ({friendIdsList.length})</p>
              {friendIdsList.length === 0 ? (
                <p className="text-xs text-muted-foreground px-2 py-2">No friends yet</p>
              ) : (
                friendIdsList.map(fid => {
                  const p = allProfiles.find(pr => pr.user_id === fid);
                  const friendship = getFriendship(fid);
                  return (
                    <div key={fid} className="flex items-center gap-2 p-2 rounded-lg hover:bg-muted cursor-pointer"
                      onClick={() => navigate(`/profile/${fid}`)}>
                      <Avatar className="h-9 w-9">
                        <AvatarImage src={p?.avatar_url || undefined} />
                        <AvatarFallback>{p?.name?.charAt(0) || "?"}</AvatarFallback>
                      </Avatar>
                      <span className="flex-1 text-sm font-medium truncate">{p?.name || "Unknown"}</span>
                      <Button size="icon" variant="ghost" className="h-7 w-7" onClick={(e) => { e.stopPropagation(); onStartDM(fid); setTab("chat"); }}>
                        <MessageCircle className="h-3.5 w-3.5" />
                      </Button>
                      <Button size="icon" variant="ghost" className="h-7 w-7" onClick={(e) => { e.stopPropagation(); removeFriend(friendship!.id); }}>
                        <UserX className="h-3.5 w-3.5 text-destructive" />
                      </Button>
                    </div>
                  );
                })
              )}

              {/* All members */}
              <p className="text-[10px] uppercase tracking-wider text-muted-foreground font-semibold px-2 py-1.5 mt-3">All Members</p>
              {filteredContacts.filter(p => !friendIdsList.includes(p.user_id)).map(p => {
                const friendship = getFriendship(p.user_id);
                const isPending = friendship?.status === "pending";
                return (
                  <div key={p.user_id} className="flex items-center gap-2 p-2 rounded-lg hover:bg-muted">
                    <Avatar className="h-9 w-9 cursor-pointer" onClick={() => navigate(`/profile/${p.user_id}`)}>
                      <AvatarImage src={p.avatar_url || undefined} />
                      <AvatarFallback>{p.name.charAt(0)}</AvatarFallback>
                    </Avatar>
                    <span className="flex-1 text-sm truncate cursor-pointer" onClick={() => navigate(`/profile/${p.user_id}`)}>{p.name}</span>
                    {isPending ? (
                      <Badge variant="outline" className="text-[10px]">Pending</Badge>
                    ) : (
                      <Button size="icon" variant="ghost" className="h-7 w-7" onClick={() => sendRequest(p.user_id)}>
                        <UserPlus className="h-4 w-4" />
                      </Button>
                    )}
                  </div>
                );
              })}
            </div>
          )}
        </ScrollArea>
      )}
    </div>
  );
}
