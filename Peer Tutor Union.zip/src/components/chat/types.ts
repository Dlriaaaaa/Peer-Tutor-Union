export type Conversation = {
  id: string;
  name: string | null;
  is_group: boolean;
  created_by: string;
  updated_at: string;
  avatar_url?: string | null;
  bot_enabled?: boolean;
  bot_persona_id?: string | null;
};

export type Message = {
  id: string;
  conversation_id: string;
  sender_id: string;
  content: string;
  created_at: string;
  bot_persona_id?: string | null;
};

export type ProfileMap = Record<string, { name: string; avatar_url: string | null }>;

export type Member = { user_id: string; conversation_id: string };

export type Friendship = {
  id: string;
  requester_id: string;
  addressee_id: string;
  status: string;
};
