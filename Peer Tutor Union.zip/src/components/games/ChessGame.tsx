import { useState, useCallback } from "react";
import { Button } from "@/components/ui/button";

type Color = "w" | "b";
type PieceType = "K" | "Q" | "R" | "B" | "N" | "P";
type Piece = { color: Color; type: PieceType } | null;

const SYMBOLS: Record<string, string> = {
  wK: "♔", wQ: "♕", wR: "♖", wB: "♗", wN: "♘", wP: "♙",
  bK: "♚", bQ: "♛", bR: "♜", bB: "♝", bN: "♞", bP: "♟",
};

function initBoard(): Piece[][] {
  const b: Piece[][] = Array.from({ length: 8 }, () => Array(8).fill(null));
  const order: PieceType[] = ["R","N","B","Q","K","B","N","R"];
  for (let c = 0; c < 8; c++) {
    b[0][c] = { color: "b", type: order[c] };
    b[1][c] = { color: "b", type: "P" };
    b[6][c] = { color: "w", type: "P" };
    b[7][c] = { color: "w", type: order[c] };
  }
  return b;
}

function serializeBoard(board: Piece[][]): any[][] {
  return board.map(row => row.map(p => p ? { c: p.color, t: p.type } : null));
}

function deserializeBoard(data: any[][]): Piece[][] {
  return data.map(row => row.map((p: any) => p ? { color: p.c, type: p.t } : null));
}

function isValidMove(board: Piece[][], fr: number, fc: number, tr: number, tc: number, turn: Color): boolean {
  const p = board[fr][fc];
  if (!p || p.color !== turn) return false;
  const target = board[tr][tc];
  if (target && target.color === turn) return false;
  const dr = tr - fr, dc = tc - fc;
  const adr = Math.abs(dr), adc = Math.abs(dc);
  switch (p.type) {
    case "P": {
      const dir = p.color === "w" ? -1 : 1;
      const start = p.color === "w" ? 6 : 1;
      if (dc === 0 && !target) {
        if (dr === dir) return true;
        if (fr === start && dr === 2 * dir && !board[fr + dir][fc]) return true;
      }
      if (adc === 1 && dr === dir && target) return true;
      return false;
    }
    case "N": return (adr === 2 && adc === 1) || (adr === 1 && adc === 2);
    case "B": return adr === adc && clearPath(board, fr, fc, tr, tc);
    case "R": return (dr === 0 || dc === 0) && clearPath(board, fr, fc, tr, tc);
    case "Q": return ((dr === 0 || dc === 0) || adr === adc) && clearPath(board, fr, fc, tr, tc);
    case "K": return adr <= 1 && adc <= 1;
  }
  return false;
}

function clearPath(board: Piece[][], fr: number, fc: number, tr: number, tc: number): boolean {
  const dr = Math.sign(tr - fr), dc = Math.sign(tc - fc);
  let r = fr + dr, c = fc + dc;
  while (r !== tr || c !== tc) {
    if (board[r][c]) return false;
    r += dr; c += dc;
  }
  return true;
}

interface ChessGameProps {
  online?: boolean;
  myColor?: string;
  gameState?: any;
  onMove?: (state: any) => void;
  isMyTurn?: boolean;
}

export default function ChessGame({ online, myColor, gameState, onMove, isMyTurn }: ChessGameProps) {
  const [localBoard, setLocalBoard] = useState<Piece[][]>(initBoard);
  const [localTurn, setLocalTurn] = useState<Color>("w");
  const [selected, setSelected] = useState<[number, number] | null>(null);
  const [captured, setCaptured] = useState<{ w: string[]; b: string[] }>({ w: [], b: [] });

  const board = online && gameState?.board ? deserializeBoard(gameState.board) : localBoard;
  const turn = online && gameState?.turn ? gameState.turn : localTurn;
  const displayCaptured = online && gameState?.captured ? gameState.captured : captured;

  const myChessColor = myColor === "black" ? "b" : "w";

  const handleClick = useCallback((r: number, c: number) => {
    if (online && !isMyTurn) return;
    const currentTurn = online ? turn : localTurn;

    if (selected) {
      const [sr, sc] = selected;
      if (sr === r && sc === c) { setSelected(null); return; }
      if (isValidMove(board, sr, sc, r, c, currentTurn as Color)) {
        const nb = board.map(row => [...row]);
        const cap = nb[r][c];
        let piece = nb[sr][sc]!;
        if (piece.type === "P" && (r === 0 || r === 7)) piece = { ...piece, type: "Q" };
        nb[r][c] = piece;
        nb[sr][sc] = null;
        const nextTurn = currentTurn === "w" ? "b" : "w";
        const newCaptured = { ...displayCaptured };
        if (cap) {
          newCaptured[currentTurn as "w" | "b"] = [...(newCaptured[currentTurn as "w" | "b"] || []), SYMBOLS[cap.color + cap.type]];
        }

        if (online && onMove) {
          onMove({ board: serializeBoard(nb), turn: nextTurn, captured: newCaptured });
        } else {
          setLocalBoard(nb);
          setCaptured(newCaptured);
          setLocalTurn(nextTurn as Color);
        }
        setSelected(null);
      } else if (board[r][c]?.color === currentTurn) {
        setSelected([r, c]);
      } else {
        setSelected(null);
      }
    } else if (board[r][c]?.color === currentTurn) {
      if (online && board[r][c]?.color !== myChessColor) return;
      setSelected([r, c]);
    }
  }, [board, localTurn, turn, selected, online, isMyTurn, onMove, displayCaptured, myChessColor]);

  const reset = () => {
    if (online && onMove) {
      onMove({ board: serializeBoard(initBoard()), turn: "w", captured: { w: [], b: [] } });
    } else {
      setLocalBoard(initBoard()); setLocalTurn("w"); setSelected(null); setCaptured({ w: [], b: [] });
    }
  };

  const cellSize = 56;

  return (
    <div className="flex flex-col items-center gap-4">
      <div className="flex items-center justify-between w-full max-w-lg">
        <div className="text-sm font-medium text-foreground">
          {online
            ? (isMyTurn ? "Your turn" : "Waiting for opponent...")
            : `Current: ${turn === "w" ? "White" : "Black"}`}
        </div>
        <Button variant="outline" size="sm" onClick={reset}>Restart</Button>
      </div>
      {online && <p className="text-xs text-muted-foreground">You are {myColor === "black" ? "Black" : "White"}</p>}
      <div className="flex gap-4 text-xs text-muted-foreground">
        <span>White captures: {(displayCaptured.w || []).join(" ") || "None"}</span>
        <span>Black captures: {(displayCaptured.b || []).join(" ") || "None"}</span>
      </div>
      <div className="rounded-xl overflow-hidden shadow-lg border border-border/50">
        <div className="grid" style={{ gridTemplateColumns: `repeat(8, ${cellSize}px)` }}>
          {board.map((row, r) => row.map((piece, c) => {
            const isLight = (r + c) % 2 === 0;
            const isSelected = selected?.[0] === r && selected?.[1] === c;
            const canMove = selected && isValidMove(board, selected[0], selected[1], r, c, (online ? turn : localTurn) as Color);
            return (
              <div key={`${r}-${c}`} onClick={() => handleClick(r, c)}
                className={`flex items-center justify-center cursor-pointer transition-colors ${
                  isSelected ? "bg-primary/30" : isLight ? "bg-amber-100 dark:bg-amber-200" : "bg-amber-700 dark:bg-amber-800"
                } ${canMove ? "ring-2 ring-inset ring-primary/50" : ""}`}
                style={{ width: cellSize, height: cellSize }}>
                {piece && (
                  <span className={`text-3xl select-none ${piece.color === "b" ? "text-gray-900" : "text-white drop-shadow-[0_1px_2px_rgba(0,0,0,0.5)]"}`}>
                    {SYMBOLS[piece.color + piece.type]}
                  </span>
                )}
              </div>
            );
          }))}
        </div>
      </div>
    </div>
  );
}
