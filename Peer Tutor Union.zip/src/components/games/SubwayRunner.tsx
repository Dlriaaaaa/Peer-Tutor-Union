/**
 * SubwayRunner — Three.js (R3F) endless runner inspired by Subway Surfers.
 * Features: 3 lanes, jump, slide, procedurally spawned trains/barriers/coins,
 * progressive speed, HUD, game-over with leaderboard submission.
 */
import { useRef, useState, useEffect, useMemo, useCallback, Suspense } from "react";
import { Canvas, useFrame } from "@react-three/fiber";
import { Sky, Stars } from "@react-three/drei";
import * as THREE from "three";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Coins, Trophy, Play, RotateCcw, Pause, ArrowLeft } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";

// ─── World constants ───
// Camera looks toward +Z; in that view, world -X appears on screen right.
// So lane 0 (left input) → +2.5, lane 2 (right input) → -2.5.
const LANE_X = [2.5, 0, -2.5] as const;
const GROUND_Y = 0;
const PLAYER_HEIGHT = 1.6;
const JUMP_VELOCITY = 9;
const GRAVITY = -22;
const SLIDE_DURATION = 0.55;
const LANE_SWITCH_TIME = 0.16;
const SEGMENT_LENGTH = 30;
const VISIBLE_SEGMENTS = 6;
const SPAWN_AHEAD = 80;
const DESPAWN_BEHIND = 18;
const BASE_SPEED = 14;
const MAX_SPEED = 38;

type Lane = 0 | 1 | 2;
type ObstacleKind = "train" | "barrier" | "lowbar";
interface Obstacle { id: number; kind: ObstacleKind; lane: Lane; z: number; length: number; }
interface Coin { id: number; lane: Lane; z: number; y: number; collected: boolean; }

// ─── Player ───
function Player({ playerRef, isSliding, isJumping }: {
  playerRef: React.MutableRefObject<THREE.Group | null>;
  isSliding: boolean;
  isJumping: boolean;
}) {
  const legL = useRef<THREE.Mesh>(null);
  const legR = useRef<THREE.Mesh>(null);
  const armL = useRef<THREE.Mesh>(null);
  const armR = useRef<THREE.Mesh>(null);
  const body = useRef<THREE.Group>(null);

  useFrame((state) => {
    const t = state.clock.elapsedTime * 8;
    if (isJumping) {
      if (legL.current) legL.current.rotation.x = -0.6;
      if (legR.current) legR.current.rotation.x = -0.6;
      if (armL.current) armL.current.rotation.x = -1.4;
      if (armR.current) armR.current.rotation.x = -1.4;
    } else if (isSliding) {
      if (body.current) body.current.rotation.x = -1.2;
    } else {
      if (legL.current) legL.current.rotation.x = Math.sin(t) * 0.9;
      if (legR.current) legR.current.rotation.x = -Math.sin(t) * 0.9;
      if (armL.current) armL.current.rotation.x = -Math.sin(t) * 0.7;
      if (armR.current) armR.current.rotation.x = Math.sin(t) * 0.7;
      if (body.current) body.current.rotation.x = 0.08;
    }
  });

  return (
    <group ref={playerRef}>
      <group ref={body} scale={isSliding ? [1, 0.55, 1] : [1, 1, 1]}>
        {/* head */}
        <mesh position={[0, 1.55, 0]} castShadow>
          <sphereGeometry args={[0.28, 16, 16]} />
          <meshStandardMaterial color="#F4C7A1" />
        </mesh>
        {/* hair */}
        <mesh position={[0, 1.72, -0.05]} castShadow>
          <boxGeometry args={[0.5, 0.18, 0.5]} />
          <meshStandardMaterial color="#3D2B1F" />
        </mesh>
        {/* torso */}
        <mesh position={[0, 1.0, 0]} castShadow>
          <boxGeometry args={[0.6, 0.7, 0.35]} />
          <meshStandardMaterial color="#4A90D9" />
        </mesh>
        {/* arms (origin at shoulder) */}
        <mesh ref={armL} position={[-0.42, 1.25, 0]} castShadow>
          <boxGeometry args={[0.18, 0.65, 0.18]} />
          <meshStandardMaterial color="#4A90D9" />
        </mesh>
        <mesh ref={armR} position={[0.42, 1.25, 0]} castShadow>
          <boxGeometry args={[0.18, 0.65, 0.18]} />
          <meshStandardMaterial color="#4A90D9" />
        </mesh>
        {/* legs */}
        <mesh ref={legL} position={[-0.18, 0.45, 0]} castShadow>
          <boxGeometry args={[0.22, 0.7, 0.22]} />
          <meshStandardMaterial color="#2C3E50" />
        </mesh>
        <mesh ref={legR} position={[0.18, 0.45, 0]} castShadow>
          <boxGeometry args={[0.22, 0.7, 0.22]} />
          <meshStandardMaterial color="#2C3E50" />
        </mesh>
        {/* shoes */}
        <mesh position={[-0.18, 0.08, 0.04]}><boxGeometry args={[0.24, 0.12, 0.32]} /><meshStandardMaterial color="#E74C3C" /></mesh>
        <mesh position={[0.18, 0.08, 0.04]}><boxGeometry args={[0.24, 0.12, 0.32]} /><meshStandardMaterial color="#E74C3C" /></mesh>
      </group>
    </group>
  );
}

// ─── Track / Ground ───
function Track({ scrollZ }: { scrollZ: number }) {
  const groundRef = useRef<THREE.Mesh>(null);
  // Repeating ground via texture-less grid: just render long planes that wrap
  const segments = useMemo(() => Array.from({ length: VISIBLE_SEGMENTS }, (_, i) => i), []);
  return (
    <group>
      {/* Main ground */}
      <mesh rotation={[-Math.PI / 2, 0, 0]} position={[0, -0.01, 0]} receiveShadow>
        <planeGeometry args={[40, 600]} />
        <meshStandardMaterial color="#5b4636" />
      </mesh>
      {/* Rails + ties (3 lanes) */}
      {segments.map((s) => {
        const baseZ = ((s * SEGMENT_LENGTH - (scrollZ % SEGMENT_LENGTH)) - SEGMENT_LENGTH);
        return (
          <group key={s} position={[0, 0, baseZ]}>
            {LANE_X.map((lx, li) => (
              <group key={li} position={[lx, 0, 0]}>
                <mesh position={[-0.5, 0.06, SEGMENT_LENGTH / 2]}>
                  <boxGeometry args={[0.1, 0.12, SEGMENT_LENGTH]} />
                  <meshStandardMaterial color="#8a8f96" metalness={0.7} roughness={0.4} />
                </mesh>
                <mesh position={[0.5, 0.06, SEGMENT_LENGTH / 2]}>
                  <boxGeometry args={[0.1, 0.12, SEGMENT_LENGTH]} />
                  <meshStandardMaterial color="#8a8f96" metalness={0.7} roughness={0.4} />
                </mesh>
              </group>
            ))}
            {/* ties */}
            {Array.from({ length: 12 }).map((_, i) => (
              <mesh key={i} position={[0, 0.02, (i * SEGMENT_LENGTH) / 12 + 1]}>
                <boxGeometry args={[8, 0.08, 0.4]} />
                <meshStandardMaterial color="#3d2a1a" />
              </mesh>
            ))}
            {/* side walls with graffiti color blocks */}
            <mesh position={[-6, 1.5, SEGMENT_LENGTH / 2]} castShadow>
              <boxGeometry args={[0.5, 3, SEGMENT_LENGTH]} />
              <meshStandardMaterial color={s % 2 ? "#c0392b" : "#27ae60"} />
            </mesh>
            <mesh position={[6, 1.5, SEGMENT_LENGTH / 2]} castShadow>
              <boxGeometry args={[0.5, 3, SEGMENT_LENGTH]} />
              <meshStandardMaterial color={s % 2 ? "#2980b9" : "#f39c12"} />
            </mesh>
            {/* far buildings */}
            <mesh position={[-12, 5, SEGMENT_LENGTH / 2]}>
              <boxGeometry args={[3, 10, SEGMENT_LENGTH * 0.8]} />
              <meshStandardMaterial color="#7f8c8d" />
            </mesh>
            <mesh position={[12, 5, SEGMENT_LENGTH / 2]}>
              <boxGeometry args={[3, 10, SEGMENT_LENGTH * 0.8]} />
              <meshStandardMaterial color="#95a5a6" />
            </mesh>
          </group>
        );
      })}
    </group>
  );
}

// ─── Obstacle visuals ───
function ObstacleMesh({ ob }: { ob: Obstacle }) {
  const x = LANE_X[ob.lane];
  if (ob.kind === "train") {
    return (
      <group position={[x, 0, ob.z]}>
        <mesh position={[0, 1.2, 0]} castShadow>
          <boxGeometry args={[2, 2.4, ob.length]} />
          <meshStandardMaterial color="#e74c3c" metalness={0.3} roughness={0.5} />
        </mesh>
        {/* yellow stripe */}
        <mesh position={[0, 0.5, 0]}>
          <boxGeometry args={[2.05, 0.3, ob.length]} />
          <meshStandardMaterial color="#f1c40f" />
        </mesh>
        {/* windows */}
        {Array.from({ length: Math.max(2, Math.floor(ob.length / 2)) }).map((_, i) => (
          <mesh key={i} position={[1.01, 1.6, -ob.length / 2 + 1 + i * 2]}>
            <boxGeometry args={[0.05, 0.6, 0.8]} />
            <meshStandardMaterial color="#2c3e50" emissive="#3498db" emissiveIntensity={0.4} />
          </mesh>
        ))}
      </group>
    );
  }
  if (ob.kind === "barrier") {
    return (
      <group position={[x, 0, ob.z]}>
        <mesh position={[0, 0.5, 0]} castShadow>
          <boxGeometry args={[1.8, 1, 0.4]} />
          <meshStandardMaterial color="#f39c12" />
        </mesh>
        <mesh position={[0, 0.5, 0]}>
          <boxGeometry args={[1.85, 0.2, 0.42]} />
          <meshStandardMaterial color="#000" />
        </mesh>
      </group>
    );
  }
  // lowbar (slide under)
  return (
    <group position={[x, 0, ob.z]}>
      <mesh position={[-0.9, 1.2, 0]}><boxGeometry args={[0.15, 2.4, 0.15]} /><meshStandardMaterial color="#7f8c8d" /></mesh>
      <mesh position={[0.9, 1.2, 0]}><boxGeometry args={[0.15, 2.4, 0.15]} /><meshStandardMaterial color="#7f8c8d" /></mesh>
      <mesh position={[0, 1.7, 0]} castShadow>
        <boxGeometry args={[2, 0.3, 0.4]} />
        <meshStandardMaterial color="#e67e22" />
      </mesh>
    </group>
  );
}

function CoinMesh({ coin, time }: { coin: Coin; time: number }) {
  if (coin.collected) return null;
  return (
    <mesh position={[LANE_X[coin.lane], coin.y, coin.z]} rotation={[0, time * 4, 0]} castShadow>
      <cylinderGeometry args={[0.32, 0.32, 0.08, 16]} />
      <meshStandardMaterial color="#FFD700" metalness={0.9} roughness={0.2} emissive="#FFA500" emissiveIntensity={0.3} />
    </mesh>
  );
}

// ─── Main world inside Canvas ───
interface WorldProps {
  playing: boolean;
  onCoin: () => void;
  onCrash: () => void;
  onScoreTick: (delta: number) => void;
  speedRef: React.MutableRefObject<number>;
  inputRef: React.MutableRefObject<{ left: boolean; right: boolean; jump: boolean; slide: boolean }>;
}
function World({ playing, onCoin, onCrash, onScoreTick, speedRef, inputRef }: WorldProps) {
  const playerRef = useRef<THREE.Group | null>(null);
  const cameraGroupRef = useRef<THREE.Group | null>(null);
  const [obstacles, setObstacles] = useState<Obstacle[]>([]);
  const [coins, setCoins] = useState<Coin[]>([]);
  const [scrollZ, setScrollZ] = useState(0);
  const stateRef = useRef({
    laneIndex: 1 as Lane,
    targetLane: 1 as Lane,
    laneT: 0,
    laneFrom: 1 as Lane,
    y: 0,
    vy: 0,
    isJumping: false,
    sliding: false,
    slideTime: 0,
    spawnZ: 30,
    nextId: 1,
    crashed: false,
    time: 0,
  });

  // Reset on play start
  useEffect(() => {
    if (playing) {
      stateRef.current = { laneIndex: 1, targetLane: 1, laneT: 0, laneFrom: 1, y: 0, vy: 0, isJumping: false, sliding: false, slideTime: 0, spawnZ: 30, nextId: 1, crashed: false, time: 0 };
      setObstacles([]);
      setCoins([]);
      setScrollZ(0);
    }
  }, [playing]);

  // Spawn segment (one row of obstacles + a coin trail)
  const spawnSegment = useCallback((startZ: number) => {
    const newObs: Obstacle[] = [];
    const newCoins: Coin[] = [];
    const occupied = new Set<Lane>();
    // 1-2 obstacles per row, never block all 3 lanes
    const obsCount = Math.random() < 0.4 ? 2 : 1;
    for (let i = 0; i < obsCount; i++) {
      let lane: Lane;
      let attempts = 0;
      do { lane = Math.floor(Math.random() * 3) as Lane; attempts++; }
      while (occupied.has(lane) && attempts < 6);
      if (occupied.has(lane)) continue;
      occupied.add(lane);
      const r = Math.random();
      const kind: ObstacleKind = r < 0.45 ? "train" : r < 0.75 ? "barrier" : "lowbar";
      const length = kind === "train" ? 4 + Math.random() * 6 : 1;
      newObs.push({ id: stateRef.current.nextId++, kind, lane, z: startZ + (kind === "train" ? length / 2 : 0), length });
    }
    // Free lane coin trail
    const freeLanes: Lane[] = ([0, 1, 2] as Lane[]).filter(l => !occupied.has(l));
    if (freeLanes.length) {
      const coinLane = freeLanes[Math.floor(Math.random() * freeLanes.length)];
      const coinCount = 4 + Math.floor(Math.random() * 4);
      for (let i = 0; i < coinCount; i++) {
        newCoins.push({ id: stateRef.current.nextId++, lane: coinLane, z: startZ + i * 1.5, y: 1, collected: false });
      }
    }
    setObstacles(prev => [...prev, ...newObs]);
    setCoins(prev => [...prev, ...newCoins]);
  }, []);

  useFrame((three, dt) => {
    if (!playing || stateRef.current.crashed) return;
    const clamped = Math.min(dt, 0.05);
    const s = stateRef.current;
    s.time += clamped;
    const speed = speedRef.current;

    // Scroll
    setScrollZ(z => z + speed * clamped);
    onScoreTick(speed * clamped * 0.5);

    // Input handling
    const inp = inputRef.current;
    if (inp.left && s.targetLane === s.laneIndex && s.laneT === 0 && s.laneIndex > 0) {
      s.laneFrom = s.laneIndex; s.targetLane = (s.laneIndex - 1) as Lane; s.laneT = 0;
      inp.left = false;
    }
    if (inp.right && s.targetLane === s.laneIndex && s.laneT === 0 && s.laneIndex < 2) {
      s.laneFrom = s.laneIndex; s.targetLane = (s.laneIndex + 1) as Lane; s.laneT = 0;
      inp.right = false;
    }
    if (inp.jump && !s.isJumping && !s.sliding) {
      s.isJumping = true; s.vy = JUMP_VELOCITY;
      inp.jump = false;
    }
    if (inp.slide && !s.sliding && !s.isJumping) {
      s.sliding = true; s.slideTime = 0;
      inp.slide = false;
    }

    // Lane interpolation
    if (s.targetLane !== s.laneIndex || s.laneT > 0) {
      s.laneT += clamped / LANE_SWITCH_TIME;
      if (s.laneT >= 1) { s.laneT = 0; s.laneIndex = s.targetLane; }
    }
    const fromX = LANE_X[s.laneFrom];
    const toX = LANE_X[s.targetLane];
    const eased = 1 - Math.pow(1 - s.laneT, 3);
    const x = s.targetLane === s.laneIndex && s.laneT === 0 ? LANE_X[s.laneIndex] : fromX + (toX - fromX) * eased;

    // Vertical
    if (s.isJumping) {
      s.vy += GRAVITY * clamped;
      s.y += s.vy * clamped;
      if (s.y <= 0) { s.y = 0; s.vy = 0; s.isJumping = false; }
    }
    if (s.sliding) {
      s.slideTime += clamped;
      if (s.slideTime >= SLIDE_DURATION) s.sliding = false;
    }

    if (playerRef.current) {
      playerRef.current.position.set(x, s.y, 0);
    }
    // Camera follows
    if (cameraGroupRef.current) {
      cameraGroupRef.current.position.x = x * 0.3;
    }

    // Spawn obstacles ahead. spawnZ is in WORLD coords; we shift entities by -scrollZ when rendering.
    while (s.spawnZ < scrollZ + SPAWN_AHEAD) {
      spawnSegment(s.spawnZ);
      s.spawnZ += 8 + Math.random() * 4;
    }

    // Collision detection — convert obstacle world Z to local screen Z = ob.z - scrollZ
    const playerZ = 0;
    const playerHalfDepth = 0.4;
    const playerHalfWidth = 0.4;
    const playerTop = (s.sliding ? PLAYER_HEIGHT * 0.55 : PLAYER_HEIGHT) + s.y;
    const playerBottom = s.y;

    for (const ob of obstacles) {
      const localZ = ob.z - scrollZ;
      const halfL = ob.length / 2;
      if (localZ - halfL > playerZ + playerHalfDepth) continue;
      if (localZ + halfL < playerZ - playerHalfDepth) continue;
      const obX = LANE_X[ob.lane];
      if (Math.abs(obX) > 4) continue;
      // Same lane (or close)
      if (Math.abs(obX - x) > 1.2) continue;
      let hit = false;
      if (ob.kind === "train") {
        if (playerBottom < 2.4) hit = true; // can't clear easily; player must be in another lane
      } else if (ob.kind === "barrier") {
        if (playerBottom < 1.0) hit = true; // jump over
      } else if (ob.kind === "lowbar") {
        if (playerTop > 1.5) hit = true; // slide under
      }
      if (hit) { s.crashed = true; onCrash(); return; }
    }

    // Coin collection
    setCoins(prev => {
      let changed = false;
      const next = prev.map(c => {
        if (c.collected) return c;
        const localZ = c.z - scrollZ;
        if (Math.abs(localZ) < 0.6 && Math.abs(LANE_X[c.lane] - x) < 1 && Math.abs(c.y - (s.y + 0.8)) < 1.2) {
          changed = true;
          onCoin();
          return { ...c, collected: true };
        }
        return c;
      });
      return changed ? next : prev;
    });

    // Despawn
    setObstacles(prev => prev.filter(ob => ob.z - scrollZ > -DESPAWN_BEHIND));
    setCoins(prev => prev.filter(c => c.z - scrollZ > -DESPAWN_BEHIND && !c.collected));
  });

  return (
    <>
      <ambientLight intensity={0.6} />
      <directionalLight position={[10, 20, 5]} intensity={1.2} castShadow />
      <hemisphereLight args={["#bfe9ff", "#3a3a4a", 0.5]} />
      <group ref={cameraGroupRef}>
        <Track scrollZ={scrollZ} />
        <Player playerRef={playerRef} isSliding={stateRef.current.sliding} isJumping={stateRef.current.isJumping} />
        {obstacles.map(ob => (
          <group key={ob.id} position={[0, 0, -scrollZ]}>
            <ObstacleMesh ob={ob} />
          </group>
        ))}
        {coins.map(c => (
          <group key={c.id} position={[0, 0, -scrollZ]}>
            <CoinMesh coin={c} time={stateRef.current.time} />
          </group>
        ))}
      </group>
    </>
  );
}

// ─── Top-level component with HUD ───
interface SubwayRunnerProps { onBack?: () => void; }
export default function SubwayRunner({ onBack }: SubwayRunnerProps) {
  const [phase, setPhase] = useState<"menu" | "playing" | "paused" | "over">("menu");
  const [score, setScore] = useState(0);
  const [coins, setCoins] = useState(0);
  const [highScore, setHighScore] = useState<number>(() => {
    return Number(localStorage.getItem("subway_high") || 0);
  });
  const [leaderboard, setLeaderboard] = useState<Array<{ name: string; score: number }>>([]);
  const speedRef = useRef(BASE_SPEED);
  const inputRef = useRef({ left: false, right: false, jump: false, slide: false });
  const scoreRef = useRef(0);
  const coinsRef = useRef(0);
  const submittedRef = useRef(false);

  // Speed ramp
  useEffect(() => {
    if (phase !== "playing") return;
    const id = window.setInterval(() => {
      speedRef.current = Math.min(MAX_SPEED, speedRef.current + 0.4);
    }, 1000);
    return () => window.clearInterval(id);
  }, [phase]);

  // Keyboard input
  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if (phase !== "playing") return;
      const k = e.key;
      if (k === "ArrowLeft" || k === "a" || k === "A") inputRef.current.left = true;
      else if (k === "ArrowRight" || k === "d" || k === "D") inputRef.current.right = true;
      else if (k === "ArrowUp" || k === "w" || k === "W" || k === " ") { inputRef.current.jump = true; e.preventDefault(); }
      else if (k === "ArrowDown" || k === "s" || k === "S") inputRef.current.slide = true;
      else if (k === "Escape" || k === "p" || k === "P") setPhase("paused");
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [phase]);

  // Touch swipes
  useEffect(() => {
    let sx = 0, sy = 0, st = 0;
    const start = (e: TouchEvent) => { const t = e.touches[0]; sx = t.clientX; sy = t.clientY; st = Date.now(); };
    const end = (e: TouchEvent) => {
      if (phase !== "playing") return;
      const t = e.changedTouches[0]; const dx = t.clientX - sx; const dy = t.clientY - sy;
      const ax = Math.abs(dx), ay = Math.abs(dy);
      if (ax < 20 && ay < 20 && Date.now() - st < 250) { inputRef.current.jump = true; return; }
      if (ax > ay) { if (dx > 0) inputRef.current.right = true; else inputRef.current.left = true; }
      else { if (dy > 0) inputRef.current.slide = true; else inputRef.current.jump = true; }
    };
    window.addEventListener("touchstart", start);
    window.addEventListener("touchend", end);
    return () => { window.removeEventListener("touchstart", start); window.removeEventListener("touchend", end); };
  }, [phase]);

  const handleScoreTick = useCallback((delta: number) => {
    scoreRef.current += delta;
    setScore(Math.floor(scoreRef.current));
  }, []);
  const handleCoin = useCallback(() => {
    coinsRef.current += 1;
    scoreRef.current += 10;
    setCoins(coinsRef.current);
    setScore(Math.floor(scoreRef.current));
  }, []);
  const handleCrash = useCallback(async () => {
    setPhase("over");
    const finalScore = Math.floor(scoreRef.current);
    if (finalScore > highScore) {
      setHighScore(finalScore);
      localStorage.setItem("subway_high", String(finalScore));
    }
    if (submittedRef.current) return;
    submittedRef.current = true;
    const { data: { user } } = await supabase.auth.getUser();
    if (user && finalScore > 0) {
      try {
        await supabase.rpc("submit_game_score", {
          _game_type: "subway", _mode: "single", _score: finalScore,
        });
      } catch (e) { console.error(e); }
    }
    fetchLeaderboard();
  }, [highScore]);

  const fetchLeaderboard = useCallback(async () => {
    const { data } = await supabase
      .from("game_leaderboards")
      .select("score, user_id")
      .eq("game_type", "subway")
      .order("score", { ascending: false })
      .limit(200);
    if (!data?.length) { setLeaderboard([]); return; }
    // Keep only the best score per user
    const bestByUser = new Map<string, number>();
    for (const row of data) {
      const prev = bestByUser.get(row.user_id) ?? -Infinity;
      if (Number(row.score) > prev) bestByUser.set(row.user_id, Number(row.score));
    }
    const top = Array.from(bestByUser.entries())
      .sort((a, b) => b[1] - a[1])
      .slice(0, 10);
    const ids = top.map(([uid]) => uid);
    const { data: profs } = await supabase.from("profiles").select("user_id, name").in("user_id", ids);
    const nameMap: Record<string, string> = {};
    profs?.forEach(p => { nameMap[p.user_id] = p.name; });
    setLeaderboard(top.map(([uid, score]) => ({ name: nameMap[uid] || "Player", score })));
  }, []);

  useEffect(() => { fetchLeaderboard(); }, [fetchLeaderboard]);

  const start = () => {
    speedRef.current = BASE_SPEED;
    scoreRef.current = 0; coinsRef.current = 0;
    setScore(0); setCoins(0);
    submittedRef.current = false;
    setPhase("playing");
  };

  return (
    <div className="w-full max-w-5xl mx-auto space-y-3">
      {onBack && (
        <Button variant="ghost" size="sm" onClick={onBack} className="gap-2">
          <ArrowLeft className="h-4 w-4" /> Back
        </Button>
      )}
      <div className="relative w-full aspect-[16/10] rounded-lg overflow-hidden border-2 border-border shadow-xl bg-gradient-to-b from-sky-300 to-sky-100">
        <Canvas shadows camera={{ position: [0, 4, -7], fov: 65 }} dpr={[1, 1.5]}>
          <Suspense fallback={null}>
            <Sky sunPosition={[100, 20, 100]} />
            <fog attach="fog" args={["#cfe7f5", 30, 110]} />
            <PerspectiveCameraRig />
            <World
              playing={phase === "playing"}
              onCoin={handleCoin}
              onCrash={handleCrash}
              onScoreTick={handleScoreTick}
              speedRef={speedRef}
              inputRef={inputRef}
            />
          </Suspense>
        </Canvas>

        {/* HUD */}
        <div className="absolute top-3 left-3 flex flex-col gap-1.5 pointer-events-none">
          <div className="bg-background/80 backdrop-blur rounded-lg px-3 py-1.5 shadow font-bold text-foreground">
            Score: {score}
          </div>
          <div className="bg-yellow-500/90 text-black rounded-lg px-3 py-1.5 shadow font-bold flex items-center gap-1.5">
            <Coins className="h-4 w-4" /> {coins}
          </div>
        </div>
        <div className="absolute top-3 right-3 bg-background/80 backdrop-blur rounded-lg px-3 py-1.5 shadow font-bold text-foreground pointer-events-none">
          High: {highScore}
        </div>

        {/* Pause button */}
        {phase === "playing" && (
          <Button size="sm" variant="secondary" className="absolute bottom-3 right-3" onClick={() => setPhase("paused")}>
            <Pause className="h-4 w-4" />
          </Button>
        )}

        {/* Menu / Game Over overlay */}
        {(phase === "menu" || phase === "over" || phase === "paused") && (
          <div className="absolute inset-0 bg-black/60 backdrop-blur-sm flex items-center justify-center p-4">
            <Card className="max-w-md w-full">
              <CardContent className="p-6 space-y-4 text-center">
                {phase === "menu" && (
                  <>
                    <h2 className="text-2xl font-bold">🚇 Subway Runner</h2>
                    <p className="text-sm text-muted-foreground">
                      Dodge trains, collect coins, survive as long as you can.<br/>
                      <span className="text-foreground font-medium">← → / A D</span>: lane change ·
                      <span className="text-foreground font-medium"> ↑ / Space</span>: jump ·
                      <span className="text-foreground font-medium"> ↓ / S</span>: slide
                    </p>
                    <Button size="lg" onClick={start} className="w-full gap-2">
                      <Play className="h-4 w-4" /> Start
                    </Button>
                  </>
                )}
                {phase === "paused" && (
                  <>
                    <h2 className="text-2xl font-bold">Paused</h2>
                    <Button size="lg" onClick={() => setPhase("playing")} className="w-full gap-2">
                      <Play className="h-4 w-4" /> Resume
                    </Button>
                    <Button variant="outline" onClick={() => setPhase("menu")} className="w-full">
                      Back to Menu
                    </Button>
                  </>
                )}
                {phase === "over" && (
                  <>
                    <h2 className="text-2xl font-bold">💥 Game Over</h2>
                    <div className="grid grid-cols-2 gap-3">
                      <div className="bg-muted rounded-lg p-3">
                        <div className="text-xs text-muted-foreground">Score</div>
                        <div className="text-2xl font-bold">{score}</div>
                      </div>
                      <div className="bg-muted rounded-lg p-3">
                        <div className="text-xs text-muted-foreground">Coins</div>
                        <div className="text-2xl font-bold text-yellow-600">{coins}</div>
                      </div>
                    </div>
                    {score >= highScore && score > 0 && (
                      <div className="text-sm font-bold text-primary">🏆 New High Score!</div>
                    )}
                    <Button size="lg" onClick={start} className="w-full gap-2">
                      <RotateCcw className="h-4 w-4" /> Play Again
                    </Button>
                  </>
                )}
              </CardContent>
            </Card>
          </div>
        )}
      </div>

      {/* Leaderboard */}
      <Card className="glass-card">
        <CardContent className="p-4">
          <div className="flex items-center gap-2 mb-3">
            <Trophy className="h-5 w-5 text-yellow-500" />
            <h3 className="font-bold">Top 10 Runners</h3>
          </div>
          {leaderboard.length === 0 ? (
            <p className="text-sm text-muted-foreground text-center py-3">No scores yet — be the first!</p>
          ) : (
            <div className="space-y-1">
              {leaderboard.map((row, i) => (
                <div key={i} className="flex items-center justify-between px-3 py-1.5 rounded bg-muted/50">
                  <div className="flex items-center gap-2">
                    <span className={`font-bold w-6 ${i === 0 ? "text-yellow-500" : i === 1 ? "text-gray-400" : i === 2 ? "text-orange-500" : "text-muted-foreground"}`}>
                      {i + 1}
                    </span>
                    <span className="font-medium">{row.name}</span>
                  </div>
                  <span className="font-bold tabular-nums">{row.score.toLocaleString()}</span>
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}

// Camera rig — slight follow / shake
function PerspectiveCameraRig() {
  useFrame(({ camera }) => {
    camera.lookAt(0, 1.2, 8);
  });
  return null;
}
