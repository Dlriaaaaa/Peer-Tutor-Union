import { useState, useRef, useEffect, useCallback } from "react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";

const W = 800, H = 440;
const BALL_R = 11;
const POCKET_R = 23;
const FRICTION = 0.985;
const MIN_V = 0.1;
const MAX_POWER = 32;
const CUE_LENGTH = 240;
const CUE_OFFSET = 16;
const RAIL = 28;

type Ball = {
  id: number; x: number; y: number; vx: number; vy: number;
  color: string; pocketed: boolean; type: "solid" | "stripe" | "cue" | "eight";
  rotAngle: number; // rolling rotation angle
  rotAxis: { x: number; y: number }; // axis of rotation for visual
};

const POCKETS = [
  { x: RAIL, y: RAIL },
  { x: W / 2, y: RAIL - 4 },
  { x: W - RAIL, y: RAIL },
  { x: RAIL, y: H - RAIL },
  { x: W / 2, y: H - RAIL + 4 },
  { x: W - RAIL, y: H - RAIL },
];

const BALL_COLORS: { color: string; type: "solid" | "stripe" }[] = [
  { color: "#FFD700", type: "solid" },   // 1
  { color: "#0044CC", type: "solid" },   // 2
  { color: "#CC0000", type: "solid" },   // 3
  { color: "#6B0099", type: "solid" },   // 4
  { color: "#FF6600", type: "solid" },   // 5
  { color: "#007700", type: "solid" },   // 6
  { color: "#8B1A1A", type: "solid" },   // 7
  { color: "#FF4081", type: "stripe" },  // 9
  { color: "#FFD700", type: "stripe" },  // 10
  { color: "#0044CC", type: "stripe" },  // 11
  { color: "#CC0000", type: "stripe" },  // 12
  { color: "#6B0099", type: "stripe" },  // 13
  { color: "#FF6600", type: "stripe" },  // 14
  { color: "#007700", type: "stripe" },  // 15
];

function createBalls(): Ball[] {
  const balls: Ball[] = [];
  const defBall = { vx: 0, vy: 0, pocketed: false, rotAngle: 0, rotAxis: { x: 0, y: 1 } };
  balls.push({ id: 0, x: 240, y: H / 2, color: "#FFFEF6", type: "cue", ...defBall });

  const startX = 560, startY = H / 2;
  const rackOrder = [0, 1, 2, 3, -1, 7, 4, 5, 8, 6, 9, 10, 11, 12, 13];
  let idx = 0;
  for (let row = 0; row < 5; row++) {
    const count = row + 1;
    for (let col = 0; col < count; col++) {
      const x = startX + row * (BALL_R * 2 + 0.5);
      const y = startY + (col - (count - 1) / 2) * (BALL_R * 2 + 0.5);
      const ri = rackOrder[idx++];
      if (ri === -1) {
        balls.push({ id: 8, x, y, color: "#111111", type: "eight", ...defBall });
      } else {
        const bc = BALL_COLORS[ri];
        balls.push({ id: ri < 7 ? ri + 1 : ri + 2, x, y, color: bc.color, type: bc.type, ...defBall });
      }
    }
  }
  return balls;
}

function isMoving(balls: Ball[]): boolean {
  return balls.some(b => !b.pocketed && (Math.abs(b.vx) > MIN_V || Math.abs(b.vy) > MIN_V));
}

type BilliardsAssignments = {
  1: "solid" | "stripe" | null;
  2: "solid" | "stripe" | null;
};

type BilliardsSnapshot = {
  balls: Ball[];
  turn: 1 | 2;
  assignments: BilliardsAssignments;
  message: string;
  gameOver: boolean;
  placingCue: boolean;
  foul: boolean;
};

function createDefaultAssignments(): BilliardsAssignments {
  return { 1: null, 2: null };
}

function cloneBalls(balls: Ball[]): Ball[] {
  return balls.map((ball) => ({ ...ball, rotAxis: { ...ball.rotAxis } }));
}

function createInitialBilliardsState(): BilliardsSnapshot {
  return {
    balls: createBalls(),
    turn: 1,
    assignments: createDefaultAssignments(),
    message: "",
    gameOver: false,
    placingCue: false,
    foul: false,
  };
}

function normalizeBilliardsState(state: any): BilliardsSnapshot {
  const initial = createInitialBilliardsState();
  return {
    balls: Array.isArray(state?.balls) ? cloneBalls(state.balls) : initial.balls,
    turn: state?.turn === 2 ? 2 : 1,
    assignments: {
      1: state?.assignments?.[1] ?? null,
      2: state?.assignments?.[2] ?? null,
    },
    message: typeof state?.message === "string" ? state.message : "",
    gameOver: Boolean(state?.gameOver),
    placingCue: Boolean(state?.placingCue),
    foul: Boolean(state?.foul),
  };
}

interface BilliardsGameProps {
  online?: boolean;
  myColor?: string;
  gameState?: any;
  onMove?: (state: any) => void;
  isMyTurn?: boolean;
  playerNames?: { me: string; opponent: string };
}

export default function BilliardsGame({ online, myColor, gameState, onMove, isMyTurn, playerNames }: BilliardsGameProps) {
  const initialState = normalizeBilliardsState(gameState);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [balls, setBalls] = useState<Ball[]>(() => (online ? initialState.balls : createBalls()));
  const [turn, setTurn] = useState<1 | 2>(() => (online ? initialState.turn : 1));
  const [aiming, setAiming] = useState(false);
  const [aimLocked, setAimLocked] = useState(false); // direction locked, adjusting power
  const [aimPos, setAimPos] = useState({ x: 0, y: 0 });
  const [lockedAimPos, setLockedAimPos] = useState({ x: 0, y: 0 }); // locked direction
  const [power, setPower] = useState(10);
  const [moving, setMoving] = useState(false);
  const [assignments, setAssignments] = useState<BilliardsAssignments>(() => (online ? initialState.assignments : createDefaultAssignments()));
  const [message, setMessage] = useState(() => (online ? initialState.message : ""));
  const [gameOver, setGameOver] = useState(() => (online ? initialState.gameOver : false));
  const [placingCue, setPlacingCue] = useState(() => (online ? initialState.placingCue : false));
  const [foul, setFoul] = useState(() => (online ? initialState.foul : false));
  const [draggingPower, setDraggingPower] = useState(false);
  const animRef = useRef<number>(0);
  const ballsRef = useRef(balls);
  ballsRef.current = balls;
  const turnRef = useRef(turn);
  turnRef.current = turn;
  const assignRef = useRef(assignments);
  assignRef.current = assignments;
  const pocketedThisTurnRef = useRef<Ball[]>([]);
  const firstHitTypeRef = useRef<string | null>(null);
  const processTurnEndRef = useRef<(bs: Ball[]) => void>(() => {});

  const lastSyncRef = useRef<string>("");
  useEffect(() => {
    if (!online) return;
    const stateStr = JSON.stringify(gameState);
    if (stateStr === lastSyncRef.current) return; // no actual change
    lastSyncRef.current = stateStr;

    const syncedState = normalizeBilliardsState(gameState);
    const turnChanged = syncedState.turn !== turnRef.current;
    setBalls(syncedState.balls);
    ballsRef.current = syncedState.balls;
    setTurn(syncedState.turn);
    turnRef.current = syncedState.turn;
    setAssignments(syncedState.assignments);
    assignRef.current = syncedState.assignments;
    setMessage(syncedState.message);
    setGameOver(syncedState.gameOver);
    setPlacingCue(syncedState.placingCue);
    setFoul(syncedState.foul);
    setMoving(false);
    // Only reset aiming if turn actually changed (opponent moved)
    if (turnChanged) {
      setAiming(false);
      setAimLocked(false);
    }
  }, [online, gameState]);

  const myTurnNum: 1 | 2 = myColor === "white" ? 2 : 1;
  const isActiveTurn = !online || turn === myTurnNum;

  const applySnapshot = useCallback((snapshot: BilliardsSnapshot) => {
    const clonedBalls = cloneBalls(snapshot.balls);
    setBalls(clonedBalls);
    ballsRef.current = clonedBalls;
    setTurn(snapshot.turn);
    turnRef.current = snapshot.turn;
    setAssignments(snapshot.assignments);
    assignRef.current = snapshot.assignments;
    setMessage(snapshot.message);
    setGameOver(snapshot.gameOver);
    setPlacingCue(snapshot.placingCue);
    setFoul(snapshot.foul);
  }, []);

  const publishOnlineState = useCallback((snapshot: BilliardsSnapshot) => {
    if (!online || !onMove) return;
    onMove({
      balls: cloneBalls(snapshot.balls),
      turn: snapshot.turn,
      assignments: { ...snapshot.assignments },
      message: snapshot.message,
      gameOver: snapshot.gameOver,
      placingCue: snapshot.placingCue,
      foul: snapshot.foul,
    });
  }, [online, onMove]);

  // 3D-style ball drawing
  const drawBall = useCallback((ctx: CanvasRenderingContext2D, b: Ball) => {
    if (b.pocketed) return;
    const r = BALL_R;

    // Shadow (offset for 3D depth)
    ctx.beginPath();
    ctx.ellipse(b.x + 3, b.y + 4, r * 0.9, r * 0.5, 0, 0, Math.PI * 2);
    ctx.fillStyle = "rgba(0,0,0,0.35)";
    ctx.fill();

    // Main sphere gradient
    const grad = ctx.createRadialGradient(b.x - r * 0.3, b.y - r * 0.35, r * 0.1, b.x, b.y, r);
    if (b.type === "cue") {
      grad.addColorStop(0, "#FFFFFF");
      grad.addColorStop(0.7, "#E8E4D8");
      grad.addColorStop(1, "#B0ACA0");
    } else {
      grad.addColorStop(0, lightenColor(b.color, 60));
      grad.addColorStop(0.5, b.color);
      grad.addColorStop(1, darkenColor(b.color, 50));
    }
    ctx.beginPath();
    ctx.arc(b.x, b.y, r, 0, Math.PI * 2);
    ctx.fillStyle = grad;
    ctx.fill();

    // Stripe band with rolling effect
    if (b.type === "stripe") {
      ctx.save();
      ctx.beginPath();
      ctx.arc(b.x, b.y, r, 0, Math.PI * 2);
      ctx.clip();
      // Rotate the stripe band based on ball rotation
      const bandOffset = Math.sin(b.rotAngle * 0.5) * 3;
      ctx.fillStyle = "rgba(255,255,255,0.85)";
      ctx.fillRect(b.x - r, b.y - 4 + bandOffset, r * 2, 8);
      ctx.restore();
    }

    // Number circle (with rotation offset for rolling feel)
    if (b.type !== "cue") {
      const numOffX = Math.sin(b.rotAngle * 0.3) * 2;
      const numOffY = Math.cos(b.rotAngle * 0.3) * 1;
      ctx.beginPath();
      ctx.arc(b.x + numOffX, b.y + numOffY, 5.5, 0, Math.PI * 2);
      ctx.fillStyle = b.type === "eight" ? "#222" : "#FFFFFF";
      ctx.fill();
      ctx.fillStyle = b.type === "eight" ? "#FFF" : "#000";
      ctx.font = "bold 7px 'Inter', sans-serif";
      ctx.textAlign = "center";
      ctx.textBaseline = "middle";
      ctx.fillText(String(b.id), b.x + numOffX, b.y + numOffY + 0.5);
    }

    // Specular highlight
    const specGrad = ctx.createRadialGradient(b.x - r * 0.35, b.y - r * 0.35, 0, b.x - r * 0.2, b.y - r * 0.2, r * 0.6);
    specGrad.addColorStop(0, "rgba(255,255,255,0.7)");
    specGrad.addColorStop(0.4, "rgba(255,255,255,0.15)");
    specGrad.addColorStop(1, "rgba(255,255,255,0)");
    ctx.beginPath();
    ctx.arc(b.x, b.y, r, 0, Math.PI * 2);
    ctx.fillStyle = specGrad;
    ctx.fill();

    // Rim edge
    ctx.beginPath();
    ctx.arc(b.x, b.y, r, 0, Math.PI * 2);
    ctx.strokeStyle = "rgba(0,0,0,0.2)";
    ctx.lineWidth = 0.5;
    ctx.stroke();
  }, []);

  const draw = useCallback((ctx: CanvasRenderingContext2D, bs: Ball[], aimData?: { cueBall: Ball; aimX: number; aimY: number; pwr: number }) => {
    // === TABLE BACKGROUND ===
    // Outer wood frame with grain effect
    const woodGrad = ctx.createLinearGradient(0, 0, W, H);
    woodGrad.addColorStop(0, "#5c3316");
    woodGrad.addColorStop(0.2, "#7a4a2a");
    woodGrad.addColorStop(0.5, "#6b3d1f");
    woodGrad.addColorStop(0.8, "#7a4a2a");
    woodGrad.addColorStop(1, "#5c3316");
    ctx.fillStyle = woodGrad;
    ctx.fillRect(0, 0, W, H);

    // Wood grain lines
    ctx.strokeStyle = "rgba(0,0,0,0.08)";
    ctx.lineWidth = 0.5;
    for (let i = 0; i < 40; i++) {
      const y = i * (H / 40) + Math.sin(i * 0.7) * 3;
      ctx.beginPath();
      ctx.moveTo(0, y);
      for (let x = 0; x < W; x += 20) {
        ctx.lineTo(x, y + Math.sin(x * 0.01 + i) * 2);
      }
      ctx.stroke();
    }

    // Inner rail (cushion) - darker wood
    const railInset = 8;
    ctx.fillStyle = "#4a2a0e";
    ctx.fillRect(railInset, railInset, W - railInset * 2, RAIL - railInset);
    ctx.fillRect(railInset, H - RAIL, W - railInset * 2, RAIL - railInset);
    ctx.fillRect(railInset, railInset, RAIL - railInset, H - railInset * 2);
    ctx.fillRect(W - RAIL, railInset, RAIL - railInset, H - railInset * 2);

    // Cushion rubber (green bumper edge)
    ctx.fillStyle = "#2d7a3e";
    const cInset = RAIL - 4;
    ctx.fillRect(RAIL + POCKET_R + 5, cInset, W / 2 - RAIL - POCKET_R * 2 - 5, 5);
    ctx.fillRect(W / 2 + POCKET_R + 5, cInset, W / 2 - RAIL - POCKET_R * 2 - 5, 5);
    ctx.fillRect(RAIL + POCKET_R + 5, H - cInset - 5, W / 2 - RAIL - POCKET_R * 2 - 5, 5);
    ctx.fillRect(W / 2 + POCKET_R + 5, H - cInset - 5, W / 2 - RAIL - POCKET_R * 2 - 5, 5);
    ctx.fillRect(cInset, RAIL + POCKET_R + 5, 5, H - 2 * RAIL - 2 * POCKET_R - 10);
    ctx.fillRect(W - cInset - 5, RAIL + POCKET_R + 5, 5, H - 2 * RAIL - 2 * POCKET_R - 10);

    // Felt playing surface with subtle texture
    const feltGrad = ctx.createRadialGradient(W / 2, H / 2, 50, W / 2, H / 2, W * 0.6);
    feltGrad.addColorStop(0, "#1d8044");
    feltGrad.addColorStop(1, "#166b38");
    ctx.fillStyle = feltGrad;
    ctx.fillRect(RAIL, RAIL, W - RAIL * 2, H - RAIL * 2);

    // Felt texture noise (subtle)
    ctx.fillStyle = "rgba(0,0,0,0.02)";
    for (let i = 0; i < 200; i++) {
      const fx = RAIL + Math.random() * (W - 2 * RAIL);
      const fy = RAIL + Math.random() * (H - 2 * RAIL);
      ctx.fillRect(fx, fy, 2, 1);
    }

    // Diamond markers on rails
    ctx.fillStyle = "#d4a84a";
    for (let i = 1; i <= 3; i++) {
      const xm = RAIL + i * (W - 2 * RAIL) / 4;
      ctx.beginPath(); ctx.arc(xm, 13, 3.5, 0, Math.PI * 2); ctx.fill();
      ctx.beginPath(); ctx.arc(xm, H - 13, 3.5, 0, Math.PI * 2); ctx.fill();
    }
    for (let i = 1; i <= 2; i++) {
      const ym = RAIL + i * (H - 2 * RAIL) / 3;
      ctx.beginPath(); ctx.arc(13, ym, 3.5, 0, Math.PI * 2); ctx.fill();
      ctx.beginPath(); ctx.arc(W - 13, ym, 3.5, 0, Math.PI * 2); ctx.fill();
    }

    // Head string line
    ctx.setLineDash([5, 7]);
    ctx.strokeStyle = "rgba(255,255,255,0.1)";
    ctx.lineWidth = 1;
    ctx.beginPath(); ctx.moveTo(280, RAIL + 2); ctx.lineTo(280, H - RAIL - 2); ctx.stroke();
    ctx.setLineDash([]);

    // Foot spot
    ctx.beginPath();
    ctx.arc(620, H / 2, 3, 0, Math.PI * 2);
    ctx.fillStyle = "rgba(255,255,255,0.15)";
    ctx.fill();

    // === POCKETS ===
    for (const p of POCKETS) {
      // Pocket shadow
      ctx.beginPath();
      ctx.arc(p.x, p.y, POCKET_R + 4, 0, Math.PI * 2);
      ctx.fillStyle = "rgba(0,0,0,0.3)";
      ctx.fill();
      // Pocket hole
      const pGrad = ctx.createRadialGradient(p.x, p.y, 0, p.x, p.y, POCKET_R);
      pGrad.addColorStop(0, "#000000");
      pGrad.addColorStop(0.7, "#0a0a0a");
      pGrad.addColorStop(1, "#1a1200");
      ctx.beginPath();
      ctx.arc(p.x, p.y, POCKET_R, 0, Math.PI * 2);
      ctx.fillStyle = pGrad;
      ctx.fill();
      // Pocket rim
      ctx.beginPath();
      ctx.arc(p.x, p.y, POCKET_R + 1, 0, Math.PI * 2);
      ctx.strokeStyle = "#3a2a10";
      ctx.lineWidth = 2.5;
      ctx.stroke();
    }

    // === BALLS ===
    // Sort by y for depth ordering
    const sortedBalls = [...bs].filter(b => !b.pocketed).sort((a, bx) => a.y - bx.y);
    for (const b of sortedBalls) {
      drawBall(ctx, b);
    }

    // Placing cue ball indicator
    if (placingCue) {
      ctx.beginPath();
      ctx.arc(aimData?.aimX || 240, aimData?.aimY || H / 2, BALL_R + 5, 0, Math.PI * 2);
      ctx.strokeStyle = "rgba(255,255,255,0.7)";
      ctx.lineWidth = 2;
      ctx.setLineDash([4, 4]);
      ctx.stroke();
      ctx.setLineDash([]);
    }

    // === CUE STICK + AIM LINE ===
    if (aimData && !placingCue) {
      const { cueBall, aimX, aimY, pwr } = aimData;
      const dx = cueBall.x - aimX, dy = cueBall.y - aimY;
      const dist = Math.sqrt(dx * dx + dy * dy);
      if (dist > 5) {
        const nx = dx / dist, ny = dy / dist;

        // Aim line (brighter, more visible)
        let lineLen = 600;
        for (const ob of bs) {
          if (ob.pocketed || ob.id === 0) continue;
          const tx = ob.x - cueBall.x, ty = ob.y - cueBall.y;
          const proj = tx * nx + ty * ny;
          if (proj > 0) {
            const perpDist = Math.abs(tx * ny - ty * nx);
            if (perpDist < BALL_R * 2) {
              lineLen = Math.min(lineLen, proj - BALL_R);
            }
          }
        }

        // Bright aim line
        ctx.setLineDash([4, 6]);
        ctx.beginPath();
        ctx.moveTo(cueBall.x + nx * (BALL_R + 2), cueBall.y + ny * (BALL_R + 2));
        ctx.lineTo(cueBall.x + nx * Math.max(lineLen, BALL_R + 5), cueBall.y + ny * Math.max(lineLen, BALL_R + 5));
        ctx.strokeStyle = "rgba(255,255,255,0.75)";
        ctx.lineWidth = 1.5;
        ctx.stroke();
        ctx.setLineDash([]);

        // Ghost ball at collision
        for (const ob of bs) {
          if (ob.pocketed || ob.id === 0) continue;
          const tx = ob.x - cueBall.x, ty = ob.y - cueBall.y;
          const proj = tx * nx + ty * ny;
          if (proj > 0) {
            const perpDist = Math.abs(tx * ny - ty * nx);
            if (perpDist < BALL_R * 2 && proj - BALL_R <= lineLen + 5) {
              const gx = cueBall.x + nx * (proj - BALL_R * 2);
              const gy = cueBall.y + ny * (proj - BALL_R * 2);
              ctx.beginPath();
              ctx.arc(gx, gy, BALL_R, 0, Math.PI * 2);
              ctx.strokeStyle = "rgba(255,255,255,0.4)";
              ctx.lineWidth = 1.5;
              ctx.stroke();

              // Projected target direction
              const hitNx = (ob.x - gx), hitNy = (ob.y - gy);
              const hitDist = Math.sqrt(hitNx * hitNx + hitNy * hitNy);
              if (hitDist > 0) {
                const hnx = hitNx / hitDist, hny = hitNy / hitDist;
                ctx.setLineDash([3, 5]);
                ctx.beginPath();
                ctx.moveTo(ob.x, ob.y);
                ctx.lineTo(ob.x + hnx * 50, ob.y + hny * 50);
                ctx.strokeStyle = "rgba(255,200,100,0.35)";
                ctx.lineWidth = 1;
                ctx.stroke();
                ctx.setLineDash([]);
              }
              break;
            }
          }
        }

        // Cue stick
        const pullBack = CUE_OFFSET + (pwr / MAX_POWER) * 50;
        const cueStartX = cueBall.x - nx * pullBack;
        const cueStartY = cueBall.y - ny * pullBack;
        const cueEndX = cueStartX - nx * CUE_LENGTH;
        const cueEndY = cueStartY - ny * CUE_LENGTH;

        // Shadow
        ctx.beginPath();
        ctx.moveTo(cueStartX + 2, cueStartY + 3);
        ctx.lineTo(cueEndX + 2, cueEndY + 3);
        ctx.strokeStyle = "rgba(0,0,0,0.25)";
        ctx.lineWidth = 7;
        ctx.lineCap = "round";
        ctx.stroke();

        // Cue body
        const cueGrad = ctx.createLinearGradient(cueStartX, cueStartY, cueEndX, cueEndY);
        cueGrad.addColorStop(0, "#f5deb3");
        cueGrad.addColorStop(0.08, "#e8d5a0");
        cueGrad.addColorStop(0.15, "#c4a35a");
        cueGrad.addColorStop(0.5, "#8B6914");
        cueGrad.addColorStop(0.85, "#5a3a08");
        cueGrad.addColorStop(1, "#2a1500");
        ctx.beginPath();
        ctx.moveTo(cueStartX, cueStartY);
        ctx.lineTo(cueEndX, cueEndY);
        ctx.strokeStyle = cueGrad;
        ctx.lineWidth = 5;
        ctx.lineCap = "round";
        ctx.stroke();

        // Wrap/ring near butt
        const wrapX = cueStartX - nx * CUE_LENGTH * 0.6;
        const wrapY = cueStartY - ny * CUE_LENGTH * 0.6;
        ctx.beginPath();
        ctx.moveTo(wrapX - nx * 15, wrapY - ny * 15);
        ctx.lineTo(wrapX + nx * 15, wrapY + ny * 15);
        ctx.strokeStyle = "#1a1a1a";
        ctx.lineWidth = 6;
        ctx.stroke();
        ctx.strokeStyle = "#c0c0c0";
        ctx.lineWidth = 5;
        ctx.stroke();

        // Ferrule
        ctx.beginPath();
        ctx.moveTo(cueStartX, cueStartY);
        ctx.lineTo(cueStartX - nx * 8, cueStartY - ny * 8);
        ctx.strokeStyle = "#f0ead6";
        ctx.lineWidth = 4;
        ctx.stroke();

        // Tip
        ctx.beginPath();
        ctx.arc(cueStartX, cueStartY, 2.5, 0, Math.PI * 2);
        ctx.fillStyle = "#3a6ea5";
        ctx.fill();

        ctx.lineCap = "butt";

        // === POWER BAR (right side, draggable) ===
      }
    }
  }, [placingCue, drawBall]);



  // Physics loop
  const simulate = useCallback(() => {
    const bs = ballsRef.current.map(b => ({ ...b }));
    let anyMoving = false;

    for (const b of bs) {
      if (b.pocketed) continue;
      b.x += b.vx;
      b.y += b.vy;

      // Rolling rotation
      const speed = Math.sqrt(b.vx * b.vx + b.vy * b.vy);
      if (speed > 0.1) {
        b.rotAngle += speed / BALL_R; // angular velocity = v/r
        b.rotAxis = { x: -b.vy / speed, y: b.vx / speed };
      }

      b.vx *= FRICTION;
      b.vy *= FRICTION;
      if (Math.abs(b.vx) < MIN_V) b.vx = 0;
      if (Math.abs(b.vy) < MIN_V) b.vy = 0;
      if (b.vx !== 0 || b.vy !== 0) anyMoving = true;

      // Wall collisions
      const minX = RAIL + BALL_R, maxX = W - RAIL - BALL_R;
      const minY = RAIL + BALL_R, maxY = H - RAIL - BALL_R;
      if (b.x < minX) { b.x = minX; b.vx = -b.vx * 0.7; }
      if (b.x > maxX) { b.x = maxX; b.vx = -b.vx * 0.7; }
      if (b.y < minY) { b.y = minY; b.vy = -b.vy * 0.7; }
      if (b.y > maxY) { b.y = maxY; b.vy = -b.vy * 0.7; }

      // Pocket check
      for (const p of POCKETS) {
        const dx = b.x - p.x, dy = b.y - p.y;
        if (Math.sqrt(dx * dx + dy * dy) < POCKET_R - 1) {
          b.pocketed = true;
          b.vx = 0; b.vy = 0;
          pocketedThisTurnRef.current.push({ ...b });
        }
      }
    }

    // Ball-ball collisions
    for (let i = 0; i < bs.length; i++) {
      for (let j = i + 1; j < bs.length; j++) {
        const a = bs[i], bj = bs[j];
        if (a.pocketed || bj.pocketed) continue;
        const dx = bj.x - a.x, dy = bj.y - a.y;
        const dist = Math.sqrt(dx * dx + dy * dy);
        if (dist < BALL_R * 2 && dist > 0) {
          const nx = dx / dist, ny = dy / dist;
          const overlap = BALL_R * 2 - dist;
          a.x -= nx * overlap / 2;
          a.y -= ny * overlap / 2;
          bj.x += nx * overlap / 2;
          bj.y += ny * overlap / 2;
          const dvx = a.vx - bj.vx, dvy = a.vy - bj.vy;
          const dot = dvx * nx + dvy * ny;
          if (dot > 0) {
            a.vx -= dot * nx * 0.95;
            a.vy -= dot * ny * 0.95;
            bj.vx += dot * nx * 0.95;
            bj.vy += dot * ny * 0.95;
          }
          if ((a.id === 0 || bj.id === 0) && !firstHitTypeRef.current) {
            const other = a.id === 0 ? bj : a;
            firstHitTypeRef.current = other.type;
          }
        }
      }
    }

    setBalls(bs);
    ballsRef.current = bs;

    if (anyMoving || isMoving(bs)) {
      animRef.current = requestAnimationFrame(simulate);
    } else {
      setMoving(false);
      processTurnEndRef.current(bs);
    }
  }, []);

  const processTurnEnd = useCallback((bs: Ball[]) => {
    const pocketed = pocketedThisTurnRef.current;
    const currentTurn = turnRef.current;
    const currentAssignments = assignRef.current;
    const nextBalls = cloneBalls(bs);
    let nextTurn: 1 | 2 = currentTurn;
    let nextAssignments = currentAssignments;
    let nextMessage = "";
    let nextGameOver = false;
    let nextPlacingCue = false;
    let nextFoul = false;
    let switchTurn = true;
    let foulOccurred = false;

    const cueBall = nextBalls.find((b) => b.id === 0);
    if (cueBall && cueBall.pocketed) {
      cueBall.pocketed = false;
      cueBall.vx = 0;
      cueBall.vy = 0;
      nextMessage = "Foul! Cue ball pocketed — opponent can place cue ball anywhere";
      foulOccurred = true;
    }

    const eightPocketed = pocketed.find((b) => b.id === 8);
    if (eightPocketed) {
      const curAssign = nextAssignments[currentTurn];
      if (curAssign) {
        const remaining = nextBalls.filter((b) => b.type === curAssign && !b.pocketed && b.id !== 8);
        nextMessage = remaining.length === 0 && !foulOccurred
          ? `🎉 Player ${currentTurn} wins!`
          : `Player ${currentTurn === 1 ? 2 : 1} wins! (Opponent illegally pocketed the 8-ball)`;
      } else {
        nextMessage = `Player ${currentTurn === 1 ? 2 : 1} wins!`;
      }
      nextGameOver = true;
    }

    if (!nextGameOver && !foulOccurred && nextAssignments[currentTurn] && firstHitTypeRef.current) {
      if (firstHitTypeRef.current !== nextAssignments[currentTurn] && firstHitTypeRef.current !== "eight") {
        foulOccurred = true;
        nextMessage = "Foul! Hit opponent's ball first — opponent can place cue ball anywhere";
      }
    }

    const nonCuePocketed = pocketed.filter((b) => b.type !== "cue" && b.type !== "eight");
    if (!nextGameOver && !nextAssignments[1] && !nextAssignments[2] && nonCuePocketed.length > 0 && !foulOccurred) {
      const firstType = nonCuePocketed[0].type as "solid" | "stripe";
      const otherType = firstType === "solid" ? "stripe" : "solid";
      nextAssignments = {
        ...currentAssignments,
        [currentTurn]: firstType,
        [currentTurn === 1 ? 2 : 1]: otherType,
      } as BilliardsAssignments;
      nextMessage = `Player ${currentTurn} pocketed a ${firstType === "solid" ? "solid" : "stripe"}! Assignments set`;
      switchTurn = false;
    }

    if (!nextGameOver && !foulOccurred && nonCuePocketed.length > 0 && nextAssignments[currentTurn]) {
      const ownPocketed = nonCuePocketed.filter((b) => b.type === nextAssignments[currentTurn]);
      if (ownPocketed.length > 0) {
        switchTurn = false;
      }
    }

    if (!nextGameOver) {
      if (foulOccurred) {
        nextFoul = true;
        nextPlacingCue = true;
        nextTurn = currentTurn === 1 ? 2 : 1;
      } else if (switchTurn) {
        nextTurn = currentTurn === 1 ? 2 : 1;
      }
    }

    const snapshot: BilliardsSnapshot = {
      balls: nextBalls,
      turn: nextTurn,
      assignments: nextAssignments,
      message: nextMessage,
      gameOver: nextGameOver,
      placingCue: nextPlacingCue,
      foul: nextFoul,
    };

    applySnapshot(snapshot);
    if (online) {
      publishOnlineState(snapshot);
    }

    pocketedThisTurnRef.current = [];
    firstHitTypeRef.current = null;
  }, [applySnapshot, online, publishOnlineState]);

  processTurnEndRef.current = processTurnEnd;

  const canPlaceCue = useCallback((x: number, y: number, bs: Ball[]): boolean => {
    const minX = RAIL + BALL_R, maxX = W - RAIL - BALL_R;
    const minY = RAIL + BALL_R, maxY = H - RAIL - BALL_R;
    if (x < minX || x > maxX || y < minY || y > maxY) return false;
    for (const b of bs) {
      if (b.pocketed || b.id === 0) continue;
      const dx = b.x - x, dy = b.y - y;
      if (Math.sqrt(dx * dx + dy * dy) < BALL_R * 2 + 2) return false;
    }
    return true;
  }, []);

  const handleMouseDown = useCallback((e: React.MouseEvent) => {
    // no-op, power bar is outside canvas now
  }, []);

  const handleMouseUp = useCallback((e: React.MouseEvent) => {
    if (draggingPower) {
      setDraggingPower(false);
      return;
    }
  }, [draggingPower]);

  const handleClick = useCallback((e: React.MouseEvent) => {
    if (moving || gameOver || draggingPower) return;
    if (!isActiveTurn) return;
    const canvas = canvasRef.current;
    if (!canvas) return;
    const rect = canvas.getBoundingClientRect();
    const mx = (e.clientX - rect.left) * (W / rect.width);
    const my = (e.clientY - rect.top) * (H / rect.height);

    if (placingCue) {
      if (canPlaceCue(mx, my, ballsRef.current)) {
        const newBalls = ballsRef.current.map(b =>
          b.id === 0 ? { ...b, x: mx, y: my, pocketed: false, vx: 0, vy: 0 } : { ...b }
        );
        const snapshot: BilliardsSnapshot = {
          balls: newBalls,
          turn,
          assignments,
          message: "",
          gameOver,
          placingCue: false,
          foul: false,
        };
        applySnapshot(snapshot);
        if (online) {
          publishOnlineState(snapshot);
        }
      }
      return;
    }

    const cueBall = ballsRef.current.find(b => b.id === 0 && !b.pocketed);
    if (!cueBall) return;

    if (!aiming && !aimLocked) {
      setAiming(true);
      setAimLocked(false);
      setAimPos({ x: mx, y: my });
      return;
    }

    if (aiming && !aimLocked) {
      setAimLocked(true);
      setLockedAimPos({ x: aimPos.x, y: aimPos.y });
      return;
    }
  }, [aiming, aimLocked, aimPos, moving, gameOver, placingCue, canPlaceCue, draggingPower, isActiveTurn, turn, assignments, online, applySnapshot, publishOnlineState]);

  // Handle clicks outside canvas to lock aim direction
  const handleWrapperClick = useCallback((e: React.MouseEvent) => {
    // Only handle if aiming and not locked yet — clicking outside canvas to lock direction
    if (!aiming || aimLocked || moving || gameOver || !isActiveTurn) return;
    // Don't handle if click was on the canvas itself (canvas handleClick will handle it)
    if (canvasRef.current && canvasRef.current.contains(e.target as Node)) return;
    setAimLocked(true);
    setLockedAimPos({ x: aimPos.x, y: aimPos.y });
  }, [aiming, aimLocked, aimPos, moving, gameOver, isActiveTurn]);

  // Handle mouse move on wrapper for aim tracking outside canvas
  const handleWrapperMouseMove = useCallback((e: React.MouseEvent) => {
    if (!aiming || aimLocked || moving || gameOver) return;
    const canvas = canvasRef.current;
    if (!canvas) return;
    const rect = canvas.getBoundingClientRect();
    const mx = (e.clientX - rect.left) * (W / rect.width);
    const my = (e.clientY - rect.top) * (H / rect.height);
    setAimPos({ x: mx, y: my });
  }, [aiming, aimLocked, moving, gameOver]);

  // Shoot button handler
  const handleShoot = useCallback(() => {
    if (moving || gameOver) return;
    if (!isActiveTurn) return;
    if (!aimLocked) return;
    const cueBall = ballsRef.current.find(b => b.id === 0 && !b.pocketed);
    if (!cueBall) return;
    const aim = lockedAimPos;
    const dx = cueBall.x - aim.x, dy = cueBall.y - aim.y;
    const dist = Math.sqrt(dx * dx + dy * dy);
    if (dist < 3) return;
    const nx = dx / dist, ny = dy / dist;
    const newBalls = ballsRef.current.map(b =>
      b.id === 0 ? { ...b, vx: nx * power, vy: ny * power } : { ...b }
    );
    setBalls(newBalls);
    ballsRef.current = newBalls;
    pocketedThisTurnRef.current = [];
    firstHitTypeRef.current = null;
    setAiming(false);
    setAimLocked(false);
    setMoving(true);
    setMessage("");
    animRef.current = requestAnimationFrame(simulate);
  }, [aimLocked, lockedAimPos, moving, power, simulate, gameOver, isActiveTurn]);

  const handleMouseMove = useCallback((e: React.MouseEvent) => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const rect = canvas.getBoundingClientRect();
    // Allow aiming beyond canvas edges by not clamping
    const scaleX = W / rect.width;
    const scaleY = H / rect.height;
    const mx = (e.clientX - rect.left) * scaleX;
    const my = (e.clientY - rect.top) * scaleY;

    if (aiming && !aimLocked) {
      setAimPos({ x: mx, y: my });
    }
    if (placingCue) {
      setAimPos({ x: mx, y: my });
    }
  }, [aiming, aimLocked, placingCue]);

  const handleWheel = useCallback((e: React.WheelEvent) => {
    e.preventDefault(); // always prevent page scroll on canvas
    if (!aiming) return;
    setPower(p => Math.max(2, Math.min(MAX_POWER, p - e.deltaY * 0.03)));
  }, [aiming]);

  const handleContextMenu = useCallback((e: React.MouseEvent) => {
    e.preventDefault();
    if (aiming) {
      setAiming(false);
      setAimLocked(false);
    }
  }, [aiming]);

  // Draw loop
  useEffect(() => {
    const ctx = canvasRef.current?.getContext("2d");
    if (!ctx) return;
    const cueBall = balls.find(b => b.id === 0 && !b.pocketed);
    const activeAim = aimLocked ? lockedAimPos : aimPos;
    const showAim = (aiming || placingCue) && cueBall;
    draw(ctx, balls, showAim ? { cueBall, aimX: activeAim.x, aimY: activeAim.y, pwr: power } : undefined);
  }, [balls, aiming, aimLocked, aimPos, lockedAimPos, power, draw, placingCue]);

  // Prevent page scroll when hovering canvas
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const preventScroll = (e: WheelEvent) => { e.preventDefault(); };
    canvas.addEventListener("wheel", preventScroll, { passive: false });
    return () => canvas.removeEventListener("wheel", preventScroll);
  }, []);

  // Document-level mousemove so aiming works when mouse leaves canvas
  useEffect(() => {
    if ((!aiming || aimLocked) && !placingCue) return;
    const canvas = canvasRef.current;
    if (!canvas) return;
    const handler = (e: MouseEvent) => {
      const rect = canvas.getBoundingClientRect();
      const mx = (e.clientX - rect.left) * (W / rect.width);
      const my = (e.clientY - rect.top) * (H / rect.height);
      setAimPos({ x: mx, y: my });
    };
    document.addEventListener("mousemove", handler);
    return () => document.removeEventListener("mousemove", handler);
  }, [aiming, aimLocked, placingCue]);

  useEffect(() => {
    return () => cancelAnimationFrame(animRef.current);
  }, []);

  const reset = () => {
    cancelAnimationFrame(animRef.current);
    setAiming(false);
    setAimLocked(false);
    setMoving(false);
    setDraggingPower(false);
    pocketedThisTurnRef.current = [];
    firstHitTypeRef.current = null;

    const snapshot = createInitialBilliardsState();
    applySnapshot(snapshot);
    if (online) {
      publishOnlineState(snapshot);
    }
  };

  const pocketedBalls = balls.filter(b => b.pocketed && b.type !== "cue");
  const p1Assign = assignments[1];
  const p2Assign = assignments[2];
  const p1Label = online ? (myColor === "black" ? (playerNames?.me || "You") : (playerNames?.opponent || "Opponent")) : "Player 1";
  const p2Label = online ? (myColor === "white" ? (playerNames?.me || "You") : (playerNames?.opponent || "Opponent")) : "Player 2";
  const powerPct = Math.round((power / MAX_POWER) * 100);
  const hue = 120 - (power / MAX_POWER) * 120;

  return (
    <div className="flex flex-col items-center gap-3">
      {/* Scoreboard */}
      <div className="flex items-center justify-between w-full" style={{ maxWidth: W + 60 }}>
        <div className="flex items-center gap-2">
          <Badge variant={turn === 1 ? "default" : "secondary"} className="text-xs">
            {p1Label} {p1Assign ? (p1Assign === "solid" ? "🔴 Solid" : "🔵 Stripe") : ""}
          </Badge>
          <Badge variant={turn === 2 ? "default" : "secondary"} className="text-xs">
            {p2Label} {p2Assign ? (p2Assign === "solid" ? "🔴 Solid" : "🔵 Stripe") : ""}
          </Badge>
        </div>
        <Button variant="outline" size="sm" onClick={reset}>Restart</Button>
      </div>

      {/* Pocketed balls */}
      {pocketedBalls.length > 0 && (
        <div className="flex gap-1 items-center">
          <span className="text-xs text-muted-foreground mr-1">Pocketed:</span>
          {pocketedBalls.map(b => (
            <div key={b.id} className="w-5 h-5 rounded-full border border-border flex items-center justify-center text-[8px] font-bold"
              style={{ backgroundColor: b.color, color: ["#0044CC", "#007700", "#6B0099", "#8B1A1A", "#111111"].includes(b.color) ? "#fff" : "#000" }}>
              {b.id}
            </div>
          ))}
        </div>
      )}

      {message && <p className="text-sm font-medium text-foreground">{message}</p>}
      {online && <p className="text-xs text-muted-foreground">{isActiveTurn ? "Your turn to shoot" : "Waiting for opponent..."}</p>}
      <p className="text-xs text-muted-foreground">
        {moving ? "Balls in motion..." :
          placingCue ? "Click the table to place the cue ball" :
            aiming && !aimLocked ? "Move mouse to aim, click to lock direction | Right-click to cancel" :
              aimLocked ? "Direction locked, scroll to adjust power, click Shoot | Right-click to cancel" :
                "Click the table to start aiming"}
      </p>

      {/* Shoot button */}
      {aimLocked && !moving && !gameOver && isActiveTurn && (
        <Button onClick={handleShoot} className="bg-green-600 hover:bg-green-700 text-white px-8 py-2 text-base font-bold shadow-lg">
          🎯 Shoot!
        </Button>
      )}

      <div className="flex items-center gap-3" onClick={handleWrapperClick} onMouseMove={handleWrapperMouseMove} style={{ padding: 20, margin: -20 }}>
        <div className="rounded-xl overflow-hidden shadow-2xl border-4 border-amber-900/80"
          style={{ boxShadow: "0 8px 32px rgba(0,0,0,0.5), inset 0 1px 0 rgba(255,255,255,0.1)" }}>
          <canvas
            ref={canvasRef}
            width={W}
            height={H}
            onClick={handleClick}
            onMouseDown={handleMouseDown}
            onMouseUp={handleMouseUp}
            onMouseMove={handleMouseMove}
            onWheel={handleWheel}
            onContextMenu={handleContextMenu}
            className="cursor-crosshair block"
            style={{ width: W, height: H }}
          />
        </div>

        {/* Power bar — outside the canvas */}
        {aimLocked && !moving && !gameOver && (
          <div className="flex flex-col items-center gap-1 select-none" style={{ height: H - 40 }}>
            <span className="text-[10px] text-muted-foreground font-semibold">Power</span>
            <div className="relative flex-1 w-6 rounded-md overflow-hidden" style={{ background: "rgba(0,0,0,0.25)" }}>
              <div
                className="absolute bottom-0 left-0 w-full rounded-md transition-all"
                style={{
                  height: `${powerPct}%`,
                  background: `linear-gradient(to top, hsl(${hue}, 90%, 35%), hsl(${hue}, 85%, 55%))`,
                }}
              />
            </div>
            <span className="text-[10px] text-muted-foreground font-bold">{powerPct}%</span>
          </div>
        )}
      </div>
    </div>
  );
}

// Helper: rounded rectangle
function roundRect(ctx: CanvasRenderingContext2D, x: number, y: number, w: number, h: number, r: number) {
  ctx.beginPath();
  ctx.moveTo(x + r, y);
  ctx.lineTo(x + w - r, y);
  ctx.quadraticCurveTo(x + w, y, x + w, y + r);
  ctx.lineTo(x + w, y + h - r);
  ctx.quadraticCurveTo(x + w, y + h, x + w - r, y + h);
  ctx.lineTo(x + r, y + h);
  ctx.quadraticCurveTo(x, y + h, x, y + h - r);
  ctx.lineTo(x, y + r);
  ctx.quadraticCurveTo(x, y, x + r, y);
  ctx.closePath();
}

function lightenColor(hex: string, amount: number): string {
  const r = Math.min(255, parseInt(hex.slice(1, 3), 16) + amount);
  const g = Math.min(255, parseInt(hex.slice(3, 5), 16) + amount);
  const b = Math.min(255, parseInt(hex.slice(5, 7), 16) + amount);
  return `rgb(${r},${g},${b})`;
}

function darkenColor(hex: string, amount: number): string {
  const r = Math.max(0, parseInt(hex.slice(1, 3), 16) - amount);
  const g = Math.max(0, parseInt(hex.slice(3, 5), 16) - amount);
  const b = Math.max(0, parseInt(hex.slice(5, 7), 16) - amount);
  return `rgb(${r},${g},${b})`;
}
