import { useState, useCallback, useEffect, useRef } from "react";
import { Button } from "@/components/ui/button";

const COLORS = {
  red: { bg: "#E74C3C", light: "#FADBD8", dark: "#922B21" },
  blue: { bg: "#3498DB", light: "#D4E6F1", dark: "#1A5276" },
  green: { bg: "#27AE60", light: "#D5F5E3", dark: "#1E8449" },
  yellow: { bg: "#F1C40F", light: "#FCF3CF", dark: "#B7950B" },
};
const COLOR_KEYS = ["red", "blue", "green", "yellow"] as const;
type ColorKey = (typeof COLOR_KEYS)[number];

/* ── Fixed 52-cell main path (clockwise) ── */
const MAIN_PATH: [number, number][] = [
  // Top arm ↓ col 6  (0-4)
  [1, 6], [2, 6], [3, 6], [4, 6], [5, 6],
  // Row 6 ← (5-10)
  [6, 5], [6, 4], [6, 3], [6, 2], [6, 1], [6, 0],
  // Left edge ↓ (11-12)
  [7, 0], [8, 0],
  // Row 8 → (13-17)
  [8, 1], [8, 2], [8, 3], [8, 4], [8, 5],
  // Bottom arm ↓ col 6  (18-23)
  [9, 6], [10, 6], [11, 6], [12, 6], [13, 6], [14, 6],
  // Bottom edge → (24-25)
  [14, 7], [14, 8],
  // Bottom arm ↑ col 8  (26-31)
  [13, 8], [12, 8], [11, 8], [10, 8], [9, 8],
  // Row 8 → (31-36)
  [8, 9], [8, 10], [8, 11], [8, 12], [8, 13], [8, 14],
  // Right edge ↑ (37-38)
  [7, 14], [6, 14],
  // Row 6 ← (39-43)
  [6, 13], [6, 12], [6, 11], [6, 10], [6, 9],
  // Top arm ↑ col 8  (44-49)
  [5, 8], [4, 8], [3, 8], [2, 8], [1, 8], [0, 8],
  // Top edge ← (50-51)
  [0, 7], [0, 6],
];

const HOME_STRETCH: Record<ColorKey, [number, number][]> = {
  red: [[1, 7], [2, 7], [3, 7], [4, 7], [5, 7], [6, 7]],
  yellow: [[7, 1], [7, 2], [7, 3], [7, 4], [7, 5], [7, 6]],
  green: [[13, 7], [12, 7], [11, 7], [10, 7], [9, 7], [8, 7]],
  blue: [[7, 13], [7, 12], [7, 11], [7, 10], [7, 9], [7, 8]],
};

const START_POS: Record<ColorKey, number> = { red: 0, yellow: 13, green: 26, blue: 39 };
const SAFE_SPOTS = new Set([0, 4, 13, 17, 26, 30, 39, 43]);

/* ── Tighter base positions ── */
const BASE_POS: Record<ColorKey, [number, number][]> = {
  red: [[2, 2], [2, 3], [3, 2], [3, 3]],
  blue: [[2, 11], [2, 12], [3, 11], [3, 12]],
  green: [[11, 11], [11, 12], [12, 11], [12, 12]],
  yellow: [[11, 2], [11, 3], [12, 2], [12, 3]],
};

type Piece = { mainPos: number; homePos: number };
type PlayerState = { color: ColorKey; pieces: Piece[] };
type AnimData = {
  playerIdx: number;
  pieceIdx: number;
  waypoints: { x: number; y: number }[];
  step: number;
};

const CELL = 38;
const BOARD_PX = 15 * CELL;
const g2p = (r: number, c: number) => ({ x: c * CELL + CELL / 2, y: r * CELL + CELL / 2 });

export default function LudoGame() {
  const [playerCount, setPlayerCount] = useState<number | null>(null);
  const [players, setPlayers] = useState<PlayerState[]>([]);
  const [current, setCurrent] = useState(0);
  const [dice, setDice] = useState<number | null>(null);
  const [rolled, setRolled] = useState(false);
  const [winner, setWinner] = useState<number | null>(null);
  const [msg, setMsg] = useState("");
  const [diceAnim, setDiceAnim] = useState(false);
  const [highlight, setHighlight] = useState<number[]>([]);
  const [anim, setAnim] = useState<AnimData | null>(null);
  const afterAnimRef = useRef<(() => void) | null>(null);

  const startGame = (count: number) => {
    const order: ColorKey[] = count === 3 ? ["red", "blue", "green"] : ["red", "blue", "green", "yellow"];
    setPlayerCount(count);
    setPlayers(order.slice(0, count).map((c) => ({ color: c, pieces: Array.from({ length: 4 }, () => ({ mainPos: -1, homePos: -1 })) })));
    setCurrent(0);
    setDice(null);
    setRolled(false);
    setWinner(null);
    setHighlight([]);
    setAnim(null);
    setMsg("RED's turn — Roll the dice!");
  };

  const getMovable = useCallback((player: PlayerState, diceVal: number): number[] => {
    const m: number[] = [];
    player.pieces.forEach((p, i) => {
      if (p.homePos === 6) return;
      if (p.mainPos === -1) { if (diceVal === 6) m.push(i); return; }
      if (p.homePos >= 0) { if (p.homePos + diceVal <= 6) m.push(i); return; }
      const dist = (p.mainPos - START_POS[player.color] + 52) % 52;
      const nd = dist + diceVal;
      if (nd > 51) { if (nd - 52 <= 6) m.push(i); } else m.push(i);
    });
    return m;
  }, []);

  /* ── Build waypoints for step-by-step animation ── */
  const buildWaypoints = useCallback((player: PlayerState, piece: Piece, diceVal: number): { x: number; y: number }[] => {
    const pts: { x: number; y: number }[] = [];
    if (piece.mainPos === -1) {
      const [r, c] = MAIN_PATH[START_POS[player.color]];
      pts.push(g2p(r, c));
      return pts;
    }
    const startP = START_POS[player.color];
    const dist0 = piece.homePos >= 0 ? 999 : (piece.mainPos - startP + 52) % 52;
    for (let i = 1; i <= diceVal; i++) {
      if (piece.homePos >= 0) {
        const idx = piece.homePos + i;
        if (idx <= 5) { const [r, c] = HOME_STRETCH[player.color][idx]; pts.push(g2p(r, c)); }
        else pts.push({ x: 7.5 * CELL, y: 7.5 * CELL });
      } else {
        const nd = dist0 + i;
        if (nd > 51) {
          const hi = nd - 52;
          if (hi <= 5) { const [r, c] = HOME_STRETCH[player.color][hi]; pts.push(g2p(r, c)); }
          else pts.push({ x: 7.5 * CELL, y: 7.5 * CELL });
        } else {
          const np = (piece.mainPos + i) % 52;
          const [r, c] = MAIN_PATH[np];
          pts.push(g2p(r, c));
        }
      }
    }
    return pts;
  }, []);

  /* ── Animation stepper ── */
  useEffect(() => {
    if (!anim) return;
    if (anim.step >= anim.waypoints.length) {
      afterAnimRef.current?.();
      afterAnimRef.current = null;
      setAnim(null);
      return;
    }
    const t = setTimeout(() => setAnim((p) => (p ? { ...p, step: p.step + 1 } : null)), 140);
    return () => clearTimeout(t);
  }, [anim?.step, anim?.waypoints.length]);

  const rollDice = () => {
    if (rolled || winner !== null || anim) return;
    setDiceAnim(true);
    setTimeout(() => {
      const val = Math.floor(Math.random() * 6) + 1;
      setDice(val);
      setRolled(true);
      setDiceAnim(false);
      const p = players[current];
      const movable = getMovable(p, val);
      setHighlight(movable);
      if (movable.length === 0) {
        setMsg(`${p.color.toUpperCase()}: No moves.`);
        setTimeout(() => nextTurn(val), 600);
      } else {
        setMsg(`${p.color.toUpperCase()}: Rolled ${val}! Pick a piece.`);
      }
    }, 400);
  };

  const nextTurn = (diceVal: number) => {
    if (!playerCount) return;
    if (diceVal === 6) {
      setRolled(false); setDice(null); setHighlight([]);
      setMsg(`${players[current].color.toUpperCase()} rolled 6! Roll again.`);
      return;
    }
    const next = (current + 1) % playerCount;
    setCurrent(next); setRolled(false); setDice(null); setHighlight([]);
    setMsg(`${players[next].color.toUpperCase()}'s turn — Roll the dice!`);
  };

  const checkCapture = (all: PlayerState[], ci: number, pos: number): boolean => {
    if (SAFE_SPOTS.has(pos)) return false;
    let cap = false;
    for (let pi = 0; pi < all.length; pi++) {
      if (pi === ci) continue;
      for (const pc of all[pi].pieces) {
        if (pc.mainPos === pos && pc.homePos < 0) { pc.mainPos = -1; pc.homePos = -1; cap = true; }
      }
    }
    return cap;
  };

  const movePiece = (pieceIdx: number) => {
    if (!rolled || dice === null || winner !== null || anim) return;
    if (!highlight.includes(pieceIdx)) return;

    const player = players[current];
    const piece = player.pieces[pieceIdx];
    const waypoints = buildWaypoints(player, piece, dice);
    setHighlight([]);

    // Store the callback to execute after animation
    const diceVal = dice;
    const curIdx = current;
    afterAnimRef.current = () => {
      setPlayers((prev) => {
        const np = prev.map((p) => ({ ...p, pieces: p.pieces.map((pc) => ({ ...pc })) }));
        const pl = np[curIdx];
        const pc = pl.pieces[pieceIdx];
        let captured = false;

        if (pc.mainPos === -1) {
          pc.mainPos = START_POS[pl.color];
          pc.homePos = -1;
          captured = checkCapture(np, curIdx, pc.mainPos);
        } else if (pc.homePos >= 0) {
          pc.homePos += diceVal;
        } else {
          const dist = (pc.mainPos - START_POS[pl.color] + 52) % 52;
          const nd = dist + diceVal;
          if (nd > 51) {
            pc.homePos = nd - 52;
            pc.mainPos = -2;
          } else {
            pc.mainPos = (pc.mainPos + diceVal) % 52;
            captured = checkCapture(np, curIdx, pc.mainPos);
          }
        }

        // Check win
        if (pl.pieces.every((p) => p.homePos === 6)) {
          setWinner(curIdx);
          setMsg(`🎉 ${pl.color.toUpperCase()} WINS!`);
          return np;
        }

        if (captured) {
          setRolled(false); setDice(null);
          setMsg(`${pl.color.toUpperCase()} captured! Roll again.`);
        } else {
          // Use setTimeout to avoid batching issues
          setTimeout(() => nextTurn(diceVal), 0);
        }
        return np;
      });
    };

    setAnim({ playerIdx: current, pieceIdx, waypoints, step: 0 });
  };

  /* ── Get pixel position for rendering ── */
  const getPieceXY = (player: PlayerState, piece: Piece, pieceIdx: number): { x: number; y: number } | null => {
    if (piece.homePos === 6) return null;
    if (piece.mainPos === -1) {
      const [r, c] = BASE_POS[player.color][pieceIdx];
      return g2p(r, c);
    }
    if (piece.homePos >= 0) {
      const [r, c] = HOME_STRETCH[player.color][piece.homePos];
      return g2p(r, c);
    }
    const [r, c] = MAIN_PATH[piece.mainPos];
    return g2p(r, c);
  };

  /* ── Dice face ── */
  const DiceFace = ({ value, size = 60 }: { value: number; size?: number }) => {
    const positions: Record<number, [number, number][]> = {
      1: [[0.5, 0.5]], 2: [[0.25, 0.25], [0.75, 0.75]],
      3: [[0.25, 0.25], [0.5, 0.5], [0.75, 0.75]],
      4: [[0.25, 0.25], [0.75, 0.25], [0.25, 0.75], [0.75, 0.75]],
      5: [[0.25, 0.25], [0.75, 0.25], [0.5, 0.5], [0.25, 0.75], [0.75, 0.75]],
      6: [[0.25, 0.2], [0.75, 0.2], [0.25, 0.5], [0.75, 0.5], [0.25, 0.8], [0.75, 0.8]],
    };
    return (
      <svg width={size} height={size} viewBox="0 0 1 1">
        <rect x="0.05" y="0.05" width="0.9" height="0.9" rx="0.12" fill="#fff" stroke="#999" strokeWidth="0.02" />
        {(positions[value] || []).map(([cx, cy], i) => (
          <circle key={i} cx={cx} cy={cy} r="0.08" fill="#333" />
        ))}
      </svg>
    );
  };

  /* ── Setup screen ── */
  if (!playerCount) {
    return (
      <div className="flex flex-col items-center gap-6">
        <h3 className="text-xl font-bold">🛫 飞行棋</h3>
        <p className="text-sm text-muted-foreground">选择玩家数量</p>
        <div className="flex gap-3">
          {[3, 4].map((n) => (
            <Button key={n} onClick={() => startGame(n)} size="lg">{n} 人游戏</Button>
          ))}
        </div>
        <div className="text-xs text-muted-foreground mt-2 space-y-1 text-center">
          <p>掷到 6 才能起飞，掷到 6 可以再掷一次</p>
          <p>落在对手棋子上可以吃子（安全格除外）</p>
          <p>所有棋子到达终点即获胜</p>
        </div>
      </div>
    );
  }

  const currentColor = players[current]?.color;
  const colorInfo = COLORS[currentColor || "red"];

  return (
    <div className="flex flex-col items-center gap-3">
      {/* Scoreboard */}
      <div className="flex gap-2 flex-wrap justify-center">
        {players.map((p, i) => {
          const c = COLORS[p.color];
          const finished = p.pieces.filter((pc) => pc.homePos === 6).length;
          return (
            <div key={i} className={`px-3 py-1 rounded-full text-xs font-bold border-2 ${i === current ? "ring-2 ring-offset-1" : ""}`}
              style={{ borderColor: c.bg, backgroundColor: i === current ? c.bg : "transparent", color: i === current ? "#fff" : c.bg }}>
              {p.color.toUpperCase()} {finished}/4 ✈
            </div>
          );
        })}
      </div>

      {/* Board */}
      <div className="relative border-2 border-border rounded-lg overflow-hidden" style={{ width: BOARD_PX, height: BOARD_PX, maxWidth: "95vw" }}>
        <svg viewBox={`0 0 ${BOARD_PX} ${BOARD_PX}`} className="w-full h-full" style={{ background: "#F5F0E1" }}>
          {/* Base areas (smaller) */}
          {(["red", "blue", "green", "yellow"] as ColorKey[]).map((color, ci) => {
            if (ci >= (playerCount || 4)) return null;
            const c = COLORS[color];
            const corners: Record<string, [number, number, number, number]> = {
              red: [CELL * 0.4, CELL * 0.4, 5.2 * CELL, 5.2 * CELL],
              blue: [9.4 * CELL, CELL * 0.4, 5.2 * CELL, 5.2 * CELL],
              green: [9.4 * CELL, 9.4 * CELL, 5.2 * CELL, 5.2 * CELL],
              yellow: [CELL * 0.4, 9.4 * CELL, 5.2 * CELL, 5.2 * CELL],
            };
            const [cx, cy, cw, ch] = corners[color];
            return (
              <g key={color}>
                <rect x={cx} y={cy} width={cw} height={ch} fill={c.bg} opacity={0.15} rx={8} />
                <rect x={cx + CELL * 0.4} y={cy + CELL * 0.4} width={cw - CELL * 0.8} height={ch - CELL * 0.8}
                  fill={c.light} rx={6} stroke={c.bg} strokeWidth={2} />
                {BASE_POS[color].map(([r, col], bi) => (
                  <circle key={bi} cx={col * CELL + CELL / 2} cy={r * CELL + CELL / 2} r={CELL * 0.32}
                    fill="#fff" stroke={c.bg} strokeWidth={2} />
                ))}
              </g>
            );
          })}

          {/* Center diamond */}
          <polygon points={`${7.5 * CELL},${6 * CELL} ${9 * CELL},${7.5 * CELL} ${7.5 * CELL},${9 * CELL} ${6 * CELL},${7.5 * CELL}`}
            fill="#F5F0E1" stroke="#ccc" strokeWidth={1} />
          {[
            { color: "red" as ColorKey, pts: `${6 * CELL},${7.5 * CELL} ${7.5 * CELL},${6 * CELL} ${7.5 * CELL},${7.5 * CELL}` },
            { color: "blue" as ColorKey, pts: `${7.5 * CELL},${6 * CELL} ${9 * CELL},${7.5 * CELL} ${7.5 * CELL},${7.5 * CELL}` },
            { color: "green" as ColorKey, pts: `${9 * CELL},${7.5 * CELL} ${7.5 * CELL},${9 * CELL} ${7.5 * CELL},${7.5 * CELL}` },
            { color: "yellow" as ColorKey, pts: `${7.5 * CELL},${9 * CELL} ${6 * CELL},${7.5 * CELL} ${7.5 * CELL},${7.5 * CELL}` },
          ].map(({ color, pts }, i) => {
            if (i >= (playerCount || 4)) return null;
            return <polygon key={i} points={pts} fill={COLORS[color].bg} opacity={0.5} />;
          })}

          {/* Main path cells */}
          {MAIN_PATH.map(([r, c], i) => {
            let fill = "#fff";
            let strokeC = "#ccc";
            for (const [ck, sp] of Object.entries(START_POS)) {
              if (i === sp) { fill = COLORS[ck as ColorKey].light; strokeC = COLORS[ck as ColorKey].bg; }
            }
            if (SAFE_SPOTS.has(i)) strokeC = "#999";
            return (
              <rect key={i} x={c * CELL + 2} y={r * CELL + 2} width={CELL - 4} height={CELL - 4} rx={4}
                fill={fill} stroke={strokeC} strokeWidth={1.5} />
            );
          })}

          {/* Safe spot stars */}
          {Array.from(SAFE_SPOTS).map((pos) => {
            const [r, c] = MAIN_PATH[pos];
            return (
              <text key={`s-${pos}`} x={c * CELL + CELL / 2} y={r * CELL + CELL / 2 + 4}
                textAnchor="middle" fontSize="12" fill="#F39C12">★</text>
            );
          })}

          {/* Home stretch cells */}
          {(Object.entries(HOME_STRETCH) as [ColorKey, [number, number][]][]).map(([color, cells]) => {
            const ci = COLOR_KEYS.indexOf(color);
            if (ci >= (playerCount || 4)) return null;
            return cells.map(([r, c], i) => (
              <rect key={`hs-${color}-${i}`} x={c * CELL + 2} y={r * CELL + 2} width={CELL - 4} height={CELL - 4} rx={4}
                fill={COLORS[color].light} stroke={COLORS[color].bg} strokeWidth={1.5} />
            ));
          })}

          {/* Pieces */}
          {players.map((player, pi) =>
            player.pieces.map((piece, pci) => {
              // If this piece is currently animating, use animation position
              if (anim && anim.playerIdx === pi && anim.pieceIdx === pci && anim.step > 0) {
                const wp = anim.waypoints[Math.min(anim.step - 1, anim.waypoints.length - 1)];
                const c = COLORS[player.color];
                return (
                  <g key={`p-${pi}-${pci}`}>
                    <circle cx={wp.x} cy={wp.y} r={CELL * 0.32}
                      fill={c.bg} stroke="#FFD700" strokeWidth={3} />
                    <text x={wp.x} y={wp.y + 5} textAnchor="middle" fontSize="14"
                      style={{ pointerEvents: "none" }}>✈</text>
                    {/* Trail glow */}
                    <circle cx={wp.x} cy={wp.y} r={CELL * 0.38} fill="none" stroke="#FFD700" strokeWidth={2} opacity={0.5}>
                      <animate attributeName="r" from={`${CELL * 0.32}`} to={`${CELL * 0.45}`} dur="0.4s" repeatCount="indefinite" />
                      <animate attributeName="opacity" from="0.6" to="0" dur="0.4s" repeatCount="indefinite" />
                    </circle>
                  </g>
                );
              }

              const pos = getPieceXY(player, piece, pci);
              if (!pos) return null;
              const c = COLORS[player.color];
              const isMovable = pi === current && rolled && highlight.includes(pci) && !anim;
              // Offset for stacking
              const sameCell = player.pieces.filter((op, oi) => {
                if (oi === pci) return false;
                const opos = getPieceXY(player, op, oi);
                return opos && Math.abs(opos.x - pos.x) < 5 && Math.abs(opos.y - pos.y) < 5;
              }).length;
              const offset = sameCell > 0 ? (pci % 2 === 0 ? -5 : 5) : 0;

              return (
                <g key={`p-${pi}-${pci}`}
                  onClick={() => isMovable && movePiece(pci)}
                  className={isMovable ? "cursor-pointer" : ""}
                  style={{ filter: isMovable ? "drop-shadow(0 0 4px gold)" : undefined }}>
                  <circle cx={pos.x + offset} cy={pos.y + offset} r={CELL * 0.32}
                    fill={c.bg} stroke={isMovable ? "#FFD700" : "#fff"} strokeWidth={isMovable ? 3 : 2} />
                  <text x={pos.x + offset} y={pos.y + offset + 5} textAnchor="middle" fontSize="14"
                    style={{ pointerEvents: "none" }}>✈</text>
                  {isMovable && (
                    <circle cx={pos.x + offset} cy={pos.y + offset} r={CELL * 0.38}
                      fill="none" stroke="#FFD700" strokeWidth={2} opacity={0.6}>
                      <animate attributeName="r" from={`${CELL * 0.32}`} to={`${CELL * 0.42}`} dur="0.8s" repeatCount="indefinite" />
                      <animate attributeName="opacity" from="0.8" to="0" dur="0.8s" repeatCount="indefinite" />
                    </circle>
                  )}
                </g>
              );
            })
          )}

          {/* Finished count in center */}
          {players.map((p, pi) => {
            const finished = p.pieces.filter((pc) => pc.homePos === 6).length;
            if (finished === 0) return null;
            const angles = [Math.PI, -Math.PI / 2, 0, Math.PI / 2];
            const cx = 7.5 * CELL + Math.cos(angles[pi]) * CELL;
            const cy = 7.5 * CELL + Math.sin(angles[pi]) * CELL;
            return (
              <text key={`fin-${pi}`} x={cx} y={cy + 4} textAnchor="middle" fontSize="11"
                fill={COLORS[p.color].dark} fontWeight="bold">{finished}✈</text>
            );
          })}
        </svg>
      </div>

      {/* Controls */}
      <div className="flex flex-col items-center gap-2">
        <p className="text-sm font-bold" style={{ color: colorInfo.bg }}>{msg}</p>
        <div className="flex items-center gap-4">
          <Button onClick={rollDice} disabled={rolled || winner !== null || diceAnim || !!anim} size="lg"
            style={{ backgroundColor: colorInfo.bg, color: "#fff" }} className="min-w-[140px]">
            {diceAnim ? "🎲 ..." : dice ? `Rolled ${dice}` : "🎲 掷骰子"}
          </Button>
          {dice && !diceAnim && (
            <div className={diceAnim ? "animate-spin" : ""}>
              <DiceFace value={dice} size={50} />
            </div>
          )}
        </div>
      </div>

      {winner !== null && (
        <div className="text-center space-y-2">
          <p className="text-lg font-bold" style={{ color: COLORS[players[winner].color].bg }}>
            🎉 {players[winner].color.toUpperCase()} 获胜！
          </p>
          <Button onClick={() => startGame(playerCount)}>再来一局</Button>
        </div>
      )}
    </div>
  );
}
