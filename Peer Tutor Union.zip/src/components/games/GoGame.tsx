import { useState, useCallback } from "react";
import { Button } from "@/components/ui/button";

const SIZE = 9;
type Stone = null | "black" | "white";

function createBoard(): Stone[][] {
  return Array.from({ length: SIZE }, () => Array(SIZE).fill(null));
}

function getGroup(board: Stone[][], r: number, c: number): { stones: [number, number][]; liberties: number } {
  const color = board[r][c];
  if (!color) return { stones: [], liberties: 0 };
  const visited = new Set<string>();
  const stones: [number, number][] = [];
  let liberties = 0;
  const stack: [number, number][] = [[r, c]];
  while (stack.length) {
    const [cr, cc] = stack.pop()!;
    const key = `${cr},${cc}`;
    if (visited.has(key)) continue;
    visited.add(key);
    stones.push([cr, cc]);
    for (const [dr, dc] of [[1,0],[-1,0],[0,1],[0,-1]]) {
      const nr = cr + dr, nc = cc + dc;
      if (nr < 0 || nr >= SIZE || nc < 0 || nc >= SIZE) continue;
      if (board[nr][nc] === null) liberties++;
      else if (board[nr][nc] === color && !visited.has(`${nr},${nc}`)) stack.push([nr, nc]);
    }
  }
  return { stones, liberties };
}

function removeCaptures(board: Stone[][], color: Stone): Stone[][] {
  const nb = board.map(r => [...r]);
  for (let r = 0; r < SIZE; r++) {
    for (let c = 0; c < SIZE; c++) {
      if (nb[r][c] === color) {
        const g = getGroup(nb, r, c);
        if (g.liberties === 0) {
          for (const [sr, sc] of g.stones) nb[sr][sc] = null;
        }
      }
    }
  }
  return nb;
}

interface GoGameProps {
  online?: boolean;
  myColor?: string;
  gameState?: any;
  onMove?: (state: any) => void;
  isMyTurn?: boolean;
}

export default function GoGame({ online, myColor, gameState, onMove, isMyTurn }: GoGameProps) {
  const [localBoard, setLocalBoard] = useState<Stone[][]>(createBoard);
  const [localTurn, setLocalTurn] = useState<"black" | "white">("black");
  const [localCaptures, setLocalCaptures] = useState({ black: 0, white: 0 });
  const [passCount, setPassCount] = useState(0);
  const [gameOver, setGameOver] = useState(false);

  const board = online && gameState?.board ? gameState.board : localBoard;
  const turn = online && gameState?.turn ? gameState.turn : localTurn;
  const captures = online && gameState?.captures ? gameState.captures : localCaptures;
  const isGameOver = online ? gameState?.gameOver : gameOver;
  const opponent = turn === "black" ? "white" : "black";

  const handleClick = useCallback((r: number, c: number) => {
    if (isGameOver || board[r][c]) return;
    if (online && !isMyTurn) return;

    const nb = board.map((row: Stone[]) => [...row]);
    nb[r][c] = turn;
    const afterCap = removeCaptures(nb, opponent);
    const selfGroup = getGroup(afterCap, r, c);
    if (selfGroup.liberties === 0) return;

    let capCount = 0;
    for (let i = 0; i < SIZE; i++) for (let j = 0; j < SIZE; j++) {
      if (nb[i][j] === opponent && afterCap[i][j] === null) capCount++;
    }

    const newCaptures = { ...captures, [turn]: (captures[turn as keyof typeof captures] || 0) + capCount };

    if (online && onMove) {
      onMove({ board: afterCap, turn: opponent, captures: newCaptures, passCount: 0, gameOver: false });
    } else {
      setLocalBoard(afterCap);
      setLocalCaptures(newCaptures);
      setLocalTurn(opponent);
      setPassCount(0);
    }
  }, [board, turn, opponent, isGameOver, captures, online, isMyTurn, onMove]);

  const pass = () => {
    const curPass = online ? (gameState?.passCount || 0) : passCount;
    if (curPass >= 1) {
      if (online && onMove) {
        onMove({ ...gameState, gameOver: true });
      } else {
        setGameOver(true);
      }
      return;
    }
    if (online && onMove) {
      onMove({ ...gameState, turn: opponent, passCount: curPass + 1 });
    } else {
      setPassCount(curPass + 1);
      setLocalTurn(opponent);
    }
  };

  const reset = () => {
    if (online && onMove) {
      onMove({ board: createBoard(), turn: "black", captures: { black: 0, white: 0 }, passCount: 0, gameOver: false });
    } else {
      setLocalBoard(createBoard()); setLocalTurn("black"); setLocalCaptures({ black: 0, white: 0 }); setPassCount(0); setGameOver(false);
    }
  };

  const cellSize = 36;
  const padding = 24;
  const svgSize = (SIZE - 1) * cellSize + padding * 2;

  return (
    <div className="flex flex-col items-center gap-4">
      <div className="flex items-center justify-between w-full max-w-md">
        <div className="text-sm font-medium text-foreground">
          {isGameOver ? "Game Over"
            : online ? (isMyTurn ? "Your turn" : "Waiting for opponent...")
            : `Current: ${turn === "black" ? "Black" : "White"}`}
        </div>
        <div className="flex gap-2">
          {!isGameOver && <Button variant="outline" size="sm" onClick={pass}>Pass</Button>}
          <Button variant="outline" size="sm" onClick={reset}>Restart</Button>
        </div>
      </div>
      {online && <p className="text-xs text-muted-foreground">You are {myColor === "black" ? "Black" : "White"}</p>}
      <div className="flex gap-4 text-xs text-muted-foreground">
        <span>Black captures: {captures.black || 0}</span>
        <span>White captures: {captures.white || 0}</span>
      </div>
      <div className="rounded-xl overflow-hidden shadow-lg">
        <svg width={svgSize} height={svgSize} className="bg-amber-200 dark:bg-amber-700">
          {Array.from({ length: SIZE }, (_, i) => (
            <g key={i}>
              <line x1={padding} y1={padding + i * cellSize} x2={padding + (SIZE-1) * cellSize} y2={padding + i * cellSize} stroke="currentColor" className="text-amber-900/60" strokeWidth={0.5} />
              <line x1={padding + i * cellSize} y1={padding} x2={padding + i * cellSize} y2={padding + (SIZE-1) * cellSize} stroke="currentColor" className="text-amber-900/60" strokeWidth={0.5} />
            </g>
          ))}
          {[[2,2],[2,6],[4,4],[6,2],[6,6]].map(([r,c]) => (
            <circle key={`${r}-${c}`} cx={padding + c * cellSize} cy={padding + r * cellSize} r={3} className="fill-amber-900/60" />
          ))}
          {board.map((row: Stone[], r: number) => row.map((stone: Stone, c: number) => (
            <g key={`${r}-${c}`}>
              <rect x={padding + c * cellSize - cellSize/2} y={padding + r * cellSize - cellSize/2} width={cellSize} height={cellSize} fill="transparent" className="cursor-pointer" onClick={() => handleClick(r, c)} />
              {stone && (
                <circle cx={padding + c * cellSize} cy={padding + r * cellSize} r={cellSize/2 - 2}
                  className={stone === "black" ? "fill-gray-900 stroke-gray-700" : "fill-white stroke-gray-300"}
                  strokeWidth={1} style={{ filter: "drop-shadow(1px 1px 1px rgba(0,0,0,0.3))" }}
                />
              )}
            </g>
          )))}
        </svg>
      </div>
    </div>
  );
}
