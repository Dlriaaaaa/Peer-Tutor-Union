import { useState, useEffect, useCallback, useRef } from "react";
import { Button } from "@/components/ui/button";
import { supabase } from "@/integrations/supabase/client";
import { Crosshair } from "lucide-react";

const TOTAL_ROUNDS = 5;
const CANVAS_W = 500;
const CANVAS_H = 500;
const TARGET_CX = CANVAS_W / 2;
const TARGET_CY = CANVAS_H / 2;
const MAX_RING_R = 200;
const RING_COUNT = 10;

// Scenes per round
const SCENES = [
  { name: "Open Field", bg: "#87CEEB", ground: "#4a7c3f" },
  { name: "Desert", bg: "#f4c364", ground: "#c9a44a" },
  { name: "Night", bg: "#1a1a3e", ground: "#2d2d4a" },
  { name: "Snowy", bg: "#d0e8f2", ground: "#e8e8e8" },
  { name: "Sunset", bg: "#ff7e5f", ground: "#3d2b1f" },
];

function getScore(dx: number, dy: number): number {
  const dist = Math.sqrt(dx * dx + dy * dy);
  if (dist > MAX_RING_R) return 0;
  const ringWidth = MAX_RING_R / RING_COUNT;
  const ring = Math.floor(dist / ringWidth);
  return Math.max(0, RING_COUNT - ring);
}

interface ShootingGameProps {
  online?: boolean;
  myColor?: string;
  gameState?: any;
  onMove?: (state: any) => void;
  isMyTurn?: boolean;
  playerNames?: { me: string; opponent: string };
  singlePlayer?: boolean;
}

export default function ShootingGame({ online, myColor, gameState, onMove, isMyTurn, playerNames, singlePlayer = false }: ShootingGameProps) {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [state, setState] = useState(() => {
    if (online && gameState?.round) return gameState;
    return {
      round: 1,
      turn: "black",
      scores: { black: [], white: [] } as { black: number[]; white: number[] },
      shots: { black: [] as { x: number; y: number }[], white: [] as { x: number; y: number }[] },
      gameOver: false,
      winner: null as string | null,
    };
  });

  // Scope wobble state
  const [scopePos, setScopePos] = useState({ x: TARGET_CX, y: TARGET_CY });
  const scopeRef = useRef({ x: TARGET_CX, y: TARGET_CY, phase: 0 });
  const animRef = useRef<number>(0);

  const mySymbol = myColor === "white" ? "white" : "black";
  const isActiveTurn = !online || (state.turn === mySymbol && isMyTurn !== false);
  const currentScene = SCENES[(state.round - 1) % SCENES.length];

  useEffect(() => {
    if (online && gameState) setState(gameState);
  }, [online, gameState]);

  // Animate scope wobble
  useEffect(() => {
    if (state.gameOver) return;
    const speed = 0.02 + (state.round - 1) * 0.005;
    const amplitude = 30 + (state.round - 1) * 10;

    const animate = () => {
      const s = scopeRef.current;
      s.phase += speed;
      s.x = TARGET_CX + Math.sin(s.phase * 1.3) * amplitude + Math.cos(s.phase * 0.7) * (amplitude * 0.5);
      s.y = TARGET_CY + Math.cos(s.phase) * amplitude + Math.sin(s.phase * 0.9) * (amplitude * 0.4);
      setScopePos({ x: s.x, y: s.y });
      animRef.current = requestAnimationFrame(animate);
    };
    animRef.current = requestAnimationFrame(animate);
    return () => cancelAnimationFrame(animRef.current);
  }, [state.round, state.gameOver]);

  // Draw target
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;

    // Scene background
    ctx.fillStyle = currentScene.bg;
    ctx.fillRect(0, 0, CANVAS_W, CANVAS_H);
    // Ground
    ctx.fillStyle = currentScene.ground;
    ctx.fillRect(0, CANVAS_H * 0.7, CANVAS_W, CANVAS_H * 0.3);

    // Draw target rings
    const ringW = MAX_RING_R / RING_COUNT;
    for (let i = RING_COUNT; i >= 1; i--) {
      ctx.beginPath();
      ctx.arc(TARGET_CX, TARGET_CY, ringW * i, 0, Math.PI * 2);
      ctx.fillStyle = i % 2 === 0 ? "#ffffff" : (i <= 2 ? "#FFD700" : i <= 4 ? "#FF4444" : i <= 6 ? "#4488FF" : "#222222");
      ctx.fill();
      ctx.strokeStyle = "#00000033";
      ctx.lineWidth = 0.5;
      ctx.stroke();
    }

    // Ring numbers
    ctx.fillStyle = "#00000088";
    ctx.font = "10px sans-serif";
    ctx.textAlign = "center";
    for (let i = 1; i <= RING_COUNT; i++) {
      const r = ringW * i - ringW / 2;
      ctx.fillText(`${RING_COUNT - i + 1}`, TARGET_CX + r, TARGET_CY + 4);
    }

    // Draw all previous shots for this round
    const allShots = [...(state.shots.black || []), ...(state.shots.white || [])];
    allShots.forEach((shot: { x: number; y: number }, idx: number) => {
      const isBlack = idx < (state.shots.black?.length || 0);
      ctx.beginPath();
      ctx.arc(shot.x, shot.y, 4, 0, Math.PI * 2);
      ctx.fillStyle = isBlack ? "#000000" : "#ffffff";
      ctx.fill();
      ctx.strokeStyle = isBlack ? "#ffffff" : "#000000";
      ctx.lineWidth = 1;
      ctx.stroke();
    });

    // Draw scope crosshair
    if (!state.gameOver) {
      ctx.strokeStyle = "#ff000099";
      ctx.lineWidth = 1.5;
      const r = 25;
      ctx.beginPath();
      ctx.arc(scopePos.x, scopePos.y, r, 0, Math.PI * 2);
      ctx.stroke();
      ctx.beginPath();
      ctx.moveTo(scopePos.x - r - 5, scopePos.y);
      ctx.lineTo(scopePos.x + r + 5, scopePos.y);
      ctx.stroke();
      ctx.beginPath();
      ctx.moveTo(scopePos.x, scopePos.y - r - 5);
      ctx.lineTo(scopePos.x, scopePos.y + r + 5);
      ctx.stroke();
    }
  }, [scopePos, state, currentScene]);

  const shoot = useCallback(() => {
    if (state.gameOver || !isActiveTurn) return;

    const sx = scopeRef.current.x;
    const sy = scopeRef.current.y;
    const dx = sx - TARGET_CX;
    const dy = sy - TARGET_CY;
    const score = getScore(dx, dy);

    const player = online ? mySymbol : (singlePlayer ? "black" : state.turn);
    const newScores = { ...state.scores };
    newScores[player] = [...(newScores[player] || []), score];
    const newShots = { ...state.shots };
    newShots[player] = [...(newShots[player] || []), { x: sx, y: sy }];

    // Determine next state
    let nextRound = state.round;
    let nextTurn = singlePlayer ? "black" : (player === "black" ? "white" : "black");
    let gameOver = false;
    let winner = null;

    if (singlePlayer) {
      // Single player: one shot per round
      const roundComplete = newScores.black.length === state.round;
      if (roundComplete) {
        if (state.round >= TOTAL_ROUNDS) {
          gameOver = true;
          const total = newScores.black.reduce((a: number, b: number) => a + b, 0);
          winner = "black";
          // Save to leaderboard
          supabase.auth.getUser().then(({ data: { user } }) => {
            if (user) {
              supabase.rpc("submit_game_score", {
                _game_type: "shooting", _score: total, _mode: "single",
              });
            }
          });
        } else {
          nextRound = state.round + 1;
        }
      }
    } else {
      const bothShot = newScores.black.length === newScores.white.length;
      const roundComplete = bothShot && newScores.black.length === state.round;
      if (roundComplete) {
        if (state.round >= TOTAL_ROUNDS) {
          gameOver = true;
          const totalBlack = newScores.black.reduce((a: number, b: number) => a + b, 0);
          const totalWhite = newScores.white.reduce((a: number, b: number) => a + b, 0);
          winner = totalBlack > totalWhite ? "black" : totalWhite > totalBlack ? "white" : "draw";
        } else {
          nextRound = state.round + 1;
          nextTurn = "black";
        }
      }
    }

    const newState = {
      round: nextRound,
      turn: nextTurn,
      scores: newScores,
      shots: (singlePlayer ? newScores.black.length === state.round : (newScores.black.length === newScores.white.length && newScores.black.length === state.round)) && !gameOver
        ? { black: [], white: [] } : newShots,
      gameOver,
      winner,
    };

    scopeRef.current.phase = Math.random() * Math.PI * 2;
    setState(newState);
    if (online && onMove) onMove(newState);
  }, [state, isActiveTurn, online, mySymbol, onMove, singlePlayer]);

  const reset = () => {
    const newState = {
      round: 1, turn: "black",
      scores: { black: [], white: [] },
      shots: { black: [], white: [] },
      gameOver: false, winner: null,
    };
    setState(newState);
    if (online && onMove) onMove(newState);
  };

  const totalBlack = (state.scores.black || []).reduce((a: number, b: number) => a + b, 0);
  const totalWhite = (state.scores.white || []).reduce((a: number, b: number) => a + b, 0);
  const p1Name = singlePlayer ? "You" : (online ? (mySymbol === "black" ? playerNames?.me || "You" : playerNames?.opponent || "Opponent") : "Player 1");
  const p2Name = online ? (mySymbol === "white" ? playerNames?.me || "You" : playerNames?.opponent || "Opponent") : "Player 2";

  return (
    <div className="flex flex-col items-center gap-4">
      {/* Score header */}
      <div className="flex items-center gap-6 text-sm">
        <div className="text-center">
          <p className="font-bold text-foreground">{p1Name}</p>
          <p className="text-lg font-mono">{totalBlack}</p>
        </div>
        <div className="text-center">
          <p className="text-xs text-muted-foreground">Round {Math.min(state.round, TOTAL_ROUNDS)}/{TOTAL_ROUNDS}</p>
          <p className="text-xs text-muted-foreground">{currentScene.name}</p>
        </div>
        {!singlePlayer && (
          <div className="text-center">
            <p className="font-bold text-foreground">{p2Name}</p>
            <p className="text-lg font-mono">{totalWhite}</p>
          </div>
        )}
      </div>

      {/* Status */}
      <p className="text-sm font-medium text-foreground">
        {state.gameOver
          ? singlePlayer
            ? `Final score: ${totalBlack} 🎯`
            : state.winner === "draw"
              ? "Draw! 🤝"
              : `${state.winner === "black" ? p1Name : p2Name} wins! 🎯`
          : singlePlayer
            ? "Press Fire!"
            : online
              ? isActiveTurn ? "Your turn — press Fire!" : "Waiting for opponent..."
              : `${state.turn === "black" ? p1Name : p2Name}'s turn`}
      </p>

      {/* Canvas */}
      <canvas
        ref={canvasRef}
        width={CANVAS_W}
        height={CANVAS_H}
        className="rounded-lg border border-border shadow-lg"
        style={{ maxWidth: "100%", imageRendering: "auto" }}
      />

      {/* Fire button */}
      <div className="flex gap-3">
        <Button
          onClick={shoot}
          disabled={state.gameOver || !isActiveTurn}
          className="gap-2 px-8"
          size="lg"
        >
          <Crosshair className="h-5 w-5" />
          Fire!
        </Button>
        <Button variant="outline" size="sm" onClick={reset}>Restart</Button>
      </div>

      {/* Round scores */}
      {state.scores.black.length > 0 && (
        <div className="text-xs text-muted-foreground">
          <table className="border-collapse">
            <thead>
              <tr>
                <th className="px-2 py-1">Round</th>
                <th className="px-2 py-1">{p1Name}</th>
                {!singlePlayer && <th className="px-2 py-1">{p2Name}</th>}
              </tr>
            </thead>
            <tbody>
              {Array.from({ length: Math.max(state.scores.black.length, state.scores.white.length) }).map((_, i) => (
                <tr key={i} className="border-t border-border/50">
                  <td className="px-2 py-0.5 text-center">{i + 1}</td>
                  <td className="px-2 py-0.5 text-center font-mono">{state.scores.black[i] ?? "—"}</td>
                  {!singlePlayer && <td className="px-2 py-0.5 text-center font-mono">{state.scores.white[i] ?? "—"}</td>}
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}

      {online && (
        <p className="text-xs text-muted-foreground">
          You are <span className="font-bold">{mySymbol === "black" ? p1Name : p2Name}</span>
        </p>
      )}
    </div>
  );
}
