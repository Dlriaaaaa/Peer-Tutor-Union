type MultiplayerPlayer = {
  user_id: string;
  player_color: string | null;
};

function createInitialBilliardsBalls() {
  const H = 440;
  const BALL_R = 11;
  const ballColors = [
    { color: "#FFD700", type: "solid" },
    { color: "#0044CC", type: "solid" },
    { color: "#CC0000", type: "solid" },
    { color: "#6B0099", type: "solid" },
    { color: "#FF6600", type: "solid" },
    { color: "#007700", type: "solid" },
    { color: "#8B1A1A", type: "solid" },
    { color: "#FF4081", type: "stripe" },
    { color: "#FFD700", type: "stripe" },
    { color: "#0044CC", type: "stripe" },
    { color: "#CC0000", type: "stripe" },
    { color: "#6B0099", type: "stripe" },
    { color: "#FF6600", type: "stripe" },
    { color: "#007700", type: "stripe" },
  ] as const;

  const balls = [] as any[];
  const defBall = { vx: 0, vy: 0, pocketed: false, rotAngle: 0, rotAxis: { x: 0, y: 1 } };
  balls.push({ id: 0, x: 240, y: H / 2, color: "#FFFEF6", type: "cue", ...defBall });

  const startX = 560;
  const startY = H / 2;
  const rackOrder = [0, 1, 2, 3, -1, 7, 4, 5, 8, 6, 9, 10, 11, 12, 13];
  let idx = 0;

  for (let row = 0; row < 5; row++) {
    const count = row + 1;
    for (let col = 0; col < count; col++) {
      const x = startX + row * (BALL_R * 2 + 0.5);
      const y = startY + (col - (count - 1) / 2) * (BALL_R * 2 + 0.5);
      const ri = rackOrder[idx++];

      if (ri === -1) {
        balls.push({ id: 8, x, y, color: "#111111", type: "eight", ...defBall });
      } else {
        const ball = ballColors[ri];
        balls.push({ id: ri < 7 ? ri + 1 : ri + 2, x, y, color: ball.color, type: ball.type, ...defBall });
      }
    }
  }

  return balls;
}

export function createInitialGameState(gameType: string): any {
  switch (gameType) {
    case "gomoku":
      return {
        board: Array.from({ length: 15 }, () => Array(15).fill(null)),
        turn: "black",
        winner: null,
        lastMove: null,
      };
    case "chess": {
      const order = ["R", "N", "B", "Q", "K", "B", "N", "R"];
      const board = Array.from({ length: 8 }, () => Array(8).fill(null));
      for (let c = 0; c < 8; c++) {
        board[0][c] = { c: "b", t: order[c] };
        board[1][c] = { c: "b", t: "P" };
        board[6][c] = { c: "w", t: "P" };
        board[7][c] = { c: "w", t: order[c] };
      }
      return { board, turn: "w", captured: { w: [], b: [] } };
    }
    case "go":
      return {
        board: Array.from({ length: 9 }, () => Array(9).fill(null)),
        turn: "black",
        captures: { black: 0, white: 0 },
        passCount: 0,
        gameOver: false,
      };
    case "billiards":
      return {
        balls: createInitialBilliardsBalls(),
        turn: 1,
        assignments: { 1: null, 2: null },
        message: "",
        gameOver: false,
        placingCue: false,
        foul: false,
      };
    case "shooting":
      return {
        round: 1, turn: "black",
        scores: { black: [], white: [] },
        shots: { black: [], white: [] },
        gameOver: false, winner: null,
      };
    case "game24": {
      const nums = [1, 2, 3, 4];
      return {
        numbers: nums,
        scores: { black: 0, white: 0 },
        round: 1,
        solved: false,
        solvedBy: null,
        gameOver: false,
      };
    }
    case "basketball":
      return { scores: [0, 0], time: 60, gameOver: false };
    case "ludo":
      return { players: [], currentPlayer: 0, dice: null, gameOver: false };
    case "doudizhu":
      return { phase: "setup", hands: [], gameOver: false };
    default:
      return {};
  }
}

export function hasInitializedGameState(gameType: string, gameState: any): boolean {
  if (!gameState || typeof gameState !== "object") return false;
  switch (gameType) {
    case "gomoku":
      return Array.isArray(gameState.board) && gameState.board.length === 15;
    case "chess":
      return Array.isArray(gameState.board) && gameState.board.length === 8;
    case "go":
      return Array.isArray(gameState.board) && gameState.board.length === 9;
    case "billiards":
      return Array.isArray(gameState.balls) && gameState.turn !== undefined;
    case "shooting":
      return gameState.round !== undefined && gameState.scores !== undefined;
    case "game24":
      return Array.isArray(gameState.numbers) && gameState.numbers.length === 4;
    case "basketball":
    case "ludo":
    case "doudizhu":
      return gameState.gameOver !== undefined;
    default:
      return Object.keys(gameState).length > 0;
  }
}

export function resolveCurrentTurnUserId(players: MultiplayerPlayer[], turn: unknown): string | null {
  const targetColor =
    turn === "black" || turn === "b" || turn === 1 || turn === "X"
      ? "black"
      : turn === "white" || turn === "w" || turn === 2 || turn === "O"
        ? "white"
        : null;

  if (!targetColor) return null;
  return players.find((p) => p.player_color === targetColor)?.user_id ?? null;
}
