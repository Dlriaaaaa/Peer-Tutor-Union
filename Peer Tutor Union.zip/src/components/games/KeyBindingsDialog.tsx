/**
 * Keybindings dialog — lets the player rebind P1/P2 controls for BasketballGame.
 * Persists via lib/keybindings (localStorage).
 *
 * Recording flow:
 *   - Click an action row → it enters "press a key" mode.
 *   - Next keydown captured (lowercased) becomes the new binding.
 *   - Esc cancels recording. Duplicate keys within the same slot get auto-swapped.
 */

import { useEffect, useMemo, useState } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import { RotateCcw, Keyboard } from "lucide-react";
import {
  ACTION_LABELS,
  type ActionKey,
  type AllBindings,
  DEFAULT_BINDINGS,
  loadBindings,
  prettyKey,
  resetBindings,
  saveBindings,
  type SlotBindings,
} from "@/lib/keybindings";
import { toast } from "sonner";

interface Props {
  open: boolean;
  onOpenChange: (open: boolean) => void;
}

const ACTION_ORDER: ActionKey[] = ["left", "right", "jump", "shoot", "steal", "sprint"];

export default function KeyBindingsDialog({ open, onOpenChange }: Props) {
  const [bindings, setBindings] = useState<AllBindings>(DEFAULT_BINDINGS);
  const [recording, setRecording] = useState<{ slot: "p1" | "p2"; action: ActionKey } | null>(null);

  // Refresh from storage every time the dialog opens (so other tabs' changes show).
  useEffect(() => {
    if (open) {
      setBindings(loadBindings());
      setRecording(null);
    }
  }, [open]);

  // Capture next keypress when recording.
  useEffect(() => {
    if (!recording) return;
    const handler = (e: KeyboardEvent) => {
      e.preventDefault();
      e.stopPropagation();
      const k = e.key.toLowerCase();
      if (k === "escape") {
        setRecording(null);
        return;
      }
      setBindings((prev) => {
        const slot = { ...prev[recording.slot] } as SlotBindings;
        // If this key is already used by a different action in the same slot,
        // swap them so each slot still has 6 distinct bindings.
        const conflictAction = (Object.keys(slot) as ActionKey[]).find(
          (a) => a !== recording.action && slot[a] === k
        );
        if (conflictAction) {
          slot[conflictAction] = slot[recording.action];
        }
        slot[recording.action] = k;
        return { ...prev, [recording.slot]: slot };
      });
      setRecording(null);
    };
    window.addEventListener("keydown", handler, { capture: true });
    return () => window.removeEventListener("keydown", handler, { capture: true } as any);
  }, [recording]);

  const handleSave = () => {
    saveBindings(bindings);
    toast.success("Key bindings saved");
    onOpenChange(false);
  };

  const handleReset = () => {
    const def = resetBindings();
    setBindings(def);
    toast.success("Reset to defaults");
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-md">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Keyboard className="h-5 w-5" /> Customize Controls
          </DialogTitle>
        </DialogHeader>

        <Tabs defaultValue="p1" className="w-full">
          <TabsList className="grid w-full grid-cols-2">
            <TabsTrigger value="p1">Player 1 (Red)</TabsTrigger>
            <TabsTrigger value="p2">Player 2 (Blue)</TabsTrigger>
          </TabsList>

          {(["p1", "p2"] as const).map((slot) => (
            <TabsContent key={slot} value={slot} className="space-y-2 mt-3">
              {ACTION_ORDER.map((action) => {
                const isRec = recording?.slot === slot && recording.action === action;
                return (
                  <div
                    key={action}
                    className="flex items-center justify-between rounded-md border border-border bg-muted/40 px-3 py-2"
                  >
                    <span className="text-sm font-medium text-foreground">
                      {ACTION_LABELS[action]}
                    </span>
                    <Button
                      variant={isRec ? "default" : "outline"}
                      size="sm"
                      className="min-w-[88px] font-mono"
                      onClick={() => setRecording({ slot, action })}
                    >
                      {isRec ? "Press a key…" : prettyKey(bindings[slot][action])}
                    </Button>
                  </div>
                );
              })}
            </TabsContent>
          ))}
        </Tabs>

        {recording && (
          <p className="text-xs text-muted-foreground text-center">
            Press any key (Esc to cancel). Conflicts within the same player are auto-swapped.
          </p>
        )}

        <DialogFooter className="flex-row justify-between sm:justify-between gap-2">
          <Button variant="ghost" size="sm" onClick={handleReset} className="gap-1">
            <RotateCcw className="h-4 w-4" /> Reset
          </Button>
          <div className="flex gap-2">
            <Button variant="outline" size="sm" onClick={() => onOpenChange(false)}>
              Cancel
            </Button>
            <Button size="sm" onClick={handleSave}>
              Save
            </Button>
          </div>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
