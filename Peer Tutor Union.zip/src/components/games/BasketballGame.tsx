import { useState, useRef, useEffect, useCallback } from "react";
import { Button } from "@/components/ui/button";
import { Keyboard } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { playShoot, playScore, playFootstep } from "@/lib/gameSounds";
import courtBg from "@/assets/basketball-court-bg.png";
import tourArenaBg from "@/assets/world-tour-arena-bg.jpg";
import { activeControlKeys, loadBindings, prettyKey, type AllBindings } from "@/lib/keybindings";
import KeyBindingsDialog from "./KeyBindingsDialog";

const W = 800, H = 500;
const GROUND_Y = H - 80;
const BALL_R = 13;
const GRAVITY = 0.38;
const RIM_Y = 155;
// Rim X is per-match: lower leagues use a compact court (rims pulled inward),
// higher leagues spread the rims out toward the sidelines. The MAX values are
// the full-size anchor points used at courtScale=1.
const RIM_LEFT_X_MAX = 60;
const RIM_RIGHT_X_MAX = 740;
const COURT_MID_X = (RIM_LEFT_X_MAX + RIM_RIGHT_X_MAX) / 2;
const RIM_RADIUS = 26;
const HEAD_R = 24;
const BODY_H = 28;
const LEG_H = 18;
/** Base player height (used for non-league modes / players without a heightBoost). */
const PLAYER_H = HEAD_R * 2 + BODY_H + LEG_H;
const DEFAULT_GAME_TIME = 90;
const MID_X = W / 2;
const SPRINT_DURATION = 30;
const SPRINT_COOLDOWN = 300;
const SPRINT_SPEED = 7;
const P_LEFT_LIMIT = 50;
const P_RIGHT_LIMIT = W - 50;

// Live rim positions for the current match — overwritten by setCourtScale()
// inside BasketballGame before each game starts.
let RIM_LEFT_X = RIM_LEFT_X_MAX;
let RIM_RIGHT_X = RIM_RIGHT_X_MAX;
function setCourtScale(scale: number) {
  const halfMax = (RIM_RIGHT_X_MAX - RIM_LEFT_X_MAX) / 2;
  const half = halfMax * scale;
  RIM_LEFT_X = COURT_MID_X - half;
  RIM_RIGHT_X = COURT_MID_X + half;
}

/** Effective body+legs height of a player, including any per-card height boost. */
function pHeight(p: { heightBoost?: number }): number {
  return PLAYER_H + (p.heightBoost ?? 0);
}

/** Trigger the takeoff stretch anim — call right after setting vy<0 + jumping=true. */
function triggerTakeoff(p: Player) {
  // Only restart the anim if not already mid-stretch (prevents stutter when
  // multiple systems try to launch the same player on the same frame).
  if ((p.takeoffAnim ?? 0) < 0.4) p.takeoffAnim = 1;
  p.landAnim = 0;
}
/** Trigger the landing squash anim — call right after setting y=GROUND_Y + jumping=false. */
function triggerLanding(p: Player) {
  // Skip squash for "non-jumps" (player was reset on the ground without falling).
  // Only fire when there was meaningful downward velocity at impact.
  if ((p.vy ?? 0) > 1.5 || p.jumping) p.landAnim = 1;
  p.takeoffAnim = 0;
}
/** Per-frame visual scale applied to a player's body. Returns {sx, sy, dy}.
 *  sy <1 = squashed (landing), >1 = stretched (takeoff). dy keeps feet planted. */
function getJumpAnimScale(p: Player): { sx: number; sy: number } {
  const t = p.takeoffAnim ?? 0;
  const l = p.landAnim ?? 0;
  // Stretch on takeoff (peaks at sy=1.10), squash on landing (sy=0.82 → 1.0).
  const sy = 1 + t * 0.10 - l * 0.18;
  const sx = 1 - t * 0.06 + l * 0.12;
  return { sx, sy };
}

// Control keys are now user-customizable. The set of keys to preventDefault on
// is derived from the live bindings inside the component (see keysRef effect).

type CardStats = { speed: number; shooting: number; three_point: number; defense: number; dunk: number };

type Player = {
  x: number; y: number; vx: number; vy: number;
  facing: 1 | -1; jumping: boolean; hasBall: boolean;
  score: number; name: string; jersey: string; skin: string;
  shootCooldown: number; grabCooldown: number;
  sprintTimer: number; sprintCooldown: number; isSprinting: boolean;
  team: number;
  isRobot: boolean;
  aiState: "idle" | "chasing" | "positioning" | "shooting" | "defending" | "rebounding" | "passing";
  aiTargetX: number;
  aiWaitTimer: number;
  /** Per-player AI difficulty (only meaningful when isRobot=true) */
  difficulty?: RobotDifficulty;
  /** Which human-control slot this player uses (1 or 2) */
  humanSlot?: 1 | 2;
  /** Coordinated team role assigned each frame: scorer attacks the rim, rebounder camps under it, defender guards opponent */
  aiRole?: "scorer" | "rebounder" | "defender";
  /** Preferred shot type chosen each possession for variety */
  preferredShot?: "dunk" | "two" | "three";
  /** Frames remaining before this AI may try to pass again */
  passCooldown?: number;
  /** Card stats used by both AI and human-controlled league players */
  playerStats?: CardStats;
  /** Extra height (px) added to legs+body for taller higher-tier players. Replaces part of what used to be a jump bonus, so reach stays similar but the silhouette grows. */
  heightBoost?: number;
  /** Traitor: when true (and AI-controlled), this player attacks their OWN basket instead of the enemy's. Used by Jeffrey Flying. */
  isTraitor?: boolean;
  /** "Wings" ability — Jeffrey Flying sprouts wings and floats upward for ~3s after losing the ball, untouchable. Counts down each frame in the physics loop. */
  flyingTimer?: number;
  /** When true, this player has the wings ability (Jeffrey Flying). Used to trigger flyingTimer on steals. */
  hasWings?: boolean;
  /** Roaming target X used while flying — re-rolled periodically for chaotic full-court flight. */
  flyTargetX?: number;
  /** Frames until next flight target re-roll. */
  flyRerollIn?: number;
  /** Thomas Wu "迟到" skill — when set, Thomas hides off-court and reappears at the scheduled match second. */
  lateUntilSecond?: number;
  /** Sandela Wu "违纪单" — flagged when this player has been fouled out and removed from play. */
  ejected?: boolean;
  /** Match-elapsed second at which this ejected player should return to the court (10s after eject). */
  ejectedReturnAt?: number;
  /** True for Sandela Wu — enables her foul-out skill button (reusable with cooldown). */
  hasFoulCard?: boolean;
  /** Match-elapsed second at which Sandela's foul card next becomes usable (20s cooldown after each use). */
  foulCardReadyAt?: number;
  /** True for Jeffrey Flying teammates — used by AI to prefer passing to him. */
  isFlyMagnet?: boolean;
  /** Jeffrey Superman ability — when he gains the ball, he leaps high and fires a shot at the enemy rim immediately. */
  hasSuperShot?: boolean;
  /** Match-elapsed seconds at which Superman's air-shot becomes ready again (5s cooldown). */
  superShotReadyAt?: number;
  /** Coach + consumable boost as a fraction (e.g. 0.10 = +10%). Applied in-game to
   *  human control profile (move speed, jump, steal, etc.) AND to AI per-player
   *  difficulty so the boost reflects in actual gameplay, not just card numbers. */
  boost?: number;
  /** Starting X position — players warp back here when ball is reset to mid-court after a score. */
  homeX?: number;
  /** Optional jersey accent color (hex) for stripe/sash overlay. */
  jerseyAccent?: string;
  /** Optional jersey style — visual pattern overlay. */
  jerseyStyle?: "solid" | "stripes-h" | "stripes-v" | "sash";
  /** Smooth jump anim — counts down from 1 → 0 right after takeoff (legs stretch). */
  takeoffAnim?: number;
  /** Smooth landing anim — counts down from 1 → 0 right after touchdown (squash & rebound). */
  landAnim?: number;
};

type Ball = {
  x: number; y: number; vx: number; vy: number;
  held: boolean; holder: number | null;
  spin: number; trail: { x: number; y: number }[];
  scored: boolean; scoreTimer: number;
  lastShooterX: number;
  scoredPoints: number;
  waitingForGround: boolean;
  /** Which team just scored (set when a basket is made, used to award possession to the other team after reset). */
  lastScoringTeam?: 0 | 1;
};

function makePlayer(
  idx: number, x: number, team: number, isRobot: boolean,
  jersey: string, skin: string,
  opts?: {
    difficulty?: RobotDifficulty; humanSlot?: 1 | 2; nameOverride?: string;
    jerseyAccent?: string; jerseyStyle?: "solid" | "stripes-h" | "stripes-v" | "sash";
  },
): Player {
  const jerseys: Record<string, string> = { red: "#E74C3C", blue: "#3498DB", orange: "#E67E22", green: "#27AE60" };
  const diffEmoji: Record<RobotDifficulty, string> = { easy: "😊", medium: "🏀", hard: "🔥", allstar: "🌟", nba: "⭐", worldchampion: "🏆" };
  const defaultName = isRobot
    ? `${diffEmoji[opts?.difficulty ?? "medium"]}${idx + 1}`
    : opts?.humanSlot ? `P${opts.humanSlot}` : `P${idx + 1}`;
  return {
    x, y: GROUND_Y, vx: 0, vy: 0, facing: team === 0 ? 1 : -1 as 1 | -1,
    jumping: false, hasBall: idx === 0, score: 0,
    name: opts?.nameOverride ?? defaultName,
    jersey: jerseys[jersey] || jersey, skin,
    shootCooldown: 0, grabCooldown: 0,
    sprintTimer: 0, sprintCooldown: 0, isSprinting: false,
    team, isRobot,
    aiState: "idle",
    aiTargetX: x,
    aiWaitTimer: 0,
    difficulty: opts?.difficulty,
    humanSlot: opts?.humanSlot,
    homeX: x,
    jerseyAccent: opts?.jerseyAccent,
    jerseyStyle: opts?.jerseyStyle,
  };
}

function initPlayers(mode: GameMode, roster?: RosterSlot[]): Player[] {
  if (mode === "teamBattle" && roster) {
    return buildPlayersFromRoster(roster);
  }
  switch (mode) {
    case "single":
      return [makePlayer(0, 280, 0, false, "red", "#D4A373")];
    case "vsRobot":
      return [
        makePlayer(0, 280, 0, false, "red", "#D4A373"),
        makePlayer(1, 520, 1, true, "blue", "#FFDAB9"),
      ];
    case "2v2":
      return [
        makePlayer(0, 220, 0, false, "red", "#D4A373"),
        makePlayer(1, 580, 1, false, "blue", "#FFDAB9"),
        makePlayer(2, 320, 0, true, "orange", "#C4A882"),
        makePlayer(3, 480, 1, true, "green", "#E8C9A0"),
      ];
    default:
      return [
        makePlayer(0, 280, 0, false, "red", "#D4A373"),
        makePlayer(1, 520, 1, false, "blue", "#FFDAB9"),
      ];
  }
}

/** Roster slot for team battle / league mode */
export type RosterSlot = {
  team: 0 | 1;
  kind: "human" | "ai";
  /** 1-indexed human slot for keybinding (1 = WASD/F/G/R, 2 = arrows/./,/) */
  humanSlot?: 1 | 2;
  difficulty?: RobotDifficulty;
  /** Optional display name (for league mode showing card name) */
  displayName?: string;
  /** Optional stat boosts (0-99 each). Used in league mode to reflect player cards. */
  stats?: { speed: number; shooting: number; three_point: number; defense: number; dunk: number };
  /** Traitor flag — when AI-controlled, this player will shoot at their own basket. */
  isTraitor?: boolean;
  /** Thomas Wu "迟到" skill activated by player — he appears late at a random 10-15s mark. */
  lateSkill?: boolean;
  /** Coach + consumable boost as a fraction (e.g. 0.10 = +10%). Applied to BOTH stats AND
   *  in-game physics (move speed, shoot power, steal chance, etc.) so the boost is felt
   *  in actual gameplay, not just on the card. Used by:
   *   • team 0 (player) — coach + consumable bonuses from teamManager
   *   • team 1 (AI)     — World Tour late-stage overflow boost (when raw baseStat > 99) */
  boost?: number;
  /** Custom jersey: primary color (hex). Overrides the default team color. */
  jerseyColor?: string;
  /** Custom jersey: accent color (hex). Used for stripes/sash overlay. */
  jerseyAccent?: string;
  /** Custom jersey style — visual pattern. */
  jerseyStyle?: "solid" | "stripes-h" | "stripes-v" | "sash";
};


const TEAM_SKINS = ["#D4A373", "#FFDAB9", "#C4A882", "#E8C9A0", "#B8956A", "#F5DEB3"];
const TEAM0_JERSEYS = ["red", "orange", "#C0392B"];
const TEAM1_JERSEYS = ["blue", "green", "#5DADE2"];

function buildPlayersFromRoster(roster: RosterSlot[]): Player[] {
  const team0 = roster.filter(r => r.team === 0);
  const team1 = roster.filter(r => r.team === 1);
  const players: Player[] = [];
  // Spread team 0 on the left third, team 1 on the right third
  const placeTeam = (slots: RosterSlot[], teamIdx: 0 | 1) => {
    const xStart = teamIdx === 0 ? 180 : 540;
    const xEnd = teamIdx === 0 ? 360 : 720;
    const span = slots.length > 1 ? (xEnd - xStart) / (slots.length - 1) : 0;
    const jerseys = teamIdx === 0 ? TEAM0_JERSEYS : TEAM1_JERSEYS;
    slots.forEach((slot, i) => {
      const x = slots.length === 1 ? (xStart + xEnd) / 2 : xStart + span * i;
      const idx = players.length;
      const isRobot = slot.kind === "ai";
      const skin = TEAM_SKINS[idx % TEAM_SKINS.length];
      // Custom jersey overrides default team color when provided.
      const jersey = slot.jerseyColor ?? jerseys[i % jerseys.length];
      const p = makePlayer(idx, x, teamIdx, isRobot, jersey, skin, {
        difficulty: slot.difficulty,
        humanSlot: slot.humanSlot,
        nameOverride: slot.displayName,
        jerseyAccent: slot.jerseyAccent,
        jerseyStyle: slot.jerseyStyle,
      });
      if (slot.stats) {
        p.playerStats = slot.stats;
        // Visual height varies by stats but capped at +30% over the base
        // silhouette (PLAYER_H = 94px → max boost ≈ 28px). Stats 60→0%, 95→30%.
        // High-tier cards look taller, but never so long-legged that they
        // can't reach a grounded ball.
        const norm = (v: number) => Math.max(0, Math.min(1, (v - 60) / 35));
        const factor = norm(slot.stats.defense) * 0.55 + norm(slot.stats.dunk) * 0.45;
        p.heightBoost = Math.round(PLAYER_H * 0.30 * factor);
      }
      if (slot.boost) p.boost = slot.boost;
      // Traitor only matters while AI-controlled: when the user grabs the
      // controls, they're free to play normally. Jeffrey Flying activates it.
      if (slot.isTraitor && isRobot) p.isTraitor = true;
      // Wings ability: Jeffrey Flying sprouts wings when he loses the ball,
      // floats up untouchable for 3s. Works even when the human controls him.
      if (slot.displayName === "Jeffrey Flying") {
        p.hasWings = true;
        p.isFlyMagnet = true;
      }
      // Sandela Wu — one-time foul-card eject ability. Player team gets a UI
      // button; AI team auto-triggers ~3-6s into the match against a random opponent.
      if (slot.displayName === "Sandela Wu") {
        p.hasFoulCard = true;
      }
      // Jeffrey Superman — every 5 s, the moment he gains possession he leaps
      // skyward and fires an immediate arc shot at the enemy basket.
      if (slot.displayName === "Jeffrey Superman") {
        p.hasSuperShot = true;
        p.superShotReadyAt = 0;
      }
      // Thomas Wu "迟到" — pick a random 10..15s appearance second; until then he's hidden.
      if (slot.lateSkill && slot.displayName === "Thomas Wu") {
        p.lateUntilSecond = 10 + Math.floor(Math.random() * 6); // 10..15
      }
      players.push(p);
    });
  };
  placeTeam(team0, 0);
  placeTeam(team1, 1);
  // Pick the first ON-COURT player to start with the ball (skips late Thomas Wu)
  const startIdx = players.findIndex(p => !p.ejected && (p.lateUntilSecond ?? 0) === 0);
  players.forEach((p, i) => { p.hasBall = i === startIdx; });
  // ── DEBUG: dump matchup math so we can see exactly what each AI looks like ──
  try {
    const sumStats = (s?: CardStats) =>
      s ? s.speed + s.shooting + s.three_point + s.defense + s.dunk : 0;
    const rows = players.map((p, i) => {
      const baseDiff = p.difficulty ? DIFFICULTY[p.difficulty] : null;
      const eff = p.playerStats && baseDiff ? applyStatsToDiff(baseDiff, p.playerStats) : baseDiff;
      return {
        team: p.team,
        name: p.name ?? `P${i}`,
        kind: p.isRobot ? (p.difficulty ?? "ai") : "human",
        OVR: sumStats(p.playerStats),
        stats: p.playerStats
          ? `spd${p.playerStats.speed} sht${p.playerStats.shooting} 3p${p.playerStats.three_point} def${p.playerStats.defense} dnk${p.playerStats.dunk}`
          : "—",
        eff_speed: eff?.speed.toFixed(2),
        eff_shootAcc: eff?.shootAccuracy.toFixed(2),
        eff_steal: eff?.stealChance.toFixed(2),
        eff_block: eff?.blockChance.toFixed(2),
        eff_react: eff?.reactionDelay,
      };
    });
    const ovrTeam0 = players.filter(p => p.team === 0).reduce((s, p) => s + sumStats(p.playerStats), 0);
    const ovrTeam1 = players.filter(p => p.team === 1).reduce((s, p) => s + sumStats(p.playerStats), 0);
    console.groupCollapsed(`[Match Debug] Team0 OVR=${ovrTeam0} vs Team1 OVR=${ovrTeam1}`);
    console.table(rows);
    console.groupEnd();
  } catch (e) { /* noop */ }
  return players;
}

function initBall(): Ball {
  return { x: 280, y: GROUND_Y - PLAYER_H + 5, vx: 0, vy: 0, held: true, holder: 0, spin: 0, trail: [], scored: false, scoreTimer: 0, lastShooterX: 280, scoredPoints: 0, waitingForGround: false };
}

export type GameMode = "single" | "vsRobot" | "local" | "2v2" | "teamBattle";
export type RobotDifficulty = "easy" | "medium" | "hard" | "allstar" | "nba" | "worldchampion";

type DifficultyParams = {
  speed: number; shootAccuracy: number; shootRange: number;
  stealChance: number; reactionDelay: number; canDunk: boolean;
  sprintChance: number; grabRange: number;
  jumpPower: number; shotAggression: number; blockChance: number; blockRange: number; contestRange: number;
};

// Note: hard/allstar/nba have been rolled back ~50% from the previous aggressive buff.
// "worldchampion" represents the original full-strength NBA difficulty (peak challenge tier).
const DIFFICULTY: Record<RobotDifficulty, DifficultyParams> = {
  easy:          { speed: 3.0, shootAccuracy: 4.2,  shootRange: 360, stealChance: 0.28, reactionDelay: 10, canDunk: false, sprintChance: 0.03, grabRange: 52, jumpPower: 9.8,  shotAggression: 0.35, blockChance: 0.26, blockRange: 60,  contestRange: 88  },
  medium:        { speed: 3.6, shootAccuracy: 2.6,  shootRange: 415, stealChance: 0.42, reactionDelay: 6,  canDunk: false, sprintChance: 0.07, grabRange: 58, jumpPower: 10.4, shotAggression: 0.52, blockChance: 0.42, blockRange: 70,  contestRange: 98  },
  hard:          { speed: 4.4, shootAccuracy: 1.55, shootRange: 460, stealChance: 0.58, reactionDelay: 3,  canDunk: true,  sprintChance: 0.15, grabRange: 67, jumpPower: 11.0, shotAggression: 0.64, blockChance: 0.58, blockRange: 80,  contestRange: 112 },
  // All-Star: tuned down from the previous "near-NBA" wall — feels reachable for ~1400 OVR teams.
  allstar:       { speed: 4.9, shootAccuracy: 1.15, shootRange: 495, stealChance: 0.66, reactionDelay: 2,  canDunk: true,  sprintChance: 0.20, grabRange: 72, jumpPower: 11.5, shotAggression: 0.74, blockChance: 0.66, blockRange: 88,  contestRange: 120 },
  // NBA Masters #1: clearable by ~1600 OVR; layers per-stage rating bump (0..+10 baseStat) for #2-#5.
  nba:           { speed: 5.4, shootAccuracy: 0.95, shootRange: 530, stealChance: 0.74, reactionDelay: 1,  canDunk: true,  sprintChance: 0.26, grabRange: 78, jumpPower: 12.0, shotAggression: 0.82, blockChance: 0.74, blockRange: 95,  contestRange: 130 },
  // World Champion stays the hardest tier, but no longer gets near-perfect steals/blocks on every possession.
  worldchampion: { speed: 6.35, shootAccuracy: 0.7,  shootRange: 590, stealChance: 0.84, reactionDelay: 0,  canDunk: true,  sprintChance: 0.30, grabRange: 82, jumpPower: 12.55, shotAggression: 0.88, blockChance: 0.85, blockRange: 98,  contestRange: 136 },
};

/**
 * Apply per-player card stats on top of the league's base difficulty so that
 * a Legend card actually plays better than a Bronze one. Each stat is 0..99
 * (typically 30..95) and contributes a small modifier — collectively this
 * makes lineup composition meaningful in league matches.
 */
function applyStatsToDiff(
  base: DifficultyParams,
  stats: CardStats,
): DifficultyParams {
  const clamp = (v: number, min: number, max: number) => Math.min(max, Math.max(min, v));
  // Wider normalization range so legendary players (95+) and bronze (40s) feel
  // dramatically different. norm(50)≈-0.4, norm(75)=0, norm(99)≈+0.96
  const norm = (v: number) => (v - 75) / 25;
  const speedN = norm(stats.speed);
  const shootingN = norm(stats.shooting);
  const threeN = norm(stats.three_point);
  const defenseN = norm(stats.defense);
  const dunkN = norm(stats.dunk);
  return {
    ...base,
    // Stronger stat translation so stacked teams actually feel stacked.
    // ── Caps tightened so super-OVR teams stay playable (don't fly off-screen):
    //   speed cap 6.4 (was 8.2), grabRange 95 (was 116), jump 13.5 (was 13.3 — head clears rim ~70px),
    //   contest 130 (was 156), block 110 (was 134).
    speed: clamp(base.speed * (1 + speedN * 0.95), 1.9, 6.4),
    shootAccuracy: clamp(base.shootAccuracy * (1 - shootingN * 1.05), 0.16, 7.0),
    shootRange: Math.round(clamp(base.shootRange + stats.three_point * 3.8 - 220, 210, 710)),
    stealChance: clamp(base.stealChance + defenseN * 0.42, 0.05, 0.92),
    grabRange: Math.round(clamp(base.grabRange + defenseN * 28 + Math.max(0, dunkN) * 16, 34, 95)),
    canDunk: base.canDunk || stats.dunk >= 64,
    sprintChance: clamp(base.sprintChance + Math.max(0, speedN) * 0.32, 0.02, 0.58),
    reactionDelay: Math.max(0, base.reactionDelay - Math.round(defenseN * 8 + speedN * 4)),
    jumpPower: clamp(base.jumpPower + Math.max(0, defenseN) * 0.7 + Math.max(0, dunkN) * 0.95, 8.9, 13.5),
    shotAggression: clamp(base.shotAggression + shootingN * 0.3 + threeN * 0.28, 0.14, 0.99),
    blockChance: clamp(base.blockChance + defenseN * 0.42 + Math.max(0, dunkN) * 0.26, 0.08, 0.95),
    blockRange: Math.round(clamp(base.blockRange + defenseN * 30 + Math.max(0, dunkN) * 22, 34, 110)),
    contestRange: Math.round(clamp(base.contestRange + defenseN * 34 + Math.max(0, speedN) * 18, 54, 130)),
  };
}

/** Trigger Jeffrey Flying's wings: 6 seconds aloft, untouchable. */
function triggerWingsIfJeffrey(p: Player) {
  if (p.hasWings) p.flyingTimer = 360; // ~6s @ 60fps
}

/**
 * Jeffrey Superman's signature move: when he gains possession (and his 5s
 * cooldown is ready), he leaps explosively into the air and immediately
 * fires a shot at the enemy rim. Works for both AI and human-controlled.
 */
function triggerSupermanShotIfReady(p: Player, ball: Ball, elapsedSec: number) {
  if (!p.hasSuperShot) return;
  if ((p.superShotReadyAt ?? 0) > elapsedSec) return;
  if (!p.hasBall || ball.holder === null) return;
  // Slam-jump skyward — Superman flies, doesn't just hop.
  p.vy = -16;
  p.jumping = true;
  // High release so the shot visibly comes from mid-air.
  const releaseX = p.x;
  const releaseY = p.y - pHeight(p) - 30;
  const trueTarget = p.team === 0 ? RIM_RIGHT_X : RIM_LEFT_X;
  const trueOwn    = p.team === 0 ? RIM_LEFT_X  : RIM_RIGHT_X;
  const targetRimX = p.isTraitor ? trueOwn : trueTarget;
  // Tight accuracy — Superman's signature shot is automatic when off cooldown.
  const shot = calcShotVelocity(releaseX, releaseY, targetRimX, RIM_Y, GRAVITY, 0.6, "rainbow");
  ball.held = false;
  ball.holder = null;
  p.hasBall = false;
  ball.x = releaseX;
  ball.y = releaseY;
  ball.vx = shot.vx;
  ball.vy = shot.vy;
  ball.lastShooterX = p.x;
  ball.trail = [];
  p.shootCooldown = Math.max(p.shootCooldown, 18);
  p.superShotReadyAt = elapsedSec + 5; // 5s cooldown
  playShoot();
}

/**
 * Players that are temporarily NOT on the court (Thomas Wu before his late
 * arrival, or anyone ejected by Sandela Wu's foul card). They:
 *   • are skipped by the AI loop, role assignment, and physics movement
 *   • do not render
 *   • cannot hold the ball
 */
function isOffCourt(p: Player): boolean {
  return !!p.ejected || (p.lateUntilSecond ?? 0) > 0;
}

function knockBallLoose(ball: Ball, holder: Player, defender: Player) {
  ball.held = false;
  ball.holder = null;
  holder.hasBall = false;
  ball.x = holder.x + defender.facing * 20;
  ball.y = Math.min(holder.y, GROUND_Y) - pHeight(holder) + 2;
  ball.vx = defender.facing * 3 + (Math.random() - 0.5) * 2;
  ball.vy = -6 - Math.max(0, holder.vy) * 0.35;
  ball.trail = [];
  triggerWingsIfJeffrey(holder);
}

function getHumanControlProfile(player: Player) {
  const clamp = (v: number, min: number, max: number) => Math.min(max, Math.max(min, v));
  // Coach + consumable boost (e.g. 0.10 = +10%). Lifts every gameplay axis so the
  // "+10% all stats" tooltip is felt in actual movement / shooting / defense.
  const b = 1 + (player.boost ?? 0);
  // ── HARD GAMEPLAY CAPS ──
  // Even with maxed cards + maxed boost, physical attributes must stay
  // playable: too-fast players overshoot the ball, too-long arms make the
  // game trivial, jump must reach above the rim but not fly off-screen.
  // jumpPower 13.6 → head clears RIM_Y (155) by ~70px at apex.
  const MAX_MOVE = 6.4;        // walking speed cap (was 7.5)
  const MAX_SPRINT = 8.6;      // sprint cap (was 9.8)
  const MAX_JUMP = 13.6;       // can dunk above the rim, doesn't fly off
  const MAX_SHOOT = 16.0;      // shot release power
  const MAX_STEAL = 0.92;      // never a guaranteed strip
  const MAX_CATCH = 82;        // grab radius (was 99 — too long)
  const MAX_CONTEST = 118;     // defensive reach (was 130)
  if (!player.playerStats) {
    return {
      moveSpeed: clamp(3.8 * b, 2.6, MAX_MOVE),
      sprintSpeed: clamp(SPRINT_SPEED * b, 6.4, MAX_SPRINT),
      jumpPower: clamp(10 * b, 9.1, MAX_JUMP),
      shootPower: clamp(12 * b, 10.4, MAX_SHOOT),
      stealChance: clamp(0.5 * b, 0.24, MAX_STEAL),
      catchRange: clamp(55 * b, 42, MAX_CATCH),
      contestRange: clamp(78 * b, 60, MAX_CONTEST),
    };
  }
  const norm = (v: number) => (v - 75) / 25;
  const { speed, shooting, three_point, defense, dunk } = player.playerStats;
  const moveSpeed = clamp(3.8 * (1 + norm(speed) * 0.55) * b, 2.6, MAX_MOVE);
  return {
    moveSpeed,
    sprintSpeed: clamp((moveSpeed + 3.0 + Math.max(0, norm(speed)) * 1.1), 6.4, MAX_SPRINT),
    jumpPower: clamp((10 + Math.max(0, norm(dunk)) * 0.9 + Math.max(0, norm(defense)) * 0.45) * b, 9.1, MAX_JUMP),
    shootPower: clamp((12 + norm(shooting) * 1.55 + norm(three_point) * 1.45) * b, 10.4, MAX_SHOOT),
    stealChance: clamp((0.5 + norm(defense) * 0.38) * b, 0.24, MAX_STEAL),
    catchRange: Math.round(clamp((55 + norm(defense) * 24 + Math.max(0, norm(dunk)) * 14) * b, 42, MAX_CATCH)),
    contestRange: Math.round(clamp((78 + norm(defense) * 26 + Math.max(0, norm(dunk)) * 18) * b, 60, MAX_CONTEST)),
  };
}

// Calculate the velocity needed to arc the ball from (sx, sy) INTO the rim from above.
// Randomizes the trajectory style each call so AI uses different shot types.
type ShotStyle = "lineDrive" | "normal" | "rainbow" | "moonshot";
function pickShotStyle(): ShotStyle {
  const r = Math.random();
  if (r < 0.25) return "lineDrive";
  if (r < 0.80) return "normal";
  return "rainbow";
}
function calcShotVelocity(sx: number, sy: number, rimX: number, rimY: number, g: number, accuracy: number, style?: ShotStyle): { vx: number; vy: number } {
  const dx = rimX - sx;
  const dist = Math.abs(dx);
  const s = style ?? pickShotStyle();
  // Different shot styles use different arc heights & flight times.
  // Caps keep flight time reasonable (no more multi-second moonshots).
  const styleParams: Record<ShotStyle, { aimAbove: number; tFactor: number; tMin: number; tMax: number }> = {
    lineDrive: { aimAbove: 25, tFactor: 7.5, tMin: 22, tMax: 38 },
    normal:    { aimAbove: 50, tFactor: 6.0, tMin: 28, tMax: 44 },
    rainbow:   { aimAbove: 75, tFactor: 5.0, tMin: 34, tMax: 50 },
    moonshot:  { aimAbove: 90, tFactor: 4.5, tMin: 38, tMax: 54 },
  };
  const sp = styleParams[s];
  const aimY = rimY - sp.aimAbove;
  const dy = aimY - sy;
  const t = Math.min(sp.tMax, Math.max(sp.tMin, dist / sp.tFactor));
  const vx = dx / t;
  const vy = (dy - 0.5 * g * t * t) / t;
  const jitterX = (Math.random() - 0.5) * accuracy * 0.6;
  const jitterY = (Math.random() - 0.5) * accuracy * 0.3;
  return { vx: vx + jitterX, vy: vy + jitterY };
}

const MIN_SHOOT_DIST = 120; // Don't shoot from directly under the basket

// X-offsets from rim for each shot type (positive = away from rim toward midcourt)
const SHOT_TYPE_OFFSETS = {
  dunk:  [40, 55, 70, 85],            // very close — drive to the rim
  two:   [130, 150, 170, 190],         // mid-range pull-up (inside arc)
  three: [220, 250, 280, 310, 340],    // beyond the arc
};

interface BasketballGameProps {
  singlePlayer?: boolean;
  timeLimit?: number;
  /** Auto-start the match without showing the controls/start screen. */
  autoStart?: boolean;
  /** When true, the game loop continues drawing but freezes time + physics (used for the intro overlay). */
  paused?: boolean;
  /** Optional display names for the score HUD (used in teamBattle / 2v2). */
  teamNames?: { team0?: string; team1?: string };
  gameMode?: GameMode;
  robotDifficulty?: RobotDifficulty;
  online?: { sessionId: string; isHost: boolean };
  onlinePlayerNames?: { me: string; opponent: string };
  /** Custom roster for "teamBattle" mode (1-6 slots, mix human + AI) */
  roster?: RosterSlot[];
  /** Called once when game ends with team scores (team0, team1). Used by league mode. */
  onMatchEnd?: (team0Score: number, team1Score: number) => void;
  /** When true, render premium World Tour visuals: massive arena background,
   *  hanging center scoreboard, and chrome-glass backboards. */
  tourMode?: boolean;
}

// ─── Team coordination ──────────────────────────────────
// Each frame, decide which teammate plays which role for each team.
// scorer    → ball-handler / chases loose ball
// rebounder → camps under appropriate rim ready for misses
// defender  → guards opposing ball-handler / cutters
function assignTeamRoles(allPlayers: Player[], ball: Ball) {
  for (const team of [0, 1] as const) {
    // AI teammates that need a role this frame.
    const mates = allPlayers.map((p, i) => ({ p, i })).filter(({ p }) => p.team === team && p.isRobot && !isOffCourt(p));
    if (mates.length === 0) continue;

    const targetRimX = team === 0 ? RIM_RIGHT_X : RIM_LEFT_X;
    const ownRimX = team === 0 ? RIM_LEFT_X : RIM_RIGHT_X;
    const weHaveBall = ball.held && ball.holder !== null && allPlayers[ball.holder]?.team === team;
    const oppHasBall = ball.held && ball.holder !== null && allPlayers[ball.holder]?.team !== team;
    // The teammate (AI or HUMAN) currently holding the ball — used as the
    // "handler" anchor so AI mates know to spread away from him for spot-up.
    // BUG FIX: previously `mates` was filtered to robots only, so when the
    // human player held the ball there was no `handler` → we fell into the
    // loose-ball branch and AI teammates clustered at one identical spot-up
    // position (effectively standing still).
    const teammateHolder = (weHaveBall && ball.holder !== null) ? allPlayers[ball.holder] : null;

    if (mates.length === 1) {
      mates[0].p.aiRole = "scorer";
      continue;
    }

    if (weHaveBall && teammateHolder) {
      // Robot mates, sorted away from the holder so the closest becomes
      // rebounder (cuts to the rim) and the rest spread out.
      const aiMates = mates.filter(({ p }) => p !== teammateHolder);
      // If the holder is one of our AI mates, mark them scorer; otherwise the
      // human is the scorer and ALL aiMates need spread roles.
      const aiHandler = aiMates.length < mates.length ? null : null;
      void aiHandler;
      mates.forEach(({ p }) => {
        if (p === teammateHolder) p.aiRole = "scorer";
      });
      const rest = aiMates;
      rest.sort((a, b) => Math.abs(a.p.x - targetRimX) - Math.abs(b.p.x - targetRimX));
      if (rest[0]) rest[0].p.aiRole = "rebounder";
      for (let k = 1; k < rest.length; k++) rest[k].p.aiRole = "scorer";
    } else if (oppHasBall) {
      const holder = allPlayers[ball.holder!];
      const sorted = [...mates].sort((a, b) => Math.abs(a.p.x - holder.x) - Math.abs(b.p.x - holder.x));
      sorted[0].p.aiRole = "defender";
      const rest = sorted.slice(1);
      rest.sort((a, b) => Math.abs(a.p.x - ownRimX) - Math.abs(b.p.x - ownRimX));
      rest[0].p.aiRole = "rebounder";
      for (let k = 1; k < rest.length; k++) rest[k].p.aiRole = "defender";
    } else {
      // Loose ball / shot in flight
      const sorted = [...mates].sort((a, b) => Math.abs(a.p.x - ball.x) - Math.abs(b.p.x - ball.x));
      sorted[0].p.aiRole = "scorer";
      const rest = sorted.slice(1);
      const ballHeadingToOppRim = Math.abs(ball.x - targetRimX) < Math.abs(ball.x - ownRimX);
      const reboundRimX = ballHeadingToOppRim ? targetRimX : ownRimX;
      rest.sort((a, b) => Math.abs(a.p.x - reboundRimX) - Math.abs(b.p.x - reboundRimX));
      if (rest[0]) rest[0].p.aiRole = "rebounder";
      for (let k = 1; k < rest.length; k++) rest[k].p.aiRole = "defender";
    }
  }
}

/** Draw a cinematic hanging center-arena scoreboard for World Tour matches.
 *  Suspended from twin cables at the top of the canvas; shows TEAM A — SCORE — :
 *  — SCORE — TEAM B with a flashing match clock and red TV-style "LIVE" pill. */
function drawHangingScoreboard(
  ctx: CanvasRenderingContext2D,
  s0: number, s1: number,
  name0: string, name1: string,
  secondsLeft: number, now: number,
) {
  const cw = 800; // canvas width assumed
  const boardW = 360, boardH = 78;
  const boardX = cw / 2 - boardW / 2;
  const boardY = 6;

  // Suspension cables
  ctx.strokeStyle = "rgba(80,90,110,0.85)";
  ctx.lineWidth = 1.4;
  for (const cx of [boardX + 50, boardX + boardW - 50]) {
    ctx.beginPath();
    ctx.moveTo(cx, 0);
    ctx.lineTo(cx, boardY + 4);
    ctx.stroke();
  }

  // Outer chrome frame
  ctx.fillStyle = "#1a1f26";
  ctx.beginPath();
  (ctx as any).roundRect(boardX - 4, boardY - 2, boardW + 8, boardH + 6, 9);
  ctx.fill();
  // Top chrome strip
  const top = ctx.createLinearGradient(0, boardY - 2, 0, boardY + 8);
  top.addColorStop(0, "#6b7380"); top.addColorStop(1, "#2a2f38");
  ctx.fillStyle = top;
  ctx.fillRect(boardX - 4, boardY - 2, boardW + 8, 6);

  // Inner LED panel
  const panel = ctx.createLinearGradient(0, boardY, 0, boardY + boardH);
  panel.addColorStop(0, "#0a1224"); panel.addColorStop(1, "#050a14");
  ctx.fillStyle = panel;
  (ctx as any).roundRect(boardX, boardY + 4, boardW, boardH - 8, 6);
  ctx.fill();

  // LED dot pattern texture
  ctx.fillStyle = "rgba(255,255,255,0.025)";
  for (let y = boardY + 8; y < boardY + boardH - 6; y += 4) {
    for (let x = boardX + 4; x < boardX + boardW - 4; x += 4) {
      ctx.fillRect(x, y, 1, 1);
    }
  }

  // Team labels (small)
  ctx.font = "bold 10px Arial";
  ctx.textAlign = "center";
  ctx.fillStyle = "#ff6b6b";
  ctx.fillText(name0.slice(0, 12).toUpperCase(), boardX + 60, boardY + 20);
  ctx.fillStyle = "#5dade2";
  ctx.fillText(name1.slice(0, 12).toUpperCase(), boardX + boardW - 60, boardY + 20);

  // Big LED scores
  ctx.font = "bold 30px 'Courier New', monospace";
  ctx.fillStyle = "#ff3b3b";
  ctx.shadowColor = "rgba(255,59,59,0.7)";
  ctx.shadowBlur = 10;
  ctx.fillText(String(s0).padStart(2, "0"), boardX + 60, boardY + 52);
  ctx.fillStyle = "#3da9fc";
  ctx.shadowColor = "rgba(61,169,252,0.7)";
  ctx.fillText(String(s1).padStart(2, "0"), boardX + boardW - 60, boardY + 52);
  ctx.shadowBlur = 0;

  // Center colon + clock
  ctx.fillStyle = "rgba(255,255,255,0.85)";
  ctx.font = "bold 24px Arial";
  ctx.fillText(":", cw / 2, boardY + 48);

  // Clock pill
  const mm = Math.floor(secondsLeft / 60);
  const ss = secondsLeft % 60;
  const clock = `${mm}:${String(ss).padStart(2, "0")}`;
  const urgent = secondsLeft <= 10;
  ctx.fillStyle = urgent ? "rgba(231,76,60,0.95)" : "rgba(20,28,42,0.95)";
  (ctx as any).roundRect(cw / 2 - 28, boardY + 12, 56, 14, 4);
  ctx.fill();
  ctx.fillStyle = urgent && Math.floor(now / 250) % 2 === 0 ? "#fff" : "#ffd166";
  ctx.font = "bold 11px 'Courier New', monospace";
  ctx.fillText(clock, cw / 2, boardY + 23);

  // LIVE pill
  if (Math.floor(now / 600) % 2 === 0) {
    ctx.fillStyle = "#e74c3c";
    (ctx as any).roundRect(cw / 2 - 17, boardY + 60, 34, 11, 3);
    ctx.fill();
    ctx.fillStyle = "#fff";
    ctx.font = "bold 8px Arial";
    ctx.fillText("● LIVE", cw / 2, boardY + 68);
  }
}

function pickShotType(diff: DifficultyParams): "dunk" | "two" | "three" {
  const r = Math.random();
  if (diff.canDunk) {
    if (r < 0.30) return "dunk";
    if (r < 0.65) return "three";
    return "two";
  }
  if (r < 0.40) return "three";
  if (r < 0.85) return "two";
  return "dunk"; // weak AI rarely drives but it can happen
}

function pickSpotForShotType(shotType: "dunk" | "two" | "three", targetRimX: number, team: number): number {
  const offsets = SHOT_TYPE_OFFSETS[shotType];
  const off = offsets[Math.floor(Math.random() * offsets.length)];
  const dir = team === 0 ? -1 : 1; // team 0 attacks right rim → shoot from its left
  return targetRimX + dir * off + (Math.random() - 0.5) * 20;
}


// ─── Pass logic ──────────────────────────────────────────
// Score how "open" a teammate is for a pass. Higher = better target.
function evaluatePassTarget(
  holder: Player, mate: Player, allPlayers: Player[], targetRimX: number,
): number {
  const dxMate = mate.x - holder.x;
  if (Math.abs(dxMate) < 60) return -Infinity; // too close to bother

  // Nearest opponent to teammate
  let minOppDist = Infinity;
  for (const p of allPlayers) {
    if (p.team === mate.team) continue;
    const d = Math.hypot(p.x - mate.x, p.y - mate.y);
    if (d < minOppDist) minOppDist = d;
  }

  // Pass-lane blocked check (defender within 32px of holder→mate segment)
  for (const p of allPlayers) {
    if (p.team === mate.team) continue;
    const lx = mate.x - holder.x;
    const ly = mate.y - holder.y;
    const len2 = lx * lx + ly * ly;
    if (len2 < 1) continue;
    const t = ((p.x - holder.x) * lx + (p.y - holder.y) * ly) / len2;
    if (t <= 0.05 || t >= 0.95) continue;
    const projX = holder.x + lx * t;
    const projY = holder.y + ly * t;
    const perpDist = Math.hypot(p.x - projX, p.y - projY);
    if (perpDist < 32) return -Infinity; // blocked
  }

  const opennessScore = Math.min(minOppDist, 200);
  const distToRim = Math.abs(mate.x - targetRimX);
  const positionBonus = Math.max(0, 400 - distToRim) * 0.3;
  // Jeffrey magnet: AI teammates strongly prefer to dish to flying Jeffrey.
  const jeffBonus = mate.isFlyMagnet ? 220 : 0;
  return opennessScore + positionBonus + jeffBonus;
}

/** Execute a pass: launches the ball toward the teammate. */
function executePass(holder: Player, mate: Player, ball: Ball): void {
  const facingDir = holder.team === 0 ? 1 : -1;
  const releaseY = Math.min(holder.y, GROUND_Y) - pHeight(holder) + 5;
  const releaseX = holder.x + facingDir * 25;
  const targetX = mate.x;
  const targetY = Math.min(mate.y, GROUND_Y) - pHeight(mate) + 5;
  const dx = targetX - releaseX;
  const dy = targetY - releaseY;
  const dist = Math.hypot(dx, dy);
  const t = Math.max(14, dist / 12); // flatter & faster than a shot
  const vx = dx / t;
  const vy = (dy - 0.5 * GRAVITY * t * t) / t;

  ball.held = false; ball.holder = null;
  holder.hasBall = false;
  ball.x = releaseX; ball.y = releaseY;
  ball.vx = vx; ball.vy = vy;
  holder.passCooldown = 60;
  holder.aiState = "passing";
  holder.facing = dx > 0 ? 1 : -1;
  mate.facing = (releaseX - mate.x) > 0 ? 1 : -1;
}

function robotAI(
  robot: Player, robotIdx: number, ball: Ball,
  allPlayers: Player[], dt: number, frameCount: number,
  diff: DifficultyParams,
  elapsedSec: number,
) {
  const opponents = allPlayers.filter(p => p.team !== robot.team);
  // Traitor twist: a traitor AI swaps which rim he attacks. Everything else
  // (passing, defense roles, stat scaling) stays normal — he just thinks the
  // OWN hoop is the target.
  const trueTarget = robot.team === 0 ? RIM_RIGHT_X : RIM_LEFT_X;
  const trueOwn    = robot.team === 0 ? RIM_LEFT_X  : RIM_RIGHT_X;
  const targetRimX = robot.isTraitor ? trueOwn : trueTarget;
  const ownRimX    = robot.isTraitor ? trueTarget : trueOwn;
  const facingDir = robot.team === 0 ? 1 : -1;
  const role = robot.aiRole ?? "scorer";

  if (diff.reactionDelay > 0 && frameCount % (diff.reactionDelay + 1) !== 0) {
    robot.vx *= 0.9;
    return;
  }

  if (robot.aiWaitTimer > 0) {
    robot.aiWaitTimer -= dt;
    robot.vx *= 0.85;
    return;
  }

  // ─── Has the ball: consider passing, then shoot ───
  if (robot.hasBall && ball.holder === robotIdx) {
    const distToRim = Math.abs(robot.x - targetRimX);
    const releaseY = Math.min(robot.y, GROUND_Y) - pHeight(robot) + 5;
    const releaseX = robot.x + facingDir * 25;

    // ── Pass decision ──
    // Look for a teammate who is significantly more open than the holder.
    // Better AI passes more often & more accurately.
    if ((robot.passCooldown ?? 0) <= 0) {
      // Self openness (used as the "shoot vs pass" baseline)
      let myMinOppDist = Infinity;
      for (const opp of opponents) {
        const d = Math.hypot(opp.x - robot.x, opp.y - robot.y);
        if (d < myMinOppDist) myMinOppDist = d;
      }
      const mySelfScore = Math.min(myMinOppDist, 200) + Math.max(0, 400 - distToRim) * 0.3;

      // Find best teammate
      let bestMate: Player | null = null;
      let bestScore = -Infinity;
      for (const mate of allPlayers) {
        if (mate.team !== robot.team || mate === robot || !mate.isRobot && mate.humanSlot === undefined) {
          // allow passing to humans too
        }
        if (mate.team !== robot.team || mate === robot) continue;
        const score = evaluatePassTarget(robot, mate, allPlayers, targetRimX);
        if (score > bestScore) { bestScore = score; bestMate = mate; }
      }

      // Pass-aggressiveness scales with difficulty (better AI requires smaller advantage)
      const passThreshold = 60 - Math.min(40, diff.shootRange * 0.05);
      // Defender pressure on holder boosts urgency to pass
      const underPressure = myMinOppDist < 55;
      const advantage = bestScore - mySelfScore;

      if (bestMate && (advantage > passThreshold || (underPressure && bestScore > mySelfScore + 10))) {
        executePass(robot, bestMate, ball);
        robot.aiWaitTimer = 12;
        return;
      }
    }
    if ((robot.passCooldown ?? 0) > 0) robot.passCooldown! -= dt;


    // Pick a NEW shot type & spot whenever we don't have one
    if (!robot.preferredShot) {
      let st = pickShotType(diff);
      if (diff.shotAggression > 0.72 && Math.random() < 0.35) st = diff.canDunk && distToRim < 150 ? "dunk" : "three";
      if (st === "dunk" && !diff.canDunk) st = "two";
      robot.preferredShot = st;
      robot.aiTargetX = pickSpotForShotType(st, targetRimX, robot.team);
      robot.aiState = "positioning";
    }

    // DUNK: drive all the way to the rim
    if (robot.preferredShot === "dunk" && diff.canDunk) {
      if (distToRim < 55 && robot.shootCooldown <= 0) {
        robot.facing = facingDir;
        ball.held = false; ball.holder = null; robot.hasBall = false;
        ball.x = releaseX; ball.y = releaseY;
        robot.shootCooldown = 15;
        ball.lastShooterX = robot.x;
        const shot = calcShotVelocity(releaseX, releaseY, targetRimX, RIM_Y, GRAVITY, diff.shootAccuracy * 0.35, "lineDrive");
        ball.vx = shot.vx; ball.vy = shot.vy;
        if (!robot.jumping) { robot.vy = -diff.jumpPower; robot.jumping = true; }
        robot.aiState = "shooting";
        robot.aiWaitTimer = 30;
        robot.preferredShot = undefined;
        playShoot();
        return;
      }
      const driveTarget = targetRimX + (robot.team === 0 ? -45 : 45);
      const dx = driveTarget - robot.x;
      robot.vx = Math.sign(dx) * Math.min(diff.speed, Math.abs(dx) * 0.18);
      robot.facing = dx > 0 ? 1 : -1;
      return;
    }

    // PULL-UP / JUMPER: get to spot, then shoot
    const tolerance = robot.preferredShot === "three" ? 60 : 45;
    const atTarget = Math.abs(robot.x - robot.aiTargetX) < tolerance;
    const nearestOppDist = opponents.reduce((best, opp) => Math.min(best, Math.hypot(opp.x - robot.x, opp.y - robot.y)), Infinity);
    const pressured = nearestOppDist < diff.contestRange;
    // For 3pt shots: trust the chosen spot — don't reject because shootRange feels short
    const isThreeAttempt = robot.preferredShot === "three";
    const validRange = isThreeAttempt
      ? distToRim >= MIN_SHOOT_DIST - 15
      : distToRim >= MIN_SHOOT_DIST - 15 && distToRim < diff.shootRange;
    const aggression = isThreeAttempt ? Math.max(diff.shotAggression, 0.7) : diff.shotAggression;
    if (atTarget && validRange && robot.shootCooldown <= 0 && (Math.random() < aggression || pressured || distToRim < 180)) {
      robot.facing = facingDir;
      ball.held = false; ball.holder = null; robot.hasBall = false;
      ball.x = releaseX; ball.y = releaseY;
      robot.shootCooldown = 20;
      ball.lastShooterX = robot.x;
      robot.aiState = "shooting";

      const arcStyle: ShotStyle = robot.preferredShot === "three"
        ? (Math.random() < 0.6 ? "rainbow" : "normal")
        : (Math.random() < 0.5 ? "normal" : "rainbow");
      // 3pt shots get extra accuracy bias to match the longer flight (otherwise they always brick)
      const accMultiplier = isThreeAttempt ? 0.55 : 0.7;
      const shot = calcShotVelocity(releaseX, releaseY, targetRimX, RIM_Y, GRAVITY, diff.shootAccuracy * accMultiplier, arcStyle);
      ball.vx = shot.vx;
      ball.vy = shot.vy;

      if (!robot.jumping && Math.random() > 0.18) {
        robot.vy = -Math.max(9, diff.jumpPower - 0.6); robot.jumping = true;
      }
      robot.aiWaitTimer = 25;
      robot.preferredShot = undefined;
      playShoot();
      return;
    }

    // Move to chosen shooting spot
    const dx = robot.aiTargetX - robot.x;
    robot.vx = Math.sign(dx) * Math.min(diff.speed, Math.abs(dx) * 0.15);
    robot.facing = dx > 0 ? 1 : -1;
    robot.aiState = "positioning";

    for (const opp of opponents) {
      if (Math.abs(opp.x - robot.x) < diff.contestRange * 0.55 && Math.abs(opp.y - robot.y) < 34 && !robot.jumping) {
        robot.vy = -Math.max(9, diff.jumpPower - 0.8); robot.jumping = true;
      }
    }
    return;
  }

  // ─── Loose ball or shot in flight ───
  if (!ball.held && !ball.scored && !ball.waitingForGround) {
    if (role === "rebounder") {
      // Race to the rim the ball is closest to
      const reboundRimX = Math.abs(ball.x - targetRimX) < Math.abs(ball.x - ownRimX) ? targetRimX : ownRimX;
      const teammateShot = reboundRimX === targetRimX;
      const offset = robot.team === 0
        ? (teammateShot ? -50 : 50)
        : (teammateShot ? 50 : -50);
      const targetX = reboundRimX + offset;
      const dx = targetX - robot.x;
      robot.vx = Math.sign(dx) * Math.min(diff.speed, Math.abs(dx) * 0.18);
      robot.facing = dx > 0 ? 1 : -1;
      robot.aiState = "rebounding";

      const ballDist = Math.hypot(ball.x - robot.x, ball.y - (robot.y - PLAYER_H / 2));
      if (ballDist < diff.contestRange && ball.y < robot.y - PLAYER_H * 0.2 && !robot.jumping) {
        robot.vy = -diff.jumpPower; robot.jumping = true;
      }
      if (ballDist < diff.grabRange && robot.grabCooldown <= 0) {
        ball.held = true; ball.holder = robotIdx; robot.hasBall = true;
        allPlayers.forEach((p, i) => { if (i !== robotIdx) p.hasBall = false; });
        robot.grabCooldown = 15;
        robot.preferredShot = undefined;
        triggerSupermanShotIfReady(robot, ball, elapsedSec);
      }
      return;
    }

    // Scorer / defender chases the ball
    robot.aiState = "chasing";
    const dx = ball.x - robot.x;
    const dist = Math.hypot(dx, ball.y - (robot.y - PLAYER_H / 2));
    robot.vx = dx > 0 ? diff.speed : -diff.speed;
    robot.facing = dx > 0 ? 1 : -1;
    // Jump for loose balls more aggressively — any ball at chest height counts
    if (ball.y < robot.y - PLAYER_H * 0.3 && !robot.jumping && dist < diff.contestRange) { robot.vy = -diff.jumpPower; robot.jumping = true; }
    if (dist < diff.grabRange && robot.grabCooldown <= 0) {
      ball.held = true; ball.holder = robotIdx; robot.hasBall = true;
      allPlayers.forEach((p, i) => { if (i !== robotIdx) p.hasBall = false; });
      robot.grabCooldown = 15;
      robot.preferredShot = undefined;
      triggerSupermanShotIfReady(robot, ball, elapsedSec);
    }
    return;
  }

  // ─── Opponent has the ball ───
  if (ball.held && ball.holder !== null && allPlayers[ball.holder]?.team !== robot.team) {
    const holder = allPlayers[ball.holder];
    // Jeffrey Flying immunity: while his wings are out, defenders can't even
    // approach him — they wander toward their assigned spot instead.
    if (holder.flyingTimer && holder.flyingTimer > 0) {
      robot.aiState = "positioning";
      const targetX = ownRimX + (robot.team === 0 ? 90 : -90);
      const dx = targetX - robot.x;
      robot.vx = Math.sign(dx) * Math.min(diff.speed * 0.6, Math.abs(dx) * 0.15);
      return;
    }

    // Rebounder still helps defend if it's already close to the ball-handler
    const distToHolder = Math.hypot(holder.x - robot.x, holder.y - robot.y);
    if (role === "rebounder" && distToHolder > diff.contestRange * 1.3) {
      // Far away — camp under own basket for the rebound
      const targetX = ownRimX + (robot.team === 0 ? 70 : -70);
      const dx = targetX - robot.x;
      robot.vx = Math.sign(dx) * Math.min(diff.speed * 0.9, Math.abs(dx) * 0.15);
      robot.facing = facingDir * -1 as 1 | -1;
      robot.aiState = "rebounding";
      return;
    }

    // Defender / scorer / nearby rebounder: pressure the ball, contest shot
    robot.aiState = "defending";
    const dx = holder.x - robot.x;
    robot.vx = dx > 0 ? diff.speed * 1.15 : -diff.speed * 1.15;
    robot.facing = dx > 0 ? 1 : -1;
    const dist = Math.hypot(ball.x - robot.x, ball.y - (robot.y - PLAYER_H / 2));

    // Anticipate a steal: jump to contest aggressively (even when holder is just standing nearby)
    const holderStill = Math.abs(holder.vx) < 0.5;
    const elevatedBall = ball.y < holder.y - PLAYER_H * 0.35 || holder.jumping;
    // Aggressive jump-contest: try to swat at any ball within contestRange, scaling with steal+block
    const contestProb = Math.max(diff.stealChance * 0.95, diff.blockChance * 1.0);
    if (dist < diff.contestRange && !robot.jumping && Math.random() < contestProb) {
      robot.vy = -diff.jumpPower; robot.jumping = true;
    }
    // Even higher chance when ball is elevated or holder is still (shooting form)
    if ((holderStill || elevatedBall) && dist < diff.contestRange && !robot.jumping && Math.random() < Math.min(0.97, contestProb + 0.3)) {
      robot.vy = -diff.jumpPower; robot.jumping = true;
    }

    // Jeffrey's "strong hands" — much better at stripping & swatting
    const jeffMul = robot.hasWings ? 2.2 : 1.0;
    const jeffRangeBoost = robot.hasWings ? 28 : 0;

    // Mid-air swat: try to knock ball loose more often, not only on elevated shots
    if (dist < diff.blockRange + jeffRangeBoost && robot.grabCooldown <= 0
        && Math.random() < Math.min(0.99, diff.blockChance * (elevatedBall ? 1.5 : 1.1) * jeffMul)) {
      knockBallLoose(ball, holder, robot);
      robot.grabCooldown = 16;
      return;
    }

    // Direct strip-attempt: extend grab range when sprinting toward holder
    const stripRange = diff.grabRange + (robot.isSprinting ? 12 : 0) + jeffRangeBoost;
    if (dist < stripRange && robot.grabCooldown <= 0) {
      const stealProb = robot.isSprinting ? 1.0 : Math.min(0.99, diff.stealChance * 1.2 * jeffMul);
      if (Math.random() < stealProb) {
        triggerWingsIfJeffrey(holder);
        ball.holder = robotIdx; robot.hasBall = true;
        allPlayers.forEach((p, i) => { if (i !== robotIdx) p.hasBall = false; });
        robot.aiState = "positioning";
        robot.preferredShot = undefined;
        triggerSupermanShotIfReady(robot, ball, elapsedSec);
      }
      robot.grabCooldown = 18;
    }
    if (Math.abs(dx) > 90 && robot.sprintCooldown <= 0 && !robot.isSprinting && Math.random() < diff.sprintChance * 1.9) {
      robot.isSprinting = true; robot.sprintTimer = SPRINT_DURATION; robot.sprintCooldown = SPRINT_COOLDOWN;
    }
    return;
  }

  // ─── Teammate has ball: spread / cut based on role ───
  if (ball.held && ball.holder !== null && allPlayers[ball.holder]?.team === robot.team && ball.holder !== robotIdx) {
    if (role === "rebounder") {
      // Cut to opp rim for offensive rebound
      const targetX = targetRimX + (robot.team === 0 ? -55 : 55);
      const dx = targetX - robot.x;
      robot.vx = Math.sign(dx) * Math.min(diff.speed * 0.9, Math.abs(dx) * 0.15);
      robot.facing = facingDir;
      robot.aiState = "rebounding";
      return;
    }
    // Spot up away from teammate. Use robotIdx to fan teammates out at
    // different distances from the rim so they don't all stack on one X.
    robot.aiState = "positioning";
    const jitter = Math.sin(frameCount * 0.05 + robotIdx * 17) * 30;
    const indexSpread = ((robotIdx % 3) - 1) * 110; // -110, 0, +110
    const offenseBase = targetRimX + (robot.team === 0 ? -180 : 180);
    const offenseX = offenseBase + (robot.team === 0 ? indexSpread : -indexSpread) + jitter;
    const dx = offenseX - robot.x;
    robot.vx = dx > 10 ? diff.speed * 0.7 : dx < -10 ? -diff.speed * 0.7 : 0;
    robot.facing = facingDir;
    return;
  }

  // Default idle
  robot.aiState = "idle";
  const defX = role === "rebounder"
    ? ownRimX + (robot.team === 0 ? 70 : -70)
    : ownRimX + (robot.team === 0 ? 120 : -120);
  const dx = defX - robot.x;
  robot.vx = dx > 10 ? 2 : dx < -10 ? -2 : 0;
  robot.facing = facingDir;
}

export default function BasketballGame({ singlePlayer = false, timeLimit, gameMode: propMode, robotDifficulty = "medium", online, roster, onMatchEnd, autoStart = false, paused = false, teamNames, tourMode = false }: BasketballGameProps) {
  const isOnline = !!online;
  const mode: GameMode = isOnline ? "single" : (propMode || (singlePlayer ? "single" : "local"));
  const GAME_TIME = isOnline ? (timeLimit || 60) : (timeLimit || (mode === "single" ? 60 : DEFAULT_GAME_TIME));
  const diffParams = DIFFICULTY[robotDifficulty];
  // Per-difficulty rim shrinking — keep GOAT hard, but remove the overly punitive mini-rim.
  const rimScale = robotDifficulty === "worldchampion" ? 0.9 : robotDifficulty === "nba" ? 0.88 : robotDifficulty === "allstar" ? 0.92 : robotDifficulty === "hard" ? 0.96 : 1;
  const effectiveRimRadius = RIM_RADIUS * rimScale;
  // Rims always sit at the court baselines (full width) — no per-league
  // shrinking, otherwise the hoops drift toward the middle of the floor.
  setCourtScale(1.0);
  const pausedRef = useRef(paused);
  useEffect(() => { pausedRef.current = paused; }, [paused]);

  const canvasRef = useRef<HTMLCanvasElement>(null);
  const bgRef = useRef<HTMLImageElement | null>(null);
  const [started, setStarted] = useState(false);
  const [gameOver, setGameOver] = useState(false);
  const [scores, setScores] = useState([0, 0]);
  const [timeLeft, setTimeLeft] = useState(isOnline ? GAME_TIME : GAME_TIME);
  const [opponentScore, setOpponentScore] = useState(0);
  // In-game banner messages (Thomas Wu late, Sandela Wu foul card, etc.)
  const [overlayMsg, setOverlayMsg] = useState<string | null>(null);
  const overlayTimerRef = useRef<number | null>(null);
  const showOverlay = useCallback((msg: string, ms = 2500) => {
    setOverlayMsg(msg);
    if (overlayTimerRef.current) window.clearTimeout(overlayTimerRef.current);
    overlayTimerRef.current = window.setTimeout(() => setOverlayMsg(null), ms);
  }, []);
  // Sandela Wu — surface UI for the violation card if the user's roster has her.
  // `cooldownLeft` (seconds) drives the button label; 0 = ready, >0 = on cooldown.
  const [sandelaState, setSandelaState] = useState<{ idx: number; cooldownLeft: number } | null>(null);
  const [showSandelaPicker, setShowSandelaPicker] = useState(false);
  const lateAnnouncedRef = useRef<Set<number>>(new Set());
  const [myName, setMyName] = useState("我");
  const [opponentName, setOpponentName] = useState("对手");
  const [scoreSaved, setScoreSaved] = useState(false);
  const keysRef = useRef<Set<string>>(new Set());
  // Live key bindings — mutable ref so the rAF loop always sees the latest
  // mapping without re-creating its closure when the user rebinds keys.
  const bindingsRef = useRef<AllBindings>(loadBindings());
  const [bindingsTick, setBindingsTick] = useState(0); // re-render help text on change
  const [showKeyDialog, setShowKeyDialog] = useState(false);
  // Mirror of `scores` so the requestAnimationFrame loop can read current
  // scores without resubscribing each render (the loop deps don't track scores).
  const scoresRef = useRef<[number, number]>([0, 0]);
  const frameCountRef = useRef(0);
  // Per-match runtime catch-up: when team 1 (opponent AI) is losing badly,
  // they get a temporary stat multiplier so the loss never feels too lopsided.
  // Recomputed each frame from current score gap; ref so the AI loop reads it
  // without re-rendering. 1 = no catch-up, >1 = stronger.
  const catchupRef = useRef<{ team0: number; team1: number }>({ team0: 1, team1: 1 });
  // Overtime tracking — each tied period adds OT_SECONDS more time, up to a cap.
  const overtimeRef = useRef<number>(0);
  const OT_SECONDS = 30;
  const MAX_OVERTIMES = 3;
  // AI Sandela Wu auto-trigger: when an AI-controlled Sandela is on a team,
  // she fouls out a random opposing on-court player every time her card is
  // ready (first ~3-6s, then 20s cooldown between uses for the rest of the match).
  const aiSandelaTriggers = useRef<{ team: 0 | 1; sandelaIdx: number; nextTriggerAt: number }[]>([]);
  // ── Free-throw / foul state ────────────────────────────────────────────
  // A random foul is called every ~18-30s of match time. The fouled team
  // gets the ball at their free-throw line. If the fouled team contains a
  // human player, AI is frozen so the human can shoot the FT manually
  // (scoring uses normal 2/3-pt rules — no special FT points). After the
  // shot resolves, play resumes normally and the next foul timer is set.
  const freeThrowRef = useRef<{
    active: boolean;
    /** Team awarded the FT (0 or 1), or null when no FT is in progress. */
    shootingTeam: 0 | 1 | null;
    /** Index of the human-controlled FT shooter (only set when manual). */
    manualHumanIdx: number | null;
    /** Match-elapsed seconds at which the next foul should fire. */
    nextFoulAt: number;
    /** True once shooter has released the ball; we then watch for the result. */
    shotReleased: boolean;
  }>({ active: false, shootingTeam: null, manualHumanIdx: null, nextFoulAt: 18, shotReleased: false });
  const stateRef = useRef({ players: initPlayers(mode, roster), ball: initBall(), time: GAME_TIME });

  const channelRef = useRef<any>(null);
  const isHost = online?.isHost ?? true;
  const [channelReady, setChannelReady] = useState(false);
  const [peerReady, setPeerReady] = useState(false);

  useEffect(() => {
    const img = new Image();
    img.src = tourMode ? tourArenaBg : courtBg;
    img.onload = () => { bgRef.current = img; };
  }, [tourMode]);

  useEffect(() => {
    if (!isOnline || !online) return;
    setChannelReady(false);
    setPeerReady(false);
    const ch = supabase.channel(`bball-${online.sessionId}`, {
      config: { broadcast: { self: false } },
    });
    ch.on('broadcast', { event: 'score' }, ({ payload }: any) => {
      if (typeof payload?.score === 'number') setOpponentScore(payload.score);
    });
    ch.on('broadcast', { event: 'ready' }, () => {
      setPeerReady(true);
    });
    ch.subscribe((status: string) => {
      if (status === 'SUBSCRIBED') {
        setChannelReady(true);
        channelRef.current = ch;
        ch.send({ type: 'broadcast', event: 'ready', payload: {} });
        const readyInterval = setInterval(() => {
          ch.send({ type: 'broadcast', event: 'ready', payload: {} });
        }, 500);
        setTimeout(() => clearInterval(readyInterval), 10000);
        (async () => {
          const { data: players } = await supabase.from("game_players").select("user_id").eq("session_id", online.sessionId);
          const userIds = players?.map(p => p.user_id) || [];
          if (userIds.length > 0) {
            const { data: { user: me } } = await supabase.auth.getUser();
            const { data: profs } = await supabase.from("profiles").select("user_id, name").in("user_id", userIds);
            const nameMap: Record<string, string> = {};
            profs?.forEach(p => { nameMap[p.user_id] = p.name; });
            if (me) {
              setMyName(nameMap[me.id] || "我");
              const oppId = userIds.find(id => id !== me.id) || "";
              setOpponentName(nameMap[oppId] || "对手");
            }
          }
        })();
      }
    });
    return () => {
      supabase.removeChannel(ch);
      channelRef.current = null;
      setChannelReady(false);
      setPeerReady(false);
    };
  }, [isOnline, online?.sessionId]);

  useEffect(() => {
    let controlKeys = activeControlKeys(bindingsRef.current);
    const refreshBindings = () => {
      bindingsRef.current = loadBindings();
      controlKeys = activeControlKeys(bindingsRef.current);
      setBindingsTick((t) => t + 1);
    };
    const down = (e: KeyboardEvent) => {
      const k = e.key.toLowerCase();
      if (controlKeys.has(k)) e.preventDefault();
      keysRef.current.add(k);
    };
    const up = (e: KeyboardEvent) => {
      const k = e.key.toLowerCase();
      if (controlKeys.has(k)) e.preventDefault();
      keysRef.current.delete(k);
    };
    const clear = () => { keysRef.current.clear(); };
    window.addEventListener("keydown", down);
    window.addEventListener("keyup", up);
    window.addEventListener("blur", clear);
    document.addEventListener("visibilitychange", clear);
    window.addEventListener("nmba-keybindings-changed", refreshBindings);
    window.addEventListener("storage", refreshBindings);
    return () => {
      window.removeEventListener("keydown", down);
      window.removeEventListener("keyup", up);
      window.removeEventListener("blur", clear);
      document.removeEventListener("visibilitychange", clear);
      window.removeEventListener("nmba-keybindings-changed", refreshBindings);
      window.removeEventListener("storage", refreshBindings);
    };
  }, []);

  const resetGame = () => {
    keysRef.current.clear();
    const players = initPlayers(mode, roster);
    const ball = initBall();
    // Hand the ball to whichever player actually starts on-court (handles Thomas Wu late)
    const starter = players.findIndex(p => p.hasBall);
    if (starter >= 0) {
      ball.holder = starter;
      ball.x = players[starter].x;
    } else {
      ball.held = false; ball.holder = null;
    }
    stateRef.current = { players, ball, time: GAME_TIME };
    // Track Sandela Wu (player team only) so we can show her foul-card button
    const sIdx = players.findIndex(p => p.hasFoulCard && p.team === 0);
    setSandelaState(sIdx >= 0 ? { idx: sIdx, cooldownLeft: 0 } : null);
    setShowSandelaPicker(false);
    // AI-controlled Sandela(s) — schedule first auto-foul-out in the first ~3-6s of play.
    // After each trigger we'll bump nextTriggerAt by 20s (cooldown) so she keeps fouling.
    aiSandelaTriggers.current = players
      .map((p, i) => ({ p, i }))
      .filter(({ p }) => p.hasFoulCard && p.team === 1)
      .map(({ i, p }) => ({
        team: p.team as 0 | 1,
        sandelaIdx: i,
        nextTriggerAt: 3 + Math.random() * 3, // first eject between match-second 3..6
      }));
    // Reset rubber-band + overtime
    catchupRef.current = { team0: 1, team1: 1 };
    overtimeRef.current = 0;
    freeThrowRef.current = { active: false, shootingTeam: null, manualHumanIdx: null, nextFoulAt: 15 + Math.random() * 12, shotReleased: false };
    lateAnnouncedRef.current = new Set();
    setOverlayMsg(null);
    scoresRef.current = [0, 0];
    setScores([0, 0]);
    setOpponentScore(0);
    setTimeLeft(GAME_TIME);
    setGameOver(false);
    setStarted(true);
    setScoreSaved(false);
    frameCountRef.current = 0;
  };

  useEffect(() => {
    if (isOnline && channelReady && peerReady && !started && !gameOver) resetGame();
  }, [isOnline, channelReady, peerReady]);

  // Auto-start (used by league mode so the court is visible behind the intro overlay)
  useEffect(() => {
    if (autoStart && !started && !gameOver && !isOnline) resetGame();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [autoStart]);

  // ── Articulated skeletal player rendering ──
  // Real human-like rig: head + neck + torso (pivots for lean) + shoulders →
  // upper arm → elbow → forearm → hand, and hips → upper leg → knee →
  // shin → foot. Shooting triggers a backward upper-body lean and shooting-arm
  // follow-through; running flexes knees and elbows; jumping tucks the legs.
  const drawPlayer = useCallback((ctx: CanvasRenderingContext2D, p: Player, idx: number, now: number) => {
    // Skip rendering for players that are off the court (Thomas Wu before
    // arrival, ejected players from Sandela's foul card)
    if (p.ejected || (p.lateUntilSecond ?? 0) > 0) return;
    const footY = Math.min(p.y, GROUND_Y);
    // Distribute the per-player heightBoost roughly 60% to legs / 40% to body
    // so taller players have longer strides AND broader shoulders.
    const hb = p.heightBoost ?? 0;
    // Smooth squash-and-stretch on takeoff (sy>1) and landing (sy<1).
    // Applied to legs+body height; feet stay planted at footY.
    const { sy: animSy } = getJumpAnimScale(p);
    const legH = (LEG_H + hb * 0.6) * animSy;
    const bodyH = (BODY_H + hb * 0.4) * animSy;
    const bodyTop = footY - legH - bodyH;
    const headCY = bodyTop - HEAD_R + 2;
    const moving = Math.abs(p.vx) > 0.5;
    const runFreq = p.isSprinting ? 0.022 : 0.014;
    const walkCycle = Math.sin(now * runFreq + idx * 3) * (moving ? 1 : 0);
    // ── Pose modifiers ──
    // shootPose: 0..1, peaks right after release (shootCooldown was just set to ~12-20).
    // We use the cooldown decay as the timeline. Cap at 1.
    const shootPose = Math.max(0, Math.min(1, (p.shootCooldown ?? 0) / 12));
    // Backward torso lean (radians) when shooting — upper body tilts back.
    const lean = -shootPose * 0.32 * p.facing;
    // Crouch when about to take off (jumping but still rising near the ground)
    const crouching = !p.jumping && p.hasBall && shootPose > 0.5;
    // Knee bend during jump (tuck) and running
    const jumpTuck = p.jumping ? Math.min(1, Math.abs(p.vy) / 12) : 0;

    // Shadow on ground
    ctx.save();
    ctx.fillStyle = "rgba(0,0,0,0.25)";
    const shadowScale = 1 - (GROUND_Y - footY) * 0.003;
    ctx.beginPath();
    ctx.ellipse(p.x, GROUND_Y + 2, 22 * Math.max(0.5, shadowScale), 6 * Math.max(0.5, shadowScale), 0, 0, Math.PI * 2);
    ctx.fill();
    ctx.restore();

    // Sprint glow
    if (p.isSprinting) {
      ctx.save();
      ctx.shadowColor = p.jersey;
      ctx.shadowBlur = 25;
      ctx.fillStyle = "rgba(255,255,100,0.12)";
      ctx.beginPath();
      ctx.ellipse(p.x, footY - pHeight(p) / 2, 32, pHeight(p) / 2 + 5, 0, 0, Math.PI * 2);
      ctx.fill();
      ctx.restore();
    }

    // ── Wings (Jeffrey Flying ability) ──
    // Drawn behind the body so they peek out from the shoulders. Flap in sync
    // with `now` so the angel-wing silhouette keeps moving while he hovers.
    if (p.flyingTimer && p.flyingTimer > 0) {
      const flap = Math.sin(now * 0.025) * 0.45;            // -0.45..0.45 rad sway
      const wingTop = footY - legH - bodyH + 12;            // shoulder-ish line
      ctx.save();
      // Soft halo behind the player
      const halo = ctx.createRadialGradient(p.x, wingTop + 14, 4, p.x, wingTop + 14, 70);
      halo.addColorStop(0, "rgba(255,250,200,0.45)");
      halo.addColorStop(1, "rgba(255,250,200,0)");
      ctx.fillStyle = halo;
      ctx.beginPath();
      ctx.arc(p.x, wingTop + 14, 70, 0, Math.PI * 2);
      ctx.fill();

      const drawWing = (side: 1 | -1) => {
        ctx.save();
        ctx.translate(p.x + side * 8, wingTop);
        ctx.rotate(side * (0.25 + flap));
        const grad = ctx.createLinearGradient(0, 0, side * 50, 30);
        grad.addColorStop(0, "rgba(255,255,255,0.95)");
        grad.addColorStop(0.6, "rgba(245,245,255,0.85)");
        grad.addColorStop(1, "rgba(200,210,240,0.55)");
        ctx.fillStyle = grad;
        ctx.strokeStyle = "rgba(180,190,220,0.7)";
        ctx.lineWidth = 1.5;
        // Feathered wing silhouette
        ctx.beginPath();
        ctx.moveTo(0, 0);
        ctx.bezierCurveTo(side * 22, -14, side * 48, -8, side * 56, 6);
        ctx.bezierCurveTo(side * 50, 14, side * 30, 22, side * 16, 24);
        ctx.bezierCurveTo(side * 12, 18, side * 6, 10, 0, 0);
        ctx.closePath();
        ctx.fill();
        ctx.stroke();
        // Feather lines
        ctx.strokeStyle = "rgba(170,180,210,0.5)";
        ctx.lineWidth = 1;
        for (let i = 1; i <= 3; i++) {
          ctx.beginPath();
          ctx.moveTo(side * (10 + i * 4), 2 + i * 3);
          ctx.lineTo(side * (40 + i * 3), 6 + i * 4);
          ctx.stroke();
        }
        ctx.restore();
      };
      drawWing(-1);
      drawWing(1);

      // Countdown badge above head
      const secsLeft = Math.ceil(p.flyingTimer / 60);
      ctx.fillStyle = "rgba(255,250,200,0.95)";
      ctx.font = "bold 11px Arial";
      ctx.textAlign = "center";
      ctx.fillText(`🪽 ${secsLeft}s`, p.x, wingTop - 28);
      ctx.restore();
    }

    // ── Articulated LEGS (hip → knee → foot) ──
    // Hips sit at the bottom of the torso. Each leg has an upper segment
    // (thigh) and lower segment (shin), joined at the knee. During running
    // the hip swings the thigh forward/back and the knee flexes; during a
    // jump both knees tuck up under the hips.
    const hipY = footY - legH;
    const hipSpread = 6;
    const legColor = darkenColor(p.skin, 0.05);
    const pantColor = darkenColor(p.jersey, 0.55);
    const skinDark = darkenColor(p.skin, 0.25);

    // Per-leg phase: legs swing 180deg out of phase. Add jump tuck offset.
    const legSwingAmt = moving ? 0.55 : 0;
    const drawLeg = (side: 1 | -1, phase: number) => {
      const hipX = p.x + side * hipSpread;
      // Hip rotation (thigh) — forward/back during run, tucked up during jump
      const swing = Math.sin(phase) * legSwingAmt;
      const tuck = jumpTuck * 0.9;
      const thighAngle = side * 0.05 + swing - tuck * side * 0.15;
      // Thigh length
      const thighLen = legH * 0.55;
      const shinLen = legH * 0.55;
      // Knee bend: more bend when tucked or mid-stride
      const kneeBend = 0.25 + Math.abs(swing) * 0.6 + tuck * 1.2 + (crouching ? 0.6 : 0);
      // Knee position (from hip, swung outward by thighAngle)
      const kneeX = hipX + Math.sin(thighAngle) * thighLen;
      const kneeY = hipY + Math.cos(thighAngle) * thighLen;
      // Shin angle = thigh + bend (toward back of leg)
      const shinAngle = thighAngle - kneeBend * (p.facing > 0 ? -1 : 1) * 0.5 + kneeBend * 0.2;
      const ankleX = kneeX + Math.sin(shinAngle) * shinLen;
      let ankleY = kneeY + Math.cos(shinAngle) * shinLen;
      // Plant the foot on the ground if not jumping (keeps feet at footY)
      if (!p.jumping && !crouching) ankleY = footY;

      // Thigh (pant)
      ctx.strokeStyle = pantColor;
      ctx.lineWidth = 9;
      ctx.lineCap = "round";
      ctx.beginPath();
      ctx.moveTo(hipX, hipY);
      ctx.lineTo(kneeX, kneeY);
      ctx.stroke();

      // Shin (skin)
      const shinGrad = ctx.createLinearGradient(kneeX, kneeY, ankleX, ankleY);
      shinGrad.addColorStop(0, p.skin);
      shinGrad.addColorStop(1, skinDark);
      ctx.strokeStyle = shinGrad;
      ctx.lineWidth = 7;
      ctx.beginPath();
      ctx.moveTo(kneeX, kneeY);
      ctx.lineTo(ankleX, ankleY);
      ctx.stroke();

      // Knee cap
      ctx.fillStyle = legColor;
      ctx.beginPath();
      ctx.arc(kneeX, kneeY, 3.5, 0, Math.PI * 2);
      ctx.fill();

      // Shoe
      const footFrontX = ankleX + p.facing * 6;
      const shoeGrad = ctx.createRadialGradient(ankleX, ankleY + 2, 1, ankleX, ankleY + 2, 12);
      shoeGrad.addColorStop(0, "#5a5a5a");
      shoeGrad.addColorStop(1, "#1c1c1c");
      ctx.fillStyle = shoeGrad;
      ctx.beginPath();
      ctx.ellipse((ankleX + footFrontX) / 2, ankleY + 2, 9, 4.5, 0, 0, Math.PI * 2);
      ctx.fill();
      // Shoe stripe (sneaker swoosh)
      ctx.strokeStyle = lightenColor(p.jersey, 0.2);
      ctx.lineWidth = 1.4;
      ctx.beginPath();
      ctx.moveTo(ankleX - p.facing * 5, ankleY + 1);
      ctx.quadraticCurveTo(ankleX, ankleY - 1, footFrontX, ankleY + 1);
      ctx.stroke();
    };
    // Two legs out of phase
    const legPhase = now * runFreq * 1.6 + idx * 2;
    drawLeg(-1, legPhase);
    drawLeg(1, legPhase + Math.PI);

    // ── Upper body (torso + arms + head) — pivots around the hips for lean ──
    ctx.save();
    ctx.translate(p.x, hipY);
    ctx.rotate(lean);
    // We'll work in a local frame where (0,0) is the hip. All upper-body
    // coordinates are y-negative (above hips).
    const localBodyTop = -bodyH;
    const localHeadCY = localBodyTop - HEAD_R + 2;

    // ── Torso (jersey) ── — slightly tapered for shoulders
    const torsoW = 18;
    const shoulderW = 22;
    const bodyGrad = ctx.createLinearGradient(-torsoW, 0, torsoW, 0);
    bodyGrad.addColorStop(0, darkenColor(p.jersey, 0.3));
    bodyGrad.addColorStop(0.3, p.jersey);
    bodyGrad.addColorStop(0.7, lightenColor(p.jersey, 0.15));
    bodyGrad.addColorStop(1, darkenColor(p.jersey, 0.2));
    ctx.fillStyle = bodyGrad;
    ctx.beginPath();
    ctx.moveTo(-shoulderW, localBodyTop);
    ctx.quadraticCurveTo(-shoulderW - 1, localBodyTop + bodyH * 0.4, -torsoW + 2, 0);
    ctx.lineTo(torsoW - 2, 0);
    ctx.quadraticCurveTo(shoulderW + 1, localBodyTop + bodyH * 0.4, shoulderW, localBodyTop);
    ctx.closePath();
    ctx.fill();

    // Jersey style overlay
    if (p.jerseyStyle && p.jerseyStyle !== "solid" && p.jerseyAccent) {
      ctx.save();
      ctx.clip();
      ctx.fillStyle = p.jerseyAccent;
      if (p.jerseyStyle === "stripes-h") {
        const band = bodyH / 5;
        ctx.fillRect(-shoulderW - 4, localBodyTop + band,         shoulderW * 2 + 8, band * 0.7);
        ctx.fillRect(-shoulderW - 4, localBodyTop + band * 3,     shoulderW * 2 + 8, band * 0.7);
      } else if (p.jerseyStyle === "stripes-v") {
        ctx.fillRect(-torsoW + 2, localBodyTop, 4, bodyH);
        ctx.fillRect(torsoW - 6, localBodyTop, 4, bodyH);
      } else if (p.jerseyStyle === "sash") {
        ctx.beginPath();
        ctx.moveTo(-shoulderW - 4, localBodyTop + 4);
        ctx.lineTo(-shoulderW + 6, localBodyTop - 2);
        ctx.lineTo(shoulderW + 4, -6);
        ctx.lineTo(shoulderW - 6, 0);
        ctx.closePath();
        ctx.fill();
      }
      ctx.restore();
    }

    // Jersey number
    ctx.fillStyle = "rgba(255,255,255,0.92)";
    ctx.font = "bold 13px Arial";
    ctx.textAlign = "center";
    ctx.textBaseline = "middle";
    ctx.fillText(p.isRobot ? "AI" : `${idx + 1}`, 0, localBodyTop + bodyH * 0.45);

    // Collar
    ctx.strokeStyle = darkenColor(p.jersey, 0.4);
    ctx.lineWidth = 2;
    ctx.beginPath();
    ctx.arc(0, localBodyTop + 2, 8, 0.2, Math.PI - 0.2);
    ctx.stroke();

    // ── Articulated ARMS (shoulder → elbow → wrist) ──
    const shoulderY = localBodyTop + 4;
    const upperArm = 13;
    const forearm = 13;
    const armDarken = 0.18;

    const drawArm2 = (
      side: 1 | -1,
      shoulderAngle: number,    // 0 = straight down; +pi/2 = raised forward
      elbowBend: number,        // 0 = straight; pi/2 = forearm perpendicular
      gripBall = false,
    ) => {
      const sx = side * (shoulderW - 4);
      const sy = shoulderY;
      const ex = sx + Math.sin(shoulderAngle) * upperArm * side;
      const ey = sy + Math.cos(shoulderAngle) * upperArm;
      const farmAngle = shoulderAngle - elbowBend;
      const wx = ex + Math.sin(farmAngle) * forearm * side;
      const wy = ey + Math.cos(farmAngle) * forearm;

      const armGrad = ctx.createLinearGradient(sx, sy, ex, ey);
      armGrad.addColorStop(0, p.skin);
      armGrad.addColorStop(1, darkenColor(p.skin, armDarken));
      ctx.strokeStyle = armGrad;
      ctx.lineWidth = 6.5;
      ctx.lineCap = "round";
      ctx.beginPath();
      ctx.moveTo(sx, sy);
      ctx.lineTo(ex, ey);
      ctx.stroke();
      const farmGrad = ctx.createLinearGradient(ex, ey, wx, wy);
      farmGrad.addColorStop(0, darkenColor(p.skin, 0.05));
      farmGrad.addColorStop(1, darkenColor(p.skin, armDarken + 0.05));
      ctx.strokeStyle = farmGrad;
      ctx.lineWidth = 5.5;
      ctx.beginPath();
      ctx.moveTo(ex, ey);
      ctx.lineTo(wx, wy);
      ctx.stroke();
      // Elbow joint
      ctx.fillStyle = darkenColor(p.skin, 0.15);
      ctx.beginPath();
      ctx.arc(ex, ey, 3, 0, Math.PI * 2);
      ctx.fill();
      // Hand
      ctx.fillStyle = darkenColor(p.skin, 0.08);
      ctx.beginPath();
      ctx.arc(wx, wy, gripBall ? 4.5 : 4, 0, Math.PI * 2);
      ctx.fill();
    };

    const armSwingPhase = now * runFreq * 1.6 + idx * 2;
    const armSwing = (moving ? 0.45 : 0.05) * Math.sin(armSwingPhase + Math.PI);
    const ss = p.facing as 1 | -1;          // strong side = facing dir
    const ws: 1 | -1 = (ss === 1 ? -1 : 1); // weak/guide side

    if (shootPose > 0.05) {
      // SHOOTING POSE — shooting arm raises overhead, guide hand assists.
      const raise = shootPose;
      const strongShoulder = raise * Math.PI * 0.95;
      const followThrough = Math.sin(raise * Math.PI);
      const strongElbow = (1 - raise) * 1.6 + followThrough * 0.4;
      drawArm2(ss, strongShoulder, strongElbow, true);
      const weakShoulder = 0.7 + raise * 0.6;
      const weakElbow = 1.2 - raise * 0.4;
      drawArm2(ws, weakShoulder, weakElbow, true);
    } else if (p.hasBall) {
      drawArm2(ss, 1.1, 0.8, true);
      drawArm2(ws, 0.3 + armSwing * 0.4, 0.4, false);
    } else {
      drawArm2(-1, 0.15 + armSwing, 0.6 + Math.abs(armSwing) * 0.3, false);
      drawArm2(1, 0.15 - armSwing, 0.6 + Math.abs(armSwing) * 0.3, false);
    }

    // ── Neck ──
    ctx.fillStyle = darkenColor(p.skin, 0.1);
    ctx.beginPath();
    ctx.moveTo(-6, localHeadCY + HEAD_R - 4);
    ctx.lineTo(6, localHeadCY + HEAD_R - 4);
    ctx.lineTo(8, shoulderY);
    ctx.lineTo(-8, shoulderY);
    ctx.closePath();
    ctx.fill();

    // ── Head ──
    const headGrad = ctx.createRadialGradient(-5, localHeadCY - 6, 3, 0, localHeadCY, HEAD_R);
    headGrad.addColorStop(0, lightenColor(p.skin, 0.2));
    headGrad.addColorStop(0.6, p.skin);
    headGrad.addColorStop(1, darkenColor(p.skin, 0.3));
    ctx.beginPath();
    ctx.arc(0, localHeadCY, HEAD_R, 0, Math.PI * 2);
    ctx.fillStyle = headGrad;
    ctx.fill();

    // Hair
    const hairColor = p.isRobot ? "#555" : (p.team === 0 ? "#2C1810" : "#1a1a2e");
    const hairGrad = ctx.createRadialGradient(-3, localHeadCY - 10, 2, 0, localHeadCY - 5, HEAD_R + 2);
    hairGrad.addColorStop(0, lightenColor(hairColor, 0.2));
    hairGrad.addColorStop(1, hairColor);
    ctx.fillStyle = hairGrad;
    ctx.beginPath();
    ctx.arc(0, localHeadCY - 5, HEAD_R + 1, -Math.PI, 0);
    ctx.fill();

    // Headband
    const bandGrad = ctx.createLinearGradient(-HEAD_R, localHeadCY - 8, HEAD_R, localHeadCY - 8);
    bandGrad.addColorStop(0, darkenColor(p.jersey, 0.1));
    bandGrad.addColorStop(0.5, lightenColor(p.jersey, 0.1));
    bandGrad.addColorStop(1, darkenColor(p.jersey, 0.1));
    ctx.fillStyle = bandGrad;
    ctx.fillRect(-HEAD_R, localHeadCY - 9, HEAD_R * 2, 6);

    // Eyes
    const lEyeY = localHeadCY - 1;
    const lEyeX1 = p.facing * 6;
    const lEyeX2 = p.facing * 15;
    if (p.isRobot) {
      ctx.save();
      ctx.shadowColor = "#ff3333";
      ctx.shadowBlur = 8;
      ctx.fillStyle = "#ff4444";
      ctx.beginPath(); ctx.arc(lEyeX1, lEyeY, 4, 0, Math.PI * 2); ctx.fill();
      ctx.beginPath(); ctx.arc(lEyeX2, lEyeY, 4, 0, Math.PI * 2); ctx.fill();
      ctx.restore();
      ctx.fillStyle = "#fff";
      ctx.beginPath(); ctx.arc(lEyeX1, lEyeY, 1.5, 0, Math.PI * 2); ctx.fill();
      ctx.beginPath(); ctx.arc(lEyeX2, lEyeY, 1.5, 0, Math.PI * 2); ctx.fill();
    } else {
      for (const ex of [lEyeX1, lEyeX2]) {
        ctx.fillStyle = "#fff";
        ctx.beginPath(); ctx.arc(ex, lEyeY, 5, 0, Math.PI * 2); ctx.fill();
        ctx.fillStyle = "#222";
        ctx.beginPath(); ctx.arc(ex + p.facing * 1.5, lEyeY, 2.5, 0, Math.PI * 2); ctx.fill();
        ctx.fillStyle = "#fff";
        ctx.beginPath(); ctx.arc(ex + p.facing * 0.5, lEyeY - 1.5, 1, 0, Math.PI * 2); ctx.fill();
      }
    }

    // Mouth — opens wider while shooting (effort grunt)
    const mouthOpen = 0.1 + shootPose * 0.4;
    ctx.beginPath();
    ctx.arc(p.facing * 9, localHeadCY + 10, 5, mouthOpen, Math.PI - mouthOpen);
    ctx.strokeStyle = p.isRobot ? "#999" : darkenColor(p.skin, 0.4);
    ctx.lineWidth = 1.5;
    ctx.stroke();

    // Robot antenna
    if (p.isRobot) {
      ctx.strokeStyle = "#888";
      ctx.lineWidth = 2;
      ctx.beginPath();
      ctx.moveTo(0, localHeadCY - HEAD_R - 1);
      ctx.lineTo(0, localHeadCY - HEAD_R - 12);
      ctx.stroke();
      ctx.save();
      ctx.shadowColor = "#ff3333";
      ctx.shadowBlur = 6;
      ctx.fillStyle = "#ff3333";
      ctx.beginPath();
      ctx.arc(0, localHeadCY - HEAD_R - 13, 3, 0, Math.PI * 2);
      ctx.fill();
      ctx.restore();
    }

    ctx.restore(); // end upper-body lean transform



    // Sprint cooldown bar
    if (p.sprintCooldown > 0) {
      const pct = 1 - p.sprintCooldown / SPRINT_COOLDOWN;
      ctx.fillStyle = "rgba(0,0,0,0.6)";
      ctx.beginPath();
      ctx.roundRect(p.x - 15, footY + 10, 30, 5, 2);
      ctx.fill();
      ctx.fillStyle = pct > 0.8 ? "#2ecc71" : "#f39c12";
      ctx.beginPath();
      ctx.roundRect(p.x - 15, footY + 10, 30 * pct, 5, 2);
      ctx.fill();
    }

    // Name tag with background
    ctx.save();
    const tag = p.name;
    ctx.font = "bold 10px Arial";
    ctx.textAlign = "center";
    const tagW = ctx.measureText(tag).width + 8;
    const tagY = headCY - HEAD_R - (p.isRobot ? 20 : 8);
    ctx.fillStyle = "rgba(0,0,0,0.5)";
    ctx.beginPath();
    ctx.roundRect(p.x - tagW / 2, tagY - 8, tagW, 14, 3);
    ctx.fill();
    ctx.fillStyle = "#fff";
    ctx.fillText(tag, p.x, tagY);
    ctx.restore();
  }, []);

  useEffect(() => {
    if (!started || gameOver) return;
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext("2d")!;
    let frameId: number;
    let lastNow = performance.now();

    const loop = (now: number) => {
      const elapsed = now - lastNow;
      lastNow = now;
      const dt = Math.min(elapsed / 16.67, 2.5);
      const s = stateRef.current;
      const keys = keysRef.current;
      frameCountRef.current++;
      const b = s.ball;

      {
      if (pausedRef.current) {
        // Frozen during intro overlay — game logic skipped, but we let AI players
        // do hype-jumps so the court feels alive during the countdown.
        for (const p of s.players) {
          if (p.isRobot) {
            // Random small hype jump every ~50 frames per player
            if (!p.jumping && Math.random() < 0.025) {
              p.vy = -8.5 - Math.random() * 2;
              p.jumping = true;
              // Random face flip for liveliness
              if (Math.random() < 0.3) p.facing = (Math.random() < 0.5 ? 1 : -1) as 1 | -1;
            }
          }
          // Apply gravity so any active jumps complete naturally
          if (p.jumping) {
            p.vy += GRAVITY * dt;
            p.y += p.vy * dt;
            // Cap apex: feet may not go above the rim top.
            if (p.y < RIM_Y) { p.y = RIM_Y; if (p.vy < 0) p.vy = 0; }
            if (p.y >= GROUND_Y) { p.y = GROUND_Y; p.vy = 0; p.jumping = false; }
          }
        }
        // Skip the rest of the update logic (time, physics, AI decisions, scoring)
      } else {
      s.time -= elapsed / 1000;
      if (s.time <= 0) {
        // ── Overtime: tied at end of regulation/OT? Add OT_SECONDS more. ──
        const t0 = scoresRef.current[0];
        const t1 = scoresRef.current[1];
        if (t0 === t1 && overtimeRef.current < MAX_OVERTIMES) {
          overtimeRef.current += 1;
          s.time = OT_SECONDS;
          setTimeLeft(Math.ceil(s.time));
          showOverlay(`🔥 加时赛 OT${overtimeRef.current} · ${OT_SECONDS}s`, 3000);
        } else {
          s.time = 0;
          setTimeLeft(0);
          setGameOver(true);
          return;
        }
      } else {
        setTimeLeft(Math.ceil(s.time));
      }

      // Sync Sandela's foul-card cooldown into React state for the button label.
      // Use functional setState so we always compare against the latest value
      // (the captured `sandelaState` from this effect closure can be stale,
      // which previously caused the cooldown to get stuck at 1s).
      if (sandelaState) {
        const sandela = s.players[sandelaState.idx];
        const elapsedNow = GAME_TIME - s.time;
        const readyAt = sandela?.foulCardReadyAt ?? 0;
        const remaining = readyAt - elapsedNow;
        const cd = remaining <= 0 ? 0 : Math.max(1, Math.floor(remaining));
        setSandelaState(prev => {
          if (!prev || prev.cooldownLeft === cd) return prev;
          return { ...prev, cooldownLeft: cd };
        });
      }

      // ── Random foul / free-throw trigger ──────────────────────────────
      // Roughly every 18-30s of match time, call a foul on whoever currently
      // has the ball (or a random team if the ball is loose). The opposing
      // team is awarded a free-throw at their FT line. If the awarded team
      // has a human player on the court, AI is paused so the human can shoot
      // the FT manually. Make/miss uses normal scoring (no special FT pts).
      {
        const ft = freeThrowRef.current;
        const elapsedSecFt = GAME_TIME - s.time;

        // Trigger a new foul when timer elapses and the ball is in a stable
        // state (held by someone, not mid-shot, not just-scored).
        if (
          !ft.active &&
          elapsedSecFt >= ft.nextFoulAt &&
          b.held &&
          b.holder !== null &&
          !b.scored &&
          !b.waitingForGround
        ) {
          const fouledByTeam = s.players[b.holder].team; // ball-holder commits foul (offensive foul flavor)
          const awardedTeam: 0 | 1 = (fouledByTeam === 0 ? 1 : 0);
          // Pick FT shooter: prefer a human on the awarded team, else any on-court player.
          const onCourt = s.players
            .map((p, i) => ({ p, i }))
            .filter(({ p }) => p.team === awardedTeam && !p.ejected && !isOffCourt(p));
          const human = onCourt.find(({ p }) => !p.isRobot);
          const shooter = human ?? onCourt[0];
          if (shooter) {
            // FT line position: ~165 px from the rim toward midcourt.
            const ftRimX = awardedTeam === 0 ? RIM_RIGHT_X : RIM_LEFT_X;
            const ftDir = awardedTeam === 0 ? -1 : 1; // shooter stands inside court relative to rim
            const ftX = ftRimX + ftDir * 175;
            shooter.p.x = Math.max(P_LEFT_LIMIT, Math.min(P_RIGHT_LIMIT, ftX));
            shooter.p.y = GROUND_Y;
            shooter.p.vx = 0;
            shooter.p.vy = 0;
            shooter.p.jumping = false;
            shooter.p.facing = (ftDir > 0 ? -1 : 1) as 1 | -1;
            shooter.p.shootCooldown = 0;
            // Hand the ball to the FT shooter
            b.held = true;
            b.holder = shooter.i;
            b.vx = 0; b.vy = 0;
            b.scored = false;
            b.waitingForGround = false;
            b.trail = [];
            s.players.forEach((pp, i) => { pp.hasBall = (i === shooter.i); });

            ft.active = true;
            ft.shootingTeam = awardedTeam;
            ft.manualHumanIdx = human ? shooter.i : null;
            ft.shotReleased = false;

            const teamLabel = awardedTeam === 0
              ? (teamNames?.team0 ?? "你方")
              : (teamNames?.team1 ?? "对方");
            const manualHint = human ? " · 按投篮键出手!" : "";
            showOverlay(`🟡 犯规! ${teamLabel} 罚球${manualHint}`, 2800);
          }
          // Schedule next foul check; if no shooter found, retry sooner.
          ft.nextFoulAt = elapsedSecFt + (shooter ? 9999 : 4);
        }

        // Maintain active FT: detect release & resolve.
        if (ft.active) {
          // Once the shooter releases the ball, mark released.
          if (!ft.shotReleased && !b.held) {
            ft.shotReleased = true;
          }
          // Resolution: scored OR shot has fully landed (ball loose & resting near ground).
          const shotResolved =
            ft.shotReleased && (
              b.scored ||
              b.waitingForGround ||
              (!b.held && b.y >= GROUND_Y - BALL_R - 1 && Math.abs(b.vy) < 1.5)
            );
          if (shotResolved) {
            ft.active = false;
            ft.shootingTeam = null;
            ft.manualHumanIdx = null;
            ft.shotReleased = false;
            ft.nextFoulAt = elapsedSecFt + 18 + Math.random() * 12;
          }
        }
      }


      // ── AI-controlled Sandela Wu auto-trigger (repeating, 20s cooldown) ──
      // When her cooldown is up, eject one random opposing on-court player for 10s.
      const elapsedSecAi = GAME_TIME - s.time;
      for (const trig of aiSandelaTriggers.current) {
        if (elapsedSecAi < trig.nextTriggerAt) continue;
        const sandela = s.players[trig.sandelaIdx];
        if (!sandela || sandela.ejected || isOffCourt(sandela)) {
          // Sandela herself is off-court — try again in 1s.
          trig.nextTriggerAt = elapsedSecAi + 1;
          continue;
        }
        // Pick a random opposing on-court player who isn't already ejected.
        const targets = s.players
          .map((p, i) => ({ p, i }))
          .filter(({ p }) => p.team !== trig.team && !p.ejected && (p.lateUntilSecond ?? 0) === 0);
        if (targets.length === 0) {
          trig.nextTriggerAt = elapsedSecAi + 2;
          continue;
        }
        const pick = targets[Math.floor(Math.random() * targets.length)];
        pick.p.ejected = true;
        pick.p.ejectedReturnAt = elapsedSecAi + 10; // back in 10s
        if (pick.p.hasBall) {
          pick.p.hasBall = false;
          const b2 = s.ball;
          b2.held = false; b2.holder = null;
          b2.x = pick.p.x; b2.y = GROUND_Y - 30; b2.vx = 0; b2.vy = 0;
        }
        trig.nextTriggerAt = elapsedSecAi + 20; // 20s cooldown until next eject
        showOverlay(`📋 Sandela Wu 使用违纪单罚下 ${pick.p.name}`, 3500);
      }

      // ── Auto-return ejected players after their 10s ban ──
      for (const p of s.players) {
        if (p.ejected && (p.ejectedReturnAt ?? 0) <= elapsedSecAi) {
          p.ejected = false;
          p.ejectedReturnAt = undefined;
          const sideX = p.team === 0 ? 220 + Math.random() * 120 : 540 + Math.random() * 120;
          p.x = sideX;
          p.y = GROUND_Y;
          p.vx = 0; p.vy = 0;
          showOverlay(`↩️ ${p.name} 回到场上`, 1800);
        }
      }

      // ── Rubber-band catch-up: when AI is losing badly, boost their stats ──
      // Only the OPPONENT (team 1 in league/friend mode) gets caught up; we never
      // hobble the player. Cap so loss stays within 1-10 points (configured by AI loop).
      {
        const myScore = scoresRef.current[0];
        const oppScore = scoresRef.current[1];
        const oppDeficit = myScore - oppScore;
        // Smooth ramp: +0% at deficit≤4, scaling linearly to +60% at deficit≥30
        const t1Boost = Math.min(0.6, Math.max(0, (oppDeficit - 4) / 26 * 0.6));
        catchupRef.current.team1 = 1 + t1Boost;
        catchupRef.current.team0 = 1; // never debuff the player
      }

      const defaultHumanProfile = { moveSpeed: 3.8, sprintSpeed: SPRINT_SPEED, jumpPower: 10, shootPower: 12, stealChance: 0.5, catchRange: 55, contestRange: 78 };
      const handleSprint = (p: Player, sprintKey: string, keySet: Set<string> = keys) => {
        if (keySet.has(sprintKey) && p.sprintCooldown <= 0 && !p.isSprinting) {
          p.isSprinting = true; p.sprintTimer = SPRINT_DURATION; p.sprintCooldown = SPRINT_COOLDOWN;
        }
        if (p.isSprinting) { p.sprintTimer -= dt; if (p.sprintTimer <= 0) p.isSprinting = false; }
        if (p.sprintCooldown > 0) p.sprintCooldown -= dt;
      };

      // Resolve which players use P1 / P2 keybindings
      let p1: Player | undefined;
      let p2: Player | undefined;
      if (mode === "teamBattle") {
        p1 = s.players.find(p => !p.isRobot && p.humanSlot === 1);
        p2 = s.players.find(p => !p.isRobot && p.humanSlot === 2);
      } else {
        p1 = s.players[0]?.isRobot ? undefined : s.players[0];
        if (mode === "local" || mode === "2v2") {
          p2 = s.players[1]?.isRobot ? undefined : s.players[1];
        }
      }

      // Live key bindings (snapshot for this frame).
      const kb = bindingsRef.current;

      if (p1) {
        const p1Profile = getHumanControlProfile(p1);
        handleSprint(p1, kb.p1.sprint, keys);
        const p1Speed = p1.isSprinting ? p1Profile.sprintSpeed : p1Profile.moveSpeed;
        if (keys.has(kb.p1.left)) { p1.vx = -p1Speed; p1.facing = -1; }
        else if (keys.has(kb.p1.right)) { p1.vx = p1Speed; p1.facing = 1; }
        else p1.vx *= 0.82;
        if (keys.has(kb.p1.jump) && !p1.jumping) { p1.vy = -p1Profile.jumpPower; p1.jumping = true; }
      }

      if (p2) {
        const p2Profile = getHumanControlProfile(p2);
        handleSprint(p2, kb.p2.sprint, keys);
        const p2Speed = p2.isSprinting ? p2Profile.sprintSpeed : p2Profile.moveSpeed;
        if (keys.has(kb.p2.left)) { p2.vx = -p2Speed; p2.facing = -1; }
        else if (keys.has(kb.p2.right)) { p2.vx = p2Speed; p2.facing = 1; }
        else p2.vx *= 0.82;
        if (keys.has(kb.p2.jump) && !p2.jumping) { p2.vy = -p2Profile.jumpPower; p2.jumping = true; }
      }

      // Coordinate AI roles per team this frame (scorer / rebounder / defender)
      assignTeamRoles(s.players, s.ball);

      // During an active free-throw we freeze AI movement so the FT shooter
      // (whether human or AI) gets a clean shot. The FT-shooter AI itself
      // gets a single dedicated shot trigger right after this loop.
      const ftActive = freeThrowRef.current.active;
      const ftShooterIdx = ftActive ? freeThrowRef.current.manualHumanIdx : null;
      for (let i = 0; i < s.players.length; i++) {
        const p = s.players[i];
        if (!p.isRobot) continue;
        if (isOffCourt(p)) continue;
        if (ftActive) { p.vx = 0; continue; }
        if (p.isSprinting) { p.sprintTimer -= dt; if (p.sprintTimer <= 0) p.isSprinting = false; }
        if (p.sprintCooldown > 0) p.sprintCooldown -= dt;
        const baseDiff = p.difficulty ? DIFFICULTY[p.difficulty] : diffParams;
        const playerStats = p.playerStats;
        let perPlayerDiff = playerStats ? applyStatsToDiff(baseDiff, playerStats) : baseDiff;
        // Coach + consumable boost — lift physical/skill axes by the boost % so
        // the "+10% all stats" tooltip is felt in actual gameplay (player's AI teammates).
        const boost = p.boost ?? 0;
        if (boost > 0) {
          const bm = 1 + boost;
          perPlayerDiff = {
            ...perPlayerDiff,
            speed: perPlayerDiff.speed * bm,
            shootAccuracy: perPlayerDiff.shootAccuracy / bm, // lower = more accurate
            shootRange: Math.round(perPlayerDiff.shootRange * bm),
            stealChance: Math.min(0.99, perPlayerDiff.stealChance * bm),
            blockChance: Math.min(0.99, perPlayerDiff.blockChance * bm),
            jumpPower: perPlayerDiff.jumpPower * bm,
            grabRange: Math.round(perPlayerDiff.grabRange * bm),
            blockRange: Math.round(perPlayerDiff.blockRange * bm),
            contestRange: Math.round(perPlayerDiff.contestRange * bm),
            reactionDelay: Math.max(0, Math.round(perPlayerDiff.reactionDelay / bm)),
          };
        }
        // Apply per-team rubber-band catch-up multiplier (only AI gets boosted when behind).
        const cu = p.team === 0 ? catchupRef.current.team0 : catchupRef.current.team1;
        if (cu !== 1) {
          perPlayerDiff = {
            ...perPlayerDiff,
            speed: perPlayerDiff.speed * cu,
            shootAccuracy: perPlayerDiff.shootAccuracy / cu,
            stealChance: Math.min(0.99, perPlayerDiff.stealChance * cu),
            blockChance: Math.min(0.99, perPlayerDiff.blockChance * cu),
            jumpPower: perPlayerDiff.jumpPower * Math.min(1.15, cu),
            shotAggression: Math.min(0.99, perPlayerDiff.shotAggression * cu),
          };
        }
        robotAI(p, i, s.ball, s.players, dt, frameCountRef.current, perPlayerDiff, GAME_TIME - s.time);
      }

      // ── AI free-throw shot ─────────────────────────────────────────────
      // When the FT shooter is an AI (no human on awarded team), make them
      // take exactly one shot ~30 frames into the FT, aimed at the rim.
      if (freeThrowRef.current.active && freeThrowRef.current.manualHumanIdx === null && !freeThrowRef.current.shotReleased) {
        const holderIdx = b.holder;
        if (holderIdx !== null && b.held) {
          const shooter = s.players[holderIdx];
          if (shooter && shooter.isRobot && shooter.shootCooldown <= 0) {
            const targetRimX = shooter.team === 0 ? RIM_RIGHT_X : RIM_LEFT_X;
            const releaseX = shooter.x;
            const releaseY = shooter.y - pHeight(shooter) + 6;
            // Use medium-difficulty accuracy for FTs so they make a reasonable %.
            const shot = calcShotVelocity(releaseX, releaseY, targetRimX, RIM_Y, GRAVITY, 1.4, "normal");
            b.held = false; b.holder = null; shooter.hasBall = false;
            shooter.shootCooldown = 12;
            b.lastShooterX = shooter.x;
            b.vx = shot.vx;
            b.vy = shot.vy;
            playShoot();
          }
        }
      }

      // Calculate elapsed match seconds (used for Thomas Wu's late arrival)
      const elapsedSec = Math.floor(GAME_TIME - s.time);

      for (let pi = 0; pi < s.players.length; pi++) {
        const p = s.players[pi];
        // ── Jump animation transitions ──
        // Snapshot pre-physics state so we can fire takeoff / landing anims
        // when this frame's physics actually changes the air state.
        // Decay both anims toward 0 so the squash/stretch is brief (~10 frames).
        const prevJumping = p.jumping;
        const prevVy = p.vy;
        if ((p.takeoffAnim ?? 0) > 0) p.takeoffAnim = Math.max(0, (p.takeoffAnim ?? 0) - 0.10 * dt);
        if ((p.landAnim ?? 0) > 0)    p.landAnim    = Math.max(0, (p.landAnim ?? 0)    - 0.12 * dt);
        // Thomas Wu "late" — count down arrival; freeze him off-court until then.
        if ((p.lateUntilSecond ?? 0) > 0) {
          // Announce once at the start of the match — show how late he'll be
          if (elapsedSec <= 1 && !lateAnnouncedRef.current.has(pi)) {
            lateAnnouncedRef.current.add(pi);
            showOverlay(`⏰ ${p.name} 迟到 ${p.lateUntilSecond} 秒`, 3500);
          }
          if (elapsedSec >= (p.lateUntilSecond ?? 0)) {
            // Arrived — drop him onto his team's side
            p.lateUntilSecond = 0;
            const sideX = p.team === 0 ? 220 + Math.random() * 120 : 540 + Math.random() * 120;
            p.x = sideX;
            p.y = GROUND_Y;
            showOverlay(`🏃 ${p.name} 终于到了！`, 2200);
          } else {
            // Hide him visually & physically
            p.x = -9999;
            p.vx = 0; p.vy = 0; p.jumping = false;
            if (p.hasBall) p.hasBall = false;
            continue;
          }
        }
        // Ejected (foul-card) — fully removed from play
        if (p.ejected) {
          p.x = -9999;
          p.vx = 0; p.vy = 0; p.jumping = false;
          if (p.hasBall) p.hasBall = false;
          continue;
        }
        // Wings: Jeffrey Flying floats high for ~6s after losing the ball.
        // Override gravity, hover near the rafters, dart wildly across court.
        if (p.flyingTimer && p.flyingTimer > 0) {
          p.flyingTimer -= dt;
          // Higher altitude — y=75 sits near the very top of the court.
          const HOVER_Y = 75;
          // Re-roll a random destination across the full court more often (~0.3s)
          if (!p.flyRerollIn || p.flyRerollIn <= 0 || p.flyTargetX === undefined) {
            p.flyTargetX = P_LEFT_LIMIT + Math.random() * (P_RIGHT_LIMIT - P_LEFT_LIMIT);
            p.flyRerollIn = 14 + Math.random() * 16;
          } else {
            p.flyRerollIn -= dt;
          }
          // Faster, more chaotic horizontal steering: bigger wobble + higher speed cap
          const dx = (p.flyTargetX ?? p.x) - p.x;
          const wobble = Math.sin((p.flyingTimer ?? 0) * 0.32) * 3.2
                       + Math.sin((p.flyingTimer ?? 0) * 0.11 + p.x * 0.01) * 2.0;
          p.vx = Math.max(-15, Math.min(15, dx * 0.12 + wobble));
          p.x += p.vx * dt;
          // Wider vertical swing so flight looks crazier
          const bob = Math.sin((p.flyingTimer ?? 0) * 0.18) * 18
                    + Math.sin((p.flyingTimer ?? 0) * 0.07) * 10;
          p.y += ((HOVER_Y + bob) - p.y) * Math.min(1, 0.18 * dt);
          p.vy = 0;
          p.jumping = false;
          p.x = Math.max(P_LEFT_LIMIT, Math.min(P_RIGHT_LIMIT, p.x));
          // Face direction of travel
          if (Math.abs(p.vx) > 0.2) p.facing = p.vx > 0 ? 1 : -1;
          if (p.shootCooldown > 0) p.shootCooldown -= dt;
          if (p.grabCooldown > 0) p.grabCooldown -= dt;
          if (p.sprintCooldown > 0) p.sprintCooldown -= dt;
          // NOTE: do NOT `continue` here — Jeffrey can still shoot while flying.
          // Footstep SFX skipped intentionally (he's airborne).
          continue;
        } else if (p.hasWings) {
          // Reset wandering state when he lands
          p.flyTargetX = undefined;
          p.flyRerollIn = 0;
        }
        p.x += p.vx * dt;
        p.vy += GRAVITY * dt;
        p.y += p.vy * dt;
        // Cap apex: feet may not go above the rim top (RIM_Y).
        if (p.y < RIM_Y) { p.y = RIM_Y; if (p.vy < 0) p.vy = 0; }
        if (p.y >= GROUND_Y) { p.y = GROUND_Y; p.vy = 0; p.jumping = false; }
        p.x = Math.max(P_LEFT_LIMIT, Math.min(P_RIGHT_LIMIT, p.x));
        // Detect takeoff / landing transitions for smooth squash-and-stretch.
        // Takeoff: was on ground, now moving upward (vy<0 after this frame).
        if (!prevJumping && p.jumping && p.vy < -0.5 && (p.takeoffAnim ?? 0) < 0.4) {
          p.takeoffAnim = 1;
          p.landAnim = 0;
        }
        // Landing: was airborne with downward velocity, now grounded.
        if (prevJumping && !p.jumping && prevVy > 1.5) {
          p.landAnim = 1;
          p.takeoffAnim = 0;
        }
        if (p.shootCooldown > 0) p.shootCooldown -= dt;
        if (p.grabCooldown > 0) p.grabCooldown -= dt;
        // Footstep SFX while running on the ground (throttled inside playFootstep)
        if (!p.jumping && Math.abs(p.vx) > 1.5) playFootstep();
      }

      // ── Player separation pass ──
      // After every position update, gently push apart any two players whose
      // bodies are overlapping in x. Without this, multiple AIs that share the
      // same target (the ball, the same defender, the rim) end up stacked on
      // the same pixel and "freeze" — none of them can move because each
      // frame's AI steering keeps pulling them right back together. We only
      // separate on the x axis (this is a 2.5D side-view court) and skip
      // anyone who is off-court, ejected, mid-flight, or jumping (so jump-
      // contests at the rim still work).
      const MIN_GAP = HEAD_R * 1.6;        // ~38 px — slightly less than two heads side-by-side
      const PUSH_PER_FRAME = 0.55;         // small nudge so it doesn't look teleporty
      for (let i = 0; i < s.players.length; i++) {
        const a = s.players[i];
        if (a.ejected || isOffCourt(a) || a.flyingTimer || a.jumping) continue;
        for (let j = i + 1; j < s.players.length; j++) {
          const bP = s.players[j];
          if (bP.ejected || isOffCourt(bP) || bP.flyingTimer || bP.jumping) continue;
          // Only push apart when they're at roughly the same vertical level
          // (otherwise a player jumping over another would still get shoved).
          if (Math.abs(a.y - bP.y) > pHeight(a) * 0.6) continue;
          const dx = bP.x - a.x;
          const absDx = Math.abs(dx);
          if (absDx < MIN_GAP) {
            const overlap = MIN_GAP - absDx;
            // Direction: if they're exactly stacked (dx == 0), push along facing
            const dir = dx === 0 ? (a.facing >= 0 ? -1 : 1) : Math.sign(dx);
            const push = Math.min(overlap * 0.5, PUSH_PER_FRAME * dt);
            a.x  -= dir * push;
            bP.x += dir * push;
            // Re-clamp to court bounds
            a.x  = Math.max(P_LEFT_LIMIT, Math.min(P_RIGHT_LIMIT, a.x));
            bP.x = Math.max(P_LEFT_LIMIT, Math.min(P_RIGHT_LIMIT, bP.x));
          }
        }
      }


      if (b.waitingForGround) {
        b.vy += GRAVITY * dt;
        b.x += b.vx * dt;
        b.y += b.vy * dt;
        b.vx *= 0.99;
        if (b.y >= GROUND_Y - BALL_R) {
          b.y = GROUND_Y - BALL_R;
          b.vy *= -0.3;
          b.vx *= 0.7;
          b.scoreTimer -= dt;
          if (b.scoreTimer <= 0 || Math.abs(b.vy) < 0.5) {
            b.scored = false;
            b.waitingForGround = false;
            // Tip-off reset: warp every active player back to their starting spot so
            // nobody is caught out of position when the new possession starts.
            for (const p of s.players) {
              if (p.ejected) continue;
              if (p.lateUntilSecond && p.lateUntilSecond > 0) continue;
              if (typeof p.homeX === "number") p.x = p.homeX;
              p.y = GROUND_Y;
              p.vx = 0; p.vy = 0;
              p.jumping = false;
              p.aiState = "idle";
              p.aiTargetX = p.x;
              p.aiWaitTimer = 0;
              p.shootCooldown = Math.max(p.shootCooldown, 8);
              p.grabCooldown = Math.max(p.grabCooldown, 8);
              p.hasBall = false;
            }
            // Hand possession to the team that was just scored on.
            const receivingTeam = b.lastScoringTeam === 0 ? 1 : b.lastScoringTeam === 1 ? 0 : null;
            let receiverIdx = -1;
            if (receivingTeam !== null) {
              receiverIdx = s.players.findIndex(p =>
                p.team === receivingTeam &&
                !p.ejected &&
                !(p.lateUntilSecond && p.lateUntilSecond > 0) &&
                !p.flyingTimer
              );
            }
            if (receiverIdx >= 0) {
              const receiver = s.players[receiverIdx];
              receiver.hasBall = true;
              b.held = true;
              b.holder = receiverIdx;
              b.x = receiver.x;
              b.y = receiver.y - PLAYER_H + 5;
              b.vx = 0; b.vy = 0;
            } else {
              b.x = W / 2; b.y = 200; b.vx = 0; b.vy = 0; b.held = false; b.holder = null;
            }
            b.lastScoringTeam = undefined;
            b.trail = [];
          }
        }
      } else if (b.held && b.holder !== null) {
        const holder = s.players[b.holder];
        b.x = holder.x + holder.facing * 25;
        b.y = Math.min(holder.y, GROUND_Y) - pHeight(holder) + 5;
        b.trail = [];
      } else if (!b.scored) {
        b.vy += GRAVITY * dt;
        b.vx *= 0.998;
        b.x += b.vx * dt;
        b.y += b.vy * dt;
        b.spin += b.vx * 0.05;
        b.trail.push({ x: b.x, y: b.y });
        if (b.trail.length > 15) b.trail.shift();

        if (b.x < BALL_R) { b.x = BALL_R; b.vx *= -0.35; }
        if (b.x > W - BALL_R) { b.x = W - BALL_R; b.vx *= -0.35; }
        // No ceiling: ball can fly off the top of the screen and arc back down (gravity returns it)
        if (b.y > GROUND_Y - BALL_R) {
          b.y = GROUND_Y - BALL_R;
          b.vy *= -0.4;
          b.vx *= 0.75;
          if (Math.abs(b.vy) < 1.2) b.vy = 0;
        }

        // Rim collision
        for (const rimX of [RIM_LEFT_X, RIM_RIGHT_X]) {
          for (const rx of [rimX - effectiveRimRadius, rimX + effectiveRimRadius]) {
            const dx = b.x - rx;
            const dy = b.y - RIM_Y;
            const dist = Math.sqrt(dx * dx + dy * dy);
            if (dist < BALL_R + 5) {
              const nx = dx / dist, ny = dy / dist;
              const dot = b.vx * nx + b.vy * ny;
              b.vx -= 1.3 * dot * nx;
              b.vy -= 1.3 * dot * ny;
              b.vx *= 0.7; b.vy *= 0.7;
              b.x = rx + nx * (BALL_R + 6);
              b.y = RIM_Y + ny * (BALL_R + 6);
            }
          }
        }

        // Backboard
        if (b.y > RIM_Y - 65 && b.y < RIM_Y + 5) {
          if (b.x < 35 + BALL_R && b.vx < 0) { b.x = 35 + BALL_R; b.vx *= -0.6; }
          if (b.x > 765 - BALL_R && b.vx > 0) { b.x = 765 - BALL_R; b.vx *= -0.6; }
        }

        // Scoring
        if (!b.scored) {
          for (const [rimX, scoringTeam] of [[RIM_RIGHT_X, 0], [RIM_LEFT_X, 1]] as const) {
            const prevY = b.y - b.vy * dt;
            if (b.vy > 2 && prevY < RIM_Y && b.y >= RIM_Y && Math.abs(b.x - rimX) < effectiveRimRadius - 6) {
              const shooterX = b.lastShooterX;
              let is3pt = false;
              if (scoringTeam === 0) is3pt = shooterX < MID_X;
              else is3pt = shooterX > MID_X;
              const pts = is3pt ? 3 : 2;

              s.players.filter(p => p.team === scoringTeam).forEach(p => p.score += pts);
              b.scored = true;
              b.scoredPoints = pts;
              b.waitingForGround = true;
              b.scoreTimer = 90;
              b.lastScoringTeam = scoringTeam;
              b.vx *= 0.3;
              b.vy = Math.abs(b.vy) * 0.5 + 1;
              playScore();

              const t0Score = s.players.filter(p => p.team === 0).reduce((acc, p) => Math.max(acc, p.score), 0);
              const t1Score = s.players.filter(p => p.team === 1).reduce((acc, p) => Math.max(acc, p.score), 0);
              scoresRef.current = [t0Score, t1Score];
              setScores([t0Score, t1Score]);
              break;
            }
          }
        }
      }

      // Shoot - human
      const tryShoot = (pIdx: number, key: string, keySet: Set<string> = keys) => {
        const p = s.players[pIdx];
        if (keySet.has(key) && p.hasBall && b.holder === pIdx && p.shootCooldown <= 0) {
          const profile = getHumanControlProfile(p);
          keySet.delete(key);
          b.held = false; b.holder = null; p.hasBall = false;
          p.shootCooldown = 12;
          b.lastShooterX = p.x;
          const power = profile.shootPower;
          b.vx = p.facing * power;
          b.vy = -Math.max(8.8, profile.jumpPower - 1);
          playShoot();
        }
      };
      const p1Idx = p1 ? s.players.indexOf(p1) : -1;
      const p2Idx = p2 ? s.players.indexOf(p2) : -1;
      if (p1Idx >= 0) tryShoot(p1Idx, kb.p1.shoot, keys);
      if (p2Idx >= 0) tryShoot(p2Idx, kb.p2.shoot, keys);

      // Grab/Steal - human
      const tryGrab = (pIdx: number, key: string, keySet: Set<string> = keys) => {
        const p = s.players[pIdx];
        if (!keySet.has(key) || p.grabCooldown > 0) return;
        const profile = getHumanControlProfile(p);
        keySet.delete(key);
        p.grabCooldown = 15;
        const dist = Math.hypot(b.x - p.x, b.y - (p.y - PLAYER_H / 2));
        const nowSec = GAME_TIME - s.time;
        if (!b.held && !b.scored && dist < profile.catchRange) {
          b.held = true; b.holder = pIdx; p.hasBall = true;
          s.players.forEach((pp, i) => { if (i !== pIdx) pp.hasBall = false; });
          triggerSupermanShotIfReady(p, b, nowSec);
        } else if (b.held && b.holder !== null && b.holder !== pIdx) {
          const holderPlayer = s.players[b.holder];
          const elevatedBall = b.y < holderPlayer.y - PLAYER_H * 0.35 || holderPlayer.jumping;
          if (holderPlayer.team !== p.team && elevatedBall && dist < profile.contestRange) {
            knockBallLoose(b, holderPlayer, p);
          } else if (holderPlayer.team !== p.team && dist < profile.catchRange) {
            const stealChance = p.isSprinting ? 1.0 : profile.stealChance;
            if (Math.random() < stealChance) {
              triggerWingsIfJeffrey(holderPlayer);
              b.holder = pIdx; p.hasBall = true;
              s.players.forEach((pp, i) => { if (i !== pIdx) pp.hasBall = false; });
              triggerSupermanShotIfReady(p, b, nowSec);
            }
          }
        }
      };
      if (p1Idx >= 0) tryGrab(p1Idx, kb.p1.steal, keys);
      if (p2Idx >= 0) tryGrab(p2Idx, kb.p2.steal, keys);

      if (isOnline && channelRef.current && frameCountRef.current % 5 === 0) {
        const myScore = s.players[0]?.score || 0;
        channelRef.current.send({ type: 'broadcast', event: 'score', payload: { score: myScore } });
      }
      } // end !paused else
      }

      // ── DRAW ──
      if (bgRef.current) {
        ctx.drawImage(bgRef.current, 0, 0, W, H);
      } else {
        ctx.fillStyle = "#0a0e27";
        ctx.fillRect(0, 0, W, H);
        ctx.fillStyle = "#C19552";
        ctx.fillRect(0, GROUND_Y, W, H - GROUND_Y);
      }

      // (Cinematic hanging scoreboard removed — World Tour now uses the same
      // standard top HUD with team names + score + countdown as league mode.)

      // Draw baskets
      const drawBasket = (rimX: number, side: 1 | -1) => {
        const bbX = rimX + side * effectiveRimRadius + side * 10;
        if (tourMode) {
          // Premium chrome pole + glass backboard
          // Pole (chrome cylinder)
          const poleGrad = ctx.createLinearGradient(bbX - 5, 0, bbX + 5, 0);
          poleGrad.addColorStop(0, "#3a3f4a");
          poleGrad.addColorStop(0.45, "#e6ecf2");
          poleGrad.addColorStop(0.55, "#ffffff");
          poleGrad.addColorStop(1, "#22272e");
          ctx.fillStyle = poleGrad;
          ctx.fillRect(bbX - 4, RIM_Y - 70, 8, GROUND_Y - RIM_Y + 70);
          // Pole shadow under rim
          ctx.fillStyle = "rgba(0,0,0,0.35)";
          ctx.fillRect(bbX - 5, RIM_Y - 70, 1.5, GROUND_Y - RIM_Y + 70);

          // Glass backboard with subtle blue-tint reflection
          const bbW = 10, bbH = 70;
          const glassGrad = ctx.createLinearGradient(bbX - bbW/2, RIM_Y - bbH, bbX + bbW/2, RIM_Y);
          glassGrad.addColorStop(0, "rgba(220,232,250,0.92)");
          glassGrad.addColorStop(0.5, "rgba(255,255,255,0.78)");
          glassGrad.addColorStop(1, "rgba(200,215,235,0.85)");
          ctx.fillStyle = glassGrad;
          ctx.fillRect(bbX - bbW/2, RIM_Y - bbH, bbW, bbH);
          // Black metal frame
          ctx.strokeStyle = "#1a1f26";
          ctx.lineWidth = 2.5;
          ctx.strokeRect(bbX - bbW/2, RIM_Y - bbH, bbW, bbH);
          // Inner red shooter's square
          ctx.strokeStyle = "#E74C3C";
          ctx.lineWidth = 2;
          ctx.strokeRect(bbX - bbW/2 + 1, RIM_Y - 42, bbW - 2, 30);
          // Glass highlight streak
          ctx.fillStyle = "rgba(255,255,255,0.35)";
          ctx.fillRect(bbX - bbW/2 + 1.5, RIM_Y - bbH + 2, 1.5, bbH - 4);

          // Rim arm (red)
          ctx.strokeStyle = "#C0392B";
          ctx.lineWidth = 5;
          ctx.beginPath();
          ctx.moveTo(bbX, RIM_Y);
          ctx.lineTo(rimX - side * effectiveRimRadius, RIM_Y);
          ctx.stroke();

          // Rim — gradient orange chrome
          const rimGrad = ctx.createLinearGradient(0, RIM_Y - 3, 0, RIM_Y + 3);
          rimGrad.addColorStop(0, "#FFB347");
          rimGrad.addColorStop(0.5, "#FF6B35");
          rimGrad.addColorStop(1, "#A03210");
          ctx.strokeStyle = rimGrad;
          ctx.lineWidth = 5.5;
          ctx.beginPath();
          ctx.moveTo(rimX - effectiveRimRadius, RIM_Y);
          ctx.lineTo(rimX + effectiveRimRadius, RIM_Y);
          ctx.stroke();
          // Rim glow
          ctx.shadowColor = "rgba(255,107,53,0.6)";
          ctx.shadowBlur = 8;
          ctx.beginPath();
          ctx.moveTo(rimX - effectiveRimRadius, RIM_Y);
          ctx.lineTo(rimX + effectiveRimRadius, RIM_Y);
          ctx.stroke();
          ctx.shadowBlur = 0;

          // Rim endpoints — chrome spheres
          for (const rx of [rimX - effectiveRimRadius, rimX + effectiveRimRadius]) {
            const sg = ctx.createRadialGradient(rx - 1.5, RIM_Y - 1.5, 0.5, rx, RIM_Y, 6);
            sg.addColorStop(0, "#FFE0AA");
            sg.addColorStop(0.5, "#FF8C42");
            sg.addColorStop(1, "#7A1F0A");
            ctx.fillStyle = sg;
            ctx.beginPath(); ctx.arc(rx, RIM_Y, 5.5, 0, Math.PI * 2); ctx.fill();
          }

          // Premium net — denser, brighter, longer
          ctx.strokeStyle = "rgba(255,255,255,0.85)";
          ctx.lineWidth = 1.1;
          for (let i = -5; i <= 5; i++) {
            ctx.beginPath();
            ctx.moveTo(rimX + i * (effectiveRimRadius / 5), RIM_Y + 2);
            const sway = Math.sin(now * 0.003 + i) * 2;
            ctx.quadraticCurveTo(
              rimX + i * (effectiveRimRadius / 6.5) + sway, RIM_Y + 30,
              rimX + i * (effectiveRimRadius / 8.5), RIM_Y + 48
            );
            ctx.stroke();
          }
          for (let j = 1; j <= 4; j++) {
            ctx.beginPath();
            const w = effectiveRimRadius - j * 4.5;
            ctx.moveTo(rimX - w, RIM_Y + j * 11);
            ctx.lineTo(rimX + w, RIM_Y + j * 11);
            ctx.stroke();
          }
          return;
        }

        // ── Standard (non-tour) basket ──
        // Post with gradient
        const postGrad = ctx.createLinearGradient(bbX - 4, RIM_Y - 65, bbX + 4, RIM_Y - 65);
        postGrad.addColorStop(0, "#777");
        postGrad.addColorStop(0.5, "#aaa");
        postGrad.addColorStop(1, "#666");
        ctx.fillStyle = postGrad;
        ctx.fillRect(bbX - 3, RIM_Y - 65, 6, GROUND_Y - RIM_Y + 65);

        // Backboard with 3D effect
        const bbGrad = ctx.createLinearGradient(bbX - 5, RIM_Y - 60, bbX + 5, RIM_Y);
        bbGrad.addColorStop(0, "rgba(255,255,255,0.95)");
        bbGrad.addColorStop(1, "rgba(220,220,220,0.85)");
        ctx.fillStyle = bbGrad;
        ctx.fillRect(bbX - 4, RIM_Y - 60, 8, 60);
        ctx.strokeStyle = "#444";
        ctx.lineWidth = 2;
        ctx.strokeRect(bbX - 4, RIM_Y - 60, 8, 60);
        ctx.strokeStyle = "#E74C3C";
        ctx.lineWidth = 1.5;
        ctx.strokeRect(bbX - 4, RIM_Y - 38, 8, 26);

        // Rim arm
        ctx.strokeStyle = "#E74C3C";
        ctx.lineWidth = 4;
        ctx.beginPath();
        ctx.moveTo(bbX, RIM_Y);
        ctx.lineTo(rimX - side * effectiveRimRadius, RIM_Y);
        ctx.stroke();

        // Rim with 3D
        ctx.strokeStyle = "#FF4500";
        ctx.lineWidth = 4.5;
        ctx.beginPath();
        ctx.moveTo(rimX - effectiveRimRadius, RIM_Y);
        ctx.lineTo(rimX + effectiveRimRadius, RIM_Y);
        ctx.stroke();

        // Rim endpoints (3D spheres)
        for (const rx of [rimX - effectiveRimRadius, rimX + effectiveRimRadius]) {
          const rimGrad = ctx.createRadialGradient(rx - 1, RIM_Y - 1, 1, rx, RIM_Y, 5);
          rimGrad.addColorStop(0, "#FF6633");
          rimGrad.addColorStop(1, "#CC3300");
          ctx.fillStyle = rimGrad;
          ctx.beginPath(); ctx.arc(rx, RIM_Y, 4.5, 0, Math.PI * 2); ctx.fill();
        }

        // Net
        ctx.strokeStyle = "rgba(255,255,255,0.65)";
        ctx.lineWidth = 1;
        for (let i = -4; i <= 4; i++) {
          ctx.beginPath();
          ctx.moveTo(rimX + i * (effectiveRimRadius / 4), RIM_Y + 2);
          const sway = Math.sin(now * 0.003 + i) * 2;
          ctx.quadraticCurveTo(rimX + i * (effectiveRimRadius / 5.5) + sway, RIM_Y + 25, rimX + i * (effectiveRimRadius / 7), RIM_Y + 40);
          ctx.stroke();
        }
        for (let j = 1; j <= 3; j++) {
          ctx.beginPath();
          const w = effectiveRimRadius - j * 5;
          ctx.moveTo(rimX - w, RIM_Y + j * 10);
          ctx.lineTo(rimX + w, RIM_Y + j * 10);
          ctx.stroke();
        }
      };

      drawBasket(RIM_LEFT_X, -1);
      drawBasket(RIM_RIGHT_X, 1);

      // Mid-court line
      ctx.strokeStyle = "rgba(255,255,255,0.15)";
      ctx.lineWidth = 2;
      ctx.setLineDash([8, 6]);
      ctx.beginPath();
      ctx.moveTo(MID_X, GROUND_Y);
      ctx.lineTo(MID_X, GROUND_Y - 10);
      ctx.stroke();
      ctx.setLineDash([]);

      // Ball trail
      if (b.trail.length > 1 && !b.held) {
        for (let i = 1; i < b.trail.length; i++) {
          const alpha = i / b.trail.length * 0.3;
          ctx.strokeStyle = `rgba(255,140,0,${alpha})`;
          ctx.lineWidth = BALL_R * (i / b.trail.length);
          ctx.beginPath();
          ctx.moveTo(b.trail[i - 1].x, b.trail[i - 1].y);
          ctx.lineTo(b.trail[i].x, b.trail[i].y);
          ctx.stroke();
        }
      }

      // Players
      for (let i = 0; i < s.players.length; i++) {
        drawPlayer(ctx, s.players[i], i, now);
      }

      // Ball (3D sphere)
      ctx.save();
      ctx.translate(b.x, b.y);
      ctx.rotate(b.spin);
      const ballGrad = ctx.createRadialGradient(-4, -4, 2, 0, 0, BALL_R);
      ballGrad.addColorStop(0, "#FFB74D");
      ballGrad.addColorStop(0.5, "#FF9800");
      ballGrad.addColorStop(0.85, "#E65100");
      ballGrad.addColorStop(1, "#BF360C");
      ctx.beginPath();
      ctx.arc(0, 0, BALL_R, 0, Math.PI * 2);
      ctx.fillStyle = ballGrad;
      ctx.fill();
      // Seams
      ctx.strokeStyle = "rgba(50,30,0,0.5)";
      ctx.lineWidth = 1;
      ctx.beginPath(); ctx.moveTo(-BALL_R, 0); ctx.lineTo(BALL_R, 0); ctx.stroke();
      ctx.beginPath(); ctx.arc(0, 0, BALL_R * 0.7, -0.4, 0.4); ctx.stroke();
      ctx.beginPath(); ctx.arc(0, 0, BALL_R * 0.7, Math.PI - 0.4, Math.PI + 0.4); ctx.stroke();
      // Highlight
      ctx.fillStyle = "rgba(255,255,255,0.3)";
      ctx.beginPath();
      ctx.ellipse(-3, -4, 4, 3, -0.5, 0, Math.PI * 2);
      ctx.fill();
      ctx.restore();

      // Score effect
      if (b.scored) {
        ctx.save();
        ctx.fillStyle = "rgba(255,215,0,0.7)";
        ctx.font = "bold 48px Arial";
        ctx.textAlign = "center";
        ctx.textBaseline = "middle";
        const ptText = b.scoredPoints === 3 ? "🏀 三分球!" : "🏀 得分!";
        ctx.fillText(ptText, W / 2, H / 2 - 30);
        if (b.scoredPoints === 3) {
          ctx.fillStyle = "rgba(255,100,0,0.6)";
          ctx.font = "bold 28px Arial";
          ctx.fillText("+3", W / 2, H / 2 + 15);
        }
        ctx.restore();
      }

      // HUD — top-center scoreboard + countdown (used in all modes, including World Tour)
      const t0Score = s.players.filter(p => p.team === 0).reduce((acc, p) => Math.max(acc, p.score), 0);
      const t1Score = s.players.filter(p => p.team === 1).reduce((acc, p) => Math.max(acc, p.score), 0);

      {
        ctx.font = "bold 22px Arial";
        const fallbackT0 = mode === "single" ? "P1" : mode === "vsRobot" ? "YOU" : mode === "2v2" || mode === "teamBattle" ? "TEAM 1" : "P1";
        const fallbackT1 = mode === "single" ? "" : mode === "vsRobot" ? "BOT" : mode === "2v2" || mode === "teamBattle" ? "TEAM 2" : "P2";
        const t0Label = isOnline ? myName : (teamNames?.team0 || fallbackT0);
        const t1Label = isOnline ? opponentName : (teamNames?.team1 || fallbackT1);
        const displayT0 = t0Score;
        const displayT1 = isOnline ? opponentScore : t1Score;
        const leftStr = `${t0Label}  ${displayT0}`;
        const rightStr = `${displayT1}  ${t1Label}`;
        const showRight = mode !== "single" || isOnline;
        const leftW = ctx.measureText(leftStr).width;
        const rightW = showRight ? ctx.measureText(rightStr).width : 0;
        const hudW = Math.max(300, leftW + rightW + 80);
        const hudH = 44;
        ctx.fillStyle = "rgba(0,0,0,0.8)";
        ctx.beginPath();
        ctx.roundRect(W / 2 - hudW / 2, 6, hudW, hudH, 10);
        ctx.fill();
        ctx.fillStyle = "#E74C3C";
        ctx.textAlign = "right";
        ctx.fillText(leftStr, W / 2 - 14, 34);
        if (showRight) {
          ctx.fillStyle = "#fff";
          ctx.textAlign = "center";
          ctx.fillText(":", W / 2, 33);
          ctx.fillStyle = "#3498DB";
          ctx.textAlign = "left";
          ctx.fillText(rightStr, W / 2 + 14, 34);
        }
        const otSuffix = overtimeRef.current > 0 ? `  · OT${overtimeRef.current}` : "";
        ctx.fillStyle = s.time < 10 ? "#E74C3C" : "#ccc";
        ctx.font = "bold 13px Arial";
        ctx.textAlign = "center";
        ctx.fillText(`⏱ ${Math.ceil(s.time)}s${otSuffix}`, W / 2, 60);
      }

      frameId = requestAnimationFrame(loop);
    };

    frameId = requestAnimationFrame(loop);
    return () => cancelAnimationFrame(frameId);
  }, [started, gameOver, drawPlayer, mode, isOnline, opponentScore, myName, opponentName, teamNames]);

  useEffect(() => {
    if (!gameOver || scoreSaved) return;
    // Emit match-end for league mode
    if (onMatchEnd) onMatchEnd(scores[0], scores[1]);
    if (mode !== "single" && mode !== "vsRobot") { setScoreSaved(true); return; }
    const save = async () => {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) return;
      await supabase.rpc("submit_game_score", {
        _game_type: `basketball_${GAME_TIME}s`,
        _score: scores[0],
        _mode: mode === "vsRobot" ? "vsRobot" : "single",
      });
      setScoreSaved(true);
    };
    save();
  }, [gameOver, mode, scores, scoreSaved, onMatchEnd]);

  if (isOnline && !started) {
    return (
      <div className="flex flex-col items-center gap-4">
        <h3 className="text-xl font-bold">🏀 在线对战</h3>
        <div className="text-sm text-muted-foreground space-y-1 text-center">
          {!channelReady && <p>🔌 正在连接...</p>}
          {channelReady && !peerReady && <p>⏳ 等待对手连接...</p>}
          {channelReady && peerReady && <p>✅ 双方已连接，即将开始！</p>}
        </div>
        <div className="animate-spin h-6 w-6 border-2 border-primary border-t-transparent rounded-full" />
      </div>
    );
  }

  if (!started) {
    const teamBattleHumans = roster?.filter(r => r.kind === "human") ?? [];
    void bindingsTick; // dep so help text refreshes when bindings change
    const kb = bindingsRef.current;
    const p1Move = `${prettyKey(kb.p1.left)} ${prettyKey(kb.p1.right)} ${prettyKey(kb.p1.jump)}`;
    const p2Move = `${prettyKey(kb.p2.left)} ${prettyKey(kb.p2.right)} ${prettyKey(kb.p2.jump)}`;
    const p1Line = `移动 ${p1Move} · 投篮 ${prettyKey(kb.p1.shoot)} · 抢球 ${prettyKey(kb.p1.steal)} · 冲刺 ${prettyKey(kb.p1.sprint)}`;
    const p2Line = `移动 ${p2Move} · 投篮 ${prettyKey(kb.p2.shoot)} · 抢球 ${prettyKey(kb.p2.steal)} · 冲刺 ${prettyKey(kb.p2.sprint)}`;

    const controls: Record<GameMode, React.ReactNode> = {
      single: (
        <>
          <p><strong>P1:</strong> {p1Line}</p>
          <p>{GAME_TIME} 秒内尽可能多得分！过中线投篮算 3 分</p>
        </>
      ),
      vsRobot: (
        <>
          <p><strong>你 (红):</strong> {p1Line}</p>
          <p>🤖 机器人会自动控制蓝方球员</p>
          <p>把球投进对方篮筐！过中线投篮算 3 分</p>
        </>
      ),
      "2v2": (
        <>
          <p><strong>P1 (红队):</strong> {p1Line}</p>
          <p><strong>P2 (蓝队):</strong> {p2Line}</p>
          <p>🤖 每队各有一个机器人队友！过中线投篮算 3 分</p>
        </>
      ),
      local: (
        <>
          <p><strong>P1 (红):</strong> {p1Line}</p>
          <p><strong>P2 (蓝):</strong> {p2Line}</p>
          <p>把球投进对方篮筐！过中线投篮算 3 分</p>
        </>
      ),
      teamBattle: (
        <>
          {teamBattleHumans.some(r => r.humanSlot === 1) && (
            <p><strong>P1:</strong> {p1Line}</p>
          )}
          {teamBattleHumans.some(r => r.humanSlot === 2) && (
            <p><strong>P2:</strong> {p2Line}</p>
          )}
          <p>🏀 团队作战 — 队伍 1 vs 队伍 2，过中线投篮算 3 分</p>
        </>
      ),
    };

    return (
      <div className="flex flex-col items-center gap-4">
        <h3 className="text-xl font-bold">🏀 大头篮球 {mode === "vsRobot" ? "- VS 机器人" : mode === "2v2" ? "- 2V2" : mode === "teamBattle" ? "- 团队作战" : ""}</h3>
        <div className="text-sm text-muted-foreground space-y-1 text-center">
          {controls[mode]}
        </div>
        <div className="flex gap-2">
          <Button variant="outline" size="sm" onClick={() => setShowKeyDialog(true)} className="gap-1">
            <Keyboard className="h-4 w-4" /> 自定义键位
          </Button>
          <Button onClick={resetGame}>开始游戏</Button>
        </div>
        <KeyBindingsDialog open={showKeyDialog} onOpenChange={setShowKeyDialog} />
      </div>
    );
  }

  if (gameOver) {
    const t0 = scores[0], t1 = scores[1];
    if (isOnline) {
      const myScore = t0;
      const oppScore = opponentScore;
      const winner = myScore > oppScore ? `${myName} 获胜! 🏆` : oppScore > myScore ? `${opponentName} 获胜! 🏆` : "平局！🤝";
      return (
        <div className="flex flex-col items-center gap-4">
          <h3 className="text-xl font-bold">🏀 在线对战结束!</h3>
          <p className="text-2xl font-bold">{myName} {myScore} : {oppScore} {opponentName}</p>
          <p className="text-primary font-semibold text-lg">{winner}</p>
          <Button onClick={resetGame}>再来一局</Button>
        </div>
      );
    }
    if (mode === "single") {
      return (
        <div className="flex flex-col items-center gap-4">
          <h3 className="text-xl font-bold">🏀 时间到!</h3>
          <p className="text-2xl font-bold">{t0} 分</p>
          <p className="text-sm text-muted-foreground">{scoreSaved ? "✅ 成绩已保存" : "保存中..."}</p>
          <Button onClick={resetGame}>再来一局</Button>
        </div>
      );
    }
    const fallbackT0 = mode === "vsRobot" ? "你" : (mode === "2v2" || mode === "teamBattle") ? "队伍1" : "Player 1 🔴";
    const fallbackT1 = mode === "vsRobot" ? "🤖 机器人" : (mode === "2v2" || mode === "teamBattle") ? "队伍2" : "Player 2 🔵";
    const t0Label = teamNames?.team0 ?? fallbackT0;
    const t1Label = teamNames?.team1 ?? fallbackT1;
    const winner = t0 > t1 ? `${t0Label} 获胜! 🏆` : t1 > t0 ? `${t1Label} 获胜! 🏆` : "平局！🤝";

    return (
      <div className="flex flex-col items-center gap-4">
        <h3 className="text-xl font-bold">🏀 比赛结束!</h3>
        <p className="text-2xl font-bold">
          <span className="text-red-400">{t0Label}</span>
          <span className="mx-2">{t0} : {t1}</span>
          <span className="text-blue-400">{t1Label}</span>
        </p>
        <p className="text-primary font-semibold text-lg">{winner}</p>
        {mode === "vsRobot" && <p className="text-sm text-muted-foreground">{scoreSaved ? "✅ 成绩已保存" : "保存中..."}</p>}
        <Button onClick={resetGame}>再来一局</Button>
      </div>
    );
  }

  // Sandela's picker — list opposing on-court players she can foul out.
  // Card is reusable: ready when cooldownLeft === 0, otherwise on 20s cooldown.
  const sandelaReady = !!sandelaState && sandelaState.cooldownLeft <= 0;
  const opposingForFoul = sandelaState && sandelaReady
    ? stateRef.current.players
        .map((p, i) => ({ p, i }))
        .filter(({ p }) => p.team !== stateRef.current.players[sandelaState.idx]?.team
                         && !p.ejected && (p.lateUntilSecond ?? 0) === 0)
    : [];

  const handleUseFoulCard = (targetIdx: number) => {
    if (!sandelaState || !sandelaReady) return;
    const players = stateRef.current.players;
    const sandela = players[sandelaState.idx];
    const target = players[targetIdx];
    if (!sandela || !target) return;
    const elapsedSec = GAME_TIME - stateRef.current.time;
    target.ejected = true;
    target.ejectedReturnAt = elapsedSec + 10; // 10s ban
    if (target.hasBall) {
      target.hasBall = false;
      // Loose ball at target's last spot
      const b = stateRef.current.ball;
      b.held = false; b.holder = null;
      b.x = target.x; b.y = GROUND_Y - 30;
      b.vx = 0; b.vy = 0;
    }
    sandela.foulCardReadyAt = elapsedSec + 20; // 20s cooldown before next use
    setSandelaState({ ...sandelaState, cooldownLeft: 20 });
    setShowSandelaPicker(false);
    showOverlay(`📋 Sandela Wu 使用违纪单罚下 ${target.name}`, 3500);
  };

  const sandelaActive = !!sandelaState && started && !gameOver;

  return (
    <div className="flex flex-col items-center gap-2">
      <div className="relative">
        <canvas ref={canvasRef} width={W} height={H} className="rounded-lg border border-border" style={{ maxWidth: "100%", background: "#0a0e27" }} />
        {overlayMsg && (
          <div className="absolute left-1/2 top-20 -translate-x-1/2 px-4 py-2 rounded-lg bg-black/80 text-yellow-200 text-base font-bold border border-yellow-400/40 shadow-lg pointer-events-none animate-in fade-in slide-in-from-top-2">
            {overlayMsg}
          </div>
        )}
        {sandelaActive && (
          <button
            type="button"
            onClick={() => sandelaReady && setShowSandelaPicker(true)}
            disabled={!sandelaReady}
            className={`absolute right-3 bottom-3 px-3 py-2 rounded-md text-white text-sm font-bold shadow-lg border ${
              sandelaReady
                ? "bg-red-600 hover:bg-red-500 border-red-300/50"
                : "bg-gray-600 border-gray-400/40 cursor-not-allowed opacity-80"
            }`}
          >
            {sandelaReady ? "📋 违纪单" : `📋 冷却 ${sandelaState!.cooldownLeft}s`}
          </button>
        )}
        {showSandelaPicker && (
          <div className="absolute inset-0 bg-black/70 flex items-center justify-center rounded-lg">
            <div className="bg-card border border-border rounded-lg p-4 max-w-sm w-full mx-4 space-y-3">
              <div className="text-base font-bold text-foreground">📋 选择要罚下的球员</div>
              <div className="grid grid-cols-1 gap-2">
                {opposingForFoul.map(({ p, i }) => (
                  <button
                    key={i}
                    type="button"
                    onClick={() => handleUseFoulCard(i)}
                    className="w-full text-left px-3 py-2 rounded-md bg-secondary hover:bg-secondary/80 text-secondary-foreground text-sm font-medium"
                  >
                    {p.name}
                  </button>
                ))}
                {opposingForFoul.length === 0 && (
                  <div className="text-sm text-muted-foreground">没有可罚下的对手</div>
                )}
              </div>
              <div className="flex justify-end">
                <Button variant="ghost" size="sm" onClick={() => setShowSandelaPicker(false)}>取消</Button>
              </div>
            </div>
          </div>
        )}
      </div>
      <div className="flex items-center justify-between gap-2 flex-wrap">
        <p className="text-xs text-muted-foreground">
          {(() => {
            void bindingsTick;
            const kb = bindingsRef.current;
            const p1 = `${prettyKey(kb.p1.left)}${prettyKey(kb.p1.right)}${prettyKey(kb.p1.jump)}+${prettyKey(kb.p1.shoot)}+${prettyKey(kb.p1.steal)}+${prettyKey(kb.p1.sprint)}`;
            const p2 = `${prettyKey(kb.p2.left)}${prettyKey(kb.p2.right)}${prettyKey(kb.p2.jump)}+${prettyKey(kb.p2.shoot)}+${prettyKey(kb.p2.steal)}+${prettyKey(kb.p2.sprint)}`;
            if (mode === "single" && !isOnline) return `P1: ${p1} | 过中线=3分`;
            if (isOnline) return `P1: ${p1} | 🌐 ${myName} vs ${opponentName}`;
            if (mode === "vsRobot") return `P1: ${p1} | VS 🤖`;
            if (mode === "2v2") return `P1: ${p1} | P2: ${p2} | 🤖队友`;
            if (mode === "local") return `P1: ${p1} | P2: ${p2} | 过中线=3分`;
            if (mode === "teamBattle") return `P1: ${p1} | P2: ${p2} | 团队作战`;
            return "";
          })()}
        </p>
        <Button variant="ghost" size="sm" onClick={() => setShowKeyDialog(true)} className="h-7 gap-1 text-xs">
          <Keyboard className="h-3.5 w-3.5" /> 键位
        </Button>
      </div>
      <KeyBindingsDialog open={showKeyDialog} onOpenChange={setShowKeyDialog} />
    </div>
  );
}

// ── Color utility functions for 3D shading ──
function parseColor(color: string): [number, number, number] {
  // Handle rgb() format
  const rgbMatch = color.match(/rgb\((\d+),\s*(\d+),\s*(\d+)\)/);
  if (rgbMatch) return [+rgbMatch[1], +rgbMatch[2], +rgbMatch[3]];
  // Handle hex
  let hex = color.replace("#", "");
  if (hex.length === 3) hex = hex[0] + hex[0] + hex[1] + hex[1] + hex[2] + hex[2];
  return [parseInt(hex.slice(0, 2), 16) || 0, parseInt(hex.slice(2, 4), 16) || 0, parseInt(hex.slice(4, 6), 16) || 0];
}

function darkenColor(color: string, amount: number): string {
  const [r, g, b] = parseColor(color);
  return `rgb(${Math.max(0, Math.round(r * (1 - amount)))},${Math.max(0, Math.round(g * (1 - amount)))},${Math.max(0, Math.round(b * (1 - amount)))})`;
}

function lightenColor(color: string, amount: number): string {
  const [r, g, b] = parseColor(color);
  return `rgb(${Math.min(255, Math.round(r + (255 - r) * amount))},${Math.min(255, Math.round(g + (255 - g) * amount))},${Math.min(255, Math.round(b + (255 - b) * amount))})`;
}
