import { useState, useEffect, useCallback, useRef } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";

// Generate 4 random numbers 1-13 that can make 24
function generateNumbers(): number[] {
  for (let attempt = 0; attempt < 200; attempt++) {
    const nums = Array.from({ length: 4 }, () => Math.floor(Math.random() * 13) + 1);
    if (canMake24(nums)) return nums;
  }
  return [1, 2, 3, 4];
}

function canMake24(nums: number[]): boolean {
  return solve24(nums.map(n => n)) !== null;
}

function solve24(nums: number[]): string | null {
  if (nums.length === 1) {
    return Math.abs(nums[0] - 24) < 1e-9 ? String(nums[0]) : null;
  }
  for (let i = 0; i < nums.length; i++) {
    for (let j = 0; j < nums.length; j++) {
      if (i === j) continue;
      const rest = nums.filter((_, k) => k !== i && k !== j);
      const ops: [string, (a: number, b: number) => number][] = [
        ["+", (a, b) => a + b],
        ["-", (a, b) => a - b],
        ["×", (a, b) => a * b],
        ["÷", (a, b) => b !== 0 ? a / b : NaN],
      ];
      for (const [op, fn] of ops) {
        const result = fn(nums[i], nums[j]);
        if (isNaN(result)) continue;
        const found = solve24([...rest, result]);
        if (found) return `(${nums[i]} ${op} ${nums[j]})`;
      }
    }
  }
  return null;
}

function evaluate(expr: string): number | null {
  try {
    const sanitized = expr.replace(/×/g, "*").replace(/÷/g, "/").replace(/[^0-9+\-*/().  ]/g, "");
    if (sanitized !== expr.replace(/×/g, "*").replace(/÷/g, "/")) return null;
    // eslint-disable-next-line no-eval
    const result = Function(`"use strict"; return (${sanitized})`)();
    return typeof result === "number" && isFinite(result) ? result : null;
  } catch {
    return null;
  }
}

function checkExpression(expr: string, numbers: number[]): { valid: boolean; message: string } {
  const usedNums = expr.match(/\d+/g)?.map(Number) || [];
  const sortedUsed = [...usedNums].sort((a, b) => a - b);
  const sortedTarget = [...numbers].sort((a, b) => a - b);

  if (sortedUsed.length !== sortedTarget.length || !sortedUsed.every((n, i) => n === sortedTarget[i])) {
    return { valid: false, message: "Must use exactly the 4 given numbers, each once" };
  }

  const result = evaluate(expr);
  if (result === null) return { valid: false, message: "Invalid expression" };
  if (Math.abs(result - 24) < 1e-9) return { valid: true, message: "Correct! 🎉" };
  return { valid: false, message: `Result is ${result}, not 24` };
}

interface Game24Props {
  online?: boolean;
  myColor?: string;
  gameState?: any;
  onMove?: (state: any) => void;
  isMyTurn?: boolean;
  singlePlayer?: boolean;
}

export default function Game24({ online, myColor, gameState, onMove, singlePlayer = false }: Game24Props) {
  const [numbers, setNumbers] = useState<number[]>(() => {
    if (online && gameState?.numbers) return gameState.numbers;
    return generateNumbers();
  });
  const [expression, setExpression] = useState("");
  const [scores, setScores] = useState<{ black: number; white: number }>(() => {
    if (online && gameState?.scores) return gameState.scores;
    return { black: 0, white: 0 };
  });
  const [round, setRound] = useState(() => gameState?.round || 1);
  const [solved, setSolved] = useState(false);
  const [solvedBy, setSolvedBy] = useState<string | null>(null);
  const [showHint, setShowHint] = useState(false);
  const inputRef = useRef<HTMLInputElement>(null);

  // Single player timer
  const [startTime, setStartTime] = useState<number | null>(null);
  const [roundTimes, setRoundTimes] = useState<number[]>([]);
  const [currentTimer, setCurrentTimer] = useState(0);
  const timerRef = useRef<number>(0);

  const myRole = myColor === "white" ? "white" : "black";
  const totalRounds = 5;

  // Start timer on first render for single player
  useEffect(() => {
    if (singlePlayer && !startTime) {
      setStartTime(Date.now());
    }
  }, [singlePlayer, startTime]);

  // Timer tick
  useEffect(() => {
    if (!singlePlayer || !startTime || round > totalRounds) return;
    const tick = () => {
      setCurrentTimer((Date.now() - startTime) / 1000);
      timerRef.current = requestAnimationFrame(tick);
    };
    timerRef.current = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(timerRef.current);
  }, [singlePlayer, startTime, round]);

  // Sync from online
  useEffect(() => {
    if (!online || !gameState) return;
    if (gameState.numbers) setNumbers(gameState.numbers);
    if (gameState.scores) setScores(gameState.scores);
    if (gameState.round !== undefined) setRound(gameState.round);
    setSolved(!!gameState.solved);
    setSolvedBy(gameState.solvedBy || null);
    setShowHint(false);
    if (gameState.solved) setExpression("");
  }, [online, gameState]);

  const handleSubmit = useCallback(() => {
    if (solved) return;
    const result = checkExpression(expression, numbers);
    if (!result.valid) {
      toast.error(result.message);
      return;
    }

    toast.success(result.message);

    if (singlePlayer) {
      const roundTime = startTime ? (Date.now() - startTime) / 1000 : 0;
      const newRoundTimes = [...roundTimes, roundTime];
      setRoundTimes(newRoundTimes);

      setSolved(true);
      setSolvedBy("black");
      setExpression("");

      const newRound = round + 1;
      const isGameOver = newRound > totalRounds;

      if (isGameOver) {
        // Save total time to leaderboard
        const totalTime = roundTime;
        supabase.auth.getUser().then(({ data: { user } }) => {
          if (user) {
            supabase.rpc("submit_game_score", {
              _game_type: "game24", _score: Math.round(totalTime * 100) / 100, _mode: "single",
            });
          }
        });
      }
      return;
    }

    const newScores = { ...scores };
    const scorer = online ? myRole : (round % 2 === 1 ? "black" : "white");
    newScores[scorer] += 1;

    setSolved(true);
    setSolvedBy(scorer);
    setScores(newScores);
    setExpression("");

    if (online && onMove) {
      const newRound = round + 1;
      onMove({
        numbers,
        scores: newScores,
        round,
        solved: true,
        solvedBy: scorer,
        gameOver: newRound > totalRounds,
      });
    }
  }, [expression, numbers, scores, round, solved, online, onMove, myRole, singlePlayer, startTime, roundTimes, totalRounds]);

  const nextRound = useCallback(() => {
    const newNums = generateNumbers();
    const newRound = round + 1;
    setNumbers(newNums);
    setRound(newRound);
    setSolved(false);
    setSolvedBy(null);
    setExpression("");
    setShowHint(false);

    if (singlePlayer) {
      setStartTime(Date.now());
    }

    if (online && onMove) {
      onMove({
        numbers: newNums,
        scores,
        round: newRound,
        solved: false,
        solvedBy: null,
        gameOver: false,
      });
    }
  }, [round, scores, online, onMove, singlePlayer]);

  const resetGame = useCallback(() => {
    const newNums = generateNumbers();
    setNumbers(newNums);
    setScores({ black: 0, white: 0 });
    setRound(1);
    setSolved(false);
    setSolvedBy(null);
    setExpression("");
    setShowHint(false);
    setRoundTimes([]);
    setStartTime(Date.now());

    if (online && onMove) {
      onMove({
        numbers: newNums,
        scores: { black: 0, white: 0 },
        round: 1,
        solved: false,
        solvedBy: null,
        gameOver: false,
      });
    }
  }, [online, onMove]);

  const hint = solve24([...numbers]);
  const gameOver = round > totalRounds;

  const p1Label = online ? (myRole === "black" ? "You" : "Opponent") : "Player 1";
  const p2Label = online ? (myRole === "white" ? "You" : "Opponent") : "Player 2";

  const formatTime = (t: number) => `${Math.floor(t / 60)}:${(t % 60).toFixed(1).padStart(4, '0')}`;

  return (
    <div className="flex flex-col items-center gap-4 max-w-md mx-auto">
      {/* Scoreboard */}
      <div className="flex items-center justify-between w-full">
        {singlePlayer ? (
          <>
            <Badge variant="default" className="text-xs">⏱ {formatTime(currentTimer)}</Badge>
            <span className="text-xs text-muted-foreground">Round {Math.min(round, totalRounds)}/{totalRounds}</span>
          </>
        ) : (
          <>
            <div className="flex items-center gap-2">
              <Badge variant="default" className="text-xs">{p1Label}: {scores.black}</Badge>
              <Badge variant="secondary" className="text-xs">{p2Label}: {scores.white}</Badge>
            </div>
            <span className="text-xs text-muted-foreground">Round {Math.min(round, totalRounds)}/{totalRounds}</span>
          </>
        )}
        <Button variant="outline" size="sm" onClick={resetGame}>Restart</Button>
      </div>

      {gameOver ? (
        <div className="text-center py-8">
          {singlePlayer ? (
            <>
              <p className="text-2xl font-bold mb-2">All rounds complete! 🎉</p>
              <p className="text-muted-foreground mb-2">
                Total time: {formatTime(roundTimes[roundTimes.length - 1] || currentTimer)}
              </p>
              <div className="text-sm text-muted-foreground mb-4">
                {roundTimes.map((t, i) => (
                  <p key={i}>Round {i + 1}: {formatTime(t)}</p>
                ))}
              </div>
              <p className="text-xs text-muted-foreground mb-4">✅ Score saved</p>
            </>
          ) : (
            <>
              <p className="text-2xl font-bold mb-2">
                {scores.black > scores.white ? `${p1Label} wins! 🎉` :
                 scores.white > scores.black ? `${p2Label} wins! 🎉` : "Draw!"}
              </p>
              <p className="text-muted-foreground mb-4">
                Final score: {scores.black} : {scores.white}
              </p>
            </>
          )}
          <Button onClick={resetGame}>Play Again</Button>
        </div>
      ) : (
        <>
          {/* Number cards */}
          <div className="flex gap-3">
            {numbers.map((num, i) => (
              <div key={i} className="w-16 h-20 rounded-lg bg-primary/10 border-2 border-primary/30 flex items-center justify-center text-2xl font-bold text-primary shadow-sm">
                {num}
              </div>
            ))}
          </div>

          <p className="text-sm text-muted-foreground">
            Use +, -, × (*), ÷ (/) and parentheses to make 24
          </p>

          {solved ? (
            <div className="text-center py-4">
              <p className="text-lg font-semibold text-primary">
                {singlePlayer ? "Solved!" : (solvedBy === myRole || !online ? "You got it!" : "Opponent got it!")}
              </p>
              {round < totalRounds && (
                <Button onClick={nextRound} className="mt-3">Next Round</Button>
              )}
              {round >= totalRounds && (
                <Button onClick={() => { setRound(r => r + 1); }} className="mt-3">View Results</Button>
              )}
            </div>
          ) : (
            <div className="flex gap-2 w-full">
              <Input
                ref={inputRef}
                value={expression}
                onChange={(e) => setExpression(e.target.value)}
                placeholder="e.g. (1+2)*(3+5)"
                onKeyDown={(e) => e.key === "Enter" && handleSubmit()}
                className="flex-1"
              />
              <Button onClick={handleSubmit} disabled={!expression.trim()}>
                Submit
              </Button>
            </div>
          )}

          {/* Hint / Skip */}
          {!solved && (
            <div className="flex gap-2">
              <Button variant="ghost" size="sm" onClick={() => setShowHint(true)}>
                {showHint ? (hint || "No solution") : "Hint"}
              </Button>
              <Button variant="ghost" size="sm" onClick={nextRound}>Skip</Button>
            </div>
          )}
        </>
      )}
    </div>
  );
}
