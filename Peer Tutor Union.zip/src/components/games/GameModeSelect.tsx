import { useState } from "react";
import { Button } from "@/components/ui/button";
import { User, Users, Bot, UsersRound, Globe } from "lucide-react";
import GameLeaderboard from "./GameLeaderboard";

interface GameModeSelectProps {
  gameName: string;
  gameType: string;
  onSinglePlayer: (timeLimit?: number) => void;
  onTwoPlayer: (timeLimit?: number) => void;
  onVsRobot?: (timeLimit?: number, difficulty?: string) => void;
  on2v2?: (timeLimit?: number, difficulty?: string) => void;
  onOnlineMultiplayer?: (timeLimit?: number) => void;
  onOnline2v2?: (timeLimit?: number, difficulty?: string) => void;
  onTeamBattle?: () => void;
  /** @deprecated Team HQ moved to dedicated /ptc-star page; kept for back-compat. */
  onTeamHQ?: () => void;
  showTimeSelect?: boolean;
  leaderboardConfig?: {
    scoreLabel?: string;
    formatScore?: (score: number) => string;
    sortAsc?: boolean;
  };
}

const TIME_OPTIONS = [
  { label: "45s", value: 45 },
  { label: "90s", value: 90 },
  { label: "120s", value: 120 },
];

const DIFFICULTIES = [
  { key: "easy", label: "Easy", emoji: "😊", desc: "慢速，低命中" },
  { key: "medium", label: "Medium", emoji: "🏀", desc: "平衡难度" },
  { key: "hard", label: "Hard", emoji: "🔥", desc: "高速，高命中" },
  { key: "allstar", label: "All-Star", emoji: "🌟", desc: "全明星，可灌篮" },
  { key: "nba", label: "NBA Player", emoji: "⭐", desc: "极强，必胜" },
];

export default function GameModeSelect({
  gameName, gameType, onSinglePlayer, onTwoPlayer,
  onVsRobot, on2v2, onOnlineMultiplayer, onOnline2v2, onTeamBattle,
  showTimeSelect = false, leaderboardConfig,
}: GameModeSelectProps) {
  const [step, setStep] = useState<"modes" | "difficulty" | "time">("modes");
  const [pendingMode, setPendingMode] = useState<"local" | "vsRobot" | "2v2" | "online" | "online2v2">("local");
  const [selectedDifficulty, setSelectedDifficulty] = useState<string>("medium");
  const [leaderboardTime, setLeaderboardTime] = useState<number>(90);

  const startWithDifficulty = (diff: string) => {
    setSelectedDifficulty(diff);
    if (showTimeSelect) {
      setStep("time");
    } else {
      if (pendingMode === "vsRobot" && onVsRobot) onVsRobot(undefined, diff);
      else if (pendingMode === "2v2" && on2v2) on2v2(undefined, diff);
      else if (pendingMode === "online2v2" && onOnline2v2) onOnline2v2(undefined, diff);
    }
  };

  const handleTimeSelect = (time: number) => {
    if ((pendingMode as string) === "single") onSinglePlayer(time);
    else if (pendingMode === "vsRobot" && onVsRobot) onVsRobot(time, selectedDifficulty);
    else if (pendingMode === "2v2" && on2v2) on2v2(time, selectedDifficulty);
    else if (pendingMode === "online2v2" && onOnline2v2) onOnline2v2(time, selectedDifficulty);
    else if (pendingMode === "online" && onOnlineMultiplayer) onOnlineMultiplayer(time);
    else onTwoPlayer(time);
  };

  const handleModeClick = (m: "vsRobot" | "2v2" | "online2v2") => {
    setPendingMode(m);
    setStep("difficulty");
  };

  return (
    <div className="flex flex-col items-center gap-6 py-4">
      <h3 className="text-xl font-bold">{gameName}</h3>

      {step === "modes" && (
        <div className="flex flex-wrap justify-center gap-4">
          <Button onClick={() => {
            if (showTimeSelect) { setPendingMode("single" as any); setStep("time"); }
            else onSinglePlayer();
          }} variant="outline" className="flex-col h-24 w-36 gap-2">
            <User className="h-6 w-6" />
            <span className="font-semibold text-xs">单人练习</span>
          </Button>

          {onVsRobot && (
            <Button onClick={() => handleModeClick("vsRobot")} variant="outline" className="flex-col h-24 w-36 gap-2">
              <Bot className="h-6 w-6" />
              <span className="font-semibold text-xs">VS 机器人</span>
            </Button>
          )}

          {/* Two-player: online if callback provided, otherwise local */}
          <Button
            onClick={() => {
              if (onOnlineMultiplayer) {
                if (showTimeSelect) { setPendingMode("online"); setStep("time"); }
                else onOnlineMultiplayer();
              } else {
                if (showTimeSelect) { setPendingMode("local"); setStep("time"); }
                else onTwoPlayer();
              }
            }}
            variant="outline"
            className="flex-col h-24 w-36 gap-2"
          >
            {onOnlineMultiplayer ? <Globe className="h-6 w-6" /> : <Users className="h-6 w-6" />}
            <span className="font-semibold text-xs">{onOnlineMultiplayer ? "在线对战" : "双人对战"}</span>
          </Button>

          {/* Team Battle: replaces online 2v2 */}
          {onTeamBattle && (
            <Button
              onClick={onTeamBattle}
              variant="outline"
              className="flex-col h-24 w-36 gap-2"
            >
              <UsersRound className="h-6 w-6" />
              <span className="font-semibold text-xs">团队作战</span>
              <span className="text-[10px] text-muted-foreground">最多 6 人 + AI</span>
            </Button>
          )}
        </div>
      )}

      {step === "difficulty" && (
        <div className="flex flex-col items-center gap-4">
          <p className="text-sm text-muted-foreground">选择机器人难度:</p>
          <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
            {DIFFICULTIES.map(d => (
              <Button
                key={d.key}
                variant="outline"
                className="flex-col h-20 w-32 gap-1"
                onClick={() => startWithDifficulty(d.key)}
              >
                <span className="text-lg">{d.emoji}</span>
                <span className="font-semibold text-xs">{d.label}</span>
                <span className="text-[10px] text-muted-foreground">{d.desc}</span>
              </Button>
            ))}
          </div>
          <Button variant="ghost" size="sm" onClick={() => setStep("modes")}>← 返回</Button>
        </div>
      )}

      {step === "time" && (
        <div className="flex flex-col items-center gap-3">
          <p className="text-sm text-muted-foreground">选择比赛时间:</p>
          <div className="flex gap-3">
            {TIME_OPTIONS.map(opt => (
              <Button key={opt.value} variant="secondary" size="sm" onClick={() => handleTimeSelect(opt.value)}>
                {opt.label}
              </Button>
            ))}
          </div>
          <Button variant="ghost" size="sm" onClick={() => ((pendingMode as string) === "single" || pendingMode === "local" || pendingMode === "online") ? setStep("modes") : setStep("difficulty")}>← 返回</Button>
        </div>
      )}

      {showTimeSelect ? (
        <div className="w-full max-w-sm">
          <div className="flex gap-2 mb-2 justify-center">
            {TIME_OPTIONS.map(opt => (
              <Button
                key={opt.value}
                variant={leaderboardTime === opt.value ? "default" : "outline"}
                size="sm"
                className="text-xs px-3"
                onClick={() => setLeaderboardTime(opt.value)}
              >
                {opt.label}
              </Button>
            ))}
          </div>
          <GameLeaderboard gameType={`${gameType}_${leaderboardTime}s`} {...leaderboardConfig} />
        </div>
      ) : (
        <GameLeaderboard gameType={gameType} {...leaderboardConfig} />
      )}
    </div>
  );
}
