import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { Badge } from "@/components/ui/badge";
import { Trophy, Medal, Award } from "lucide-react";

interface LeaderboardEntry {
  id: string;
  user_id: string;
  score: number;
  created_at: string;
  profile_name?: string;
}

interface GameLeaderboardProps {
  gameType: string;
  scoreLabel?: string;
  formatScore?: (score: number) => string;
  sortAsc?: boolean; // true for "lower is better" (e.g. time)
}

export default function GameLeaderboard({ gameType, scoreLabel = "Score", formatScore, sortAsc = false }: GameLeaderboardProps) {
  const [entries, setEntries] = useState<LeaderboardEntry[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const load = async () => {
      // Fetch all scores, then deduplicate to best per user client-side
      const { data } = await supabase
        .from("game_leaderboards")
        .select("*")
        .eq("game_type", gameType)
        .eq("mode", "single")
        .order("score", { ascending: sortAsc })
        .limit(100);

      if (!data) { setLoading(false); return; }

      // Keep only best score per user
      const bestMap = new Map<string, typeof data[0]>();
      for (const row of data) {
        const existing = bestMap.get(row.user_id);
        if (!existing || (sortAsc ? Number(row.score) < Number(existing.score) : Number(row.score) > Number(existing.score))) {
          bestMap.set(row.user_id, row);
        }
      }
      const best = [...bestMap.values()].sort((a, b) => sortAsc ? Number(a.score) - Number(b.score) : Number(b.score) - Number(a.score));

      const userIds = [...new Set(best.map(d => d.user_id))];
      const { data: profiles } = await supabase
        .from("profiles")
        .select("user_id, name")
        .in("user_id", userIds);

      const nameMap: Record<string, string> = {};
      profiles?.forEach(p => { nameMap[p.user_id] = p.name; });

      setEntries(best.map(d => ({
        ...d,
        score: Number(d.score),
        profile_name: nameMap[d.user_id] || "Unknown",
      })));
      setLoading(false);
    };
    load();
  }, [gameType, sortAsc]);

  const icons = [
    <Trophy key="1" className="h-4 w-4 text-yellow-500" />,
    <Medal key="2" className="h-4 w-4 text-gray-400" />,
    <Award key="3" className="h-4 w-4 text-amber-600" />,
  ];

  const fmt = formatScore || ((s: number) => String(s));

  if (loading) return <p className="text-xs text-muted-foreground">Loading leaderboard...</p>;
  if (entries.length === 0) return <p className="text-xs text-muted-foreground">No records yet. Be the first!</p>;

  return (
    <div className="w-full max-w-sm">
      <h4 className="text-sm font-semibold mb-2 flex items-center gap-1.5">
        <Trophy className="h-4 w-4 text-yellow-500" /> Leaderboard
      </h4>
      <div className="space-y-1">
        {entries.slice(0, 10).map((e, i) => (
          <div key={e.id} className="flex items-center gap-2 text-xs py-1 px-2 rounded bg-muted/30">
            <span className="w-5 text-center font-bold">
              {i < 3 ? icons[i] : `${i + 1}`}
            </span>
            <span className="flex-1 truncate">{e.profile_name}</span>
            <Badge variant="secondary" className="text-xs font-mono">
              {fmt(e.score)}
            </Badge>
          </div>
        ))}
      </div>
    </div>
  );
}
