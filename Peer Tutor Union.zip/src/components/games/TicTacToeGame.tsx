import { useState, useEffect, useCallback } from "react";
import { Button } from "@/components/ui/button";

type Cell = null | "X" | "O";

const LINES = [
  [0,1,2],[3,4,5],[6,7,8],
  [0,3,6],[1,4,7],[2,5,8],
  [0,4,8],[2,4,6],
];

function checkWinner(board: Cell[]): Cell {
  for (const [a,b,c] of LINES) {
    if (board[a] && board[a] === board[b] && board[a] === board[c]) return board[a];
  }
  return null;
}

function getWinLine(board: Cell[]): number[] | null {
  for (const line of LINES) {
    const [a,b,c] = line;
    if (board[a] && board[a] === board[b] && board[a] === board[c]) return line;
  }
  return null;
}

interface TicTacToeGameProps {
  online?: boolean;
  myColor?: string;
  gameState?: any;
  onMove?: (state: any) => void;
  isMyTurn?: boolean;
}

export default function TicTacToeGame({ online, myColor, gameState, onMove, isMyTurn }: TicTacToeGameProps) {
  const [board, setBoard] = useState<Cell[]>(() => {
    if (online && gameState?.board) return [...gameState.board];
    return Array(9).fill(null);
  });
  const [turn, setTurn] = useState<"X" | "O">(() => {
    if (online && gameState?.turn) return gameState.turn;
    return "X";
  });
  const [winner, setWinner] = useState<Cell>(null);

  // My symbol: black = X (goes first), white = O
  const mySymbol: "X" | "O" = myColor === "white" ? "O" : "X";
  const isActiveTurn = !online || (turn === mySymbol && isMyTurn !== false);

  // Sync from online state
  useEffect(() => {
    if (!online || !gameState) return;
    if (gameState.board) setBoard([...gameState.board]);
    if (gameState.turn) setTurn(gameState.turn);
    setWinner(gameState.winner || null);
  }, [online, gameState]);

  const handleClick = useCallback((idx: number) => {
    if (board[idx] || winner) return;
    if (!isActiveTurn) return;

    const newBoard = [...board];
    newBoard[idx] = turn;
    const w = checkWinner(newBoard);
    const nextTurn = turn === "X" ? "O" : "X";
    const isDraw = !w && newBoard.every(c => c !== null);

    setBoard(newBoard);
    setWinner(w);
    setTurn(nextTurn);

    if (online && onMove) {
      onMove({
        board: newBoard,
        turn: w || isDraw ? turn : nextTurn,
        winner: w,
        draw: isDraw,
      });
    }
  }, [board, turn, winner, isActiveTurn, online, onMove]);

  const reset = () => {
    const newBoard = Array(9).fill(null);
    setBoard(newBoard);
    setTurn("X");
    setWinner(null);
    if (online && onMove) {
      onMove({ board: newBoard, turn: "X", winner: null, draw: false });
    }
  };

  const winLine = getWinLine(board);
  const isDraw = !winner && board.every(c => c !== null);

  return (
    <div className="flex flex-col items-center gap-4">
      <div className="flex items-center gap-4">
        <p className="text-sm font-medium text-foreground">
          {winner ? `${winner} wins! 🎉` : isDraw ? "Draw!" : online
            ? (isActiveTurn ? `Your turn (${mySymbol})` : "Waiting for opponent...")
            : `Turn: ${turn}`}
        </p>
        <Button variant="outline" size="sm" onClick={reset}>Restart</Button>
      </div>

      <div className="grid grid-cols-3 gap-1 bg-border rounded-lg p-1">
        {board.map((cell, idx) => {
          const isWinCell = winLine?.includes(idx);
          return (
            <button
              key={idx}
              onClick={() => handleClick(idx)}
              disabled={!!cell || !!winner || !isActiveTurn}
              className={`w-20 h-20 flex items-center justify-center text-3xl font-bold rounded-md transition-all duration-200
                ${isWinCell ? "bg-primary/20 scale-105" : "bg-card hover:bg-accent/50"}
                ${!cell && !winner && isActiveTurn ? "cursor-pointer" : "cursor-default"}
                ${cell === "X" ? "text-blue-500" : cell === "O" ? "text-red-500" : "text-transparent"}
              `}
            >
              {cell || "·"}
            </button>
          );
        })}
      </div>

      {online && (
        <p className="text-xs text-muted-foreground">
          You are <span className="font-bold">{mySymbol}</span>
        </p>
      )}
    </div>
  );
}
