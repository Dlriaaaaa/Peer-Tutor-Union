/**
 * BaseballGame — orchestrator with camera POV selector + pro difficulty.
 */

import { useState, useCallback, useRef, useEffect } from "react";
import GameScene3D from "@/components/GameScene3D";
import GameHUD from "@/components/GameHUD";
import ControlsPanel from "@/components/ControlsPanel";
import type { SceneState, BillboardConfig, CameraView } from "@/render/three/sceneTypes";

import { createInitialGameState, applyPitchOutcome } from "@/game/rulesEngine";
import { aiSelectPitch } from "@/game/ai";
import { resolveSwing } from "@/game/hitting";
import { resolveFielding } from "@/game/fielding";
import { createRng } from "@/game/pitching";
import type { GameState, Pitch, HitBall, SwingDecision } from "@/game/types";

type Phase = "idle" | "pitching" | "deciding" | "result" | "game_over";

/** Pro difficulty: faster pitch, shorter decision window */
const PITCH_FLIGHT_MS = 600;
const RESULT_DISPLAY_MS = 900;
const HIT_FLIGHT_MS = 700;
const DECIDE_TIMEOUT_MS = 1200; // 1.2s auto-take for pro

const PHASE_LABELS: Record<Phase, string> = {
  idle: "Ready — Press Space or click Next Pitch",
  pitching: "Pitcher winding up…",
  deciding: "⚡ SWING or TAKE!",
  result: "Resolving play…",
  game_over: "Game Over",
};

const CAMERA_OPTIONS: { value: CameraView; label: string }[] = [
  { value: "broadcast", label: "📺 Broadcast" },
  { value: "catcher", label: "🧤 Catcher" },
  { value: "umpire", label: "⚖️ Umpire" },
  { value: "pitcher", label: "⚾ Pitcher" },
];

interface Props {
  mode: string;
  onBack: () => void;
  billboardLogoUrl?: string;
  billboardOpacity?: number;
  billboardScale?: number;
  billboardX?: number;
  billboardY?: number;
}

export default function BaseballGame({
  mode,
  onBack,
  billboardLogoUrl = "/images/nymba_logo.png",
  billboardOpacity = 1,
  billboardScale = 1.6,
  billboardX = 0,
  billboardY = 0,
}: Props) {
  const [gameState, setGameState] = useState<GameState>(createInitialGameState);
  const [phase, setPhase] = useState<Phase>("idle");
  const [currentPitch, setCurrentPitch] = useState<Pitch | null>(null);
  const [lastPitch, setLastPitch] = useState<Pitch | null>(null);
  const [lastResult, setLastResult] = useState<string>("");
  const [ballProgress, setBallProgress] = useState<number | null>(null);
  const [hitBall, setHitBall] = useState<{ x: number; y: number; visible: boolean } | null>(null);
  const [cameraView, setCameraView] = useState<CameraView>("catcher");
  const [decideTimeLeft, setDecideTimeLeft] = useState(DECIDE_TIMEOUT_MS);

  const rngRef = useRef(createRng(Date.now()));
  const pitchResolvedRef = useRef(false);
  const decideTimerRef = useRef<ReturnType<typeof setTimeout>>();

  const billboard: BillboardConfig = {
    logoUrl: billboardLogoUrl,
    opacity: billboardOpacity,
    scale: billboardScale,
    offsetX: billboardX,
    offsetY: billboardY,
  };

  const sceneState: SceneState = {
    bases: gameState.bases,
    ballProgress,
    currentPitch,
    billboard,
    hitBall,
    phaseLabel: PHASE_LABELS[gameState.status === "over" ? "game_over" : phase],
    phase,
    cameraView,
  };

  // ─── Handle "Next Pitch" ─────────────────────────────
  const handleNextPitch = useCallback(() => {
    if (phase !== "idle" || gameState.status === "over") return;

    const rng = rngRef.current;
    const ctx = {
      count: gameState.count,
      outs: gameState.outs,
      bases: gameState.bases,
      inning: gameState.inning,
      scoreDiff:
        gameState.half === "top"
          ? gameState.score.home - gameState.score.away
          : gameState.score.away - gameState.score.home,
    };
    const pitch = aiSelectPitch(ctx, rng);
    setCurrentPitch(pitch);
    setLastPitch(pitch);
    setLastResult("");
    pitchResolvedRef.current = false;

    setPhase("pitching");
    const startTime = performance.now();

    const animatePitch = (now: number) => {
      const elapsed = now - startTime;
      const progress = Math.min(elapsed / PITCH_FLIGHT_MS, 1);
      setBallProgress(progress);

      if (progress < 1) {
        requestAnimationFrame(animatePitch);
      } else {
        setBallProgress(1);
        setPhase("deciding");
        setDecideTimeLeft(DECIDE_TIMEOUT_MS);

        // Pro mode: auto-take after timeout
        const countdownStart = Date.now();
        const interval = setInterval(() => {
          const remaining = DECIDE_TIMEOUT_MS - (Date.now() - countdownStart);
          if (remaining <= 0) {
            clearInterval(interval);
            if (!pitchResolvedRef.current) {
              resolveDecision(pitch, { action: "take" });
            }
          } else {
            setDecideTimeLeft(remaining);
          }
        }, 30);
        decideTimerRef.current = interval;
      }
    };

    requestAnimationFrame(animatePitch);
  }, [phase, gameState]);

  // ─── Resolve Swing/Take ──────────────────────────────
  const resolveDecision = useCallback(
    (pitch: Pitch, decision: SwingDecision) => {
      if (pitchResolvedRef.current) return;
      pitchResolvedRef.current = true;
      if (decideTimerRef.current) clearInterval(decideTimerRef.current);

      setPhase("result");
      const rng = rngRef.current;

      const outcome = resolveSwing(pitch, decision, rng);
      setLastResult(outcome.description);

      let newState: GameState;

      if (outcome.pitchOutcome === "in_play") {
        const hitBallData: HitBall | undefined = (outcome as any).hitBall;
        if (hitBallData) {
          animateHitBall(hitBallData);
          const fieldResult = resolveFielding(hitBallData, gameState.outs, gameState.bases, rng);
          newState = applyPitchOutcome(gameState, "in_play", fieldResult);
        } else {
          newState = applyPitchOutcome(gameState, "in_play", { type: "ground_out" });
        }
      } else {
        newState = applyPitchOutcome(gameState, outcome.pitchOutcome);
      }

      setTimeout(() => {
        setGameState(newState);
        setBallProgress(null);
        setCurrentPitch(null);
        setHitBall(null);

        if (newState.status === "over") {
          setPhase("game_over");
        } else {
          setPhase("idle");
        }
      }, RESULT_DISPLAY_MS);
    },
    [gameState],
  );

  const handleSwing = useCallback(() => {
    if (phase !== "deciding" || !currentPitch) return;
    const rng = rngRef.current;
    const timing = (rng() - 0.5) * 20;
    const aimPoint = {
      x: currentPitch.location.x + (rng() - 0.5) * 0.3,
      y: currentPitch.location.y + (rng() - 0.5) * 0.3,
    };
    resolveDecision(currentPitch, { action: "swing", timing, aimPoint });
  }, [phase, currentPitch, resolveDecision]);

  const handleTake = useCallback(() => {
    if (phase !== "deciding" || !currentPitch) return;
    resolveDecision(currentPitch, { action: "take" });
  }, [phase, currentPitch, resolveDecision]);

  const handleNewGame = useCallback(() => {
    setGameState(createInitialGameState());
    setPhase("idle");
    setCurrentPitch(null);
    setLastPitch(null);
    setLastResult("");
    setBallProgress(null);
    setHitBall(null);
    rngRef.current = createRng(Date.now());
  }, []);

  const animateHitBall = (data: HitBall) => {
    const startX = 400;
    const startY = 400;
    const angle = (-90 + data.pullAngle) * (Math.PI / 180);
    const maxDist = Math.min(data.distance * 0.6, 350);
    const endX = startX + Math.sin(angle) * maxDist;
    const endY = startY - Math.cos(angle) * maxDist;

    const start = performance.now();
    const animate = (now: number) => {
      const raw = Math.min((now - start) / HIT_FLIGHT_MS, 1);
      const t = 1 - Math.pow(1 - raw, 3);
      setHitBall({
        x: startX + (endX - startX) * t,
        y: startY + (endY - startY) * t - Math.sin(raw * Math.PI) * 60,
        visible: true,
      });
      if (raw < 1) requestAnimationFrame(animate);
    };
    requestAnimationFrame(animate);
  };

  useEffect(() => {
    const onKeyDown = (e: KeyboardEvent) => {
      if (e.repeat) return;
      if (e.code === "Space") {
        e.preventDefault();
        if (phase === "idle" && gameState.status !== "over") handleNextPitch();
        else if (phase === "deciding") handleSwing();
      }
      if (e.code === "KeyT" && phase === "deciding") {
        e.preventDefault();
        handleTake();
      }
      // Camera shortcuts: 1-4
      if (e.code === "Digit1") setCameraView("broadcast");
      if (e.code === "Digit2") setCameraView("catcher");
      if (e.code === "Digit3") setCameraView("umpire");
      if (e.code === "Digit4") setCameraView("pitcher");
    };
    const onKeyUp = (e: KeyboardEvent) => { if (e.code === "Space") e.preventDefault(); };
    window.addEventListener("keydown", onKeyDown);
    window.addEventListener("keyup", onKeyUp);
    return () => { window.removeEventListener("keydown", onKeyDown); window.removeEventListener("keyup", onKeyUp); };
  }, [phase, gameState.status, handleNextPitch, handleSwing, handleTake]);

  return (
    <div className="flex flex-col items-center gap-1.5 p-2 w-full h-[calc(100vh-3rem)] overflow-hidden">
      <div className="flex items-center justify-between w-full max-w-[800px]">
        <button onClick={onBack} className="text-xs text-muted-foreground hover:text-foreground transition-colors">
          ← Back
        </button>
        <h2 className="text-sm font-bold">⚾ Baseball 3D</h2>
        <div className="text-[10px] text-muted-foreground">Space/T · 1-4: Cam</div>
      </div>

      {/* Camera selector */}
      <div className="flex gap-1 w-full max-w-[800px]">
        {CAMERA_OPTIONS.map((opt) => (
          <button
            key={opt.value}
            onClick={() => setCameraView(opt.value)}
            className={`flex-1 py-1 rounded text-[10px] font-medium transition-colors ${
              cameraView === opt.value
                ? "bg-primary text-primary-foreground"
                : "bg-muted text-muted-foreground hover:bg-muted/80"
            }`}
          >
            {opt.label}
          </button>
        ))}
      </div>

      <div className="w-full max-w-[800px] flex-1 min-h-0">
        <GameScene3D state={sceneState} />
      </div>

      <ControlsPanel
        phase={gameState.status === "over" ? "game_over" : phase}
        onNextPitch={handleNextPitch}
        onSwing={handleSwing}
        onTake={handleTake}
        onNewGame={handleNewGame}
        decideTimeLeft={phase === "deciding" ? decideTimeLeft : undefined}
      />

      <GameHUD state={gameState} lastPitch={lastPitch} lastResult={lastResult} />
    </div>
  );
}
