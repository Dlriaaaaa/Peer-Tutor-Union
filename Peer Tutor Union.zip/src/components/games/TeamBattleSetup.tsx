import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { User, Bot, X, Play } from "lucide-react";
import type { RosterSlot, RobotDifficulty } from "./BasketballGame";

const DIFFICULTIES: { key: RobotDifficulty; label: string; emoji: string }[] = [
  { key: "easy", label: "Easy", emoji: "😊" },
  { key: "medium", label: "Medium", emoji: "🏀" },
  { key: "hard", label: "Hard", emoji: "🔥" },
  { key: "allstar", label: "All-Star", emoji: "🌟" },
  { key: "nba", label: "NBA", emoji: "⭐" },
  { key: "worldchampion", label: "Tour Finals", emoji: "🏆" },
];

const TIME_OPTIONS = [
  { label: "45s", value: 45 },
  { label: "90s", value: 90 },
  { label: "120s", value: 120 },
];

type SlotState =
  | { kind: "empty" }
  | { kind: "human"; humanSlot: 1 | 2 }
  | { kind: "ai"; difficulty: RobotDifficulty };

interface TeamBattleSetupProps {
  onStart: (roster: RosterSlot[], timeLimit: number) => void;
  onBack: () => void;
}

const TEAM_LABELS = ["队伍 1 🔴", "队伍 2 🔵"];

const initialSlots = (): SlotState[][] => [
  // Team 0: 1 human + 2 empty
  [{ kind: "human", humanSlot: 1 }, { kind: "ai", difficulty: "medium" }, { kind: "empty" }],
  // Team 1: 3 AI of varied difficulty
  [{ kind: "ai", difficulty: "medium" }, { kind: "ai", difficulty: "medium" }, { kind: "empty" }],
];

export default function TeamBattleSetup({ onStart, onBack }: TeamBattleSetupProps) {
  const [slots, setSlots] = useState<SlotState[][]>(initialSlots());
  const [timeLimit, setTimeLimit] = useState(90);

  const allSlots = slots.flat();
  const humanCount = allSlots.filter(s => s.kind === "human").length;
  const usedHumanSlots = new Set(
    allSlots.filter((s): s is { kind: "human"; humanSlot: 1 | 2 } => s.kind === "human").map(s => s.humanSlot)
  );
  const team0Active = slots[0].filter(s => s.kind !== "empty").length;
  const team1Active = slots[1].filter(s => s.kind !== "empty").length;
  const totalActive = team0Active + team1Active;

  const cycleSlot = (teamIdx: number, slotIdx: number) => {
    setSlots(prev => {
      const next = prev.map(t => [...t]);
      const cur = next[teamIdx][slotIdx];

      // Cycle order: empty → human (next free slot) → ai easy → medium → hard → allstar → nba → empty
      if (cur.kind === "empty") {
        // Try to make human if a slot is free
        const freeSlot: 1 | 2 | null = !usedHumanSlots.has(1) ? 1 : !usedHumanSlots.has(2) ? 2 : null;
        if (freeSlot !== null) {
          next[teamIdx][slotIdx] = { kind: "human", humanSlot: freeSlot };
        } else {
          next[teamIdx][slotIdx] = { kind: "ai", difficulty: "easy" };
        }
      } else if (cur.kind === "human") {
        next[teamIdx][slotIdx] = { kind: "ai", difficulty: "easy" };
      } else {
        // AI — cycle through difficulties, then empty
        const order: RobotDifficulty[] = ["easy", "medium", "hard", "allstar", "nba", "worldchampion"];
        const i = order.indexOf(cur.difficulty);
        if (i < order.length - 1) {
          next[teamIdx][slotIdx] = { kind: "ai", difficulty: order[i + 1] };
        } else {
          next[teamIdx][slotIdx] = { kind: "empty" };
        }
      }
      return next;
    });
  };

  const clearSlot = (teamIdx: number, slotIdx: number) => {
    setSlots(prev => {
      const next = prev.map(t => [...t]);
      next[teamIdx][slotIdx] = { kind: "empty" };
      return next;
    });
  };

  const handleStart = () => {
    const roster: RosterSlot[] = [];
    slots.forEach((teamSlots, teamIdx) => {
      teamSlots.forEach(slot => {
        if (slot.kind === "empty") return;
        if (slot.kind === "human") {
          roster.push({ team: teamIdx as 0 | 1, kind: "human", humanSlot: slot.humanSlot });
        } else {
          roster.push({ team: teamIdx as 0 | 1, kind: "ai", difficulty: slot.difficulty });
        }
      });
    });
    onStart(roster, timeLimit);
  };

  const canStart = team0Active > 0 && team1Active > 0 && humanCount > 0;

  const renderSlot = (slot: SlotState, teamIdx: number, slotIdx: number) => {
    const isEmpty = slot.kind === "empty";
    const isHuman = slot.kind === "human";
    const teamColor = teamIdx === 0 ? "border-red-500/40" : "border-blue-500/40";
    const activeColor = teamIdx === 0 ? "bg-red-500/15" : "bg-blue-500/15";

    return (
      <div
        key={slotIdx}
        className={`relative rounded-lg border-2 ${teamColor} ${isEmpty ? "bg-muted/30 border-dashed" : activeColor} p-3 flex flex-col items-center gap-1 min-h-[88px] cursor-pointer transition-all hover:scale-105`}
        onClick={() => cycleSlot(teamIdx, slotIdx)}
      >
        {!isEmpty && (
          <button
            onClick={(e) => { e.stopPropagation(); clearSlot(teamIdx, slotIdx); }}
            className="absolute -top-1.5 -right-1.5 h-5 w-5 rounded-full bg-destructive text-destructive-foreground flex items-center justify-center text-[10px] hover:scale-110 transition-transform"
            aria-label="Remove player"
          >
            <X className="h-3 w-3" />
          </button>
        )}

        {isEmpty && (
          <>
            <div className="h-6 w-6 rounded-full border border-dashed border-muted-foreground/40 flex items-center justify-center text-muted-foreground/60">+</div>
            <span className="text-[10px] text-muted-foreground">点击添加</span>
          </>
        )}

        {isHuman && (
          <>
            <User className="h-5 w-5" />
            <span className="text-xs font-bold">P{slot.humanSlot}</span>
            <span className="text-[10px] text-muted-foreground">真人</span>
          </>
        )}

        {slot.kind === "ai" && (
          <>
            <div className="text-lg leading-none">{DIFFICULTIES.find(d => d.key === slot.difficulty)?.emoji}</div>
            <Bot className="h-4 w-4" />
            <span className="text-[10px] font-semibold">{DIFFICULTIES.find(d => d.key === slot.difficulty)?.label}</span>
          </>
        )}
      </div>
    );
  };

  return (
    <Card className="glass-card">
      <CardContent className="p-6 space-y-6">
        <div className="text-center space-y-1">
          <h3 className="text-xl font-bold">🏀 团队作战 — 阵容编辑</h3>
          <p className="text-xs text-muted-foreground">
            点击格子切换：空 → 真人 → AI(由易到难) → 空。每队 1-3 人，自由搭配 1V2 / 2V2 / 2V3 / 3V3。
          </p>
          <p className="text-[11px] text-muted-foreground">
            键盘最多 2 个真人：P1 用 WASD/F/G/R，P2 用 方向键/./,/。其他位置必须是 AI 或留空。
          </p>
        </div>

        <div className="grid grid-cols-2 gap-6">
          {[0, 1].map(teamIdx => (
            <div key={teamIdx} className="space-y-3">
              <div className={`text-center font-bold text-sm ${teamIdx === 0 ? "text-red-400" : "text-blue-400"}`}>
                {TEAM_LABELS[teamIdx]}
                <span className="ml-2 text-xs text-muted-foreground font-normal">
                  ({slots[teamIdx].filter(s => s.kind !== "empty").length} 人)
                </span>
              </div>
              <div className="grid grid-cols-3 gap-2">
                {slots[teamIdx].map((slot, slotIdx) => renderSlot(slot, teamIdx, slotIdx))}
              </div>
            </div>
          ))}
        </div>

        <div className="text-center text-sm">
          对阵: <span className="font-mono font-bold">{team0Active} V {team1Active}</span>
          <span className="ml-3 text-xs text-muted-foreground">
            场上 {totalActive} 人 · {humanCount} 真人 · {totalActive - humanCount} AI
          </span>
        </div>

        <div className="flex flex-col items-center gap-3">
          <p className="text-xs text-muted-foreground">比赛时间</p>
          <div className="flex gap-2">
            {TIME_OPTIONS.map(opt => (
              <Button
                key={opt.value}
                variant={timeLimit === opt.value ? "default" : "outline"}
                size="sm"
                onClick={() => setTimeLimit(opt.value)}
              >
                {opt.label}
              </Button>
            ))}
          </div>
        </div>

        {!canStart && (
          <p className="text-xs text-center text-amber-500">
            ⚠️ 每队至少需要 1 人，且至少要有 1 个真人玩家
          </p>
        )}

        <div className="flex justify-center gap-3">
          <Button variant="ghost" onClick={onBack}>← 返回</Button>
          <Button onClick={handleStart} disabled={!canStart} className="gap-2">
            <Play className="h-4 w-4" /> 开始比赛
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}
