import { useState, useCallback } from "react";
import { Button } from "@/components/ui/button";

const SIZE = 15;
type Stone = null | "black" | "white";

function createBoard(): Stone[][] {
  return Array.from({ length: SIZE }, () => Array(SIZE).fill(null));
}

function checkWin(board: Stone[][], row: number, col: number, stone: Stone): boolean {
  if (!stone) return false;
  const dirs = [[1,0],[0,1],[1,1],[1,-1]];
  for (const [dr, dc] of dirs) {
    let count = 1;
    for (let d = 1; d < 5; d++) {
      const r = row + dr * d, c = col + dc * d;
      if (r >= 0 && r < SIZE && c >= 0 && c < SIZE && board[r][c] === stone) count++;
      else break;
    }
    for (let d = 1; d < 5; d++) {
      const r = row - dr * d, c = col - dc * d;
      if (r >= 0 && r < SIZE && c >= 0 && c < SIZE && board[r][c] === stone) count++;
      else break;
    }
    if (count >= 5) return true;
  }
  return false;
}

interface GomokuGameProps {
  online?: boolean;
  myColor?: string;
  gameState?: any;
  onMove?: (state: any) => void;
  isMyTurn?: boolean;
}

export default function GomokuGame({ online, myColor, gameState, onMove, isMyTurn }: GomokuGameProps) {
  const [localBoard, setLocalBoard] = useState<Stone[][]>(createBoard);
  const [localTurn, setLocalTurn] = useState<"black" | "white">("black");
  const [winner, setWinner] = useState<Stone>(null);

  const board = online && gameState?.board ? gameState.board : localBoard;
  const turn = online && gameState?.turn ? gameState.turn : localTurn;

  const handleClick = useCallback((r: number, c: number) => {
    if (winner) return;
    if (online && !isMyTurn) return;
    if (board[r][c]) return;

    const newBoard = board.map((row: Stone[]) => [...row]);
    newBoard[r][c] = turn;
    const won = checkWin(newBoard, r, c, turn);
    const nextTurn = turn === "black" ? "white" : "black";

    if (online && onMove) {
      onMove({ board: newBoard, turn: nextTurn, winner: won ? turn : null, lastMove: [r, c] });
    } else {
      if (won) setWinner(turn);
      setLocalBoard(newBoard);
      setLocalTurn(nextTurn);
    }
  }, [board, turn, winner, online, isMyTurn, onMove]);

  // Sync online winner
  const displayWinner = online ? gameState?.winner : winner;

  const reset = () => {
    if (online && onMove) {
      onMove({ board: createBoard(), turn: "black", winner: null, lastMove: null });
    } else {
      setLocalBoard(createBoard()); setLocalTurn("black"); setWinner(null);
    }
  };

  const cellSize = 28;
  const padding = 20;
  const svgSize = (SIZE - 1) * cellSize + padding * 2;

  return (
    <div className="flex flex-col items-center gap-4">
      <div className="flex items-center justify-between w-full max-w-md">
        <div className="text-sm font-medium text-foreground">
          {displayWinner
            ? `🎉 ${displayWinner === "black" ? "Black" : "White"} wins!`
            : online
              ? (isMyTurn ? "Your turn" : "Waiting for opponent...")
              : `Current: ${turn === "black" ? "Black" : "White"}`}
        </div>
        <Button variant="outline" size="sm" onClick={reset}>Restart</Button>
      </div>
      {online && <p className="text-xs text-muted-foreground">You are {myColor === "black" ? "Black" : "White"}</p>}
      <div className="rounded-xl overflow-hidden shadow-lg">
        <svg width={svgSize} height={svgSize} className="bg-amber-200 dark:bg-amber-700">
          {Array.from({ length: SIZE }, (_, i) => (
            <g key={i}>
              <line x1={padding} y1={padding + i * cellSize} x2={padding + (SIZE-1) * cellSize} y2={padding + i * cellSize} stroke="currentColor" className="text-amber-900/60" strokeWidth={0.5} />
              <line x1={padding + i * cellSize} y1={padding} x2={padding + i * cellSize} y2={padding + (SIZE-1) * cellSize} stroke="currentColor" className="text-amber-900/60" strokeWidth={0.5} />
            </g>
          ))}
          {[[3,3],[3,11],[7,7],[11,3],[11,11]].map(([r,c]) => (
            <circle key={`${r}-${c}`} cx={padding + c * cellSize} cy={padding + r * cellSize} r={3} className="fill-amber-900/60" />
          ))}
          {board.map((row: Stone[], r: number) => row.map((stone: Stone, c: number) => (
            <g key={`${r}-${c}`}>
              <rect x={padding + c * cellSize - cellSize/2} y={padding + r * cellSize - cellSize/2} width={cellSize} height={cellSize} fill="transparent" className="cursor-pointer" onClick={() => handleClick(r, c)} />
              {stone && (
                <circle cx={padding + c * cellSize} cy={padding + r * cellSize} r={cellSize/2 - 2}
                  className={stone === "black" ? "fill-gray-900 stroke-gray-700" : "fill-white stroke-gray-300"}
                  strokeWidth={1} style={{ filter: "drop-shadow(1px 1px 1px rgba(0,0,0,0.3))" }}
                />
              )}
            </g>
          )))}
        </svg>
      </div>
    </div>
  );
}
