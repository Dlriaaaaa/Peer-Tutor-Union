import { useState, useEffect, useCallback } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/contexts/AuthContext";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Input } from "@/components/ui/input";
import { Users, Search, ArrowLeft, Loader2, Bell } from "lucide-react";
import { toast } from "sonner";
import { createInitialGameState, hasInitializedGameState } from "@/components/games/gameStateUtils";

type GameSession = {
  id: string;
  game_type: string;
  status: string;
  host_id: string;
  game_state: any;
  current_turn: string | null;
  winner_id: string | null;
};

type Profile = {
  user_id: string;
  name: string;
  avatar_url: string | null;
};

type GameInvitation = {
  id: string;
  session_id: string;
  inviter_id: string;
  invitee_id: string;
  status: string;
  game_sessions?: GameSession;
};

export function useGameMultiplayer(gameType: string) {
  const { user } = useAuth();
  const [session, setSession] = useState<GameSession | null>(null);
  const [playerColor, setPlayerColor] = useState<string>("black");
  const [opponentReady, setOpponentReady] = useState(false);
  const [isOnline, setIsOnline] = useState(false);

  // Create a new game session
  const createSession = useCallback(async (initialState?: any) => {
    if (!user) return null;
    const sessionState = initialState ?? createInitialGameState(gameType);
    const { data, error } = await supabase
      .from("game_sessions")
      .insert({ game_type: gameType, host_id: user.id, status: "waiting", game_state: sessionState })
      .select()
      .single();
    if (error) { toast.error("Failed to create room"); return null; }

    // Join as player 1
    await supabase.from("game_players").insert({
      session_id: data.id, user_id: user.id, player_color: "black", is_ready: true,
    });

    setSession(data);
    setPlayerColor("black");
    setIsOnline(true);
    return data;
  }, [user, gameType]);

  // Join existing session
  const joinSession = useCallback(async (sessionId: string) => {
    if (!user) return;
    const { data: sess } = await supabase
      .from("game_sessions").select("*").eq("id", sessionId).single();
    if (!sess) { toast.error("Room not found"); return; }
    const gs = hasInitializedGameState(sess.game_type, sess.game_state)
      ? sess.game_state : createInitialGameState(sess.game_type);

    await supabase.from("game_players").insert({
      session_id: sessionId, user_id: user.id, player_color: "white", is_ready: true,
    });

    await supabase.from("game_sessions")
      .update({ status: "playing", current_turn: sess.host_id, game_state: gs })
      .eq("id", sessionId);

    setSession({ ...sess, status: "playing", current_turn: sess.host_id, game_state: gs });
    setPlayerColor("white");
    setIsOnline(true);
    setOpponentReady(true);
  }, [user]);

  // Update game state
  const updateGameState = useCallback(async (state: any, nextTurn?: string) => {
    if (!session) return;
    const update: any = { game_state: state };
    if (nextTurn) update.current_turn = nextTurn;
    await supabase.from("game_sessions").update(update).eq("id", session.id);
  }, [session]);

  // Set winner
  const setWinner = useCallback(async (winnerId: string) => {
    if (!session) return;
    await supabase.from("game_sessions")
      .update({ winner_id: winnerId, status: "finished" })
      .eq("id", session.id);
  }, [session]);

  // Listen for realtime updates
  useEffect(() => {
    if (!session || !isOnline) return;

    const channel = supabase
      .channel(`game-${session.id}`)
      .on("postgres_changes", {
        event: "*", schema: "public", table: "game_sessions",
        filter: `id=eq.${session.id}`,
      }, (payload: any) => {
        if (payload.new) {
          setSession(payload.new as GameSession);
        }
      })
      .on("postgres_changes", {
        event: "INSERT", schema: "public", table: "game_players",
        filter: `session_id=eq.${session.id}`,
      }, () => {
        setOpponentReady(true);
      })
      .subscribe();

    return () => { supabase.removeChannel(channel); };
  }, [session?.id, isOnline]);

  // Polling fallback to catch missed realtime events
  useEffect(() => {
    if (!session || !isOnline || !user) return;
    let cancelled = false;
    const poll = async () => {
      const [{ data: latest }, { data: players }] = await Promise.all([
        supabase.from("game_sessions").select("*").eq("id", session.id).maybeSingle(),
        supabase.from("game_players").select("user_id").eq("session_id", session.id),
      ]);
      if (cancelled || !latest) return;
      const hasOpp = players?.some(p => p.user_id !== user.id) ?? false;
      if (hasOpp) setOpponentReady(true);
      if (hasOpp && latest.status === "waiting" && latest.host_id === user.id) {
        const gs = hasInitializedGameState(latest.game_type, latest.game_state)
          ? latest.game_state : createInitialGameState(latest.game_type);
        await supabase.from("game_sessions")
          .update({ status: "playing", current_turn: latest.host_id, game_state: gs })
          .eq("id", latest.id);
      }
      setSession(latest as GameSession);
    };
    poll();
    const id = window.setInterval(poll, 1500);
    return () => { cancelled = true; window.clearInterval(id); };
  }, [session?.id, isOnline, user?.id]);

  const leaveSession = useCallback(async () => {
    if (!session || !user) return;
    await supabase.from("game_players").delete()
      .eq("session_id", session.id).eq("user_id", user.id);
    if (session.host_id === user.id) {
      await supabase.from("game_sessions").delete().eq("id", session.id);
    }
    setSession(null);
    setIsOnline(false);
    setOpponentReady(false);
  }, [session, user]);

  return {
    session, playerColor, opponentReady, isOnline,
    createSession, joinSession, updateGameState, setWinner: setWinner,
    leaveSession, setIsOnline,
  };
}

// Friend invitation dialog
export function InviteFriendDialog({
  open, onClose, sessionId,
}: {
  open: boolean; onClose: () => void; sessionId: string;
}) {
  const { user } = useAuth();
  const [friends, setFriends] = useState<Profile[]>([]);
  const [search, setSearch] = useState("");
  const [loading, setLoading] = useState(true);
  const [inviting, setInviting] = useState<string | null>(null);

  useEffect(() => {
    if (!open || !user) return;
    // Load all approved members as potential invitees
    supabase.from("profiles").select("user_id, name, avatar_url")
      .eq("is_approved", true)
      .neq("user_id", user.id)
      .then(({ data }) => {
        setFriends(data || []);
        setLoading(false);
      });
  }, [open, user]);

  const invite = async (inviteeId: string) => {
    if (!user) return;
    setInviting(inviteeId);
    const { error } = await supabase.from("game_invitations").insert({
      session_id: sessionId, inviter_id: user.id, invitee_id: inviteeId,
    });
    if (error) toast.error("Invite failed");
    else toast.success("Invite sent!");
    setInviting(null);
  };

  const filtered = friends.filter(f =>
    f.name.toLowerCase().includes(search.toLowerCase())
  );

  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent className="max-w-md">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Users className="h-5 w-5" /> Invite Friend
          </DialogTitle>
        </DialogHeader>
        <div className="relative mb-3">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <Input placeholder="Search members..." value={search} onChange={e => setSearch(e.target.value)} className="pl-9" />
        </div>
        <div className="max-h-64 overflow-y-auto space-y-1">
          {loading ? (
            <div className="flex justify-center py-4"><Loader2 className="h-5 w-5 animate-spin text-muted-foreground" /></div>
          ) : filtered.length === 0 ? (
            <p className="text-sm text-muted-foreground text-center py-4">No members found</p>
          ) : filtered.map(f => (
            <div key={f.user_id} className="flex items-center gap-3 p-2 rounded-lg hover:bg-muted/50">
              <Avatar className="h-8 w-8">
                <AvatarImage src={f.avatar_url || undefined} />
                <AvatarFallback className="text-xs">{f.name.charAt(0)}</AvatarFallback>
              </Avatar>
              <span className="text-sm font-medium flex-1">{f.name}</span>
              <Button size="sm" variant="outline" disabled={inviting === f.user_id} onClick={() => invite(f.user_id)}>
                {inviting === f.user_id ? <Loader2 className="h-3 w-3 animate-spin" /> : "Invite"}
              </Button>
            </div>
          ))}
        </div>
      </DialogContent>
    </Dialog>
  );
}

// Game invitations notification component
export function GameInvitations({ onAccept }: { onAccept: (sessionId: string) => void }) {
  const { user } = useAuth();
  const [invitations, setInvitations] = useState<any[]>([]);
  const [profiles, setProfiles] = useState<Record<string, Profile>>({});

  useEffect(() => {
    if (!user) return;
    const load = async () => {
      const { data } = await supabase
        .from("game_invitations")
        .select("*, game_sessions(*)")
        .eq("invitee_id", user.id)
        .eq("status", "pending");
      setInvitations(data || []);

      if (data?.length) {
        const inviterIds = [...new Set(data.map(i => i.inviter_id))];
        const { data: profs } = await supabase
          .from("profiles").select("user_id, name, avatar_url")
          .in("user_id", inviterIds);
        const map: Record<string, Profile> = {};
        profs?.forEach(p => { map[p.user_id] = p; });
        setProfiles(map);
      }
    };
    load();

    const channel = supabase
      .channel("my-invitations")
      .on("postgres_changes", {
        event: "INSERT", schema: "public", table: "game_invitations",
        filter: `invitee_id=eq.${user.id}`,
      }, () => { load(); })
      .subscribe();

    return () => { supabase.removeChannel(channel); };
  }, [user]);

  const accept = async (inv: any) => {
    await supabase.from("game_invitations")
      .update({ status: "accepted" }).eq("id", inv.id);
    setInvitations(prev => prev.filter(i => i.id !== inv.id));
    onAccept(inv.session_id);
  };

  const decline = async (inv: any) => {
    await supabase.from("game_invitations")
      .update({ status: "declined" }).eq("id", inv.id);
    setInvitations(prev => prev.filter(i => i.id !== inv.id));
  };

  if (invitations.length === 0) return null;

  const GAME_NAMES: Record<string, string> = {
    gomoku: "Gomoku", chess: "Chess", go: "Go", billiards: "Billiards",
    shooting: "Shooting", basketball: "Basketball", ludo: "Ludo", doudizhu: "斗地主",
  };

  return (
    <Card className="glass-card border-primary/30">
      <CardContent className="p-4 space-y-3">
        <div className="flex items-center gap-2 text-sm font-semibold text-foreground">
          <Bell className="h-4 w-4 text-primary" /> Game Invitations
        </div>
        {invitations.map(inv => {
          const inviter = profiles[inv.inviter_id];
          const gameType = inv.game_sessions?.game_type || "unknown";
          return (
            <div key={inv.id} className="flex items-center gap-3 p-2 rounded-lg bg-muted/30">
              <Avatar className="h-8 w-8">
                <AvatarImage src={inviter?.avatar_url || undefined} />
                <AvatarFallback className="text-xs">{inviter?.name?.charAt(0) || "?"}</AvatarFallback>
              </Avatar>
              <div className="flex-1 min-w-0">
                <p className="text-sm font-medium truncate">{inviter?.name || "Someone"}</p>
                <p className="text-xs text-muted-foreground">invites you to play {GAME_NAMES[gameType] || gameType}</p>
              </div>
              <div className="flex gap-1.5">
                <Button size="sm" onClick={() => accept(inv)}>Accept</Button>
                <Button size="sm" variant="outline" onClick={() => decline(inv)}>Decline</Button>
              </div>
            </div>
          );
        })}
      </CardContent>
    </Card>
  );
}

// Game lobby component
export function GameLobby({
  gameType,
  gameName,
  onStartLocal,
  onStartOnline,
  initialGameState,
}: {
  gameType: string;
  gameName: string;
  onStartLocal: () => void;
  onStartOnline: (session: GameSession, playerColor: string) => void;
  initialGameState?: any;
}) {
  const { user, isAdmin } = useAuth();
  const { session, playerColor, opponentReady, createSession, joinSession, leaveSession } = useGameMultiplayer(gameType);
  const [inviteOpen, setInviteOpen] = useState(false);
  const [waitingRooms, setWaitingRooms] = useState<any[]>([]);
  const [hostProfiles, setHostProfiles] = useState<Record<string, Profile>>({});

  const loadRooms = useCallback(async () => {
    const { data } = await supabase.from("game_sessions")
      .select("*")
      .eq("game_type", gameType)
      .eq("status", "waiting")
      .order("created_at", { ascending: false })
      .limit(20);
    setWaitingRooms(data || []);
    if (data?.length) {
      const hostIds = [...new Set(data.map(r => r.host_id))];
      const { data: profs } = await supabase
        .from("profiles").select("user_id, name, avatar_url")
        .in("user_id", hostIds);
      const map: Record<string, Profile> = {};
      profs?.forEach(p => { map[p.user_id] = p; });
      setHostProfiles(map);
    }
  }, [gameType]);

  useEffect(() => { loadRooms(); }, [loadRooms]);

  // When opponent joins, start the game
  useEffect(() => {
    if (session && opponentReady && session.status === "playing") {
      onStartOnline(session, playerColor);
    }
  }, [session, opponentReady, playerColor, onStartOnline]);

  const handleCreate = async () => {
    const sess = await createSession(initialGameState);
    if (sess) setInviteOpen(true);
  };

  const handleJoin = async (sessionId: string) => {
    await joinSession(sessionId);
  };

  const handleAdminDelete = async (roomId: string) => {
    await supabase.from("game_players").delete().eq("session_id", roomId);
    await supabase.from("game_invitations").delete().eq("session_id", roomId);
    await supabase.from("game_sessions").delete().eq("id", roomId);
    toast.success("Room deleted");
    loadRooms();
  };

  return (
    <div className="space-y-6 max-w-lg mx-auto">
      <div className="grid grid-cols-2 gap-4">
        <Button onClick={onStartLocal} variant="outline" className="h-24 flex-col gap-2">
          <Users className="h-6 w-6" />
          <span>Local 2P</span>
        </Button>
        <Button onClick={handleCreate} className="h-24 flex-col gap-2">
          <Users className="h-6 w-6" />
          <span>Create Online Room</span>
        </Button>
      </div>

      {session && session.status === "waiting" && (
        <Card className="glass-card">
          <CardContent className="p-4 text-center space-y-3">
            <Loader2 className="h-6 w-6 animate-spin mx-auto text-primary" />
            <p className="text-sm font-medium">Waiting for opponent to join...</p>
            <div className="flex gap-2 justify-center">
              <Button size="sm" variant="outline" onClick={() => setInviteOpen(true)}>Invite Friend</Button>
              <Button size="sm" variant="ghost" onClick={leaveSession}>Cancel</Button>
            </div>
          </CardContent>
        </Card>
      )}

      {waitingRooms.length > 0 && (
        <div>
          <h3 className="text-sm font-semibold text-muted-foreground mb-2">Available Rooms</h3>
          <div className="space-y-2">
            {waitingRooms.map(room => {
              const host = hostProfiles[room.host_id];
              const isMyRoom = room.host_id === user?.id;
              return (
                <div key={room.id} className="flex items-center gap-3 p-3 rounded-lg bg-muted/30">
                  <Avatar className="h-8 w-8">
                    <AvatarImage src={host?.avatar_url || undefined} />
                    <AvatarFallback className="text-xs">{host?.name?.charAt(0) || "?"}</AvatarFallback>
                  </Avatar>
                  <span className="text-sm font-medium flex-1">{host?.name || "Someone"}'s room</span>
                  {!isMyRoom && <Button size="sm" onClick={() => handleJoin(room.id)}>Join</Button>}
                  {isAdmin && (
                    <Button size="sm" variant="destructive" onClick={() => handleAdminDelete(room.id)}>Delete</Button>
                  )}
                </div>
              );
            })}
          </div>
        </div>
      )}

      {session && (
        <InviteFriendDialog open={inviteOpen} onClose={() => setInviteOpen(false)} sessionId={session.id} />
      )}
    </div>
  );
}
