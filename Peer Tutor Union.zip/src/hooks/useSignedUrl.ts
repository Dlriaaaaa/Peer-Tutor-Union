import { useState, useEffect } from "react";
import { supabase } from "@/integrations/supabase/client";
import { extractStoragePath } from "@/lib/attachmentUtils";

/**
 * Hook to resolve a storage path (or legacy URL) to a fresh signed URL.
 * Returns the signed URL or the original value while loading.
 */
export function useSignedUrl(fileUrl: string | null | undefined, bucket = "attachments") {
  const [url, setUrl] = useState<string | null>(fileUrl || null);

  useEffect(() => {
    if (!fileUrl) { setUrl(null); return; }

    let cancelled = false;
    const resolve = async () => {
      const path = extractStoragePath(fileUrl);
      const { data } = await supabase.storage.from(bucket).createSignedUrl(path, 3600);
      if (!cancelled) setUrl(data?.signedUrl || fileUrl);
    };
    resolve();
    return () => { cancelled = true; };
  }, [fileUrl, bucket]);

  return url;
}
