import { useState, useEffect, useCallback } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/contexts/AuthContext";

const LAST_CHAT_VISIT_KEY = "nmba_last_chat_visit";

export function useUnreadMessages() {
  const { user } = useAuth();
  const [hasUnread, setHasUnread] = useState(false);

  const checkUnread = useCallback(async () => {
    if (!user) return;
    const lastVisit = localStorage.getItem(`${LAST_CHAT_VISIT_KEY}_${user.id}`);

    // Get conversations user is a member of
    const { data: memberships } = await supabase
      .from("conversation_members")
      .select("conversation_id")
      .eq("user_id", user.id);

    if (!memberships || memberships.length === 0) return;

    const convIds = memberships.map((m) => m.conversation_id);

    // Check for messages from others newer than last visit
    let query = supabase
      .from("messages")
      .select("id", { count: "exact", head: true })
      .in("conversation_id", convIds)
      .neq("sender_id", user.id);

    if (lastVisit) {
      query = query.gt("created_at", lastVisit);
    }

    const { count } = await query;
    if (count && count > 0) {
      setHasUnread(true);
    }
  }, [user]);

  useEffect(() => {
    if (!user) return;

    checkUnread();

    const channel = supabase
      .channel("unread-messages")
      .on(
        "postgres_changes",
        { event: "INSERT", schema: "public", table: "messages" },
        (payload) => {
          const msg = payload.new as { sender_id: string };
          if (msg.sender_id !== user.id) {
            setHasUnread(true);
          }
        }
      )
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  }, [user, checkUnread]);

  const clearUnread = useCallback(() => {
    setHasUnread(false);
    if (user) {
      localStorage.setItem(`${LAST_CHAT_VISIT_KEY}_${user.id}`, new Date().toISOString());
    }
  }, [user]);

  return { hasUnread, clearUnread };
}
