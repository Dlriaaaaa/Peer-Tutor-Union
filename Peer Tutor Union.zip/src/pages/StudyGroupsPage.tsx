import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Users } from "lucide-react";
import { useSearchParams } from "react-router-dom";
import StudyGroups from "@/components/tutoring/StudyGroups";
import StudyGroupInviteCard from "@/components/tutoring/StudyGroupInviteCard";

export default function StudyGroupsPage() {
  const [searchParams] = useSearchParams();
  const invitedGroupId = searchParams.get("group");

  return (
    <div className="max-w-5xl mx-auto space-y-6">
      <div>
        <h1 className="text-2xl font-bold text-foreground flex items-center gap-2">
          <Users className="h-6 w-6 text-primary" /> Study Groups
        </h1>
        <p className="text-sm text-muted-foreground">Create a group or join an open one.</p>
      </div>

      {invitedGroupId && (
        <Card className="glass-card">
          <CardHeader>
            <CardTitle className="text-base flex items-center gap-2"><Users className="h-4 w-4 text-primary" /> You were invited</CardTitle>
            <CardDescription>Join this study group with one click</CardDescription>
          </CardHeader>
          <CardContent>
            <StudyGroupInviteCard groupId={invitedGroupId} />
          </CardContent>
        </Card>
      )}

      <StudyGroups />
    </div>
  );
}
