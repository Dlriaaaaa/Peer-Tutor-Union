import FunctionCalculator from "@/components/tools/FunctionCalculator";
import { useNavigate } from "react-router-dom";

export default function CalculatorPage() {
  const navigate = useNavigate();
  return <FunctionCalculator onBack={() => navigate(-1)} />;
}
