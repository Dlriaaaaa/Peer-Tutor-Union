import { useState, useEffect, useCallback } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/contexts/AuthContext";
import { toast } from "sonner";
import ChatSidebar from "@/components/chat/ChatSidebar";
import ChatMessages from "@/components/chat/ChatMessages";
import ChatGroupInfo from "@/components/chat/ChatGroupInfo";
import { Conversation, Message, ProfileMap, Member } from "@/components/chat/types";
import { canChat } from "@/lib/roleUtils";
import RestrictedAccess from "@/components/RestrictedAccess";

const BOT_USER_ID = "00000000-0000-0000-0000-00000000000b";

export default function Chat() {
  const { user, isAdmin, displayRole } = useAuth();
  const allowChat = canChat(displayRole);
  const [conversations, setConversations] = useState<Conversation[]>([]);
  const [activeConv, setActiveConv] = useState<string | null>(null);
  const [messages, setMessages] = useState<Message[]>([]);
  const [newMsg, setNewMsg] = useState("");
  const [profiles, setProfiles] = useState<ProfileMap>({});
  const [convMembers, setConvMembers] = useState<Member[]>([]);
  const [lastMessages, setLastMessages] = useState<Record<string, Message>>({});
  const [loading, setLoading] = useState(true);
  const [showGroupInfo, setShowGroupInfo] = useState(false);
  const [friendUsers, setFriendUsers] = useState<{ user_id: string; name: string }[]>([]);
  const [pinnedIds, setPinnedIds] = useState<Set<string>>(new Set());
  const [unreadCounts, setUnreadCounts] = useState<Record<string, number>>({});
  const [botPersonas, setBotPersonas] = useState<{ id: string; name: string; avatar_url: string | null }[]>([]);
  const [botPersonaMap, setBotPersonaMap] = useState<Record<string, { name: string; avatar_url: string | null }>>({});
  const [convBotIds, setConvBotIds] = useState<Record<string, string[]>>({});

  const fetchConversations = useCallback(async () => {
    if (!user) return;

    // Fetch all in parallel for speed
    const [membersRes, profsRes, pinsRes] = await Promise.all([
      supabase.from("conversation_members").select("conversation_id, user_id"),
      supabase.from("profiles").select("user_id, name, avatar_url"),
      supabase.from("pinned_conversations").select("conversation_id").eq("user_id", user.id),
    ]);

    const memberRows = membersRes.data || [];
    setConvMembers(memberRows);

    const map: ProfileMap = {};
    (profsRes.data || []).forEach((p) => { map[p.user_id] = { name: p.name, avatar_url: p.avatar_url }; });
    // Default bot profile - will be overridden per-conversation
    map[BOT_USER_ID] = { name: "PTC Bot", avatar_url: null };
    setProfiles(map);

    // Fetch persona data to update bot profiles per conversation
    const { data: personaData } = await supabase.from("bot_personas").select("id, name, avatar_url");
    const personaMap: Record<string, { name: string; avatar_url: string | null }> = {};
    (personaData as any[] || []).forEach((p: any) => { personaMap[p.id] = { name: p.name, avatar_url: p.avatar_url }; });
    setBotPersonaMap(personaMap);

    // Fetch conversation_bots for all conversations
    const { data: convBotsData } = await supabase.from("conversation_bots").select("conversation_id, bot_persona_id");
    const cbMap: Record<string, string[]> = {};
    (convBotsData || []).forEach((cb: any) => {
      if (!cbMap[cb.conversation_id]) cbMap[cb.conversation_id] = [];
      cbMap[cb.conversation_id].push(cb.bot_persona_id);
    });
    setConvBotIds(cbMap);

    setPinnedIds(new Set((pinsRes.data || []).map((p) => p.conversation_id)));

    const myConvIds = memberRows.filter((m) => m.user_id === user.id).map((m) => m.conversation_id);

    let convs: Conversation[] = [];
    if (isAdmin) {
      const { data } = await supabase.from("conversations").select("*").order("updated_at", { ascending: false });
      convs = data || [];
    } else if (myConvIds.length > 0) {
      const { data } = await supabase.from("conversations").select("*").in("id", myConvIds).order("updated_at", { ascending: false });
      convs = data || [];
    }
    setConversations(convs);

    // Batch fetch last messages - single query with distinct on
    if (convs.length > 0) {
      const convIds = convs.map(c => c.id);
      // Fetch last message per conversation efficiently
      const { data: allMsgs } = await supabase
        .from("messages")
        .select("*")
        .in("conversation_id", convIds)
        .order("created_at", { ascending: false });
      
      const msgMap: Record<string, Message> = {};
      if (allMsgs) {
        for (const msg of allMsgs) {
          if (!msgMap[msg.conversation_id]) {
            msgMap[msg.conversation_id] = msg;
          }
        }
      }
      setLastMessages(msgMap);
    }

    // Compute per-conversation unread counts
    if (convs.length > 0) {
      const LAST_READ_KEY = "nmba_conv_last_read_";
      const counts: Record<string, number> = {};
      const convIds = convs.map(c => c.id);
      const { data: unreadMsgs } = await supabase
        .from("messages")
        .select("conversation_id, created_at")
        .in("conversation_id", convIds)
        .neq("sender_id", user.id)
        .order("created_at", { ascending: false });

      if (unreadMsgs) {
        for (const msg of unreadMsgs) {
          const lastRead = localStorage.getItem(`${LAST_READ_KEY}${user.id}_${msg.conversation_id}`);
          if (!lastRead || new Date(msg.created_at) > new Date(lastRead)) {
            counts[msg.conversation_id] = (counts[msg.conversation_id] || 0) + 1;
          }
        }
      }
      setUnreadCounts(counts);
    }

    setLoading(false);
  }, [user, isAdmin]);

  useEffect(() => { if (user) fetchConversations(); }, [user, fetchConversations]);

  // Fetch bot personas
  useEffect(() => {
    supabase.from("bot_personas").select("id, name, avatar_url").order("created_at").then(({ data }) => {
      setBotPersonas((data as any[]) || []);
    });
  }, []);

  // Mark conversation as read when switching to it
  useEffect(() => {
    if (!activeConv || !user) return;
    const LAST_READ_KEY = "nmba_conv_last_read_";
    localStorage.setItem(`${LAST_READ_KEY}${user.id}_${activeConv}`, new Date().toISOString());
    setUnreadCounts(prev => { const n = { ...prev }; delete n[activeConv]; return n; });

    const fetchMessages = async () => {
      const { data } = await supabase.from("messages").select("*").eq("conversation_id", activeConv).order("created_at");
      setMessages(data || []);
    };
    fetchMessages();

    const channel = supabase
      .channel(`messages-${activeConv}`)
      .on("postgres_changes", { event: "INSERT", schema: "public", table: "messages", filter: `conversation_id=eq.${activeConv}` },
        (payload) => {
          const newMessage = payload.new as Message;
          // Deduplicate: skip if this message already exists (from optimistic insert)
          setMessages((prev) => {
            if (prev.some((m) => m.id === newMessage.id)) return prev;
            return [...prev, newMessage];
          });
          setLastMessages((prev) => ({ ...prev, [newMessage.conversation_id]: newMessage }));
          localStorage.setItem(`${LAST_READ_KEY}${user.id}_${activeConv}`, new Date().toISOString());
        }
      )
      .on("postgres_changes", { event: "DELETE", schema: "public", table: "messages", filter: `conversation_id=eq.${activeConv}` },
        (payload) => {
          const deleted = payload.old as { id: string };
          setMessages((prev) => prev.filter((m) => m.id !== deleted.id));
        }
      )
      .subscribe();

    // Listen for messages in OTHER conversations to update unread counts
    const globalChannel = supabase
      .channel(`unread-${activeConv}`)
      .on("postgres_changes", { event: "INSERT", schema: "public", table: "messages" },
        (payload) => {
          const msg = payload.new as Message;
          if (msg.sender_id !== user.id && msg.conversation_id !== activeConv) {
            setUnreadCounts(prev => ({ ...prev, [msg.conversation_id]: (prev[msg.conversation_id] || 0) + 1 }));
          }
        }
      )
      .subscribe();

    return () => { supabase.removeChannel(channel); supabase.removeChannel(globalChannel); };
  }, [activeConv]);

  const canSendInActiveConv = () => {
    if (!activeConv || !user) return false;
    const isMember = convMembers.some((m) => m.conversation_id === activeConv && m.user_id === user.id);
    if (isAdmin && !isMember) return false;
    return isMember;
  };


  const sendMessage = async (content?: string) => {
    const msgContent = content || newMsg.trim();
    if (!msgContent || !activeConv || !user || !canSendInActiveConv()) return;
    if (!content) setNewMsg("");

    // Optimistic: add message to UI immediately
    const optimisticMsg: Message = {
      id: crypto.randomUUID(),
      conversation_id: activeConv,
      sender_id: user.id,
      content: msgContent,
      created_at: new Date().toISOString(),
      bot_persona_id: null,
    };
    setMessages((prev) => [...prev, optimisticMsg]);
    setLastMessages((prev) => ({ ...prev, [activeConv]: optimisticMsg }));

    const { error, data } = await supabase.from("messages").insert({ conversation_id: activeConv, sender_id: user.id, content: msgContent }).select().single();
    if (error) {
      toast.error(error.message || "Failed to send");
      // Rollback optimistic message
      setMessages((prev) => prev.filter((m) => m.id !== optimisticMsg.id));
      return;
    }
    // Replace optimistic message with real one (to get correct id)
    if (data) {
      setMessages((prev) => prev.map((m) => m.id === optimisticMsg.id ? data : m));
    }
    await supabase.from("conversations").update({ updated_at: new Date().toISOString() }).eq("id", activeConv);
  };

  const recallMessage = async (messageId: string) => {
    if (!user) return;
    const { error } = await supabase.from("messages").delete().eq("id", messageId).eq("sender_id", user.id);
    if (error) { toast.error("Failed to recall"); return; }
    setMessages((prev) => prev.filter((m) => m.id !== messageId));
    toast.success("Message recalled");
  };

  const dissolveGroup = async () => {
    if (!activeConv || !user) return;
    // Delete members, then messages, then conversation
    await supabase.from("conversation_members").delete().eq("conversation_id", activeConv);
    await supabase.from("messages").delete().eq("conversation_id", activeConv);
    await supabase.from("pinned_conversations").delete().eq("conversation_id", activeConv);
    const { error } = await supabase.from("conversations").delete().eq("id", activeConv);
    if (error) { toast.error("Failed to dissolve group"); return; }
    setActiveConv(null);
    setShowGroupInfo(false);
    toast.success("Group dissolved");
    fetchConversations();
  };

  const togglePin = async (convId: string) => {
    if (!user) return;
    if (pinnedIds.has(convId)) {
      await supabase.from("pinned_conversations").delete().eq("user_id", user.id).eq("conversation_id", convId);
      setPinnedIds(prev => { const n = new Set(prev); n.delete(convId); return n; });
      toast.success("Unpinned");
    } else {
      await supabase.from("pinned_conversations").insert({ user_id: user.id, conversation_id: convId });
      setPinnedIds(prev => new Set(prev).add(convId));
      toast.success("Pinned");
    }
  };

  const fetchFriends = async () => {
    if (!user) return;
    const { data: friendships } = await supabase.from("friendships").select("*").eq("status", "accepted");
    if (!friendships) { setFriendUsers([]); return; }
    const friendIds = friendships.map((f) => f.requester_id === user.id ? f.addressee_id : f.requester_id);
    const { data: profs } = await supabase.from("profiles").select("user_id, name").in("user_id", friendIds.length > 0 ? friendIds : [""]).order("name");
    setFriendUsers(profs || []);
  };

  const createGroupChat = async (groupName: string, selectedUsers: string[]) => {
    if (!groupName.trim() || selectedUsers.length === 0 || !user) return;
    const { data: conv, error } = await supabase.from("conversations").insert({ name: groupName, is_group: true, created_by: user.id }).select().single();
    if (error || !conv) { toast.error("Failed to create"); return; }
    await supabase.from("conversation_members").insert({ conversation_id: conv.id, user_id: user.id });
    const otherMembers = selectedUsers.map((uid) => ({ conversation_id: conv.id, user_id: uid }));
    if (otherMembers.length > 0) await supabase.from("conversation_members").insert(otherMembers);
    toast.success("Group created");
    await fetchConversations();
    setActiveConv(conv.id);
  };

  const startDM = async (otherUserId: string) => {
    if (!user) return;
    const myConvIds = convMembers.filter((m) => m.user_id === user.id).map((m) => m.conversation_id);
    const otherConvIds = convMembers.filter((m) => m.user_id === otherUserId).map((m) => m.conversation_id);
    const common = myConvIds.filter((id) => otherConvIds.includes(id));
    for (const cid of common) {
      const conv = conversations.find((c) => c.id === cid && !c.is_group);
      if (conv) { setActiveConv(conv.id); return; }
    }
    const { data: conv, error } = await supabase.from("conversations").insert({ is_group: false, created_by: user.id }).select().single();
    if (error || !conv) { toast.error("Failed to create"); return; }
    await supabase.from("conversation_members").insert({ conversation_id: conv.id, user_id: user.id });
    await supabase.from("conversation_members").insert({ conversation_id: conv.id, user_id: otherUserId });
    await fetchConversations();
    setActiveConv(conv.id);
  };

  const addBot = async (convId: string, personaId: string) => {
    const existing = convBotIds[convId] || [];
    if (existing.includes(personaId)) { toast.info("该智能体已在群中"); return; }
    const { error } = await supabase.from("conversation_bots").insert({ conversation_id: convId, bot_persona_id: personaId });
    if (error) { toast.error("添加失败"); return; }
    setConvBotIds(prev => ({ ...prev, [convId]: [...(prev[convId] || []), personaId] }));
    toast.success("智能体已加入");
    // Send greeting
    try {
      await fetch(`${import.meta.env.VITE_SUPABASE_URL}/functions/v1/nanmo-ai-chat`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${import.meta.env.VITE_SUPABASE_PUBLISHABLE_KEY}`,
        },
        body: JSON.stringify({ conversation_id: convId, greeting: true, bot_persona_id: personaId }),
      });
    } catch (e) {
      console.error("Bot greeting failed:", e);
    }
  };

  const removeBot = async (convId: string, personaId: string) => {
    const { error } = await supabase.from("conversation_bots").delete()
      .eq("conversation_id", convId).eq("bot_persona_id", personaId);
    if (error) { toast.error("移除失败"); return; }
    setConvBotIds(prev => ({ ...prev, [convId]: (prev[convId] || []).filter(id => id !== personaId) }));
    toast.success("智能体已移除");
  };

  if (!allowChat) return <RestrictedAccess message="Chat is currently disabled for your account. Please contact an administrator." />;
  if (loading) return <div className="flex items-center justify-center h-full text-muted-foreground">Loading...</div>;

  const activeConversation = conversations.find((c) => c.id === activeConv) || null;
  const isMonitoring = !!activeConv && !canSendInActiveConv() && isAdmin;
  const memberCount = activeConv ? convMembers.filter((m) => m.conversation_id === activeConv).length : 0;

  // Get members of active conversation for @mention
  const activeMembers = activeConv
    ? convMembers.filter((m) => m.conversation_id === activeConv && m.user_id !== user!.id)
        .map((m) => ({ user_id: m.user_id, name: profiles[m.user_id]?.name || "Unknown" }))
    : [];

  const getConvDisplayName = (conv: Conversation) => {
    if (conv.is_group && conv.name) return conv.name;
    const members = convMembers.filter((m) => m.conversation_id === conv.id && m.user_id !== user!.id);
    return members.map((m) => profiles[m.user_id]?.name || "Unknown").join(", ") || "Chat";
  };

  // Sort: pinned first, then by updated_at
  const sortedConversations = [...conversations].sort((a, b) => {
    const aPinned = pinnedIds.has(a.id);
    const bPinned = pinnedIds.has(b.id);
    if (aPinned && !bPinned) return -1;
    if (!aPinned && bPinned) return 1;
    return new Date(b.updated_at).getTime() - new Date(a.updated_at).getTime();
  });

  const activeConvBots = activeConv ? (convBotIds[activeConv] || []) : [];
  const activeConvBotPersonas = activeConvBots.map(id => botPersonaMap[id]).filter(Boolean);

  return (
    <div className="flex h-[calc(100vh-4rem)] bg-muted/20 rounded-lg overflow-hidden border border-border">
      <ChatSidebar
        conversations={sortedConversations}
        activeConv={activeConv}
        setActiveConv={setActiveConv}
        profiles={profiles}
        convMembers={convMembers}
        lastMessages={lastMessages}
        userId={user!.id}
        isAdmin={isAdmin}
        friendUsers={friendUsers}
        onCreateGroup={createGroupChat}
        onStartDM={startDM}
        onFetchFriends={fetchFriends}
        pinnedIds={pinnedIds}
        onTogglePin={togglePin}
        unreadCounts={unreadCounts}
      />
      <ChatMessages
        conversation={activeConversation}
        messages={messages}
        profiles={profiles}
        userId={user!.id}
        isMonitoring={isMonitoring}
        newMsg={newMsg}
        setNewMsg={setNewMsg}
        onSend={sendMessage}
        onRecallMessage={recallMessage}
        displayName={activeConversation ? getConvDisplayName(activeConversation) : ""}
        memberCount={memberCount}
        isGroup={activeConversation?.is_group}
        onToggleInfo={() => setShowGroupInfo((p) => !p)}
        activeMembers={activeMembers}
        convBotPersonas={activeConvBotPersonas}
        onAddBot={activeConv ? (personaId: string) => addBot(activeConv, personaId) : undefined}
        botPersonas={botPersonas}
        botPersonaMap={botPersonaMap}
        convBotIds={activeConvBots}
      />
      {showGroupInfo && activeConversation && (
        <ChatGroupInfo
          conversation={activeConversation}
          profiles={profiles}
          convMembers={convMembers}
          userId={user!.id}
          onClose={() => setShowGroupInfo(false)}
          onRefresh={fetchConversations}
          onDissolveGroup={activeConversation.is_group ? dissolveGroup : undefined}
          friendUsers={friendUsers}
          onFetchFriends={fetchFriends}
          botPersonas={botPersonas}
          convBotIds={activeConvBots}
          botPersonaMap={botPersonaMap}
          onAddBot={(pid: string) => addBot(activeConv!, pid)}
          onRemoveBot={(pid: string) => removeBot(activeConv!, pid)}
          isAdmin={isAdmin}
        />
      )}
    </div>
  );
}
