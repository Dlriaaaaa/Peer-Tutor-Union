import { Navigate, Outlet, useLocation } from "react-router-dom";
import { useAuth } from "@/contexts/AuthContext";

const TEACHER_ALLOWED = ["/admin/tutoring", "/admin/grades", "/admin/resources", "/admin/quizzes", "/admin/question-bank", "/admin/members"];

export default function AdminLayout() {
  const { isAdmin, loading, displayRole } = useAuth();
  const location = useLocation();
  const hasAdminAccess = isAdmin || ["President", "VicePresident", "Teacher", "GeneralSecretary"].includes(displayRole);
  if (loading) return <div className="min-h-screen flex items-center justify-center text-muted-foreground">Loading...</div>;
  if (!hasAdminAccess) return <Navigate to="/schedule" replace />;
  if (displayRole === "Teacher" && !TEACHER_ALLOWED.some((p) => location.pathname.startsWith(p))) {
    return <Navigate to="/admin/tutoring" replace />;
  }
  return (
    <div className="max-w-5xl mx-auto">
      <Outlet />
    </div>
  );
}
