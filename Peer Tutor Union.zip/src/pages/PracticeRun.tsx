import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { useNavigate, useParams } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { toast } from "sonner";
import { Flag, ChevronLeft, ChevronRight, Pause, Play, Timer, CheckCircle2, XCircle } from "lucide-react";
import { cn } from "@/lib/utils";
import { useAuth } from "@/contexts/AuthContext";
import MathText from "@/components/questions/MathText";
import AttachmentPreview from "@/components/questions/AttachmentPreview";
import StimulusPanel from "@/components/questions/StimulusPanel";
import DifficultyStars from "@/components/questions/DifficultyStars";
import FrqAnswerEditor from "@/components/questions/FrqAnswerEditor";
import { fetchParts, Question, QuestionPart, questionOptions, questionPoints } from "@/lib/questionBank";

type AnswerRow = {
  id?: string;
  question_id: string;
  part_id: string | null;
  selected_option: string | null;
  text_answer: string | null;
  is_correct: boolean | null;
  flagged: boolean;
  points_awarded: number | null;
  feedback: string | null;
  time_spent_seconds?: number | null;
};

const fmt = (s: number) => {
  const m = Math.max(0, Math.floor(s / 60));
  const sec = Math.max(0, s % 60);
  return `${String(m).padStart(2, "0")}:${String(sec).padStart(2, "0")}`;
};

export default function PracticeRun() {
  const { sessionId } = useParams();
  const navigate = useNavigate();
  const { user } = useAuth();

  const [session, setSession] = useState<any>(null);
  const [questions, setQuestions] = useState<Question[]>([]);
  const [parts, setParts] = useState<Record<string, QuestionPart[]>>({});
  const [answers, setAnswers] = useState<Record<string, AnswerRow>>({});
  const [idx, setIdx] = useState(0);
  const [revealed, setRevealed] = useState<Record<string, boolean>>({});
  const [paused, setPaused] = useState(false);
  const [remaining, setRemaining] = useState<number | null>(null);
  const [loading, setLoading] = useState(true);
  const [grading, setGrading] = useState(false);
  const submittingRef = useRef(false);
  const spentRef = useRef<Record<string, number>>({});

  const key = (qid: string, pid: string | null) => `${qid}|${pid || ""}`;

  useEffect(() => {
    const load = async () => {
      const { data: s } = await supabase.from("practice_sessions").select("*").eq("id", sessionId).maybeSingle();
      if (!s) { toast.error("Session not found"); navigate("/practice"); return; }
      setSession(s);
      const { data: qs } = await supabase.from("questions").select("*").in("id", s.question_ids);
      const ordered = (s.question_ids as string[])
        .map((id) => (qs || []).find((q: any) => q.id === id))
        .filter(Boolean) as Question[];
      setQuestions(ordered);
      setParts(await fetchParts(ordered.map((q) => q.id)));
      const { data: ans } = await supabase.from("practice_answers").select("*").eq("session_id", s.id);
      const map: Record<string, AnswerRow> = {};
      (ans || []).forEach((a: any) => { map[key(a.question_id, a.part_id)] = a; });
      setAnswers(map);
      setLoading(false);
    };
    load();
    // eslint-disable-next-line
  }, [sessionId]);

  const sections = useMemo(() => {
    const mcq = questions.filter((q) => q.question_type === "mcq");
    const frq = questions.filter((q) => q.question_type === "frq");
    const out: { key: string; name: string; questions: Question[] }[] = [];
    if (mcq.length) out.push({ key: "mcq", name: "Section I: Multiple Choice", questions: mcq });
    if (frq.length) out.push({ key: "frq", name: "Section II: Free Response", questions: frq });
    return out;
  }, [questions]);

  const submitted: string[] = session?.sections_submitted || [];
  const currentSection = useMemo(
    () => sections.find((s) => !submitted.includes(s.key)) || sections[sections.length - 1],
    [sections, submitted]
  );
  const isCompleted = session?.status === "completed";
  const activeQuestions = isCompleted ? questions : currentSection?.questions || [];
  const q = activeQuestions[Math.min(idx, Math.max(0, activeQuestions.length - 1))];

  // Section timer
  useEffect(() => {
    if (!session || session.mode !== "timed" || isCompleted || !currentSection) { setRemaining(null); return; }
    const total = Number(session.section_seconds?.[currentSection.key] || 0);
    if (!total) { setRemaining(null); return; }
    const storeKey = `practice-deadline-${session.id}-${currentSection.key}`;
    let deadline = Number(localStorage.getItem(storeKey) || 0);
    if (!deadline) {
      deadline = Date.now() + total * 1000;
      localStorage.setItem(storeKey, String(deadline));
    }
    const tick = () => setRemaining(Math.round((deadline - Date.now()) / 1000));
    tick();
    const t = setInterval(tick, 1000);
    return () => clearInterval(t);
  }, [session, currentSection, isCompleted]);

  // Per-question time tracking: accumulate seconds and store them on the answer row
  useEffect(() => {
    if (isCompleted || !q || !session) return;
    const qid = q.id;
    const startedAt = Date.now();
    return () => {
      const elapsed = Math.round((Date.now() - startedAt) / 1000);
      if (elapsed <= 0) return;
      spentRef.current[qid] = (spentRef.current[qid] || 0) + elapsed;
      void supabase
        .from("practice_answers")
        .update({ time_spent_seconds: spentRef.current[qid] })
        .eq("session_id", session.id)
        .eq("question_id", qid)
        .is("part_id", null);
    };
    // eslint-disable-next-line
  }, [q?.id, isCompleted, session?.id]);




  const saveAnswer = useCallback(async (qid: string, pid: string | null, patch: Partial<AnswerRow>) => {
    if (!user || !session) return;
    const k = key(qid, pid);
    const existing = answers[k];
    const question = questions.find((x) => x.id === qid);
    let is_correct = existing?.is_correct ?? null;
    if (question?.question_type === "mcq" && patch.selected_option !== undefined) {
      is_correct = patch.selected_option === question.correct_option;
    }
    const row: AnswerRow = {
      ...(existing || { question_id: qid, part_id: pid, selected_option: null, text_answer: null, is_correct: null, flagged: false, points_awarded: null, feedback: null }),
      ...patch,
      is_correct,
    };
    setAnswers((prev) => ({ ...prev, [k]: row }));
    if (existing?.id) {
      await supabase.from("practice_answers").update({
        selected_option: row.selected_option, text_answer: row.text_answer, is_correct: row.is_correct, flagged: row.flagged,
      }).eq("id", existing.id);
    } else {
      const { data } = await supabase.from("practice_answers").insert({
        session_id: session.id, question_id: qid, part_id: pid, user_id: user.id,
        selected_option: row.selected_option, text_answer: row.text_answer, is_correct: row.is_correct, flagged: row.flagged,
      }).select("id").single();
      if (data) setAnswers((prev) => ({ ...prev, [k]: { ...row, id: data.id } }));
    }
  }, [answers, questions, session, user]);

  const finishSession = useCallback(async () => {
    if (!session) return;
    let score = 0, total = 0;
    const wrongIds: string[] = [];
    const correctIds: string[] = [];
    questions.forEach((qq) => {
      const pts = questionPoints(qq, parts[qq.id] || []);
      total += pts;
      if (qq.question_type !== "mcq") return;
      const a = answers[key(qq.id, null)];
      if (a?.is_correct) { score += pts; correctIds.push(qq.id); }
      else if (a?.selected_option) wrongIds.push(qq.id);
    });
    await supabase.from("practice_sessions").update({
      status: "completed", score, total_points: total, completed_at: new Date().toISOString(),
      sections_submitted: sections.map((s) => s.key),
    }).eq("id", session.id);

    // Wrong-question book: add new misses, offer to clear questions answered correctly on a redo
    if (user) {
      if (wrongIds.length) {
        const { data: known } = await supabase
          .from("wrong_questions").select("question_id").eq("user_id", user.id).in("question_id", wrongIds);
        const existing = new Set((known || []).map((r: any) => r.question_id));
        const toAdd = wrongIds.filter((id) => !existing.has(id));
        if (toAdd.length) {
          await supabase.from("wrong_questions").insert(toAdd.map((question_id) => ({ user_id: user.id, question_id })));
          toast.info(`${toAdd.length} question${toAdd.length === 1 ? "" : "s"} added to your wrong-question book`);
        }
      }
      if (correctIds.length) {
        const { data: known } = await supabase
          .from("wrong_questions").select("question_id").eq("user_id", user.id).in("question_id", correctIds);
        const fixed = (known || []).map((r: any) => r.question_id);
        if (fixed.length) {
          toast("You got some wrong-book questions right", {
            description: `Remove ${fixed.length} question${fixed.length === 1 ? "" : "s"} from your wrong-question book?`,
            action: {
              label: "Remove",
              onClick: () => {
                supabase.from("wrong_questions").delete().eq("user_id", user.id).in("question_id", fixed)
                  .then(() => toast.success("Wrong-question book updated"));
              },
            },
          });
        }
      }
    }

    setSession((s: any) => ({ ...s, status: "completed", score, total_points: total, sections_submitted: sections.map((x) => x.key) }));

    // AI grading for free response, based on the teacher's reference answer
    const hasFrq = questions.some((qq) => qq.question_type === "frq");
    if (hasFrq) {
      setGrading(true);
      try {
        const { data, error } = await supabase.functions.invoke("grade-frq", { body: { sessionId: session.id } });
        if (error) throw error;
        if (data?.graded) {
          const { data: ans } = await supabase.from("practice_answers").select("*").eq("session_id", session.id);
          const map: Record<string, AnswerRow> = {};
          (ans || []).forEach((a: any) => { map[key(a.question_id, a.part_id)] = a; });
          setAnswers(map);
          setSession((s: any) => ({ ...s, score: data.score ?? s.score }));
          toast.success("Free response graded by AI");
        }
      } catch (e: any) {
        toast.error(e?.message || "AI grading is unavailable; a teacher can grade manually");
      } finally {
        setGrading(false);
      }
    }
  }, [session, questions, parts, answers, sections, user]);

  const submitSection = useCallback(async () => {
    if (!session || !currentSection || submittingRef.current) return;
    submittingRef.current = true;
    const next = [...submitted, currentSection.key];
    localStorage.removeItem(`practice-deadline-${session.id}-${currentSection.key}`);
    await supabase.from("practice_sessions").update({ sections_submitted: next }).eq("id", session.id);
    setSession((s: any) => ({ ...s, sections_submitted: next }));
    setIdx(0);
    if (next.length >= sections.length) await finishSession();
    submittingRef.current = false;
  }, [session, currentSection, submitted, sections, finishSession]);

  // Auto-submit on timeout
  useEffect(() => {
    if (remaining !== null && remaining <= 0 && !isCompleted) {
      toast.info("Time is up — section submitted automatically");
      submitSection();
    }
    // eslint-disable-next-line
  }, [remaining]);

  if (loading || !session) return <div className="p-8 text-muted-foreground">Loading…</div>;

  /* ---------------- Result screen ---------------- */
  if (isCompleted) {
    return (
      <div className="max-w-4xl mx-auto space-y-6">
        <div className="glass-card rounded-2xl border p-6 text-center">
          <h1 className="text-2xl font-bold">{session.title} — Results</h1>
          <p className="mt-2 text-4xl font-bold text-primary">{session.score ?? 0} / {session.total_points ?? 0}</p>
          <p className="text-sm text-muted-foreground mt-1">
            {grading
              ? "AI is grading your free response against the reference answer…"
              : "Multiple choice is auto-scored. Free response is graded by AI against the reference answer, and a teacher can still adjust it."}
          </p>
        </div>

        {sections.map((sec) => {
          const correct = sec.questions.filter((qq) => answers[key(qq.id, null)]?.is_correct).length;
          return (
            <div key={sec.key} className="space-y-3">
              <div className="flex items-center justify-between">
                <h2 className="font-semibold">{sec.name}</h2>
                {sec.key === "mcq" && <Badge variant="secondary">{correct} correct / {sec.questions.length - correct} incorrect</Badge>}
              </div>
              {sec.questions.map((qq, i) => {
                const a = answers[key(qq.id, null)];
                return (
                  <div key={qq.id} className="rounded-xl border bg-muted/10 p-4 space-y-2">
                    <div className="flex items-center gap-2">
                      <span className="text-sm font-semibold">Q{i + 1}</span>
                      <DifficultyStars level={qq.difficulty} />
                      {qq.question_type === "mcq" && (a?.is_correct
                        ? <CheckCircle2 className="h-4 w-4 text-emerald-500" />
                        : <XCircle className="h-4 w-4 text-destructive" />)}
                    </div>
                    <MathText text={qq.stem} />
                    {qq.question_type === "mcq" ? (
                      <p className="text-sm text-muted-foreground">
                        Your answer: <strong>{a?.selected_option || "—"}</strong> · Correct: <strong>{qq.correct_option}</strong>
                      </p>
                    ) : (
                      <div className="space-y-2">
                        {(parts[qq.id] || [{ id: "", label: "", prompt: "", points: qq.max_points, sample_answer: null, sort_order: 0, question_id: qq.id } as QuestionPart]).map((p) => {
                          const pa = answers[key(qq.id, p.id || null)];
                          return (
                            <div key={p.id || "single"} className="rounded-lg border bg-background/50 p-2 text-sm">
                              {p.label && <p className="font-medium">{p.label}</p>}
                              <div className="prose prose-sm max-w-none" dangerouslySetInnerHTML={{ __html: pa?.text_answer || "<em>No response</em>" }} />
                              <p className="mt-1 text-xs text-muted-foreground">
                                Score: {pa?.points_awarded ?? "pending"} / {p.points}
                                {pa?.feedback ? ` · Feedback: ${pa.feedback}` : ""}
                              </p>
                            </div>
                          );
                        })}
                      </div>
                    )}
                    {(qq.explanation || qq.answer_file_url) && (
                      <div className="rounded-lg border border-primary/30 bg-primary/5 p-2 space-y-2">
                        <p className="text-xs font-semibold uppercase text-primary mb-1">Explanation</p>
                        <MathText text={qq.explanation} />
                        <AttachmentPreview path={qq.answer_file_url} name={qq.answer_file_name} />
                      </div>
                    )}
                  </div>
                );
              })}
            </div>
          );
        })}
        <Button variant="outline" onClick={() => navigate("/practice")}>Back to Practice</Button>
      </div>
    );
  }

  /* ---------------- Exam screen ---------------- */
  if (!q) return <div className="p-8 text-muted-foreground">No questions in this section.</div>;

  const answeredCount = activeQuestions.filter((qq) => {
    const ps = parts[qq.id] || [];
    if (qq.question_type === "frq" && ps.length) return ps.some((p) => answers[key(qq.id, p.id)]?.text_answer);
    return answers[key(qq.id, null)]?.selected_option || answers[key(qq.id, null)]?.text_answer;
  }).length;
  const current = answers[key(q.id, null)];
  const qParts = parts[q.id] || [];
  const isUntimed = session.mode === "untimed";
  const showAnswer = isUntimed && revealed[q.id];

  return (
    <div className="max-w-6xl mx-auto space-y-4">
      {/* Top bar */}
      <div className="glass-card sticky top-2 z-10 flex flex-wrap items-center gap-3 rounded-2xl border px-4 py-3">
        <div className="min-w-0">
          <p className="font-semibold truncate">{session.title}</p>
          <p className="text-xs text-muted-foreground">{currentSection?.name}</p>
        </div>
        <Badge variant="outline" className="ml-auto">Question {idx + 1} / {activeQuestions.length}</Badge>
        {isUntimed ? (
          <Button size="sm" variant="outline" className="gap-2" onClick={() => setPaused((p) => !p)}>
            {paused ? <><Play className="h-4 w-4" /> Resume</> : <><Pause className="h-4 w-4" /> Pause</>}
          </Button>
        ) : (
          remaining !== null && (
            <div className={cn("flex items-center gap-2 rounded-lg border px-3 py-1 font-mono text-sm",
              remaining <= 60 ? "border-destructive text-destructive" : "")}>
              <Timer className="h-4 w-4" /> {fmt(remaining)}
            </div>
          )
        )}
      </div>
      <Progress value={(answeredCount / activeQuestions.length) * 100} className="h-2" />

      {paused ? (
        <div className="glass-card rounded-2xl border p-12 text-center">
          <p className="text-lg font-medium">Practice paused</p>
          <Button className="mt-4 gap-2" onClick={() => setPaused(false)}><Play className="h-4 w-4" /> Resume</Button>
        </div>
      ) : (
        <div className="grid gap-4 lg:grid-cols-[1fr_260px]">
          <div className="space-y-4">
            <div className={cn("grid gap-4", (q.stimulus_text || q.stimulus_file_url) ? "lg:grid-cols-2" : "")}>
              {(q.stimulus_text || q.stimulus_file_url) && (
                <StimulusPanel text={q.stimulus_text} filePath={q.stimulus_file_url} fileName={q.stimulus_file_name} className="max-h-[70vh]" />
              )}
              <div className="glass-card rounded-xl border p-4 space-y-4">
                <div className="flex items-center gap-2">
                  <Badge variant="outline" className="text-[10px]">{q.question_type.toUpperCase()}</Badge>
                  <DifficultyStars level={q.difficulty} />
                  <Button size="sm" variant={current?.flagged ? "secondary" : "ghost"} className="ml-auto gap-1"
                    onClick={() => saveAnswer(q.id, null, { flagged: !current?.flagged })}>
                    <Flag className={cn("h-3.5 w-3.5", current?.flagged && "fill-amber-400 text-amber-500")} /> Flag for review
                  </Button>
                </div>
                <MathText text={q.stem} />

                {q.question_type === "mcq" ? (
                  <div className="space-y-2">
                    {questionOptions(q).map(({ letter, text }) => {
                      const chosen = current?.selected_option === letter;
                      const correctK = showAnswer && q.correct_option === letter;
                      return (
                        <button key={letter} onClick={() => saveAnswer(q.id, null, { selected_option: letter })}
                          className={cn("w-full text-left rounded-xl border px-3 py-2 text-sm transition-colors",
                            chosen ? "border-primary bg-primary/10" : "hover:bg-accent",
                            correctK && "border-emerald-500 bg-emerald-500/10")}>
                          <strong className="mr-2">{letter}.</strong>{text}
                        </button>
                      );
                    })}
                    {isUntimed && (
                      <Button size="sm" variant="outline" disabled={!current?.selected_option}
                        onClick={() => setRevealed((r) => ({ ...r, [q.id]: true }))}>
                        Check answer
                      </Button>
                    )}
                    {showAnswer && (
                      <div className="rounded-lg border border-primary/30 bg-primary/5 p-3 text-sm">
                        <p className="font-medium mb-1">Correct answer: {q.correct_option}</p>
                        <MathText text={q.explanation} />
                        <AttachmentPreview path={q.answer_file_url} name={q.answer_file_name} className="mt-2" />
                      </div>
                    )}
                  </div>
                ) : (
                  <div className="space-y-4">
                    {(qParts.length ? qParts : [null]).map((p, i) => {
                      const pid = p?.id || null;
                      const a = answers[key(q.id, pid)];
                      return (
                        <div key={pid || i} className="space-y-2">
                          {p && (
                            <div>
                              <p className="text-sm font-medium">{p.label} <span className="text-xs text-muted-foreground">({p.points} pts)</span></p>
                              <MathText text={p.prompt} />
                            </div>
                          )}
                          <FrqAnswerEditor value={a?.text_answer || ""} onChange={(html) => saveAnswer(q.id, pid, { text_answer: html })} />
                        </div>
                      );
                    })}
                    {isUntimed && (
                      <>
                        <Button size="sm" variant="outline" onClick={() => setRevealed((r) => ({ ...r, [q.id]: true }))}>
                          View sample answer
                        </Button>
                        {showAnswer && (
                          <div className="rounded-lg border border-primary/30 bg-primary/5 p-3 text-sm space-y-2">
                            <MathText text={q.explanation} />
                            <AttachmentPreview path={q.answer_file_url} name={q.answer_file_name} />
                            {qParts.map((p) => (
                              (p.sample_answer || p.sample_answer_file_url) ? (
                                <div key={p.id} className="space-y-1">
                                  {p.sample_answer && <p><strong>{p.label}:</strong> {p.sample_answer}</p>}
                                  <AttachmentPreview path={p.sample_answer_file_url} name={p.sample_answer_file_name} />
                                </div>
                              ) : null
                            ))}
                          </div>
                        )}
                      </>
                    )}
                  </div>
                )}

                <div className="flex items-center justify-between pt-2">
                  <Button variant="outline" size="sm" disabled={idx === 0} onClick={() => setIdx(idx - 1)}>
                    <ChevronLeft className="h-4 w-4" /> Back
                  </Button>
                  {idx < activeQuestions.length - 1 ? (
                    <Button size="sm" onClick={() => setIdx(idx + 1)}>Next <ChevronRight className="h-4 w-4" /></Button>
                  ) : (
                    <Button size="sm" onClick={submitSection}>
                      {submitted.length + 1 >= sections.length ? "Submit & finish" : "Submit section"}
                    </Button>
                  )}
                </div>
              </div>
            </div>
          </div>

          {/* Navigator */}
          <div className="glass-card rounded-xl border p-4 h-fit">
            <p className="text-xs font-semibold uppercase tracking-wide text-muted-foreground mb-2">Questions</p>
            <div className="grid grid-cols-5 gap-2">
              {activeQuestions.map((qq, i) => {
                const a = answers[key(qq.id, null)];
                const ps = parts[qq.id] || [];
                const done = qq.question_type === "frq" && ps.length
                  ? ps.some((p) => answers[key(qq.id, p.id)]?.text_answer)
                  : !!(a?.selected_option || a?.text_answer);
                return (
                  <button key={qq.id} onClick={() => setIdx(i)}
                    className={cn("h-9 rounded-lg border text-sm font-medium transition-colors",
                      i === idx && "ring-2 ring-primary",
                      a?.flagged ? "border-amber-400 bg-amber-400/20"
                        : done ? "border-primary bg-primary/15" : "bg-muted/30")}>
                    {i + 1}
                  </button>
                );
              })}
            </div>
            <div className="mt-3 space-y-1 text-[11px] text-muted-foreground">
              <p><span className="inline-block h-2 w-2 rounded bg-primary/50 mr-1" /> Answered</p>
              <p><span className="inline-block h-2 w-2 rounded bg-muted mr-1" /> Unanswered</p>
              <p><span className="inline-block h-2 w-2 rounded bg-amber-400 mr-1" /> Flagged</p>
            </div>
            <Button size="sm" className="w-full mt-4" onClick={submitSection}>
              {submitted.length + 1 >= sections.length ? "Submit & finish" : "Submit section"}
            </Button>
            {!isUntimed && <p className="mt-2 text-[11px] text-muted-foreground">You cannot return to a submitted section.</p>}
          </div>
        </div>
      )}
    </div>
  );
}
