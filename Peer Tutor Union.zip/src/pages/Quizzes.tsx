import { useState, useEffect } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/contexts/AuthContext";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Search, Brain, Clock, ArrowRight, CheckCircle2, Loader2 } from "lucide-react";
import { useNavigate } from "react-router-dom";

type Quiz = {
  id: string; title: string; description: string; category: string;
  time_limit_minutes: number | null; is_published: boolean; created_at: string;
  allow_retake: boolean; results_published: boolean;
};
type Attempt = { quiz_id: string; completed_at: string | null; score: number | null; total_points: number | null };

export default function Quizzes() {
  const { user } = useAuth();
  const [quizzes, setQuizzes] = useState<Quiz[]>([]);
  const [attempts, setAttempts] = useState<Attempt[]>([]);
  const [search, setSearch] = useState("");
  const [loading, setLoading] = useState(true);
  const navigate = useNavigate();

  useEffect(() => {
    if (!user) return;
    Promise.all([
      supabase.from("quizzes").select("*").eq("is_published", true).order("created_at", { ascending: false }),
      supabase.from("quiz_attempts").select("quiz_id, completed_at, score, total_points").eq("student_id", user.id),
    ]).then(([quizRes, attRes]) => {
      setQuizzes((quizRes.data as Quiz[]) || []);
      setAttempts(attRes.data || []);
      setLoading(false);
    });
  }, [user]);

  const filtered = quizzes.filter((q) =>
    q.title.toLowerCase().includes(search.toLowerCase()) ||
    (q.description || "").toLowerCase().includes(search.toLowerCase())
  );

  const getQuizStatus = (quizId: string) => {
    const att = attempts.filter(a => a.quiz_id === quizId);
    const completed = att.find(a => a.completed_at);
    const inProgress = att.find(a => !a.completed_at);
    if (completed) return { status: "completed" as const, score: completed.score, total: completed.total_points };
    if (inProgress) return { status: "in_progress" as const, score: null, total: null };
    return { status: "not_started" as const, score: null, total: null };
  };

  const categories = [...new Set(filtered.map(q => q.category))].sort();

  if (loading) return <div className="flex items-center justify-center py-12 text-muted-foreground">Loading...</div>;

  return (
    <div className="max-w-4xl mx-auto space-y-4">
      <div className="flex items-center justify-between">
        <h2 className="text-2xl font-bold text-foreground">Quizzes</h2>
        <div className="relative w-64">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <Input placeholder="Search quizzes..." value={search} onChange={(e) => setSearch(e.target.value)} className="pl-9" />
        </div>
      </div>

      <div className="flex items-center gap-2 text-sm text-muted-foreground">
        <span>All Quizzes</span>
        <span className="text-border">·</span>
        <span>{filtered.length} available</span>
      </div>

      {filtered.length === 0 ? (
        <Card className="glass-card">
          <CardContent className="py-16 text-center text-muted-foreground">
            <Brain className="h-12 w-12 mx-auto mb-4 opacity-30" />
            <p className="text-base">No quizzes available yet.</p>
          </CardContent>
        </Card>
      ) : (
        <div className="grid gap-3">
          {categories.map(cat => (
            <div key={cat}>
              <p className="text-xs font-semibold uppercase tracking-wider text-muted-foreground mb-2">{cat}</p>
              <div className="grid gap-2">
                {filtered.filter(q => q.category === cat).map(quiz => {
                  const status = getQuizStatus(quiz.id);
                  return (
                    <Card key={quiz.id} className="glass-card cursor-pointer hover:border-primary/30" onClick={() => navigate(`/quiz/${quiz.id}`)}>
                      <CardContent className="flex items-center gap-3 py-3 px-4">
                        <Brain className="h-5 w-5 text-emerald-500 shrink-0" />
                        <div className="flex-1 min-w-0">
                          <p className="text-sm font-medium truncate">{quiz.title}</p>
                          {quiz.description && <p className="text-xs text-muted-foreground truncate">{quiz.description}</p>}
                        </div>
                        {quiz.time_limit_minutes && (
                          <span className="text-xs text-muted-foreground flex items-center gap-1 shrink-0">
                            <Clock className="h-3 w-3" /> {quiz.time_limit_minutes}min
                          </span>
                        )}
                        {status.status === "completed" && (
                          <Badge variant="default" className="text-[10px] h-5 shrink-0">
                            <CheckCircle2 className="h-3 w-3 mr-0.5" />
                            {status.score !== null && status.total ? `${Math.round((status.score / status.total) * 100)}%` : "Done"}
                          </Badge>
                        )}
                        {status.status === "in_progress" && (
                          <Badge variant="secondary" className="text-[10px] h-5 shrink-0">
                            <Loader2 className="h-3 w-3 mr-0.5 animate-spin" /> In progress
                          </Badge>
                        )}
                        <ArrowRight className="h-4 w-4 text-muted-foreground shrink-0" />
                      </CardContent>
                    </Card>
                  );
                })}
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
