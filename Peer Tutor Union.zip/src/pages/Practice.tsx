import { useEffect, useMemo, useState } from "react";
import { useNavigate } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { toast } from "sonner";
import { Timer, BookOpen, Plus, Play } from "lucide-react";
import { useAuth } from "@/contexts/AuthContext";
import {
  canUploadQuestions,
  canManageSubjects,
  countQuestions,
  fetchKnowledgePoints,
  fetchQuestions,
  fetchSubjects,
  KnowledgePoint,
  Question,
  Subject,
} from "@/lib/questionBank";
import QuestionUploadDialog from "@/components/questions/QuestionUploadDialog";
import QuestionBankBrowser from "@/components/questions/QuestionBankBrowser";
import SubjectManagerDialog from "@/components/questions/SubjectManagerDialog";
import DifficultyStars from "@/components/questions/DifficultyStars";
import PracticeHistory from "@/components/practice/PracticeHistory";

export default function Practice() {
  const { user, displayRole, isAdmin, clubRole, hasUploadGrant } = useAuth();
  const navigate = useNavigate();
  const isAuthor = canUploadQuestions(displayRole, isAdmin, clubRole || undefined, hasUploadGrant);
  const isSubjectManager = canManageSubjects(displayRole, isAdmin, clubRole || undefined);

  const [subjects, setSubjects] = useState<Subject[]>([]);
  const [knowledgePoints, setKnowledgePoints] = useState<KnowledgePoint[]>([]);
  const [subjectId, setSubjectId] = useState("all");
  const [pointId, setPointId] = useState("all");
  const [difficulty, setDifficulty] = useState("all");
  const [type, setType] = useState("all");
  const [visibility, setVisibility] = useState("all");
  const [count, setCount] = useState("10");
  const [mcqMinutes, setMcqMinutes] = useState("45");
  const [frqMinutes, setFrqMinutes] = useState("45");
  const [pool, setPool] = useState<Question[]>([]);
  const [available, setAvailable] = useState(0);
  const [sessions, setSessions] = useState<any[]>([]);
  const [uploadOpen, setUploadOpen] = useState(false);
  const [refreshKey, setRefreshKey] = useState(0);

  const loadSubjects = () => fetchSubjects().then(setSubjects);
  useEffect(() => { loadSubjects(); }, [refreshKey]);

  useEffect(() => {
    setPointId("all");
    fetchKnowledgePoints(subjectId === "all" ? undefined : subjectId).then(setKnowledgePoints);
  }, [subjectId, refreshKey]);

  const filters = useMemo(() => ({
    subjectId: subjectId !== "all" ? subjectId : undefined,
    knowledgePointId: pointId !== "all" ? pointId : undefined,
    difficulty: difficulty !== "all" ? Number(difficulty) : undefined,
    type: type !== "all" ? (type as "mcq" | "frq") : undefined,
    visibility: visibility !== "all" ? (visibility as "public" | "private") : undefined,
  }), [subjectId, pointId, difficulty, type, visibility]);

  useEffect(() => {
    fetchQuestions(filters).then(setPool);
    countQuestions(filters).then(setAvailable);
  }, [filters, refreshKey]);

  const loadSessions = async () => {
    if (!user) return;
    const { data } = await supabase
      .from("practice_sessions").select("*").eq("user_id", user.id)
      .order("created_at", { ascending: false }).limit(15);
    setSessions(data || []);
  };
  useEffect(() => { loadSessions(); /* eslint-disable-next-line */ }, [user, refreshKey]);

  const subjectName = useMemo(() => Object.fromEntries(subjects.map((s) => [s.id, s.name])), [subjects]);

  const start = async (mode: "untimed" | "timed") => {
    if (!user) return;
    const n = Math.max(1, Number(count) || 10);
    if (pool.length === 0) { toast.error("No questions match these filters"); return; }
    const shuffled = [...pool].sort(() => Math.random() - 0.5).slice(0, n);
    // MCQ first, then FRQ (Section I / Section II)
    const ordered = [...shuffled.filter((q) => q.question_type === "mcq"), ...shuffled.filter((q) => q.question_type === "frq")];
    const { data, error } = await supabase.from("practice_sessions").insert({
      user_id: user.id,
      mode,
      title: `${subjectId !== "all" ? subjectName[subjectId] : "Mixed"} ${mode === "timed" ? "Timed Test" : "Practice"}`,
      subject_id: subjectId !== "all" ? subjectId : null,
      difficulty: difficulty !== "all" ? Number(difficulty) : null,
      question_ids: ordered.map((q) => q.id),
      section_seconds: mode === "timed"
        ? { mcq: (Number(mcqMinutes) || 45) * 60, frq: (Number(frqMinutes) || 45) * 60 }
        : {},
    }).select("id").single();
    if (error) { toast.error(error.message); return; }
    navigate(`/practice/${data.id}`);
  };

  return (
    <div className="max-w-5xl mx-auto space-y-6">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <h1 className="text-2xl font-bold text-foreground">Practice</h1>
          <p className="text-sm text-muted-foreground">Practice by subject, knowledge point and difficulty, or simulate an AP digital exam.</p>
        </div>
        {isAuthor && (
          <div className="flex items-center gap-2">
            {isSubjectManager && <SubjectManagerDialog onChanged={() => setRefreshKey((k) => k + 1)} />}
            <Button size="sm" className="gap-2" onClick={() => setUploadOpen(true)}><Plus className="h-4 w-4" /> Upload question</Button>
          </div>
        )}
      </div>

      <Tabs defaultValue="start">
        <TabsList>
          <TabsTrigger value="start">Start practice</TabsTrigger>
          <TabsTrigger value="history">My history</TabsTrigger>
          <TabsTrigger value="results">My results</TabsTrigger>
          <TabsTrigger value="bank">Question bank</TabsTrigger>
        </TabsList>

        <TabsContent value="start" className="space-y-4 pt-4">
          <Card className="glass-card">
            <CardHeader><CardTitle className="text-base">Choose your question set</CardTitle></CardHeader>
            <CardContent className="space-y-4">
              <div className="grid gap-3 sm:grid-cols-3 lg:grid-cols-6">
                <div>
                  <Label className="text-xs">Subject</Label>
                  <Select value={subjectId} onValueChange={setSubjectId}>
                    <SelectTrigger><SelectValue /></SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">All subjects</SelectItem>
                      {subjects.map((s) => <SelectItem key={s.id} value={s.id}>{s.name}</SelectItem>)}
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <Label className="text-xs">Knowledge point</Label>
                  <Select value={pointId} onValueChange={setPointId}>
                    <SelectTrigger><SelectValue /></SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">All knowledge points</SelectItem>
                      {knowledgePoints.map((k) => <SelectItem key={k.id} value={k.id}>{k.name}</SelectItem>)}
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <Label className="text-xs">Difficulty</Label>
                  <Select value={difficulty} onValueChange={setDifficulty}>
                    <SelectTrigger><SelectValue /></SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">Any</SelectItem>
                      <SelectItem value="1">★☆☆</SelectItem>
                      <SelectItem value="2">★★☆</SelectItem>
                      <SelectItem value="3">★★★</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <Label className="text-xs">Type</Label>
                  <Select value={type} onValueChange={setType}>
                    <SelectTrigger><SelectValue /></SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">MCQ + FRQ</SelectItem>
                      <SelectItem value="mcq">MCQ only</SelectItem>
                      <SelectItem value="frq">FRQ only</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <Label className="text-xs">Visibility</Label>
                  <Select value={visibility} onValueChange={setVisibility}>
                    <SelectTrigger><SelectValue /></SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">All</SelectItem>
                      <SelectItem value="public">Public</SelectItem>
                      <SelectItem value="private">My club only</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <Label className="text-xs">Questions</Label>
                  <Input type="number" min="1" value={count} onChange={(e) => setCount(e.target.value)} />
                </div>
              </div>
              <p className="text-xs text-muted-foreground">{available} question{available === 1 ? "" : "s"} available with these filters.</p>

              <div className="grid gap-4 md:grid-cols-2">
                <div className="rounded-xl border p-4 space-y-2">
                  <div className="flex items-center gap-2 font-medium"><BookOpen className="h-4 w-4" /> Untimed practice</div>
                  <p className="text-sm text-muted-foreground">No countdown. Pause anytime and see the answer and explanation right after each question.</p>
                  <Button className="gap-2" onClick={() => start("untimed")}><Play className="h-4 w-4" /> Start untimed</Button>
                </div>
                <div className="rounded-xl border p-4 space-y-2">
                  <div className="flex items-center gap-2 font-medium"><Timer className="h-4 w-4" /> Timed test (AP digital exam)</div>
                  <p className="text-sm text-muted-foreground">Sections with their own timers, question navigator, flags. Once a section is submitted you cannot return.</p>
                  <div className="flex gap-2">
                    <div><Label className="text-xs">Section I (min)</Label><Input type="number" min="1" value={mcqMinutes} onChange={(e) => setMcqMinutes(e.target.value)} /></div>
                    <div><Label className="text-xs">Section II (min)</Label><Input type="number" min="1" value={frqMinutes} onChange={(e) => setFrqMinutes(e.target.value)} /></div>
                  </div>
                  <Button className="gap-2" onClick={() => start("timed")}><Play className="h-4 w-4" /> Start timed test</Button>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="history" className="pt-4">
          <PracticeHistory refreshKey={refreshKey} />
        </TabsContent>

        <TabsContent value="results" className="space-y-2 pt-4">
          {sessions.length === 0 && <p className="text-sm text-muted-foreground">No practice sessions yet.</p>}
          {sessions.map((s) => (
            <div key={s.id} className="flex items-center justify-between rounded-xl border bg-muted/10 p-3">
              <div>
                <p className="font-medium text-sm">{s.title}</p>
                <p className="text-xs text-muted-foreground">
                  {new Date(s.created_at).toLocaleString()} · {s.question_ids.length} questions · {s.mode === "timed" ? "Timed" : "Untimed"}
                  {s.difficulty ? <> · <DifficultyStars level={s.difficulty} className="ml-1" /></> : null}
                </p>
              </div>
              <div className="flex items-center gap-2">
                {s.status === "completed"
                  ? <Badge variant="secondary">{s.score ?? 0} / {s.total_points ?? 0}</Badge>
                  : <Badge variant="outline">In progress</Badge>}
                <Button size="sm" variant="outline" onClick={() => navigate(`/practice/${s.id}`)}>
                  {s.status === "completed" ? "Review" : "Resume"}
                </Button>
              </div>
            </div>
          ))}
        </TabsContent>

        <TabsContent value="bank" className="pt-4">
          <QuestionBankBrowser refreshKey={refreshKey} />
        </TabsContent>
      </Tabs>

      <QuestionUploadDialog open={uploadOpen} onOpenChange={setUploadOpen} onSaved={() => setRefreshKey((k) => k + 1)} />
    </div>
  );
}
