import { useState, useEffect } from "react";
import { useParams, useNavigate } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/contexts/AuthContext";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { toast } from "sonner";
import { Camera, Grid3X3, Award, Edit2, Save, X, FileText, UserCheck, Users, Share2, Heart, ImagePlus, Settings } from "lucide-react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { ScrollArea } from "@/components/ui/scroll-area";
import { format } from "date-fns";
import AvatarCropDialog from "@/components/AvatarCropDialog";
import BannerCropDialog from "@/components/BannerCropDialog";
import PostDetailDialog from "@/components/posts/PostDetailDialog";
import CelebrityBadge from "@/components/posts/CelebrityBadge";
import { resolvePostsAttachments } from "@/lib/attachmentUtils";
import { CelebrityInfo, getVirtualLikes, getVirtualFollowers, formatCount } from "@/lib/celebrityUtils";
import { getRoleBorderClass } from "@/lib/roleUtils";
import TourChampionBadge from "@/components/team/TourChampionBadge";
import AccountSettingsDialog from "@/components/profile/AccountSettingsDialog";

type Profile = { user_id: string; name: string; avatar_url: string | null; bio: string; display_role?: string; banner_url?: string | null };
type AwardType = { id: string; title: string; description: string; granted_at: string };
type Post = {
  id: string;
  title: string;
  content: string;
  created_at: string;
  author_id: string;
  post_attachments: { id: string; file_url: string; file_name: string }[];
};
type ProfileMap = Record<string, { name: string; avatar_url: string | null }>;

export default function ProfilePage() {
  const { userId } = useParams();
  const navigate = useNavigate();
  const { user, refreshProfile } = useAuth();
  const targetId = userId || user?.id;
  const isOwnProfile = !userId || userId === user?.id;
  const [showSettings, setShowSettings] = useState(false);

  const [profile, setProfile] = useState<Profile | null>(null);
  const [awards, setAwards] = useState<AwardType[]>([]);
  const [posts, setPosts] = useState<Post[]>([]);
  const [profiles, setProfiles] = useState<ProfileMap>({});
  const [editing, setEditing] = useState(false);
  const [name, setName] = useState("");
  const [bio, setBio] = useState("");
  const [loading, setLoading] = useState(true);
  const [uploading, setUploading] = useState(false);
  const [cropSrc, setCropSrc] = useState<string | null>(null);
  const [bannerCropSrc, setBannerCropSrc] = useState<string | null>(null);
  const [following, setFollowing] = useState(false);
  const [followerCount, setFollowerCount] = useState(0);
  const [followingCount, setFollowingCount] = useState(0);
  const [isMutual, setIsMutual] = useState(false);
  const [selectedPost, setSelectedPost] = useState<Post | null>(null);
  const [showFollowers, setShowFollowers] = useState(false);
  const [showFollowing, setShowFollowing] = useState(false);
  const [followersList, setFollowersList] = useState<{ user_id: string; name: string; avatar_url: string | null }[]>([]);
  const [followingList, setFollowingList] = useState<{ user_id: string; name: string; avatar_url: string | null }[]>([]);
  const [shareAward, setShareAward] = useState<AwardType | null>(null);
  const [shareConversations, setShareConversations] = useState<{ id: string; name: string; isGroup?: boolean }[]>([]);
  const [celebrity, setCelebrity] = useState<CelebrityInfo | null>(null);
  const [totalLikes, setTotalLikes] = useState(0);
  const [wcTitles, setWcTitles] = useState(0);
  useEffect(() => {
    if (!targetId) return;
    const fetchAll = async () => {
      const [profRes, awardRes, postsRes, followersRes, followingRes, profilesRes, celRes, teamRes] = await Promise.all([
        supabase.from("profiles").select("*, banner_url").eq("user_id", targetId).single(),
        supabase.from("awards").select("*").eq("student_id", targetId).order("granted_at", { ascending: false }),
        supabase.from("posts").select("*, post_attachments(*)").eq("author_id", targetId).order("created_at", { ascending: false }),
        supabase.from("follows").select("*", { count: "exact", head: true }).eq("following_id", targetId),
        supabase.from("follows").select("*", { count: "exact", head: true }).eq("follower_id", targetId),
        supabase.from("profiles").select("user_id, name, avatar_url"),
        supabase.from("celebrities").select("*").eq("user_id", targetId).maybeSingle(),
        supabase.from("team_managers").select("wc_titles").eq("user_id", targetId).maybeSingle(),
      ]);
      setWcTitles((teamRes.data as any)?.wc_titles ?? 0);
      if (profRes.data) {
        setProfile(profRes.data);
        setName(profRes.data.name);
        setBio(profRes.data.bio || "");
      }
      setAwards(awardRes.data || []);
      const resolvedPosts = await resolvePostsAttachments((postsRes.data as unknown as Post[]) || []);
      setPosts(resolvedPosts);
      setFollowerCount(followersRes.count || 0);
      setFollowingCount(followingRes.count || 0);

      const celData = celRes.data as unknown as CelebrityInfo | null;
      setCelebrity(celData);

      // Calculate total likes (real + virtual)
      const postIds = resolvedPosts.map(p => p.id);
      let realLikes = 0;
      if (postIds.length > 0) {
        const { count } = await supabase.from("post_likes").select("*", { count: "exact", head: true }).in("post_id", postIds);
        realLikes = count || 0;
      }
      let virtualTotal = 0;
      if (celData) {
        resolvedPosts.forEach(p => { virtualTotal += getVirtualLikes(p.id, p.created_at, celData.likes_multiplier || 1, celData.likes_multiplier_changed_at); });
      }
      setTotalLikes(realLikes + virtualTotal);

      const map: ProfileMap = {};
      (profilesRes.data || []).forEach((p) => { map[p.user_id] = { name: p.name, avatar_url: p.avatar_url }; });
      setProfiles(map);

      if (!isOwnProfile && user) {
        const [followCheck, mutualCheck] = await Promise.all([
          supabase.from("follows").select("id").eq("follower_id", user.id).eq("following_id", targetId).maybeSingle(),
          supabase.from("follows").select("id").eq("follower_id", targetId).eq("following_id", user.id).maybeSingle(),
        ]);
        setFollowing(!!followCheck.data);
        setIsMutual(!!followCheck.data && !!mutualCheck.data);
      }
      setLoading(false);
    };
    fetchAll();
  }, [targetId]);

  const handleFollow = async () => {
    if (!user || !targetId) return;
    if (following) {
      await supabase.from("follows").delete().eq("follower_id", user.id).eq("following_id", targetId);
      setFollowing(false);
      setIsMutual(false);
      setFollowerCount((c) => c - 1);
    } else {
      await supabase.from("follows").insert({ follower_id: user.id, following_id: targetId });
      await supabase.from("notifications").insert({ user_id: targetId, actor_id: user.id, type: "follow" });
      setFollowing(true);
      setFollowerCount((c) => c + 1);
      const { data } = await supabase.from("follows").select("id").eq("follower_id", targetId).eq("following_id", user.id).maybeSingle();
      setIsMutual(!!data);
    }
  };

  const fetchFollowersList = async () => {
    if (!targetId) return;
    const { data } = await supabase.from("follows").select("follower_id").eq("following_id", targetId);
    if (data) {
      const ids = data.map(d => d.follower_id);
      const { data: profs } = await supabase.from("profiles").select("user_id, name, avatar_url").in("user_id", ids);
      setFollowersList(profs || []);
    }
    setShowFollowers(true);
  };

  const fetchFollowingList = async () => {
    if (!targetId) return;
    const { data } = await supabase.from("follows").select("following_id").eq("follower_id", targetId);
    if (data) {
      const ids = data.map(d => d.following_id);
      const { data: profs } = await supabase.from("profiles").select("user_id, name, avatar_url").in("user_id", ids);
      setFollowingList(profs || []);
    }
    setShowFollowing(true);
  };

  const handleSave = async () => {
    if (!targetId) return;
    const { error } = await supabase.from("profiles").update({ name, bio }).eq("user_id", targetId);
    if (error) { toast.error(error.message); return; }
    setProfile((p) => p ? { ...p, name, bio } : p);
    setEditing(false);
    toast.success("Profile updated");
    if (isOwnProfile) refreshProfile();
  };

  const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = () => setCropSrc(reader.result as string);
    reader.readAsDataURL(file);
    e.target.value = "";
  };

  const handleCropComplete = async (blob: Blob) => {
    if (!targetId) return;
    setCropSrc(null);
    setUploading(true);
    const path = `${targetId}/avatar.jpg`;
    const { error: upErr } = await supabase.storage.from("avatars").upload(path, blob, { upsert: true, contentType: "image/jpeg" });
    if (upErr) { toast.error(upErr.message); setUploading(false); return; }
    const { data: { publicUrl } } = supabase.storage.from("avatars").getPublicUrl(path);
    const avatarUrl = publicUrl + "?t=" + Date.now();
    await supabase.from("profiles").update({ avatar_url: avatarUrl }).eq("user_id", targetId);
    setProfile((p) => p ? { ...p, avatar_url: avatarUrl } : p);
    setUploading(false);
    toast.success("Avatar updated");
    if (isOwnProfile) refreshProfile();
  };

  const handleBannerFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = () => setBannerCropSrc(reader.result as string);
    reader.readAsDataURL(file);
    e.target.value = "";
  };

  const handleBannerCropComplete = async (blob: Blob) => {
    if (!targetId) return;
    setBannerCropSrc(null);
    const path = `${targetId}/banner.jpg`;
    const { error: upErr } = await supabase.storage.from("avatars").upload(path, blob, { upsert: true, contentType: "image/jpeg" });
    if (upErr) { toast.error(upErr.message); return; }
    const { data: { publicUrl } } = supabase.storage.from("avatars").getPublicUrl(path);
    const bannerUrl = publicUrl + "?t=" + Date.now();
    await supabase.from("profiles").update({ banner_url: bannerUrl }).eq("user_id", targetId);
    setProfile((p) => p ? { ...p, banner_url: bannerUrl } : p);
    toast.success("Background updated");
  };

  const getPostThumbnail = (post: Post) => {
    const img = post.post_attachments?.find((att) => /\.(jpg|jpeg|png|gif|webp|svg)$/i.test(att.file_name));
    return img?.file_url || null;
  };

  const handleDeletePost = async (postId: string) => {
    if (!confirm("Delete this post?")) return;
    await supabase.from("post_attachments").delete().eq("post_id", postId);
    await supabase.from("posts").delete().eq("id", postId);
    setPosts((prev) => prev.filter((p) => p.id !== postId));
    setSelectedPost(null);
    toast.success("Post deleted");
  };

  const handleShareAward = async (award: AwardType) => {
    if (!user) return;
    // Fetch conversations user belongs to
    const { data: members } = await supabase
      .from("conversation_members").select("conversation_id").eq("user_id", user.id);
    if (members && members.length > 0) {
      const convIds = members.map((m: any) => m.conversation_id);
      const { data: convs } = await supabase
        .from("conversations").select("id, name, is_group").in("id", convIds);
      // Resolve DM names
      const dmConvs = (convs || []).filter((c: any) => !c.is_group && !c.name);
      let dmNameMap: Record<string, string> = {};
      if (dmConvs.length > 0) {
        const dmIds = dmConvs.map((c: any) => c.id);
        const { data: allMembers } = await supabase
          .from("conversation_members").select("conversation_id, user_id").in("conversation_id", dmIds);
        const otherIds = [...new Set((allMembers || []).filter((m: any) => m.user_id !== user.id).map((m: any) => m.user_id))];
        if (otherIds.length > 0) {
          const { data: profs } = await supabase.from("profiles").select("user_id, name").in("user_id", otherIds);
          const profMap = new Map((profs || []).map((p: any) => [p.user_id, p.name]));
          (allMembers || []).filter((m: any) => m.user_id !== user.id).forEach((m: any) => {
            dmNameMap[m.conversation_id] = profMap.get(m.user_id) || "Unknown";
          });
        }
      }
      setShareConversations(
        (convs || []).map((c: any) => ({
          id: c.id,
          name: c.name || (c.is_group ? "Group Chat" : dmNameMap[c.id] || "Unknown"),
          isGroup: c.is_group,
        }))
      );
    } else {
      setShareConversations([]);
    }
    setShareAward(award);
  };

  const shareAwardToChat = async (convId: string) => {
    if (!shareAward || !user) return;
    const msg = `🏆 I just received an award: "${shareAward.title}"!${shareAward.description ? ` — ${shareAward.description}` : ""}`;
    await supabase.from("messages").insert({ conversation_id: convId, sender_id: user.id, content: msg });
    await supabase.from("conversations").update({ updated_at: new Date().toISOString() }).eq("id", convId);
    toast.success("Shared to chat");
    setShareAward(null);
  };

  const shareAwardAsPost = async () => {
    if (!shareAward || !user) return;
    const { error } = await supabase.from("posts").insert({
      title: `🏆 ${shareAward.title}`,
      content: `<p>I'm honored to receive the award: <strong>${shareAward.title}</strong>!</p>${shareAward.description ? `<p>${shareAward.description}</p>` : ""}`,
      author_id: user.id,
    });
    if (error) { toast.error("Failed to create post"); return; }
    toast.success("Award shared as post!");
    setShareAward(null);
  };

  if (loading) return <div className="flex items-center justify-center py-12 text-muted-foreground">Loading...</div>;
  if (!profile) return <div className="text-center py-12 text-muted-foreground">Profile not found.</div>;

  return (
    <div className="max-w-2xl mx-auto">
      <div className="relative">
        {/* Banner */}
        <div className="relative w-full aspect-[5/2] overflow-hidden bg-gradient-to-br from-primary/30 via-primary/15 to-accent/10">
          {profile.banner_url && (
            <img src={profile.banner_url} alt="" className="w-full h-full object-cover" />
          )}
          <div className="absolute inset-0 bg-gradient-to-b from-background/10 via-transparent to-background pointer-events-none" />
        </div>
        {isOwnProfile && editing && (
          <>
            <input id="profile-banner-upload" type="file" accept="image/*" className="sr-only" onChange={handleBannerFileSelect} />
            <label
              htmlFor="profile-banner-upload"
              className="absolute top-3 right-3 z-30 pointer-events-auto inline-flex select-none items-center gap-1.5 rounded-lg border border-border/60 bg-background/80 px-3 py-2 text-sm font-medium text-foreground shadow-sm backdrop-blur-sm cursor-pointer transition-colors hover:bg-background"
            >
              <ImagePlus className="h-4 w-4" />
              Change Background
            </label>
          </>
        )}
        {bannerCropSrc && (
          <BannerCropDialog open={!!bannerCropSrc} imageSrc={bannerCropSrc} onClose={() => setBannerCropSrc(null)} onCropComplete={handleBannerCropComplete} />
        )}

        {/* Profile header */}
        <div className="px-4 py-4 -mt-12 relative z-20">
          <div className="flex items-start gap-6 sm:gap-10">
            <div className="relative group shrink-0">
              <Avatar className={`h-20 w-20 sm:h-24 sm:w-24 ${getRoleBorderClass(profile.display_role)}`}>
                <AvatarImage src={profile.avatar_url || undefined} />
                <AvatarFallback className="text-2xl">{profile.name.charAt(0).toUpperCase()}</AvatarFallback>
              </Avatar>
              {isOwnProfile && (
                <label className="absolute inset-0 flex items-center justify-center bg-foreground/40 rounded-full opacity-0 group-hover:opacity-100 transition-opacity cursor-pointer">
                  <Camera className="h-5 w-5 text-background" />
                  <input type="file" accept="image/*" className="hidden" onChange={handleFileSelect} disabled={uploading} />
                </label>
              )}
              {cropSrc && (
                <AvatarCropDialog open={!!cropSrc} imageSrc={cropSrc} onClose={() => setCropSrc(null)} onCropComplete={handleCropComplete} />
              )}
            </div>

            <div className="flex-1 min-w-0">
              <div className="flex items-center gap-2 flex-wrap">
                <h2 className="text-xl font-semibold text-foreground">{profile.name}</h2>
                {celebrity && <CelebrityBadge celebrity={celebrity} />}
                <TourChampionBadge count={wcTitles} />
                {profile.display_role && profile.display_role !== "Student" && (
                  <span className="inline-flex items-center gap-1 text-xs font-medium text-amber-600 bg-amber-100 dark:text-amber-400 dark:bg-amber-900/30 px-2 py-0.5 rounded-full">
                    {{ President: "President", VicePresident: "Vice President", Teacher: "Teacher", GeneralSecretary: "General Secretary" }[profile.display_role] || profile.display_role}
                  </span>
                )}
                {isMutual && (
                  <span className="inline-flex items-center gap-1 text-xs font-medium text-primary bg-primary/10 px-2 py-0.5 rounded-full">
                    <UserCheck className="h-3 w-3" /> Friends
                  </span>
                )}
              </div>

              <div className="flex items-center gap-5 mt-3 flex-wrap">
                <div><span className="font-semibold text-foreground">{posts.length}</span><span className="text-sm text-muted-foreground ml-1">posts</span></div>
                <button onClick={fetchFollowersList} className="hover:opacity-70">
                  <span className="font-semibold text-foreground">{formatCount(followerCount + (celebrity ? getVirtualFollowers(targetId!, celebrity.created_at, celebrity.follower_multiplier || 1, celebrity.follower_multiplier_changed_at, celebrity.virtual_follower_seed || 0) : 0))}</span>
                  <span className="text-sm text-muted-foreground ml-1">followers</span>
                </button>
                <button onClick={fetchFollowingList} className="hover:opacity-70"><span className="font-semibold text-foreground">{followingCount}</span><span className="text-sm text-muted-foreground ml-1">following</span></button>
                {totalLikes > 0 && (
                  <div className="flex items-center gap-1">
                    <Heart className="h-3.5 w-3.5 text-red-500 fill-red-500" />
                    <span className="font-semibold text-foreground">{formatCount(totalLikes)}</span>
                    <span className="text-sm text-muted-foreground">likes</span>
                  </div>
                )}
              </div>

              {editing ? (
                <div className="space-y-2 mt-3">
                  <div><Label className="text-xs">Name</Label><Input value={name} onChange={(e) => setName(e.target.value)} className="h-8 text-sm" /></div>
                  <div><Label className="text-xs">Bio</Label><Textarea value={bio} onChange={(e) => setBio(e.target.value)} rows={2} placeholder="Bio..." className="text-sm" /></div>
                  <div className="flex gap-2">
                    <Button size="sm" variant="default" onClick={handleSave} className="h-7 text-xs"><Save className="h-3 w-3 mr-1" /> Save</Button>
                    <Button size="sm" variant="ghost" onClick={() => setEditing(false)} className="h-7 text-xs"><X className="h-3 w-3 mr-1" /> Cancel</Button>
                  </div>
                </div>
              ) : (
                <p className="text-sm text-foreground mt-2">{profile.bio || ""}</p>
              )}

              <div className="flex gap-2 mt-3">
                {isOwnProfile ? (
                  <>
                    <Button variant="outline" size="sm" className="h-8 text-xs" onClick={() => setEditing(true)}>
                      <Edit2 className="h-3 w-3 mr-1" /> Edit Profile
                    </Button>
                    <Button variant="outline" size="sm" className="h-8 text-xs" onClick={() => setShowSettings(true)}>
                      <Settings className="h-3 w-3 mr-1" /> Settings
                    </Button>
                  </>
                ) : (
                  <>
                    <Button variant={following ? "outline" : "default"} size="sm" className="h-8 text-xs min-w-[80px]" onClick={handleFollow}>
                      {following ? "Following" : "Follow"}
                    </Button>
                    <Button variant="outline" size="sm" className="h-8 text-xs" onClick={() => navigate("/chat")}>Message</Button>
                  </>
                )}
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Tabs */}
      <Tabs defaultValue="posts" className="w-full">
        <TabsList className="w-full justify-center bg-transparent border-t border-border rounded-none h-11">
          <TabsTrigger value="posts" className="flex items-center gap-1.5 data-[state=active]:border-t-2 data-[state=active]:border-foreground rounded-none data-[state=active]:shadow-none">
            <Grid3X3 className="h-3.5 w-3.5" /><span className="text-xs uppercase tracking-wider font-medium">Posts</span>
          </TabsTrigger>
          <TabsTrigger value="awards" className="flex items-center gap-1.5 data-[state=active]:border-t-2 data-[state=active]:border-foreground rounded-none data-[state=active]:shadow-none">
            <Award className="h-3.5 w-3.5" /><span className="text-xs uppercase tracking-wider font-medium">Awards</span>
          </TabsTrigger>
        </TabsList>

        <TabsContent value="posts" className="mt-0">
          {posts.length === 0 ? (
            <div className="flex flex-col items-center justify-center py-16 text-muted-foreground">
              <Grid3X3 className="h-10 w-10 mb-3 opacity-30" /><p className="text-sm">No posts yet</p>
            </div>
          ) : (
            <div className="grid grid-cols-3 gap-0.5">
              {posts.map((post) => {
                const thumb = getPostThumbnail(post);
                return (
                  <button key={post.id} className="aspect-square relative overflow-hidden bg-muted group"
                    onClick={() => setSelectedPost(post)}>
                    {thumb ? (
                      <img src={thumb} alt="" className="w-full h-full object-cover group-hover:opacity-80 transition-opacity" loading="lazy" />
                    ) : (
                      <div className="w-full h-full flex flex-col items-center justify-center bg-muted p-2 group-hover:opacity-80 transition-opacity">
                        <FileText className="h-6 w-6 text-muted-foreground/40 mb-1" />
                        <p className="text-[10px] text-muted-foreground text-center line-clamp-3">{post.title}</p>
                      </div>
                    )}
                  </button>
                );
              })}
            </div>
          )}
        </TabsContent>

        <TabsContent value="awards" className="mt-0 px-4 py-4">
          {awards.length === 0 ? (
            <div className="flex flex-col items-center justify-center py-16 text-muted-foreground">
              <Award className="h-10 w-10 mb-3 opacity-30" /><p className="text-sm">No awards yet</p>
            </div>
          ) : (
            <div className="space-y-3">
              {awards.map((a) => (
                <div key={a.id} className="flex items-start gap-3 p-3 rounded-lg bg-muted/50">
                  <Award className="h-5 w-5 text-yellow-500 mt-0.5 shrink-0" />
                  <div className="flex-1">
                    <p className="font-medium text-foreground text-sm">{a.title}</p>
                    {a.description && <p className="text-xs text-muted-foreground">{a.description}</p>}
                    <p className="text-[10px] text-muted-foreground mt-1">{format(new Date(a.granted_at), "MMM d, yyyy")}</p>
                  </div>
                  {isOwnProfile && (
                    <Button variant="ghost" size="icon" className="h-7 w-7 shrink-0" onClick={() => handleShareAward(a)}>
                      <Share2 className="h-3.5 w-3.5" />
                    </Button>
                  )}
                </div>
              ))}
            </div>
          )}
        </TabsContent>
      </Tabs>

      {/* Post detail dialog */}
      <AccountSettingsDialog open={showSettings} onOpenChange={setShowSettings} />

      <PostDetailDialog
        post={selectedPost}
        profiles={profiles}
        userId={user?.id || ""}
        isAdmin={false}
        onClose={() => setSelectedPost(null)}
        onDelete={handleDeletePost}
        celebrityMap={celebrity ? { [celebrity.user_id]: celebrity } : {}}
      />

      {/* Followers Dialog */}
      <Dialog open={showFollowers} onOpenChange={setShowFollowers}>
        <DialogContent className="sm:max-w-sm">
          <DialogHeader><DialogTitle className="flex items-center gap-2"><Users className="h-4 w-4" /> Followers</DialogTitle></DialogHeader>
          <div className="max-h-80 overflow-y-auto space-y-2">
            {followersList.length === 0 ? (
              <p className="text-sm text-muted-foreground text-center py-4">No followers yet</p>
            ) : followersList.map((p) => (
              <button key={p.user_id} className="flex items-center gap-3 w-full p-2 rounded-lg hover:bg-muted transition-colors"
                onClick={() => { setShowFollowers(false); navigate(`/profile/${p.user_id}`); }}>
                <Avatar className="h-9 w-9">
                  <AvatarImage src={p.avatar_url || undefined} />
                  <AvatarFallback className="text-sm">{p.name.charAt(0).toUpperCase()}</AvatarFallback>
                </Avatar>
                <span className="text-sm font-medium text-foreground">{p.name}</span>
              </button>
            ))}
            {celebrity && (() => {
              const virtualFollowers = getVirtualFollowers(targetId!, celebrity.created_at, celebrity.follower_multiplier || 1, celebrity.follower_multiplier_changed_at, celebrity.virtual_follower_seed || 0);
              return virtualFollowers > 0 ? (
                <p className="text-sm text-muted-foreground text-center py-3 border-t border-border mt-2">
                  + {formatCount(virtualFollowers)} more followers
                </p>
              ) : null;
            })()}
          </div>
        </DialogContent>
      </Dialog>

      {/* Following Dialog */}
      <Dialog open={showFollowing} onOpenChange={setShowFollowing}>
        <DialogContent className="sm:max-w-sm">
          <DialogHeader><DialogTitle className="flex items-center gap-2"><Users className="h-4 w-4" /> Following</DialogTitle></DialogHeader>
          <div className="max-h-80 overflow-y-auto space-y-2">
            {followingList.length === 0 ? (
              <p className="text-sm text-muted-foreground text-center py-4">Not following anyone yet</p>
            ) : followingList.map((p) => (
              <button key={p.user_id} className="flex items-center gap-3 w-full p-2 rounded-lg hover:bg-muted transition-colors"
                onClick={() => { setShowFollowing(false); navigate(`/profile/${p.user_id}`); }}>
                <Avatar className="h-9 w-9">
                  <AvatarImage src={p.avatar_url || undefined} />
                  <AvatarFallback className="text-sm">{p.name.charAt(0).toUpperCase()}</AvatarFallback>
                </Avatar>
                <span className="text-sm font-medium text-foreground">{p.name}</span>
              </button>
            ))}
          </div>
        </DialogContent>
      </Dialog>
      {/* Award Share Dialog */}
      <Dialog open={!!shareAward} onOpenChange={() => setShareAward(null)}>
        <DialogContent className="sm:max-w-sm">
          <DialogHeader><DialogTitle className="flex items-center gap-2"><Share2 className="h-4 w-4" /> Share Award</DialogTitle></DialogHeader>
          <div className="space-y-3">
            <Button variant="outline" className="w-full justify-start" onClick={shareAwardAsPost}>
              <FileText className="h-4 w-4 mr-2" /> Share as Post
            </Button>
            <div className="border-t border-border pt-3">
              <p className="text-xs font-medium text-muted-foreground mb-2">Send to Chat</p>
              {shareConversations.length === 0 ? (
                <p className="text-sm text-muted-foreground text-center py-2">No chats available</p>
              ) : (
                <ScrollArea className="max-h-52">
                  <div className="space-y-0.5">
                    {shareConversations.map((conv) => (
                      <button key={conv.id}
                        className="w-full flex items-center gap-3 px-3 py-2 rounded-lg hover:bg-muted transition-colors text-left"
                        onClick={() => shareAwardToChat(conv.id)}>
                        <Avatar className="h-7 w-7">
                          <AvatarFallback className="text-xs">{conv.name.charAt(0)}</AvatarFallback>
                        </Avatar>
                        <span className="text-sm font-medium truncate">{conv.name}</span>
                      </button>
                    ))}
                  </div>
                </ScrollArea>
              )}
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}
