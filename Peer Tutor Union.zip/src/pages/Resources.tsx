import { useState, useEffect, useCallback } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/contexts/AuthContext";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Search, FolderOpen } from "lucide-react";
import FileViewerDialog from "@/components/FileViewerDialog";
import ResourceTree, { FolderItem, ResourceItem } from "@/components/resources/ResourceTree";
import { handleResourceDrop } from "@/lib/resourceDrop";

export default function Resources() {
  const { user, isAdmin } = useAuth();
  const [resources, setResources] = useState<ResourceItem[]>([]);
  const [folders, setFolders] = useState<FolderItem[]>([]);
  const [search, setSearch] = useState("");
  const [loading, setLoading] = useState(true);
  const [previewing, setPreviewing] = useState<ResourceItem | null>(null);
  const [expanded, setExpanded] = useState<Set<string>>(new Set());

  const load = useCallback(async () => {
    const [resRes, folderRes] = await Promise.all([
      supabase.from("resources").select("*").order("sort_order"),
      supabase.from("resource_folders").select("*").order("sort_order"),
    ]);
    setResources((resRes.data as ResourceItem[]) || []);
    setFolders((folderRes.data as FolderItem[]) || []);
    setLoading(false);
  }, []);

  useEffect(() => { if (user) load(); }, [user, load]);

  const toggleExpand = (id: string) => {
    setExpanded(prev => {
      const next = new Set(prev);
      next.has(id) ? next.delete(id) : next.add(id);
      return next;
    });
  };

  const totalFiles = resources.filter(r =>
    !search || r.title.toLowerCase().includes(search.toLowerCase())
  ).length;

  if (loading) return <div className="flex items-center justify-center py-12 text-muted-foreground">Loading...</div>;

  return (
    <div className="max-w-4xl mx-auto space-y-4">
      <div className="flex items-center justify-between">
        <h2 className="text-2xl font-bold text-foreground">Materials</h2>
        <div className="relative w-64">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <Input placeholder="Search materials..." value={search} onChange={(e) => setSearch(e.target.value)} className="pl-9" />
        </div>
      </div>

      <div className="flex items-center gap-2 text-sm text-muted-foreground">
        <span>All Materials</span>
        <span className="text-border">·</span>
        <span>{totalFiles} files</span>
        {isAdmin && (
          <span className="ml-auto text-xs italic">Drag files & folders to reorder · Drop files from your computer to upload</span>
        )}
      </div>

      <Card className="glass-card">
        <CardContent className="p-2">
          {folders.length === 0 ? (
            <div className="py-16 text-center text-muted-foreground">
              <FolderOpen className="h-12 w-12 mx-auto mb-4 opacity-30" />
              <p className="text-base">No materials available yet.</p>
            </div>
          ) : (
            <ResourceTree
              folders={folders}
              resources={resources}
              search={search}
              expanded={expanded}
              toggleExpand={toggleExpand}
              onPreview={setPreviewing}
              draggable={isAdmin}
              onDropAction={(target, payload, files) =>
                handleResourceDrop({
                  target, payload, files,
                  folders, resources,
                  authorId: user!.id,
                  onChanged: load,
                })
              }
            />
          )}
        </CardContent>
      </Card>

      {previewing && (
        <FileViewerDialog
          open={!!previewing}
          onOpenChange={(o) => !o && setPreviewing(null)}
          fileUrl={previewing.file_url}
          fileName={previewing.file_name}
          title={previewing.title}
        />
      )}
    </div>
  );
}
