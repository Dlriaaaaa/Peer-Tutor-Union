import { useState, useEffect, useCallback, useRef } from "react";
import { useParams, useNavigate } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/contexts/AuthContext";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { toast } from "sonner";
import { ArrowLeft, Clock, CheckCircle2, XCircle, ChevronLeft, ChevronRight, Play, Trophy, Star, Zap, Award } from "lucide-react";
import SignedImage from "@/components/SignedImage";

type Quiz = {
  id: string; title: string; description: string; category: string;
  time_limit_minutes: number | null; allow_retake: boolean; results_published: boolean;
};
type Question = { id: string; question_text: string; question_type: string; image_url: string | null; points: number; sort_order: number; correct_answer?: string | null };
type Option = { id: string; question_id: string; option_text: string; is_correct?: boolean; sort_order: number };
type Attempt = { id: string; score: number | null; total_points: number | null; completed_at: string | null; created_at: string };

type Phase = "loading" | "landing" | "quiz" | "results" | "pending";

export default function QuizTake() {
  const { quizId } = useParams();
  const navigate = useNavigate();
  const { user } = useAuth();

  const [quiz, setQuiz] = useState<Quiz | null>(null);
  const [questions, setQuestions] = useState<Question[]>([]);
  const [options, setOptions] = useState<Record<string, Option[]>>({});
  const [phase, setPhase] = useState<Phase>("loading");
  const [current, setCurrent] = useState(0);
  // answers: for multiple_select, store comma-separated option ids
  const [answers, setAnswers] = useState<Record<string, string>>({});
  const [attemptId, setAttemptId] = useState<string | null>(null);
  const [existingAttempt, setExistingAttempt] = useState<Attempt | null>(null);
  const [timeLeft, setTimeLeft] = useState<number | null>(null);
  const [score, setScore] = useState<{ correct: number; total: number } | null>(null);
  const [questionCount, setQuestionCount] = useState(0);
  const saveTimerRef = useRef<NodeJS.Timeout | null>(null);

  // Load quiz data and check existing attempts
  useEffect(() => {
    if (!quizId || !user) return;
    (async () => {
      const { data: q } = await supabase.from("quizzes").select("*").eq("id", quizId).single();
      if (!q) { navigate("/resources"); return; }
      setQuiz(q as Quiz);

      // Answer-free feed for taking the quiz
      const { data: items } = await supabase.rpc("get_quiz_items" as any, { _quiz_id: quizId });
      let qs: Question[] = ((items as any[]) || []).map((it) => ({
        id: it.id, question_text: it.question_text, question_type: it.question_type,
        image_url: it.image_url, points: it.points, sort_order: it.sort_order,
      }));
      let grouped: Record<string, Option[]> = {};
      ((items as any[]) || []).forEach((it) => { grouped[it.id] = (it.options || []) as Option[]; });

      // Once results are published, answer keys become readable for review
      if ((q as Quiz).results_published) {
        const { data: fullQs } = await supabase.from("quiz_questions").select("*").eq("quiz_id", quizId).order("sort_order");
        if (fullQs && fullQs.length) {
          qs = fullQs as Question[];
          const { data: opts } = await supabase.from("quiz_options").select("*").in("question_id", fullQs.map(x => x.id)).order("sort_order");
          grouped = {};
          (opts || []).forEach(o => { if (!grouped[o.question_id]) grouped[o.question_id] = []; grouped[o.question_id].push(o as Option); });
        }
      }

      setQuestions(qs);
      setQuestionCount(qs.length);
      setOptions(grouped);

      // Check existing attempt
      const { data: attempts } = await supabase
        .from("quiz_attempts")
        .select("*")
        .eq("quiz_id", quizId)
        .eq("student_id", user.id)
        .order("created_at", { ascending: false })
        .limit(1);

      const latest = attempts?.[0] as Attempt | undefined;

      if (latest) {
        setExistingAttempt(latest);
        if (latest.completed_at) {
          // Already completed
          if ((q as Quiz).results_published) {
            setScore({ correct: latest.score || 0, total: latest.total_points || 0 });
            // Load saved answers for review
            const { data: savedAns } = await supabase.from("quiz_answers").select("*").eq("attempt_id", latest.id);
            if (savedAns) {
              const ansMap: Record<string, string> = {};
              savedAns.forEach((a: any) => {
                if (a.selected_option_ids && a.selected_option_ids.length > 0) {
                  ansMap[a.question_id] = a.selected_option_ids.join(",");
                } else if (a.selected_option_id) {
                  ansMap[a.question_id] = a.selected_option_id;
                } else if (a.text_answer) {
                  ansMap[a.question_id] = a.text_answer;
                }
              });
              setAnswers(ansMap);
            }
            setPhase("results");
          } else {
            setPhase("pending");
          }
        } else {
          // In progress — resume
          setAttemptId(latest.id);
          // Calculate remaining time
          if ((q as Quiz).time_limit_minutes) {
            const elapsed = (Date.now() - new Date(latest.created_at).getTime()) / 1000;
            const remaining = Math.max(0, (q as Quiz).time_limit_minutes! * 60 - elapsed);
            if (remaining <= 0) {
              // Time expired while away — auto submit (graded server-side)
              await supabase.rpc("finalize_quiz_attempt" as any, { _attempt_id: latest.id });
              setPhase("pending");
              return;
            }
            setTimeLeft(Math.floor(remaining));
          }
          // Load saved answers
          const { data: savedAns } = await supabase.from("quiz_answers").select("*").eq("attempt_id", latest.id);
          if (savedAns) {
            const ansMap: Record<string, string> = {};
            savedAns.forEach((a: any) => {
              if (a.selected_option_ids && a.selected_option_ids.length > 0) {
                ansMap[a.question_id] = a.selected_option_ids.join(",");
              } else if (a.selected_option_id) {
                ansMap[a.question_id] = a.selected_option_id;
              } else if (a.text_answer) {
                ansMap[a.question_id] = a.text_answer;
              }
            });
            setAnswers(ansMap);
          }
          setPhase("quiz");
          return;
        }

        // If completed and no retake allowed
        if (latest.completed_at && !(q as Quiz).allow_retake) {
          return; // Already set phase above
        }
      }

      if (!latest || (latest.completed_at && (q as Quiz).allow_retake)) {
        setPhase("landing");
      }

    })();
  }, [quizId, user]);

  // Timer countdown
  useEffect(() => {
    if (timeLeft === null || timeLeft <= 0 || phase !== "quiz") return;
    const t = setInterval(() => {
      setTimeLeft(p => {
        if (p !== null && p <= 1) { handleSubmit(); return 0; }
        return p !== null ? p - 1 : null;
      });
    }, 1000);
    return () => clearInterval(t);
  }, [timeLeft, phase]);

  // Real-time save: graded server-side so answer keys never reach the client
  const saveAnswer = useCallback(async (questionId: string, answer: string) => {
    if (!attemptId) return;
    const q = questions.find(q => q.id === questionId);
    if (!q) return;

    let selectedOptionId: string | null = null;
    let selectedOptionIds: string[] | null = null;
    let textAnswer: string | null = null;

    if (q.question_type === "multiple_choice") {
      selectedOptionId = answer || null;
    } else if (q.question_type === "multiple_select") {
      const ids = answer.split(",").filter(Boolean);
      selectedOptionIds = ids.length > 0 ? ids : null;
    } else {
      textAnswer = answer || null;
    }

    await supabase.rpc("save_quiz_answer" as any, {
      _attempt_id: attemptId,
      _question_id: questionId,
      _option_id: selectedOptionId,
      _option_ids: selectedOptionIds,
      _text: textAnswer,
    });
  }, [attemptId, questions]);

  // Debounced save
  const handleAnswerChange = useCallback((questionId: string, value: string) => {
    setAnswers(p => ({ ...p, [questionId]: value }));
    if (saveTimerRef.current) clearTimeout(saveTimerRef.current);
    saveTimerRef.current = setTimeout(() => saveAnswer(questionId, value), 500);
  }, [saveAnswer]);

  const startQuiz = async () => {
    if (!user || !quizId || !quiz) return;
    const { data: attempt } = await supabase.from("quiz_attempts").insert({
      quiz_id: quizId, student_id: user.id, total_points: questions.reduce((s, q) => s + q.points, 0),
    }).select().single();
    if (!attempt) { toast.error("Failed to start quiz"); return; }
    setAttemptId(attempt.id);
    if (quiz.time_limit_minutes) setTimeLeft(quiz.time_limit_minutes * 60);
    setPhase("quiz");
  };

  const handleSubmit = useCallback(async () => {
    if (phase !== "quiz" || !attemptId) return;
    for (const q of questions) {
      if (answers[q.id] !== undefined) {
        await saveAnswer(q.id, answers[q.id]);
      }
    }

    const { data: result } = await supabase.rpc("finalize_quiz_attempt" as any, { _attempt_id: attemptId });
    const res = (result as any) || {};
    setScore({ correct: Number(res.score) || 0, total: Number(res.total) || questions.reduce((s, q) => s + q.points, 0) });

    if (quiz?.results_published) {
      setPhase("results");
    } else {
      setPhase("pending");
    }
    toast.success("Quiz submitted!");
  }, [phase, attemptId, questions, answers, quiz, saveAnswer]);

  const formatTime = (s: number) => `${Math.floor(s / 60)}:${(s % 60).toString().padStart(2, "0")}`;

  // LOADING
  if (phase === "loading") {
    return (
      <div className="flex items-center justify-center py-20">
        <div className="glass-card rounded-2xl p-8 text-center space-y-4">
          <div className="w-12 h-12 rounded-full border-2 border-primary border-t-transparent animate-spin mx-auto" />
          <p className="text-muted-foreground">Loading quiz...</p>
        </div>
      </div>
    );
  }

  // PENDING (results not published)
  if (phase === "pending") {
    return (
      <div className="max-w-lg mx-auto py-12">
        <div className="glass-card rounded-3xl p-10 text-center space-y-6">
          <div className="inline-flex items-center justify-center w-20 h-20 rounded-full bg-warning/10">
            <Clock className="h-10 w-10 text-warning" />
          </div>
          <h1 className="text-2xl font-bold text-foreground">Quiz Submitted</h1>
          <p className="text-muted-foreground">Your answers have been submitted. Results will be available once your teacher publishes them.</p>
          <Badge variant="secondary" className="text-base px-4 py-2">⏳ Pending Review</Badge>
          <Button onClick={() => navigate("/resources")} variant="outline" className="mt-4">
            <ArrowLeft className="h-4 w-4 mr-1" /> Back to Resources
          </Button>
        </div>
      </div>
    );
  }

  if (!quiz || questions.length === 0) {
    return <div className="flex items-center justify-center py-20 text-muted-foreground">Quiz not found or empty.</div>;
  }

  // LANDING PAGE
  if (phase === "landing") {
    return (
      <div className="max-w-lg mx-auto py-12">
        <div className="glass-card rounded-3xl p-10 text-center space-y-8">
          <div className="space-y-2">
            <Badge variant="outline" className="text-xs mb-2">{quiz.category}</Badge>
            <h1 className="text-3xl font-bold text-foreground">{quiz.title}</h1>
            {quiz.description && <p className="text-muted-foreground mt-2">{quiz.description}</p>}
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div className="rounded-2xl bg-muted/50 p-4 space-y-1">
              <p className="text-2xl font-bold text-foreground">{questionCount}</p>
              <p className="text-xs text-muted-foreground">Questions</p>
            </div>
            <div className="rounded-2xl bg-muted/50 p-4 space-y-1">
              <p className="text-2xl font-bold text-foreground">{quiz.time_limit_minutes ? `${quiz.time_limit_minutes}m` : "∞"}</p>
              <p className="text-xs text-muted-foreground">Time Limit</p>
            </div>
          </div>

          <div className="rounded-2xl bg-muted/30 p-4 text-left space-y-2 text-sm text-muted-foreground">
            <p>📌 Once you start, the timer begins and cannot be paused.</p>
            <p>📌 Your answers are saved automatically.</p>
            <p>📌 You can navigate between questions freely.</p>
            {!quiz.allow_retake && <p>📌 You can only take this quiz <strong className="text-foreground">once</strong>.</p>}
          </div>

          <Button size="lg" className="w-full h-14 text-lg rounded-2xl" onClick={startQuiz}>
            <Play className="h-5 w-5 mr-2" /> Start Quiz
          </Button>

          <Button variant="ghost" size="sm" onClick={() => navigate("/resources")}>
            <ArrowLeft className="h-4 w-4 mr-1" /> Back to Resources
          </Button>
        </div>
      </div>
    );
  }

  // RESULTS
  if (phase === "results" && score) {
    const pct = Math.round((score.correct / score.total) * 100);
    const motivation = getMotivation(pct);

    return (
      <div className="max-w-2xl mx-auto py-8">
        <div className="glass-card rounded-3xl p-8 text-center space-y-6">
          {/* Motivation Banner */}
          <div className={`inline-flex items-center justify-center w-24 h-24 rounded-full ${motivation.bgClass}`}>
            <motivation.icon className={`h-12 w-12 ${motivation.iconClass}`} />
          </div>
          <h1 className="text-3xl font-bold text-foreground">{quiz.title}</h1>
          <div className="text-5xl font-black text-foreground">{pct}%</div>
          <p className="text-muted-foreground">{score.correct} / {score.total} points</p>

          {/* Motivation Message */}
          <div className={`rounded-2xl px-6 py-4 ${motivation.bgClass}`}>
            <p className={`text-lg font-semibold ${motivation.textClass}`}>{motivation.title}</p>
            <p className={`text-sm mt-1 ${motivation.textClass} opacity-80`}>{motivation.message}</p>
          </div>

          {/* Review */}
          <div className="text-left space-y-3 mt-8">
            {questions.map((q, i) => {
              const ans = answers[q.id] || "";
              let isCorrect = false;
              if (q.question_type === "multiple_choice") {
                isCorrect = (options[q.id] || []).find(o => o.id === ans)?.is_correct || false;
              } else if (q.question_type === "multiple_select") {
                const ids = ans.split(",").filter(Boolean).sort();
                const correctIds = (options[q.id] || []).filter(o => o.is_correct).map(o => o.id).sort();
                isCorrect = JSON.stringify(ids) === JSON.stringify(correctIds);
              } else {
                isCorrect = ans.trim().toLowerCase() === q.correct_answer?.trim().toLowerCase();
              }
              return (
                <div key={q.id} className="glass-card rounded-xl p-4 space-y-2">
                  <div className="flex items-start justify-between">
                    <p className="font-medium text-foreground text-sm">Q{i + 1}. {q.question_text}</p>
                    {isCorrect ? <CheckCircle2 className="h-5 w-5 text-green-500 shrink-0" /> : <XCircle className="h-5 w-5 text-destructive shrink-0" />}
                  </div>
                  {q.image_url && <SignedImage storagePath={q.image_url} className="max-h-32 rounded-lg" />}
                  {(q.question_type === "multiple_choice" || q.question_type === "multiple_select") ? (
                    <div className="space-y-1">
                      {(options[q.id] || []).map(o => {
                        const selected = q.question_type === "multiple_select"
                          ? ans.split(",").includes(o.id)
                          : ans === o.id;
                        return (
                          <div key={o.id} className={`text-sm px-3 py-1.5 rounded-lg ${
                            o.is_correct ? 'bg-green-500/10 font-medium' :
                            selected && !o.is_correct ? 'bg-destructive/10 text-destructive line-through' :
                            'text-muted-foreground'
                          }`}>
                            {o.option_text}
                          </div>
                        );
                      })}
                    </div>
                  ) : (
                    <div className="text-sm">
                      <span className="text-muted-foreground">Your answer: </span>
                      <span className={isCorrect ? "font-medium" : "text-destructive"}>{ans || "—"}</span>
                      {!isCorrect && <span className="text-muted-foreground"> → Correct: <span className="font-medium">{q.correct_answer}</span></span>}
                    </div>
                  )}
                </div>
              );
            })}
          </div>

          <Button onClick={() => navigate("/resources")} className="mt-4">
            <ArrowLeft className="h-4 w-4 mr-1" /> Back to Resources
          </Button>
        </div>
      </div>
    );
  }

  // QUIZ IN PROGRESS
  const q = questions[current];
  const qOptions = options[q.id] || [];

  return (
    <div className="max-w-2xl mx-auto py-8 space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <Button variant="ghost" size="sm" onClick={() => navigate("/resources")}>
          <ArrowLeft className="h-4 w-4 mr-1" /> Exit
        </Button>
        {timeLeft !== null && (
          <Badge variant={timeLeft < 60 ? "destructive" : "secondary"} className="text-sm px-3 py-1.5 font-mono">
            <Clock className="h-3.5 w-3.5 mr-1.5" /> {formatTime(timeLeft)}
          </Badge>
        )}
      </div>

      <div className="glass-card rounded-3xl overflow-hidden">
        {/* Progress */}
        <div className="px-6 pt-6 pb-3">
          <div className="flex items-center justify-between mb-3">
            <h2 className="text-lg font-bold text-foreground">{quiz.title}</h2>
            <span className="text-sm text-muted-foreground font-medium">{current + 1} / {questions.length}</span>
          </div>
          <div className="w-full h-2 bg-muted rounded-full overflow-hidden">
            <div className="h-full bg-primary rounded-full transition-all duration-500 ease-out" style={{ width: `${((current + 1) / questions.length) * 100}%` }} />
          </div>
        </div>

        {/* Question */}
        <div className="px-6 py-6 space-y-5">
          <div className="space-y-3">
            <div className="flex items-center gap-2">
              <Badge variant="outline" className="text-xs">{q.points} pt{q.points > 1 ? "s" : ""}</Badge>
              <Badge variant="outline" className="text-xs">
                {q.question_type === "multiple_choice" ? "Select one" : q.question_type === "multiple_select" ? "Select all that apply" : "Type answer"}
              </Badge>
            </div>
            <h3 className="text-xl font-semibold text-foreground leading-relaxed">{q.question_text}</h3>
          </div>

          {q.image_url && (
            <div className="rounded-xl overflow-hidden border">
              <SignedImage storagePath={q.image_url} alt="Question" className="w-full max-h-64 object-contain bg-muted/50" />
            </div>
          )}

          {q.question_type === "multiple_choice" ? (
            <div className="space-y-2.5">
              {qOptions.map((opt, i) => {
                const selected = answers[q.id] === opt.id;
                return (
                  <button key={opt.id}
                    onClick={() => handleAnswerChange(q.id, opt.id)}
                    className={`w-full text-left px-5 py-3.5 rounded-xl border-2 transition-all duration-200 flex items-center gap-3 group
                      ${selected ? "border-primary bg-primary/5 shadow-sm" : "border-border hover:border-primary/40 hover:bg-muted/50"}`}
                  >
                    <span className={`flex items-center justify-center w-7 h-7 rounded-full text-xs font-bold transition-colors
                      ${selected ? "bg-primary text-primary-foreground" : "bg-muted text-muted-foreground group-hover:bg-primary/10"}`}>
                      {String.fromCharCode(65 + i)}
                    </span>
                    <span className={`text-sm ${selected ? "font-medium text-foreground" : "text-foreground/80"}`}>{opt.option_text}</span>
                  </button>
                );
              })}
            </div>
          ) : q.question_type === "multiple_select" ? (
            <div className="space-y-2.5">
              {qOptions.map((opt, i) => {
                const selectedIds = (answers[q.id] || "").split(",").filter(Boolean);
                const selected = selectedIds.includes(opt.id);
                return (
                  <button key={opt.id}
                    onClick={() => {
                      const cur = (answers[q.id] || "").split(",").filter(Boolean);
                      const next = selected ? cur.filter(id => id !== opt.id) : [...cur, opt.id];
                      handleAnswerChange(q.id, next.join(","));
                    }}
                    className={`w-full text-left px-5 py-3.5 rounded-xl border-2 transition-all duration-200 flex items-center gap-3 group
                      ${selected ? "border-primary bg-primary/5 shadow-sm" : "border-border hover:border-primary/40 hover:bg-muted/50"}`}
                  >
                    <span className={`flex items-center justify-center w-6 h-6 rounded-md text-xs font-bold transition-colors border
                      ${selected ? "bg-primary text-primary-foreground border-primary" : "bg-muted text-muted-foreground border-muted-foreground/30"}`}>
                      {selected && <CheckCircle2 className="h-4 w-4" />}
                    </span>
                    <span className={`text-sm ${selected ? "font-medium text-foreground" : "text-foreground/80"}`}>{opt.option_text}</span>
                  </button>
                );
              })}
            </div>
          ) : (
            <Input
              value={answers[q.id] || ""}
              onChange={(e) => handleAnswerChange(q.id, e.target.value)}
              placeholder="Type your answer..."
              className="h-12 text-base rounded-xl"
            />
          )}
        </div>

        {/* Navigation */}
        <div className="px-6 pb-6 flex items-center justify-between">
          <Button variant="outline" onClick={() => setCurrent(p => p - 1)} disabled={current === 0} className="rounded-xl">
            <ChevronLeft className="h-4 w-4 mr-1" /> Previous
          </Button>
          {current < questions.length - 1 ? (
            <Button onClick={() => setCurrent(p => p + 1)} className="rounded-xl">
              Next <ChevronRight className="h-4 w-4 ml-1" />
            </Button>
          ) : (
            <Button onClick={handleSubmit} className="rounded-xl bg-green-600 hover:bg-green-700 text-white">
              <CheckCircle2 className="h-4 w-4 mr-1" /> Submit Quiz
            </Button>
          )}
        </div>

        {/* Question dots */}
        <div className="px-6 pb-5">
          <div className="flex items-center justify-center gap-1.5 flex-wrap">
            {questions.map((_, i) => (
              <button key={i} onClick={() => setCurrent(i)}
                className={`w-8 h-8 rounded-lg text-xs font-medium transition-all
                  ${i === current ? "bg-primary text-primary-foreground shadow-sm" :
                    answers[questions[i].id] ? "bg-primary/20 text-primary" : "bg-muted text-muted-foreground hover:bg-muted/80"}`}
              >
                {i + 1}
              </button>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}

function getMotivation(pct: number) {
  if (pct >= 90) return {
    icon: Trophy, bgClass: "bg-yellow-500/10", iconClass: "text-yellow-500",
    textClass: "text-yellow-700 dark:text-yellow-400",
    title: "🏆 Outstanding!", message: "You've mastered this material. Keep up the excellent work!",
  };
  if (pct >= 80) return {
    icon: Star, bgClass: "bg-green-500/10", iconClass: "text-green-500",
    textClass: "text-green-700 dark:text-green-400",
    title: "⭐ Great Job!", message: "You have a strong understanding. Just a little more to reach perfection!",
  };
  if (pct >= 60) return {
    icon: Zap, bgClass: "bg-blue-500/10", iconClass: "text-blue-500",
    textClass: "text-blue-700 dark:text-blue-400",
    title: "⚡ Good Effort!", message: "You're on the right track. Review the missed questions to improve!",
  };
  return {
    icon: Award, bgClass: "bg-orange-500/10", iconClass: "text-orange-500",
    textClass: "text-orange-700 dark:text-orange-400",
    title: "💪 Keep Going!", message: "Don't give up! Review the material and try again.",
  };
}
