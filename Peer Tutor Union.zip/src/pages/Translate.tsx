import { useState, useCallback, useRef, useEffect } from "react";
import { ArrowLeftRight, Languages, Loader2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";
import { useAuth } from "@/contexts/AuthContext";
import { canUseAI } from "@/lib/roleUtils";
import RestrictedAccess from "@/components/RestrictedAccess";

type Direction = "en2zh" | "zh2en";

export default function Translate() {
  const { displayRole } = useAuth();
  const [source, setSource] = useState("");
  const [result, setResult] = useState("");
  const [direction, setDirection] = useState<Direction>("en2zh");
  const [loading, setLoading] = useState(false);
  const debounceRef = useRef<ReturnType<typeof setTimeout>>();
  const abortRef = useRef<AbortController>();
  const requestIdRef = useRef(0);

  const translate = useCallback(async (text: string, dir: Direction) => {
    if (!text.trim()) { setResult(""); return; }
    
    // Cancel previous request
    abortRef.current?.abort();
    const controller = new AbortController();
    abortRef.current = controller;
    const thisId = ++requestIdRef.current;

    setLoading(true);
    try {
      const { data, error } = await supabase.functions.invoke("translate", {
        body: { text: text.trim(), direction: dir },
      });
      // Ignore stale responses
      if (thisId !== requestIdRef.current) return;
      if (error) throw error;
      if (data?.error) { toast.error(data.error); return; }
      setResult(data?.translation || "");
    } catch (e: any) {
      if (thisId !== requestIdRef.current) return;
      if (e.name !== "AbortError") {
        toast.error(e.message || "Translation failed");
      }
    } finally {
      if (thisId === requestIdRef.current) setLoading(false);
    }
  }, []);

  // Auto-translate with debounce (500ms)
  useEffect(() => {
    if (debounceRef.current) clearTimeout(debounceRef.current);
    if (!source.trim()) { setResult(""); setLoading(false); return; }
    setLoading(true);
    debounceRef.current = setTimeout(() => {
      translate(source, direction);
    }, 500);
    return () => { if (debounceRef.current) clearTimeout(debounceRef.current); };
  }, [source, direction, translate]);

  const toggleDirection = () => {
    const newDir: Direction = direction === "en2zh" ? "zh2en" : "en2zh";
    setDirection(newDir);
    const oldSource = source;
    setSource(result);
    setResult(oldSource);
  };

  const leftLabel = direction === "en2zh" ? "English" : "中文";
  const rightLabel = direction === "en2zh" ? "中文" : "English";

  if (!canUseAI(displayRole)) {
    return <RestrictedAccess message="AI tools are only available to VIP students and staff. Please contact an administrator to upgrade your access." />;
  }

  return (
    <div className="max-w-5xl mx-auto space-y-4">
      <div className="flex items-center gap-3">
        <Languages className="h-6 w-6 text-primary" />
        <h2 className="text-2xl font-bold text-foreground">Translator</h2>
      </div>

      <div className="flex items-center justify-center gap-4">
        <span className="text-sm font-medium text-foreground/80 min-w-[60px] text-right">{leftLabel}</span>
        <Button variant="outline" size="icon" className="rounded-full h-9 w-9" onClick={toggleDirection}>
          <ArrowLeftRight className="h-4 w-4" />
        </Button>
        <span className="text-sm font-medium text-foreground/80 min-w-[60px]">{rightLabel}</span>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div className="space-y-2">
          <label className="text-xs font-medium text-muted-foreground uppercase tracking-wider">{leftLabel}</label>
          <Textarea
            className="min-h-[260px] resize-none text-base"
            placeholder={direction === "en2zh" ? "Paste English text here…" : "在此粘贴中文…"}
            value={source}
            onChange={e => setSource(e.target.value)}
          />
        </div>
        <div className="space-y-2">
          <label className="text-xs font-medium text-muted-foreground uppercase tracking-wider">{rightLabel}</label>
          <div className="min-h-[260px] rounded-lg border border-border/60 bg-card/50 backdrop-blur-sm px-3.5 py-2.5 text-base whitespace-pre-wrap text-foreground/90">
            {loading ? (
              <div className="flex items-center gap-2 text-muted-foreground">
                <Loader2 className="h-4 w-4 animate-spin" /> Translating…
              </div>
            ) : result || <span className="text-muted-foreground/50">Translation will appear here</span>}
          </div>
        </div>
      </div>
    </div>
  );
}
