import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/contexts/AuthContext";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { toast } from "sonner";
import { CalendarClock, X, Send, CalendarDays } from "lucide-react";
import { OTHER_SUBJECT, useSubjectOptions } from "@/lib/subjectOptions";


type TutoringRequest = {
  id: string;
  subject: string;
  session_type: string;
  requested_date: string;
  start_time: string;
  end_time: string;
  tutor_name: string | null;
  location: string | null;
  student_note: string | null;
  admin_note: string | null;
  status: string;
};

const statusVariant: Record<string, "default" | "secondary" | "destructive"> = {
  approved: "default",
  pending: "secondary",
  rejected: "destructive",
};

type TutorCourse = {
  id: string;
  subject: string;
  requested_date: string;
  start_time: string;
  end_time: string;
  tutor_name: string | null;
  location: string | null;
  enrolled: number;
  already_requested: boolean;
};

export default function Tutoring() {
  const { user } = useAuth();
  const [busy, setBusy] = useState<string | null>(null);
  const [requests, setRequests] = useState<TutoringRequest[]>([]);
  const [tutors, setTutors] = useState<string[]>([]);
  const [courses, setCourses] = useState<TutorCourse[]>([]);
  const [courseId, setCourseId] = useState("");
  const [submitting, setSubmitting] = useState(false);
  const [open, setOpen] = useState(false);
  const [reqType, setReqType] = useState<"tutorial" | "student">("tutorial");
  const { subjectNames, reload: reloadSubjects } = useSubjectOptions();
  const [customSubject, setCustomSubject] = useState(false);
  const [req, setReq] = useState({
    subject: "", session_type: "tutorial", requested_date: "",
    start_time: "15:00", end_time: "16:00", tutor_name: "", student_note: "",
  });

  const load = async () => {
    const { data } = await supabase
      .from("tutoring_requests").select("*").eq("user_id", user?.id ?? "")
      .order("requested_date", { ascending: true });
    setRequests((data as TutoringRequest[]) || []);
  };

  const loadTutors = async () => {
    const { data } = await supabase
      .from("profiles").select("name").eq("display_role", "Teacher").order("name");
    setTutors(((data as { name: string }[]) || []).map((t) => t.name).filter(Boolean));
  };

  const loadCourses = async () => {
    const { data } = await supabase.rpc("list_tutor_courses" as any);
    setCourses((data as TutorCourse[]) || []);
  };

  const submitRequest = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user) return;

    if (reqType === "student") {
      const course = courses.find((c) => c.id === courseId);
      if (!course) return toast.error("Please pick a tutor course");
      setSubmitting(true);
      const { error } = await supabase.from("tutoring_requests").insert({
        user_id: user.id,
        subject: course.subject,
        session_type: "student",
        requested_date: course.requested_date,
        start_time: course.start_time,
        end_time: course.end_time,
        tutor_name: course.tutor_name,
        location: course.location,
        student_note: req.student_note || null,
        parent_request_id: course.id,
        status: "pending",
      } as any);
      setSubmitting(false);
      if (error) return toast.error(error.message);
      toast.success("Join request submitted — waiting for approval");
      setCourseId("");
      setReq({ ...req, student_note: "" });
      setOpen(false);
      load();
      loadCourses();
      return;
    }

    if (!req.subject) return toast.error("Please pick a subject");
    setSubmitting(true);
    const { error } = await supabase.from("tutoring_requests").insert({
      user_id: user.id,
      subject: req.subject,
      session_type: "tutorial",
      requested_date: req.requested_date,
      start_time: req.start_time,
      end_time: req.end_time,
      tutor_name: req.tutor_name || null,
      student_note: req.student_note || null,
    } as any);
    setSubmitting(false);
    if (error) return toast.error(error.message);
    toast.success("Request submitted — waiting for approval");
    setReq({ ...req, subject: "", tutor_name: "", student_note: "" });
    setOpen(false);
    load();
  };

  const cancelRequest = async (id: string) => {
    setBusy(id);
    const { error } = await supabase.from("tutoring_requests").delete().eq("id", id);
    setBusy(null);
    if (error) return toast.error(error.message);
    toast.success("Request cancelled");
    load();
    loadCourses();
  };

  useEffect(() => { if (user) { load(); loadTutors(); loadCourses(); } }, [user]);


  return (
    <div className="max-w-5xl mx-auto space-y-6">
      <div className="flex flex-wrap items-start justify-between gap-3">
        <div>
          <h1 className="text-2xl font-bold text-foreground flex items-center gap-2">
            <CalendarClock className="h-6 w-6 text-primary" /> Tutoring & Study Groups
          </h1>
          <p className="text-sm text-muted-foreground">Request a tutorial with your own date and time — staff will approve or adjust it.</p>
        </div>
        <Dialog open={open} onOpenChange={(o) => { setOpen(o); if (o) { loadCourses(); reloadSubjects(); } }}>
          <DialogTrigger asChild>
            <Button><Send className="h-4 w-4 mr-1" /> Submit Request</Button>
          </DialogTrigger>
          <DialogContent className="max-w-2xl">
            <DialogHeader>
              <DialogTitle>Submit a Request</DialogTitle>
              <DialogDescription>Request your own tutorial, or join an existing tutor course as a student.</DialogDescription>
            </DialogHeader>
            <form onSubmit={submitRequest} className="grid gap-4 md:grid-cols-2">
              <div className="md:col-span-2">
                <Label>Type</Label>
                <Select value={reqType} onValueChange={(v) => setReqType(v as "tutorial" | "student")}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="tutorial">Tutorial — request a new session</SelectItem>
                    <SelectItem value="student">Student — join an existing tutor course</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              {reqType === "student" ? (
                <div className="md:col-span-2">
                  <Label>Tutor course</Label>
                  <Select value={courseId} onValueChange={setCourseId}>
                    <SelectTrigger><SelectValue placeholder={courses.length ? "Select a course" : "No courses available yet"} /></SelectTrigger>
                    <SelectContent>
                      {courses.map((c) => (
                        <SelectItem key={c.id} value={c.id} disabled={c.already_requested}>
                          {c.subject} · {c.requested_date} {c.start_time}–{c.end_time}
                          {c.tutor_name ? ` · ${c.tutor_name}` : ""}
                          {c.location ? ` · ${c.location}` : ""}
                          {` · ${c.enrolled} enrolled`}
                          {c.already_requested ? " · already requested" : ""}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              ) : (
                <>
                  <div>
                    <Label>Subject</Label>
                    {customSubject ? (
                      <div className="flex gap-2">
                        <Input
                          value={req.subject}
                          placeholder="Type a subject"
                          onChange={(e) => setReq({ ...req, subject: e.target.value })}
                        />
                        <Button type="button" variant="outline" onClick={() => { setCustomSubject(false); setReq({ ...req, subject: "" }); }}>
                          List
                        </Button>
                      </div>
                    ) : (
                      <Select
                        value={req.subject}
                        onValueChange={(v) => {
                          if (v === OTHER_SUBJECT) { setCustomSubject(true); setReq({ ...req, subject: "" }); return; }
                          setReq({ ...req, subject: v });
                        }}
                      >
                        <SelectTrigger><SelectValue placeholder="Select a subject" /></SelectTrigger>
                        <SelectContent>
                          {subjectNames.map((s) => <SelectItem key={s} value={s}>{s}</SelectItem>)}
                          <SelectItem value={OTHER_SUBJECT}>Other subject…</SelectItem>
                        </SelectContent>
                      </Select>
                    )}
                  </div>
                  <div><Label>Date</Label><Input type="date" value={req.requested_date} onChange={(e) => setReq({ ...req, requested_date: e.target.value })} required /></div>
                  <div>
                    <Label>Preferred tutor (optional)</Label>
                    <Select value={req.tutor_name} onValueChange={(v) => setReq({ ...req, tutor_name: v === "__any" ? "" : v })}>
                      <SelectTrigger><SelectValue placeholder="Any available tutor" /></SelectTrigger>
                      <SelectContent>
                        <SelectItem value="__any">Any available tutor</SelectItem>
                        {tutors.map((t) => <SelectItem key={t} value={t}>{t}</SelectItem>)}
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="grid grid-cols-2 gap-2">
                    <div><Label>Start</Label><Input type="time" value={req.start_time} onChange={(e) => setReq({ ...req, start_time: e.target.value })} required /></div>
                    <div><Label>End</Label><Input type="time" value={req.end_time} onChange={(e) => setReq({ ...req, end_time: e.target.value })} required /></div>
                  </div>
                </>
              )}

              <div className="md:col-span-2"><Label>Note (optional)</Label><Textarea rows={2} value={req.student_note} onChange={(e) => setReq({ ...req, student_note: e.target.value })} placeholder="What do you need help with?" /></div>
              <div className="md:col-span-2">
                <Button type="submit" disabled={submitting} className="w-full">
                  <Send className="h-4 w-4 mr-1" /> {submitting ? "Submitting..." : "Submit Request"}
                </Button>
              </div>
            </form>
          </DialogContent>

        </Dialog>
      </div>

      <Card className="glass-card">
        <CardHeader>
          <CardTitle className="text-base flex items-center gap-2"><CalendarDays className="h-4 w-4 text-primary" /> My Schedule</CardTitle>
          <CardDescription>Approved sessions and pending requests</CardDescription>
        </CardHeader>
        <CardContent>
          {requests.length === 0 ? (
            <p className="text-sm text-muted-foreground">No requests yet.</p>
          ) : (
            <Table>
              <TableHeader>
                <TableRow><TableHead>Date</TableHead><TableHead>Time</TableHead><TableHead>Subject</TableHead><TableHead>Type</TableHead><TableHead>Tutor</TableHead><TableHead>Location</TableHead><TableHead>Status</TableHead><TableHead>Note</TableHead><TableHead /></TableRow>
              </TableHeader>
              <TableBody>
                {requests.map((r) => (
                  <TableRow key={r.id}>
                    <TableCell>{r.requested_date}</TableCell>
                    <TableCell>{r.start_time}–{r.end_time}</TableCell>
                    <TableCell>{r.subject}</TableCell>
                    <TableCell>{r.session_type === "tutorial" ? "Tutorial" : r.session_type === "student" ? "Student" : "Study Group"}</TableCell>
                    <TableCell>{r.tutor_name || "—"}</TableCell>
                    <TableCell>{r.location || "—"}</TableCell>
                    <TableCell><Badge variant={statusVariant[r.status] || "secondary"}>{r.status}</Badge></TableCell>
                    <TableCell className="text-xs text-muted-foreground">{r.admin_note || r.student_note || "—"}</TableCell>
                    <TableCell>
                      {r.status === "pending" && (
                        <Button size="sm" variant="outline" disabled={busy === r.id} onClick={() => cancelRequest(r.id)}>
                          <X className="h-4 w-4" />
                        </Button>
                      )}
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          )}
        </CardContent>
      </Card>

    </div>
  );
}

