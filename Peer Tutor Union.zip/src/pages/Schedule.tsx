import { useEffect, useMemo, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/contexts/AuthContext";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent } from "@/components/ui/card";
import { ChevronLeft, ChevronRight, CalendarDays, GraduationCap, MapPin, User } from "lucide-react";
import { Link } from "react-router-dom";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { toast } from "@/hooks/use-toast";

type Kind = "tutorial" | "event" | "group";

/** What can be edited on the underlying record. */
type EditKind = "group_session" | "group_recurring" | "tutorial_request";

type Item = {
  id: string;
  title: string;
  subtitle?: string | null;
  location?: string | null;
  person?: string | null;
  start: Date;
  end: Date;
  kind: Kind;
  sessionId?: string;
  editable?: boolean;
  editKind?: EditKind;
  refId?: string;
};

type Recurring = {
  id: string;
  title: string;
  subtitle?: string | null;
  location?: string | null;
  person?: string | null;
  dow: number; // 0 = Monday
  startMin: number;
  endMin: number;
  kind: Kind;
  editable?: boolean;
  editKind?: EditKind;
  refId?: string;
};

const DOW_NAMES = ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"];

const DAY_START = 8;
const DAY_END = 21;
const HOUR_PX = 56;

function startOfWeek(d: Date) {
  const date = new Date(d);
  const day = (date.getDay() + 6) % 7; // Monday first
  date.setDate(date.getDate() - day);
  date.setHours(0, 0, 0, 0);
  return date;
}

function parseTime(dateStr: string, timeStr: string | null, fallbackHour: number) {
  const [y, m, d] = dateStr.split("-").map(Number);
  const [hh, mm] = (timeStr || "").split(":").map(Number);
  return new Date(y, (m || 1) - 1, d || 1, isNaN(hh) ? fallbackHour : hh, isNaN(mm) ? 0 : mm);
}

const DOW_PATTERNS: [RegExp, number][] = [
  [/mon|周一|星期一|礼拜一/i, 0],
  [/tue|周二|星期二|礼拜二/i, 1],
  [/wed|周三|星期三|礼拜三/i, 2],
  [/thu|周四|星期四|礼拜四/i, 3],
  [/fri|周五|星期五|礼拜五/i, 4],
  [/sat|周六|星期六|礼拜六/i, 5],
  [/sun|周日|周天|星期日|星期天|礼拜天/i, 6],
];

function parseDow(text: string | null | undefined): number | null {
  if (!text) return null;
  for (const [re, i] of DOW_PATTERNS) if (re.test(text)) return i;
  return null;
}

function toMinutes(t: string | null | undefined, fallback: number) {
  if (!t) return fallback;
  const m = t.match(/(\d{1,2})[:：](\d{2})/);
  if (!m) return fallback;
  return Number(m[1]) * 60 + Number(m[2]);
}

function parseTimeRange(text: string | null | undefined) {
  const matches = (text || "").match(/(\d{1,2})[:：](\d{2})/g) || [];
  if (matches.length === 0) return { startMin: 16 * 60, endMin: 17 * 60 };
  const startMin = toMinutes(matches[0], 16 * 60);
  const endMin = matches[1] ? toMinutes(matches[1], startMin + 60) : startMin + 60;
  return { startMin, endMin: Math.max(endMin, startMin + 30) };
}

export default function Schedule() {
  const { user, isAdmin, displayRole, profile } = useAuth();
  const [weekStart, setWeekStart] = useState(() => startOfWeek(new Date()));
  const [items, setItems] = useState<Item[]>([]);
  const [recurring, setRecurring] = useState<Recurring[]>([]);
  const [loading, setLoading] = useState(true);
  const [selected, setSelected] = useState<Item | null>(null);

  // Only admins (President) see everyone's schedule. Teachers see the sessions they tutor.
  const isAdminView = isAdmin || displayRole === "President";
  const isTeacher = displayRole === "Teacher";
  const canManageGroups =
    isAdmin || ["President", "Vice President", "VicePresident"].includes(String(displayRole));
  const [saving, setSaving] = useState(false);
  const [reloadKey, setReloadKey] = useState(0);
  const [editDate, setEditDate] = useState("");
  const [editStart, setEditStart] = useState("");
  const [editEnd, setEditEnd] = useState("");
  const [editLocation, setEditLocation] = useState("");
  const [editDow, setEditDow] = useState(0);
  const myName = profile?.name ?? "";

  useEffect(() => {
    const load = async () => {
      setLoading(true);
      const uid = user?.id ?? "";
      let q = supabase.from("tutoring_requests").select("*").eq("status", "approved");
      if (!isAdminView) {
        q = isTeacher && myName
          ? q.or(`user_id.eq.${uid},tutor_name.eq.${myName.replace(/[,()]/g, "")}`)
          : q.eq("user_id", uid);
      }

      let bq = supabase
        .from("tutoring_bookings")
        .select("*, tutoring_slots(*)")
        .eq("status", "approved");
      if (!isAdminView) bq = bq.eq("user_id", uid);

      const [reqRes, eventsRes, bookingRes, memberRes, ownedRes, allGroupRes] = await Promise.all([
        q,
        supabase.from("events").select("*").not("event_date", "is", null),
        bq,
        supabase.from("study_group_members").select("group_id, study_groups(*)").eq("user_id", uid),
        supabase.from("study_groups").select("*").eq("creator_id", uid),
        isAdminView ? supabase.from("study_groups").select("*") : Promise.resolve({ data: [] as any[] }),
      ]);

      // Resolve names of the people the sessions belong to (admin view shows them)
      const ownerIds = new Set<string>();
      ((reqRes.data as any[]) || []).forEach((r) => r.user_id && ownerIds.add(r.user_id));
      ((bookingRes.data as any[]) || []).forEach((b) => b.user_id && ownerIds.add(b.user_id));
      ((allGroupRes.data as any[]) || []).forEach((g) => g.creator_id && ownerIds.add(g.creator_id));
      const nameMap = new Map<string, string>();
      if (ownerIds.size > 0) {
        const { data: profs } = await supabase
          .from("profiles")
          .select("user_id, name")
          .in("user_id", [...ownerIds]);
        ((profs as any[]) || []).forEach((p) => nameMap.set(p.user_id, p.name));
      }

      const list: Item[] = [];
      const rec: Recurring[] = [];

      ((reqRes.data as any[]) || []).forEach((r) => {
        list.push({
          id: `t-${r.id}`,
          title: r.subject,
          subtitle: r.tutor_name ? `Tutor: ${r.tutor_name}` : r.session_type === "study_group" ? "Study Group" : "Tutorial",
          location: r.location,
          person: nameMap.get(r.user_id) || null,
          start: parseTime(r.requested_date, r.start_time, 15),
          end: parseTime(r.requested_date, r.end_time, 16),
          kind: "tutorial",
          editable: canManageGroups,
          editKind: "tutorial_request",
          refId: r.id,
        });
      });

      ((eventsRes.data as any[]) || []).forEach((e) => {
        const s = new Date(e.event_date);
        list.push({
          id: `e-${e.id}`,
          title: e.title,
          subtitle: "Activity",
          location: e.location,
          start: s,
          end: new Date(s.getTime() + 60 * 60 * 1000),
          kind: "event",
        });
      });

      ((bookingRes.data as any[]) || []).forEach((b) => {
        const s = b.tutoring_slots;
        if (!s) return;
        const dow = parseDow(s.day_of_week);
        if (dow === null) return;
        rec.push({
          id: `b-${b.id}`,
          title: s.subject,
          subtitle: s.tutor_name ? `Tutor: ${s.tutor_name}` : s.session_type === "study_group" ? "Study Group" : "Tutorial",
          location: s.location,
          person: nameMap.get(b.user_id) || null,
          dow,
          startMin: toMinutes(s.start_time, 16 * 60),
          endMin: toMinutes(s.end_time, 17 * 60),
          kind: "tutorial",
        });
      });

      const groups = new Map<string, any>();
      ((memberRes.data as any[]) || []).forEach((m) => m.study_groups && groups.set(m.study_groups.id, m.study_groups));
      ((ownedRes.data as any[]) || []).forEach((g) => groups.set(g.id, g));
      ((allGroupRes.data as any[]) || []).forEach((g) => groups.set(g.id, g));
      groups.forEach((g) => {
        if (g.status && g.status !== "active") return;
        if (g.expires_at && new Date(g.expires_at) < new Date()) return;
        const dow = parseDow(g.meeting_time) ?? parseDow(g.frequency);
        if (dow === null) return;
        const { startMin, endMin } = parseTimeRange(g.meeting_time);
        rec.push({
          id: `g-${g.id}`,
          title: g.title,
          subtitle: `Study Group · ${g.subject}`,
          location: g.location,
          person: nameMap.get(g.creator_id) || null,
          dow,
          startMin,
          endMin,
          kind: "group",
          editable: canManageGroups || g.creator_id === uid,
          editKind: "group_recurring",
          refId: g.id,
        });
      });

      const groupIds = [...groups.keys()];
      if (groupIds.length > 0) {
        const { data: gs } = await supabase
          .from("study_group_sessions")
          .select("*")
          .in("group_id", groupIds);
        ((gs as any[]) || []).forEach((s) => {
          const g = groups.get(s.group_id);
          list.push({
            id: `gs-${s.id}`,
            title: g?.title || "Study Group",
            subtitle: g?.subject ? `Study Group · ${g.subject}` : "Study Group",
            location: s.location || g?.location || null,
            person: g?.creator_id ? nameMap.get(g.creator_id) || null : null,
            start: parseTime(s.session_date, s.start_time, 16),
            end: parseTime(s.session_date, s.end_time, 17),
            kind: "group",
            sessionId: s.id,
            editable: canManageGroups || g?.creator_id === uid,
            editKind: "group_session",
            refId: s.id,
          });
        });
      }

      setItems(list);
      setRecurring(rec);
      setLoading(false);

    };
    if (user) load();
  }, [user, isAdminView, isTeacher, myName, canManageGroups, reloadKey]);

  useEffect(() => {
    if (selected?.editable) {
      const pad = (n: number) => String(n).padStart(2, "0");
      setEditDate(`${selected.start.getFullYear()}-${pad(selected.start.getMonth() + 1)}-${pad(selected.start.getDate())}`);
      setEditStart(`${pad(selected.start.getHours())}:${pad(selected.start.getMinutes())}`);
      setEditEnd(`${pad(selected.end.getHours())}:${pad(selected.end.getMinutes())}`);
      setEditLocation(selected.location || "");
      setEditDow((selected.start.getDay() + 6) % 7);
    }
  }, [selected]);

  const saveSession = async () => {
    if (!selected?.refId || !selected.editKind) return;
    setSaving(true);
    let error: { message: string } | null = null;

    if (selected.editKind === "group_session") {
      ({ error } = await supabase
        .from("study_group_sessions")
        .update({ session_date: editDate, start_time: editStart, end_time: editEnd, location: editLocation || null })
        .eq("id", selected.refId));
    } else if (selected.editKind === "group_recurring") {
      ({ error } = await supabase
        .from("study_groups")
        .update({ meeting_time: `${DOW_NAMES[editDow]} ${editStart}-${editEnd}`, location: editLocation || null })
        .eq("id", selected.refId));
    } else {
      ({ error } = await supabase
        .from("tutoring_requests")
        .update({ requested_date: editDate, start_time: editStart, end_time: editEnd, location: editLocation || null })
        .eq("id", selected.refId));
    }

    setSaving(false);
    if (error) {
      toast({ title: "无法保存", description: error.message, variant: "destructive" });
      return;
    }
    toast({ title: "日程已更新" });
    setSelected(null);
    setReloadKey((k) => k + 1);
  };


  const days = useMemo(
    () => Array.from({ length: 7 }, (_, i) => {
      const d = new Date(weekStart);
      d.setDate(d.getDate() + i);
      return d;
    }),
    [weekStart]
  );

  const weekEnd = useMemo(() => {
    const d = new Date(weekStart);
    d.setDate(d.getDate() + 7);
    return d;
  }, [weekStart]);

  const expand = (from: Date, weeks: number): Item[] =>
    Array.from({ length: weeks }, (_, w) => w).flatMap((w) =>
      recurring.map((r) => {
        const d = new Date(from);
        d.setDate(d.getDate() + w * 7 + r.dow);
        const start = new Date(d);
        start.setHours(0, r.startMin, 0, 0);
        const end = new Date(d);
        end.setHours(0, r.endMin, 0, 0);
        return {
          id: `${r.id}-${w}`, title: r.title, subtitle: r.subtitle, location: r.location, person: r.person,
          start, end, kind: r.kind, editable: r.editable, editKind: r.editKind, refId: r.refId,
        };
      })
    );

  const weekItems = [...items.filter((i) => i.start >= weekStart && i.start < weekEnd), ...expand(weekStart, 1)];
  const upcoming = [...items, ...expand(startOfWeek(new Date()), 4)]
    .filter((i) => i.end >= new Date())
    .sort((a, b) => a.start.getTime() - b.start.getTime())
    .slice(0, 5);


  const today = new Date();
  const shift = (n: number) => {
    const d = new Date(weekStart);
    d.setDate(d.getDate() + n * 7);
    setWeekStart(d);
  };

  return (
    <div className="space-y-4">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <h1 className="text-xl font-semibold tracking-tight text-foreground flex items-center gap-2">
            <CalendarDays className="h-5 w-5 text-primary" /> Schedule
          </h1>
          <p className="text-sm text-muted-foreground">
            {weekStart.toLocaleDateString(undefined, { month: "long", day: "numeric" })} –{" "}
            {days[6].toLocaleDateString(undefined, { month: "long", day: "numeric", year: "numeric" })}
          </p>
        </div>
        <div className="flex items-center gap-2">
          <Button variant="outline" size="icon" onClick={() => shift(-1)}><ChevronLeft className="h-4 w-4" /></Button>
          <Button variant="outline" size="sm" onClick={() => setWeekStart(startOfWeek(new Date()))}>Today</Button>
          <Button variant="outline" size="icon" onClick={() => shift(1)}><ChevronRight className="h-4 w-4" /></Button>
          <Button asChild size="sm"><Link to="/tutoring">Book a session</Link></Button>
        </div>
      </div>

      <Card className="glass-card overflow-hidden">
        <CardContent className="p-0">
          <div className="overflow-x-auto">
            <div className="min-w-[720px]">
              {/* header row */}
              <div className="grid" style={{ gridTemplateColumns: `60px repeat(7, minmax(0,1fr))` }}>
                <div className="border-b border-border/60" />
                {days.map((d) => {
                  const isToday = d.toDateString() === today.toDateString();
                  return (
                    <div key={d.toISOString()} className={`border-b border-l border-border/60 px-2 py-2 text-center ${isToday ? "bg-primary/5" : ""}`}>
                      <div className="text-[11px] uppercase tracking-wide text-muted-foreground">
                        {d.toLocaleDateString(undefined, { weekday: "short" })}
                      </div>
                      <div className={`text-sm font-semibold ${isToday ? "text-primary" : "text-foreground"}`}>{d.getDate()}</div>
                    </div>
                  );
                })}
              </div>
              {/* grid */}
              <div className="grid relative" style={{ gridTemplateColumns: `60px repeat(7, minmax(0,1fr))` }}>
                <div>
                  {Array.from({ length: DAY_END - DAY_START }, (_, i) => (
                    <div key={i} className="text-[11px] text-muted-foreground pr-2 text-right" style={{ height: HOUR_PX }}>
                      {String(DAY_START + i).padStart(2, "0")}:00
                    </div>
                  ))}
                </div>
                {days.map((d) => {
                  const dayItems = weekItems.filter((i) => i.start.toDateString() === d.toDateString());
                  return (
                    <div key={d.toISOString()} className="relative border-l border-border/60">
                      {Array.from({ length: DAY_END - DAY_START }, (_, i) => (
                        <div key={i} className="border-b border-border/40" style={{ height: HOUR_PX }} />
                      ))}
                      {dayItems.map((it) => {
                        const startH = it.start.getHours() + it.start.getMinutes() / 60;
                        const endH = it.end.getHours() + it.end.getMinutes() / 60;
                        const top = (Math.max(startH, DAY_START) - DAY_START) * HOUR_PX;
                        const height = Math.max((Math.min(endH, DAY_END) - Math.max(startH, DAY_START)) * HOUR_PX, 42);
                        const compact = height < 44;
                        return (
                          <button
                            type="button"
                            key={it.id}
                            onClick={() => setSelected(it)}
                            className={`absolute left-1 right-1 z-10 rounded-lg px-2 py-1 text-left text-[11px] leading-tight shadow-sm backdrop-blur-sm overflow-hidden transition-transform hover:scale-[1.02] ${
                              it.kind === "tutorial"
                                ? "bg-primary/15 border border-primary/30 text-foreground"
                                : it.kind === "group"
                                  ? "bg-secondary/60 border border-secondary text-foreground"
                                  : "bg-accent/40 border border-accent text-foreground"

                            }`}
                            style={{ top, height }}
                          >
                            <div className="font-semibold truncate">{it.title}</div>
                            {!compact && (
                              <div className="text-muted-foreground truncate">
                                {it.start.toLocaleTimeString(undefined, { hour: "2-digit", minute: "2-digit" })}
                                {it.subtitle ? ` · ${it.subtitle}` : ""}
                              </div>
                            )}
                          </button>
                        );
                      })}

                    </div>
                  );
                })}
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      <Card className="glass-card">
        <CardContent className="p-4 space-y-3">
          <h2 className="text-sm font-semibold text-foreground">Upcoming</h2>
          {loading ? (
            <p className="text-sm text-muted-foreground">Loading...</p>
          ) : upcoming.length === 0 ? (
            <p className="text-sm text-muted-foreground">Nothing scheduled yet.</p>
          ) : (
            upcoming.map((it) => (
              <button type="button" onClick={() => setSelected(it)} key={it.id} className="w-full text-left flex items-center gap-3 rounded-xl border border-border/60 px-3 py-2 transition-colors hover:bg-muted/40">
                <div className="text-center min-w-12">
                  <div className="text-[10px] uppercase text-muted-foreground">{it.start.toLocaleDateString(undefined, { month: "short" })}</div>
                  <div className="text-base font-semibold text-foreground">{it.start.getDate()}</div>
                </div>
                <div className="min-w-0 flex-1">
                  <p className="text-sm font-medium truncate flex items-center gap-1.5">
                    <GraduationCap className="h-3.5 w-3.5 text-primary" /> {it.title}
                  </p>
                  <p className="text-xs text-muted-foreground truncate">
                    {it.start.toLocaleTimeString(undefined, { hour: "2-digit", minute: "2-digit" })} –{" "}
                    {it.end.toLocaleTimeString(undefined, { hour: "2-digit", minute: "2-digit" })}
                    {it.location ? ` · ${it.location}` : ""}
                  </p>
                </div>
                <Badge variant={it.kind === "tutorial" ? "default" : "secondary"}>
                  {it.kind === "tutorial" ? "Session" : it.kind === "group" ? "Study Group" : "Activity"}
                </Badge>

              </button>
            ))
          )}
        </CardContent>
      </Card>

      <Dialog open={!!selected} onOpenChange={(o) => !o && setSelected(null)}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              {selected?.kind === "event" ? <CalendarDays className="h-4 w-4 text-primary" /> : <GraduationCap className="h-4 w-4 text-primary" />}
              {selected?.title}
            </DialogTitle>
          </DialogHeader>
          {selected && (
            <div className="space-y-3 text-sm">
              <Badge variant={selected.kind === "tutorial" ? "default" : "secondary"}>
                {selected.kind === "tutorial" ? "Tutoring session" : selected.kind === "group" ? "Study group" : "Activity"}
              </Badge>
              <div className="flex items-start gap-2">
                <CalendarDays className="h-4 w-4 mt-0.5 text-muted-foreground" />
                <div>
                  <p className="font-medium">
                    {selected.start.toLocaleDateString(undefined, { weekday: "long", month: "long", day: "numeric", year: "numeric" })}
                  </p>
                  <p className="text-muted-foreground">
                    {selected.start.toLocaleTimeString(undefined, { hour: "2-digit", minute: "2-digit" })} –{" "}
                    {selected.end.toLocaleTimeString(undefined, { hour: "2-digit", minute: "2-digit" })}
                  </p>
                </div>
              </div>
              <div className="flex items-start gap-2">
                <MapPin className="h-4 w-4 mt-0.5 text-muted-foreground" />
                <p>{selected.location || "Location TBD"}</p>
              </div>
              {(isAdminView || isTeacher) && selected.person && (
                <div className="flex items-start gap-2">
                  <User className="h-4 w-4 mt-0.5 text-muted-foreground" />
                  <p>{selected.kind === "group" ? `Organizer: ${selected.person}` : `Student: ${selected.person}`}</p>
                </div>
              )}
              {selected.subtitle && (
                <div className="flex items-start gap-2">
                  <GraduationCap className="h-4 w-4 mt-0.5 text-muted-foreground" />
                  <p>{selected.subtitle}</p>
                </div>
              )}
              {selected.editable && selected.refId && (
                <div className="space-y-2 rounded-xl border border-border/60 p-3">
                  <p className="text-sm font-medium">
                    {selected.editKind === "group_recurring"
                      ? "修改小组固定时间"
                      : selected.editKind === "tutorial_request"
                        ? "修改课程安排"
                        : "修改小组讨论时间"}
                  </p>
                  <div className="grid grid-cols-3 gap-2">
                    <div className="space-y-1">
                      <Label className="text-xs">{selected.editKind === "group_recurring" ? "星期" : "日期"}</Label>
                      {selected.editKind === "group_recurring" ? (
                        <select
                          className="h-10 w-full rounded-md border border-input bg-background px-2 text-sm"
                          value={editDow}
                          onChange={(e) => setEditDow(Number(e.target.value))}
                        >
                          {DOW_NAMES.map((d, i) => <option key={d} value={i}>{d}</option>)}
                        </select>
                      ) : (
                        <Input type="date" value={editDate} onChange={(e) => setEditDate(e.target.value)} />
                      )}
                    </div>
                    <div className="space-y-1">
                      <Label className="text-xs">开始</Label>
                      <Input type="time" value={editStart} onChange={(e) => setEditStart(e.target.value)} />
                    </div>
                    <div className="space-y-1">
                      <Label className="text-xs">结束</Label>
                      <Input type="time" value={editEnd} onChange={(e) => setEditEnd(e.target.value)} />
                    </div>
                  </div>
                  <div className="space-y-1">
                    <Label className="text-xs">地点</Label>
                    <Input value={editLocation} onChange={(e) => setEditLocation(e.target.value)} placeholder="地点" />
                  </div>
                  <Button size="sm" className="w-full" disabled={saving} onClick={saveSession}>
                    {saving ? "保存中..." : "保存修改"}
                  </Button>
                </div>
              )}
              <Button asChild variant="outline" size="sm" className="w-full">
                <Link to={selected.kind === "event" ? "/events" : "/tutoring"}>
                  {selected.kind === "event" ? "View activities" : "Open Tutoring"}
                </Link>
              </Button>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </div>

  );
}
