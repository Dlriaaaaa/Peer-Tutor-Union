import { Navigate } from "react-router-dom";
import { useAuth } from "@/contexts/AuthContext";
import logo from "@/assets/logo-dark.png";

const Index = () => {
  const { user, loading } = useAuth();

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-background">
        <img src={logo} alt="Loading" className="h-16 w-16 animate-pulse" />
      </div>
    );
  }

  if (user) return <Navigate to="/schedule" replace />;
  return <Navigate to="/login" replace />;
};

export default Index;
