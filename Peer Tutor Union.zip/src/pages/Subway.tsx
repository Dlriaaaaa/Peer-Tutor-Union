import { useNavigate } from "react-router-dom";
import SubwayRunner from "@/components/games/SubwayRunner";

export default function Subway() {
  const navigate = useNavigate();
  return (
    <div className="py-4">
      <SubwayRunner onBack={() => navigate(-1)} />
    </div>
  );
}
