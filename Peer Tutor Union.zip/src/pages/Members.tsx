import { useState, useEffect } from "react";
import { supabase } from "@/integrations/supabase/client";
import { Link } from "react-router-dom";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Users, Search } from "lucide-react";
import { getRoleBorderClass } from "@/lib/roleUtils";

type Member = {
  user_id: string;
  name: string;
  avatar_url: string | null;
  bio: string;
  role?: string;
  display_role?: string;
};

export default function Members() {
  const [members, setMembers] = useState<Member[]>([]);
  const [search, setSearch] = useState("");
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetch = async () => {
      const { data: profiles } = await supabase.from("profiles").select("*").order("name");
      const { data: roles } = await supabase.from("user_roles").select("user_id, role");
      const roleMap = new Map(roles?.map((r) => [r.user_id, r.role]) || []);
      setMembers(
        (profiles || []).map((p: any) => ({ ...p, role: roleMap.get(p.user_id) || "student", display_role: p.display_role || "Student" }))
      );
      setLoading(false);
    };
    fetch();
  }, []);

  const roleOrder: Record<string, number> = {
    President: 0, VicePresident: 1, Teacher: 2, GeneralSecretary: 3, Student: 4,
  };
  const filtered = members
    .filter((m) => m.name.toLowerCase().includes(search.toLowerCase()))
    .sort((a, b) => (roleOrder[a.display_role || "Student"] ?? 4) - (roleOrder[b.display_role || "Student"] ?? 4));

  if (loading) return <div className="flex items-center justify-center py-12 text-muted-foreground">Loading...</div>;

  return (
    <div className="max-w-4xl mx-auto space-y-6">
      <div className="flex items-center justify-between">
        <h2 className="text-2xl font-bold text-foreground">Members</h2>
        <div className="relative w-64">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <Input placeholder="Search members..." value={search} onChange={(e) => setSearch(e.target.value)} className="pl-9" />
        </div>
      </div>

      {filtered.length === 0 ? (
        <Card>
          <CardContent className="py-12 text-center text-muted-foreground">
            <Users className="h-12 w-12 mx-auto mb-4 opacity-40" />
            <p>No members found.</p>
          </CardContent>
        </Card>
      ) : (
        <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
          {filtered.map((m) => (
            <Link key={m.user_id} to={`/profile/${m.user_id}`}>
              <Card className="hover:shadow-md transition-shadow cursor-pointer">
                <CardContent className="flex items-center gap-4 py-4">
                  <Avatar className={`h-12 w-12 ${getRoleBorderClass(m.display_role)}`}>
                    <AvatarImage src={m.avatar_url || undefined} />
                    <AvatarFallback>{m.name.charAt(0).toUpperCase()}</AvatarFallback>
                  </Avatar>
                  <div className="flex-1 min-w-0">
                    <p className="font-medium text-foreground truncate">{m.name}</p>
                    <Badge variant={m.display_role !== "Student" ? "default" : "secondary"} className="mt-1">
                      {{ President: "President", VicePresident: "Vice President", Teacher: "Teacher", GeneralSecretary: "General Secretary", Student: "Student" }[m.display_role || "Student"] || m.display_role}
                    </Badge>
                  </div>
                </CardContent>
              </Card>
            </Link>
          ))}
        </div>
      )}
    </div>
  );
}
