import { useState, useEffect } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/contexts/AuthContext";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { BarChart3, ChevronDown, ChevronRight } from "lucide-react";

type Category = { id: string; name: string; weight: number };
type Assignment = { id: string; name: string; max_score: number; category_id: string };
type Score = { assignment_id: string; score: number };

function CategorySection({ cat, children, avg }: {
  cat: Category; children: React.ReactNode; avg: number | null;
}) {
  const [open, setOpen] = useState(false);
  return (
    <Card>
      <button
        onClick={() => setOpen(!open)}
        className="w-full flex items-center justify-between px-6 py-4 text-left transition-colors hover:bg-muted/40 rounded-t-lg"
      >
        <div className="flex items-center gap-2">
          <span className="text-muted-foreground">
            {open ? <ChevronDown className="h-4 w-4" /> : <ChevronRight className="h-4 w-4" />}
          </span>
          <span className="font-semibold text-foreground">{cat.name} ({cat.weight}%)</span>
        </div>
        <div className="flex items-center gap-2">
          {avg !== null && <Badge variant={avg >= 90 ? "default" : "secondary"}>{avg.toFixed(2)}%</Badge>}
        </div>
      </button>
      {open && <CardContent className="pt-0">{children}</CardContent>}
    </Card>
  );
}

export default function Grades() {
  const { user, isAdmin, displayRole } = useAuth();
  // GeneralSecretary is admin but should still see their own student-style grade view
  const showAsStudent = !isAdmin || displayRole === "GeneralSecretary";
  const [categories, setCategories] = useState<Category[]>([]);
  const [assignments, setAssignments] = useState<Assignment[]>([]);
  const [scores, setScores] = useState<Score[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetch = async () => {
      const [catRes, assRes, scoreRes] = await Promise.all([
        supabase.from("grade_categories").select("*"),
        supabase.from("assignments").select("*").order("name"),
        showAsStudent ? supabase.from("scores").select("assignment_id, score").eq("student_id", user!.id) : { data: [] },
      ]);
      const categoryOrder = ["attendence", "attendance", "quiz", "class performance", "activities", "mid-term", "mid term", "final exam", "final", "bonus"];
      const sortedCats = (catRes.data || []).sort((a, b) => {
        const ai = categoryOrder.findIndex(o => a.name.toLowerCase().includes(o));
        const bi = categoryOrder.findIndex(o => b.name.toLowerCase().includes(o));
        return (ai === -1 ? 999 : ai) - (bi === -1 ? 999 : bi);
      });
      setCategories(sortedCats);
      setAssignments(assRes.data || []);
      setScores(scoreRes.data || []);
      setLoading(false);
    };
    if (user) fetch();
  }, [user, isAdmin, showAsStudent]);

  const getScore = (assignmentId: string) => scores.find((s) => s.assignment_id === assignmentId);

  const getCategoryAvg = (catId: string) => {
    const catAssignments = assignments.filter((a) => a.category_id === catId);
    if (catAssignments.length === 0) return null;
    const scored = catAssignments.map((a) => {
      const s = getScore(a.id);
      return s ? (s.score / a.max_score) * 100 : null;
    }).filter((v): v is number => v !== null);
    if (scored.length === 0) return null;
    return scored.reduce((a, b) => a + b, 0) / scored.length;
  };

  const overallGrade = () => {
    const totalWeight = categories.reduce((a, c) => a + Number(c.weight), 0);
    if (totalWeight === 0) return null;
    let weighted = 0;
    let counted = 0;
    categories.forEach((cat) => {
      const avg = getCategoryAvg(cat.id);
      if (avg !== null) {
        weighted += avg * (Number(cat.weight) / totalWeight);
        counted += Number(cat.weight);
      }
    });
    return counted > 0 ? weighted * (totalWeight / counted) : null;
  };

  if (loading) return <div className="flex items-center justify-center py-12 text-muted-foreground">Loading...</div>;

  if (!showAsStudent) {
    return (
      <div className="max-w-4xl mx-auto space-y-4">
        <h2 className="text-2xl font-bold text-foreground">Grades Overview</h2>
        <p className="text-muted-foreground">Manage grades from the Admin Panel.</p>
        {categories.map((cat, i) => (
          <CategorySection key={cat.id} cat={cat} avg={null}>
            {assignments.filter((a) => a.category_id === cat.id).length === 0 ? (
              <p className="text-sm text-muted-foreground">No assignments in this category.</p>
            ) : (
              <Table>
                <TableHeader>
                  <TableRow><TableHead>Assignment</TableHead><TableHead className="text-right">Max Score</TableHead></TableRow>
                </TableHeader>
                <TableBody>
                  {assignments.filter((a) => a.category_id === cat.id).map((a) => (
                    <TableRow key={a.id}><TableCell>{a.name}</TableCell><TableCell className="text-right">{a.max_score}</TableCell></TableRow>
                  ))}
                </TableBody>
              </Table>
            )}
          </CategorySection>
        ))}
      </div>
    );
  }

  const overall = overallGrade();

  return (
    <div className="max-w-4xl mx-auto space-y-4">
      <div className="flex items-center justify-between">
        <h2 className="text-2xl font-bold text-foreground">My Grades</h2>
        {overall !== null && (
          <Badge className="text-lg px-4 py-1" variant={overall >= 90 ? "default" : "secondary"}>
            Overall: {overall.toFixed(2)}%
          </Badge>
        )}
      </div>

      {categories.length === 0 ? (
        <Card>
          <CardContent className="py-12 text-center text-muted-foreground">
            <BarChart3 className="h-12 w-12 mx-auto mb-4 opacity-40" />
            <p>No grade categories set up yet.</p>
          </CardContent>
        </Card>
      ) : (
        categories.map((cat, i) => {
          const avg = getCategoryAvg(cat.id);
          return (
            <CategorySection key={cat.id} cat={cat} avg={avg}>
              {assignments.filter((a) => a.category_id === cat.id).length === 0 ? (
                <p className="text-sm text-muted-foreground">No assignments yet.</p>
              ) : (
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Assignment</TableHead>
                      <TableHead className="text-right">Score</TableHead>
                      <TableHead className="text-right">Max</TableHead>
                      <TableHead className="text-right">%</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {assignments.filter((a) => a.category_id === cat.id).map((a) => {
                      const s = getScore(a.id);
                      return (
                        <TableRow key={a.id}>
                          <TableCell>{a.name}</TableCell>
                          <TableCell className="text-right">{s ? s.score : "—"}</TableCell>
                          <TableCell className="text-right">{a.max_score}</TableCell>
                          <TableCell className="text-right">{s ? ((s.score / a.max_score) * 100).toFixed(2) + "%" : "—"}</TableCell>
                        </TableRow>
                      );
                    })}
                  </TableBody>
                </Table>
              )}
            </CategorySection>
          );
        })
      )}
    </div>
  );
}
