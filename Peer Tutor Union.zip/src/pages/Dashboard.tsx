import { useState, useEffect, useRef } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/contexts/AuthContext";
import { canPost } from "@/lib/roleUtils";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Plus, ImagePlus, X, Paperclip } from "lucide-react";
import { compressImage } from "@/lib/imageCompress";
import { toast } from "sonner";
import RichTextEditor from "@/components/RichTextEditor";
import PostCard from "@/components/posts/PostCard";
import NotificationBell from "@/components/NotificationBell";
import { resolvePostsAttachments } from "@/lib/attachmentUtils";
import { uploadWithRetry } from "@/lib/uploadWithRetry";
import { CelebrityInfo } from "@/lib/celebrityUtils";
import { extractHashtags } from "@/lib/contentParser";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { fetchSchools, type School } from "@/lib/schools";
import { FEED_SCOPES, feedScopeHint, feedScopeLabel, canSeePost, matchesFilter, type FeedScope } from "@/lib/feedScope";

type Post = {
  id: string;
  title: string;
  content: string;
  created_at: string;
  author_id: string;
  post_attachments: { id: string; file_url: string; file_name: string }[];
  school_id: string | null;
  scope: FeedScope;
};

type ProfileMap = Record<string, { name: string; avatar_url: string | null; display_role?: string }>;

export default function Dashboard() {
  const { user, isAdmin, displayRole, schoolId } = useAuth();
  const allowPost = canPost(displayRole);
  const [posts, setPosts] = useState<Post[]>([]);
  const [profiles, setProfiles] = useState<ProfileMap>({});
  const [loading, setLoading] = useState(true);
  const [celebrityMap, setCelebrityMap] = useState<Record<string, CelebrityInfo>>({});
  const [dialogOpen, setDialogOpen] = useState(false);
  const [newTitle, setNewTitle] = useState("");
  const [newContent, setNewContent] = useState("");
  const [images, setImages] = useState<File[]>([]);
  const [files, setFiles] = useState<File[]>([]);
  const [submitting, setSubmitting] = useState(false);
  const [schools, setSchools] = useState<School[]>([]);
  const [newScope, setNewScope] = useState<FeedScope>("school");
  const [filter, setFilter] = useState<FeedScope>("global");
  const imgInputRef = useRef<HTMLInputElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const fetchData = async () => {
    const [postsRes, profilesRes, celRes] = await Promise.all([
      supabase.from("posts").select("*, post_attachments(*)").order("created_at", { ascending: false }),
      supabase.from("profiles").select("user_id, name, avatar_url, display_role"),
      supabase.from("celebrities").select("*"),
    ]);
    setSchools(await fetchSchools(false));
    const rawPosts = (postsRes.data as unknown as Post[]) || [];
    const resolvedPosts = await resolvePostsAttachments(rawPosts);
    setPosts(resolvedPosts);
    const map: ProfileMap = {};
    (profilesRes.data || []).forEach((p) => { map[p.user_id] = { name: p.name, avatar_url: p.avatar_url, display_role: p.display_role }; });
    setProfiles(map);
    const cMap: Record<string, CelebrityInfo> = {};
    ((celRes.data as any[]) || []).forEach((c: any) => { cMap[c.user_id] = c; });
    setCelebrityMap(cMap);
    setLoading(false);
  };

  useEffect(() => { fetchData(); }, []);

  const handleSubmit = async () => {
    if (!newTitle.trim() || !newContent.trim() || !user) return;
    if (!allowPost) { toast.error("Your account is restricted from posting."); return; }
    setSubmitting(true);
    try {
      const { data: post, error } = await supabase.from("posts").insert({
        title: newTitle.trim(),
        content: newContent,
        author_id: user.id,
        school_id: schoolId,
        scope: newScope,
      } as any).select().single();
      if (error) throw error;

      const allFiles = [...images, ...files];
      console.log("Upload attempt:", { imageCount: images.length, fileCount: files.length, totalFiles: allFiles.length });
      let uploadErrors = 0;
      for (const file of allFiles) {
        console.log("Uploading file:", { name: file.name, size: file.size, type: file.type });
        // Keep original quality; only convert/shrink HEIC or very large files
        const isImage = file.type.startsWith("image/") || /\.(heic|heif|jpg|jpeg|png|gif|webp)$/i.test(file.name);
        const isHeic = /\.(heic|heif)$/i.test(file.name) || /hei[cf]/i.test(file.type);
        let uploadBlob: Blob;
        let uploadName = file.name;
        let uploadType = file.type || "application/octet-stream";
        if (isImage) {
          if (isHeic || file.size > 10_000_000) {
            uploadBlob = await compressImage(file, 4096, 0.95);
          } else {
            uploadBlob = file; // upload original, no quality loss
          }
          if (uploadBlob !== file) {
            uploadName = file.name.replace(/\.\w+$/, ".jpg");
            uploadType = "image/jpeg";
          }
        } else {
          const arrayBuffer = await file.arrayBuffer();
          uploadBlob = new Blob([arrayBuffer], { type: uploadType });
        }
        const safeName = uploadName.replace(/[^a-zA-Z0-9._-]/g, "_");
        const path = `${user.id}/posts/${post.id}/${crypto.randomUUID()}-${safeName}`;
        const { error: upErr } = await uploadWithRetry("attachments", path, uploadBlob, uploadType);
        if (upErr) {
          console.error("Upload failed:", upErr);
          uploadErrors++;
          toast.error(`Failed to upload ${file.name}: ${upErr}`);
          continue;
        }
        // Store only the storage path, not full URL
        const { error: attErr } = await supabase.from("post_attachments").insert({
          post_id: post.id,
          file_name: uploadName,
          file_url: path,
        });
        if (attErr) {
          console.error("Attachment record failed:", attErr);
          toast.error(`Failed to save attachment record for ${file.name}`);
        }
      }
      if (uploadErrors > 0 && uploadErrors === allFiles.length) {
        toast.warning("Post created but all file uploads failed");
      }

      // Save hashtags
      const tags = extractHashtags(newContent);
      if (tags.length > 0) {
        await supabase.from("post_tags").insert(
          tags.map((tag) => ({ post_id: post.id, tag }))
        );
      }

      toast.success("Post published!");
      setNewTitle("");
      setNewContent("");
      setImages([]);
      setFiles([]);
      setDialogOpen(false);
      fetchData();
    } catch (e: any) {
      toast.error(e.message || "Failed to create post");
    } finally {
      setSubmitting(false);
    }
  };

  const handleDeletePost = async (postId: string) => {
    if (!confirm("Delete this post?")) return;
    await supabase.from("post_attachments").delete().eq("post_id", postId);
    await supabase.from("posts").delete().eq("id", postId);
    toast.success("Post deleted");
    fetchData();
  };

  const mySchool = schools.find((s) => s.id === schoolId);
  const visiblePosts = posts.filter((p) => {
    const theirs = schools.find((s) => s.id === p.school_id);
    const scope = (p.scope || "school") as FeedScope;
    return canSeePost(scope, theirs, mySchool) && matchesFilter(filter, theirs, mySchool);
  });

  if (loading) return <div className="flex items-center justify-center py-12 text-muted-foreground">Loading...</div>;

  return (
    <div className="max-w-lg mx-auto">
      {/* Top bar: notification bell + create post */}
      <div className="flex items-center justify-end gap-2 py-2 px-1">
        <NotificationBell />
      {allowPost && (
      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogTrigger asChild>
          <Button size="icon" className="h-12 w-12 rounded-full shadow-lg">
            <Plus className="h-5 w-5" />
          </Button>
        </DialogTrigger>
        <DialogContent className="sm:max-w-lg max-h-[85vh] overflow-y-auto">
          <DialogHeader><DialogTitle>New Post</DialogTitle></DialogHeader>
          <div className="space-y-4">
            <div>
              <Label>Title</Label>
              <Input value={newTitle} onChange={(e) => setNewTitle(e.target.value)} placeholder="Post title" />
            </div>
            <div>
              <Label>Content</Label>
              <RichTextEditor content={newContent} onChange={setNewContent} placeholder="Write something..." />
            </div>

            <div>
              <Label>Who can see this</Label>
              <Select value={newScope} onValueChange={(v) => setNewScope(v as FeedScope)}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  {FEED_SCOPES.map((s) => (
                    <SelectItem key={s} value={s}>{feedScopeLabel[s]}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
              <p className="text-xs text-muted-foreground mt-1">{feedScopeHint[newScope]}</p>
            </div>

            <div>
              <Label className="flex items-center gap-1"><ImagePlus className="h-4 w-4" /> Images</Label>
              <input ref={imgInputRef} type="file" accept="image/*" multiple className="hidden"
                onChange={(e) => { if (e.target.files) setImages((prev) => [...prev, ...Array.from(e.target.files!)]); }} />
              <Button variant="outline" size="sm" className="mt-1" onClick={() => imgInputRef.current?.click()}>
                Add Images
              </Button>
              {images.length > 0 && (
                <div className="flex flex-wrap gap-2 mt-2">
                  {images.map((f, i) => (
                    <div key={i} className="relative">
                      <img src={URL.createObjectURL(f)} className="h-16 w-16 rounded object-cover" alt={f.name} />
                      <button className="absolute -top-1 -right-1 bg-destructive text-destructive-foreground rounded-full p-0.5"
                        onClick={() => setImages((prev) => prev.filter((_, j) => j !== i))}>
                        <X className="h-3 w-3" />
                      </button>
                    </div>
                  ))}
                </div>
              )}
            </div>

            {isAdmin && (
              <div>
                <Label className="flex items-center gap-1"><Paperclip className="h-4 w-4" /> Files</Label>
                <input ref={fileInputRef} type="file" multiple className="hidden"
                  onChange={(e) => { if (e.target.files) setFiles((prev) => [...prev, ...Array.from(e.target.files!)]); }} />
                <Button variant="outline" size="sm" className="mt-1" onClick={() => fileInputRef.current?.click()}>
                  Attach Files
                </Button>
                {files.length > 0 && (
                  <div className="space-y-1 mt-2">
                    {files.map((f, i) => (
                      <div key={i} className="flex items-center gap-2 text-sm">
                        <Paperclip className="h-3.5 w-3.5" />
                        <span className="truncate">{f.name}</span>
                        <button onClick={() => setFiles((prev) => prev.filter((_, j) => j !== i))}>
                          <X className="h-3.5 w-3.5 text-destructive" />
                        </button>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            )}

            <Button onClick={handleSubmit} disabled={submitting || !newTitle.trim() || !newContent.trim()} className="w-full">
              {submitting ? "Publishing..." : "Share"}
            </Button>
          </div>
        </DialogContent>
      </Dialog>
      )}
      </div>

      {/* Feed */}
      <div className="flex items-center gap-2 px-1 pb-3">
        <span className="text-xs text-muted-foreground">Showing</span>
        <Select value={filter} onValueChange={(v) => setFilter(v as FeedScope)}>
          <SelectTrigger className="h-8 w-40 text-xs"><SelectValue /></SelectTrigger>
          <SelectContent>
            {FEED_SCOPES.map((s) => <SelectItem key={s} value={s}>{feedScopeLabel[s]}</SelectItem>)}
          </SelectContent>
        </Select>
      </div>

      {visiblePosts.length === 0 ? (
        <div className="flex flex-col items-center justify-center py-20 text-muted-foreground">
          <p className="text-lg">No posts yet</p>
          <p className="text-sm mt-1">Be the first to share something!</p>
        </div>
      ) : (
        <div className="divide-y divide-border">
          {visiblePosts.map((post) => (
            <PostCard
              key={post.id}
              post={post}
              profiles={profiles}
              userId={user?.id || ""}
              isAdmin={isAdmin}
              onDelete={handleDeletePost}
              celebrityMap={celebrityMap}
            />
          ))}
        </div>
      )}
    </div>
  );
}
