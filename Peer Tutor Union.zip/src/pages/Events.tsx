import { useState, useEffect } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/contexts/AuthContext";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { toast } from "sonner";
import { CalendarDays, MapPin, Users, Clock, CheckCircle2 } from "lucide-react";
import { format } from "date-fns";

type Event = {
  id: string;
  title: string;
  description: string;
  event_date: string | null;
  location: string;
  max_participants: number | null;
  registration_deadline: string | null;
  registration_link: string | null;
  status: string;
  created_by: string;
  created_at: string;
};

type Registration = {
  id: string;
  event_id: string;
  user_id: string;
  phone: string;
  notes: string;
  created_at: string;
};

export default function Events() {
  const { user, isAdmin } = useAuth();
  const [events, setEvents] = useState<Event[]>([]);
  const [myRegistrations, setMyRegistrations] = useState<Set<string>>(new Set());
  const [registrationCounts, setRegistrationCounts] = useState<Map<string, number>>(new Map());
  const [loading, setLoading] = useState(true);

  const fetchEvents = async () => {
    const { data } = await supabase
      .from("events")
      .select("*")
      .order("event_date", { ascending: true });
    setEvents((data as Event[]) || []);

    if (user) {
      const { data: regs } = await supabase
        .from("event_registrations")
        .select("event_id")
        .eq("user_id", user.id);
      setMyRegistrations(new Set((regs || []).map((r: any) => r.event_id)));
    }

    if (isAdmin) {
      // Admin can see all registrations to get counts
      const { data: allRegs } = await supabase
        .from("event_registrations")
        .select("event_id");
      const counts = new Map<string, number>();
      (allRegs || []).forEach((r: any) => {
        counts.set(r.event_id, (counts.get(r.event_id) || 0) + 1);
      });
      setRegistrationCounts(counts);
    }

    setLoading(false);
  };

  useEffect(() => { fetchEvents(); }, [user]);

  if (loading) return <div className="flex items-center justify-center py-12 text-muted-foreground">Loading...</div>;

  return (
    <div className="max-w-4xl mx-auto space-y-6">
      <div className="flex items-center justify-between">
        <h2 className="text-2xl font-bold text-foreground">Activities</h2>
      </div>

      {events.length === 0 ? (
        <Card>
          <CardContent className="py-12 text-center text-muted-foreground">
            <CalendarDays className="h-12 w-12 mx-auto mb-4 opacity-40" />
            <p>No activities posted yet.</p>
          </CardContent>
        </Card>
      ) : (
        <div className="space-y-4">
          {events.map((event) => (
            <EventCard
              key={event.id}
              event={event}
              isRegistered={myRegistrations.has(event.id)}
              registrationCount={registrationCounts.get(event.id) || 0}
              isAdmin={isAdmin}
              userId={user?.id}
              onRefresh={fetchEvents}
            />
          ))}
        </div>
      )}
    </div>
  );
}

function EventCard({
  event, isRegistered, registrationCount, isAdmin, userId, onRefresh,
}: {
  event: Event;
  isRegistered: boolean;
  registrationCount: number;
  isAdmin: boolean;
  userId?: string;
  onRefresh: () => void;
}) {
  const [open, setOpen] = useState(false);
  const [name, setName] = useState("");
  const [wechat, setWechat] = useState("");
  const [phone, setPhone] = useState("");
  const [submitting, setSubmitting] = useState(false);
  const [viewOpen, setViewOpen] = useState(false);
  const [registrants, setRegistrants] = useState<any[]>([]);

  const isPast = event.registration_deadline && new Date(event.registration_deadline) < new Date();
  const isFull = event.max_participants != null && registrationCount >= event.max_participants;

  const handleRegister = async () => {
    if (!userId) return;
    setSubmitting(true);
    const { error } = await supabase.from("event_registrations").insert({
      event_id: event.id,
      user_id: userId,
      phone,
      notes: `Name: ${name}\nWeChat: ${wechat}`,
    } as any);
    setSubmitting(false);
    if (error) { toast.error(error.message); return; }
    toast.success("Successfully registered!");
    setOpen(false);
    setName(""); setWechat(""); setPhone("");
    onRefresh();
  };

  const handleCancel = async () => {
    if (!userId) return;
    await supabase.from("event_registrations").delete().eq("event_id", event.id).eq("user_id", userId);
    toast.success("Registration cancelled");
    onRefresh();
  };

  const viewRegistrants = async () => {
    const { data } = await supabase
      .from("event_registrations")
      .select("*, profiles!event_registrations_user_id_fkey(name)")
      .eq("event_id", event.id);
    setRegistrants(data || []);
    setViewOpen(true);
  };

  return (
    <Card>
      <CardHeader>
        <div className="flex items-start justify-between">
          <div>
            <CardTitle className="text-lg">{event.title}</CardTitle>
            <CardDescription className="mt-1 whitespace-pre-wrap">{event.description}</CardDescription>
          </div>
          <Badge variant={event.status === "open" ? "default" : "secondary"}>
            {event.status === "open" ? "Open" : "Closed"}
          </Badge>
        </div>
      </CardHeader>
      <CardContent className="space-y-3">
        <div className="flex flex-wrap gap-4 text-sm text-muted-foreground">
          {event.event_date && (
            <span className="flex items-center gap-1"><CalendarDays className="h-4 w-4" />{format(new Date(event.event_date), "PPP p")}</span>
          )}
          {event.location && (
            <span className="flex items-center gap-1"><MapPin className="h-4 w-4" />{event.location}</span>
          )}
          {event.max_participants && (
            <span className="flex items-center gap-1"><Users className="h-4 w-4" />{isAdmin ? `${registrationCount}/` : ""}{event.max_participants} spots</span>
          )}
          {event.registration_deadline && (
            <span className="flex items-center gap-1"><Clock className="h-4 w-4" />Deadline: {format(new Date(event.registration_deadline), "PPP")}</span>
          )}
        </div>

        <div className="flex gap-2 pt-2">
          {isRegistered ? (
            <>
              <Badge variant="outline" className="gap-1"><CheckCircle2 className="h-3 w-3" /> Registered</Badge>
              <Button variant="outline" size="sm" onClick={handleCancel}>Cancel Registration</Button>
            </>
          ) : event.registration_link ? (
              <Button size="sm" disabled={isPast || isFull || event.status !== "open"} asChild>
                <a href={event.registration_link} target="_blank" rel="noopener noreferrer">
                  {isPast ? "Deadline Passed" : isFull ? "Full" : "Register"}
                </a>
              </Button>
          ) : (
              <Dialog open={open} onOpenChange={setOpen}>
                <DialogTrigger asChild>
                  <Button size="sm" disabled={isPast || isFull || event.status !== "open"}>
                    {isPast ? "Deadline Passed" : isFull ? "Full" : "Register"}
                  </Button>
                </DialogTrigger>
                <DialogContent>
                  <DialogHeader><DialogTitle>Register for {event.title}</DialogTitle></DialogHeader>
                  <div className="space-y-4">
                    <div><Label>Name</Label><Input value={name} onChange={(e) => setName(e.target.value)} placeholder="Your name" /></div>
                    <div><Label>Contact (WeChat)</Label><Input value={wechat} onChange={(e) => setWechat(e.target.value)} placeholder="Your WeChat ID" /></div>
                    <div><Label>Phone</Label><Input value={phone} onChange={(e) => setPhone(e.target.value)} placeholder="Your phone number" /></div>
                    <Button onClick={handleRegister} disabled={submitting || !name.trim()} className="w-full">{submitting ? "Submitting..." : "Confirm Registration"}</Button>
                  </div>
                </DialogContent>
              </Dialog>
          )}

          {isAdmin && (
            <Button variant="outline" size="sm" onClick={viewRegistrants}>
              View Registrants ({registrationCount})
            </Button>
          )}
        </div>

        {/* Admin view registrants dialog */}
        <Dialog open={viewOpen} onOpenChange={setViewOpen}>
          <DialogContent className="max-w-lg">
            <DialogHeader><DialogTitle>Registrants - {event.title}</DialogTitle></DialogHeader>
            {registrants.length === 0 ? (
              <p className="text-muted-foreground text-sm">No registrations yet.</p>
            ) : (
              <div className="space-y-2 max-h-80 overflow-y-auto">
                {registrants.map((r: any) => (
                  <div key={r.id} className="flex items-center justify-between p-2 rounded border">
                    <div>
                      <p className="font-medium text-sm">{(r.profiles as any)?.name || "Unknown"}</p>
                      {r.phone && <p className="text-xs text-muted-foreground">📞 {r.phone}</p>}
                      {r.notes && <p className="text-xs text-muted-foreground">📝 {r.notes}</p>}
                    </div>
                    <Button variant="ghost" size="sm" onClick={async () => {
                      await supabase.from("event_registrations").delete().eq("id", r.id);
                      toast.success("Registration removed");
                      viewRegistrants();
                      onRefresh();
                    }}>Remove</Button>
                  </div>
                ))}
              </div>
            )}
          </DialogContent>
        </Dialog>
      </CardContent>
    </Card>
  );
}
