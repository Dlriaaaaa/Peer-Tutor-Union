import { useState, useEffect } from "react";
import { useParams, useNavigate } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/contexts/AuthContext";
import { ArrowLeft, Hash } from "lucide-react";
import { Button } from "@/components/ui/button";
import PostCard from "@/components/posts/PostCard";
import { resolvePostsAttachments } from "@/lib/attachmentUtils";
import { CelebrityInfo } from "@/lib/celebrityUtils";

type Post = {
  id: string;
  title: string;
  content: string;
  created_at: string;
  author_id: string;
  post_attachments: { id: string; file_url: string; file_name: string }[];
};

type ProfileMap = Record<string, { name: string; avatar_url: string | null; display_role?: string }>;

export default function TagPosts() {
  const { tag } = useParams<{ tag: string }>();
  const navigate = useNavigate();
  const { user, isAdmin } = useAuth();
  const [posts, setPosts] = useState<Post[]>([]);
  const [profiles, setProfiles] = useState<ProfileMap>({});
  const [celebrityMap, setCelebrityMap] = useState<Record<string, CelebrityInfo>>({});
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!tag) return;
    fetchTagPosts();
  }, [tag]);

  const fetchTagPosts = async () => {
    setLoading(true);
    // Get post IDs with this tag
    const { data: tagData } = await supabase
      .from("post_tags")
      .select("post_id")
      .eq("tag", tag!.toLowerCase());

    if (!tagData || tagData.length === 0) {
      setPosts([]);
      setLoading(false);
      return;
    }

    const postIds = tagData.map((t: any) => t.post_id);
    const [postsRes, profilesRes, celRes] = await Promise.all([
      supabase.from("posts").select("*, post_attachments(*)").in("id", postIds).order("created_at", { ascending: false }),
      supabase.from("profiles").select("user_id, name, avatar_url, display_role"),
      supabase.from("celebrities").select("*"),
    ]);

    const rawPosts = (postsRes.data as unknown as Post[]) || [];
    const resolvedPosts = await resolvePostsAttachments(rawPosts);
    setPosts(resolvedPosts);

    const map: ProfileMap = {};
    (profilesRes.data || []).forEach((p: any) => { map[p.user_id] = { name: p.name, avatar_url: p.avatar_url, display_role: p.display_role }; });
    setProfiles(map);

    const cMap: Record<string, CelebrityInfo> = {};
    ((celRes.data as any[]) || []).forEach((c: any) => { cMap[c.user_id] = c; });
    setCelebrityMap(cMap);
    setLoading(false);
  };

  const handleDeletePost = async (postId: string) => {
    if (!confirm("Delete this post?")) return;
    await supabase.from("post_attachments").delete().eq("post_id", postId);
    await supabase.from("posts").delete().eq("id", postId);
    fetchTagPosts();
  };

  return (
    <div className="max-w-lg mx-auto">
      <div className="flex items-center gap-3 py-4 px-2">
        <Button variant="ghost" size="icon" onClick={() => navigate(-1)}>
          <ArrowLeft className="h-5 w-5" />
        </Button>
        <div className="flex items-center gap-1.5">
          <Hash className="h-5 w-5 text-primary" />
          <h1 className="text-xl font-bold text-foreground">{tag}</h1>
        </div>
        <span className="text-sm text-muted-foreground ml-auto">{posts.length} posts</span>
      </div>

      {loading ? (
        <div className="flex items-center justify-center py-12 text-muted-foreground">Loading...</div>
      ) : posts.length === 0 ? (
        <div className="flex flex-col items-center justify-center py-20 text-muted-foreground">
          <p className="text-lg">No posts with #{tag}</p>
        </div>
      ) : (
        <div className="divide-y divide-border">
          {posts.map((post) => (
            <PostCard
              key={post.id}
              post={post}
              profiles={profiles}
              userId={user?.id || ""}
              isAdmin={isAdmin}
              onDelete={handleDeletePost}
              celebrityMap={celebrityMap}
            />
          ))}
        </div>
      )}
    </div>
  );
}
