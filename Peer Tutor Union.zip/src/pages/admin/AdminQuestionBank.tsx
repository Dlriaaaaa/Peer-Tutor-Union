import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { toast } from "sonner";
import { Plus } from "lucide-react";
import { useAuth } from "@/contexts/AuthContext";
import QuestionBankBrowser from "@/components/questions/QuestionBankBrowser";
import QuestionUploadDialog from "@/components/questions/QuestionUploadDialog";
import SubjectManagerDialog from "@/components/questions/SubjectManagerDialog";
import MathText from "@/components/questions/MathText";
import { canManageSubjects } from "@/lib/questionBank";

type Pending = {
  id: string;
  session_id: string;
  question_id: string;
  part_id: string | null;
  user_id: string;
  text_answer: string | null;
  points_awarded: number | null;
  feedback: string | null;
};

export default function AdminQuestionBank() {
  const { displayRole, isAdmin, user } = useAuth();
  const [uploadOpen, setUploadOpen] = useState(false);
  const [refreshKey, setRefreshKey] = useState(0);
  const [pending, setPending] = useState<Pending[]>([]);
  const [questions, setQuestions] = useState<Record<string, any>>({});
  const [partsMap, setPartsMap] = useState<Record<string, any>>({});
  const [names, setNames] = useState<Record<string, string>>({});
  const [draft, setDraft] = useState<Record<string, { points: string; feedback: string }>>({});

  const loadGrading = async () => {
    const { data } = await supabase
      .from("practice_answers")
      .select("*")
      .not("text_answer", "is", null)
      .is("points_awarded", null)
      .order("created_at", { ascending: false })
      .limit(100);
    const rows = (data as Pending[]) || [];
    setPending(rows);
    if (rows.length) {
      const { data: qs } = await supabase.from("questions").select("*").in("id", [...new Set(rows.map((r) => r.question_id))]);
      setQuestions(Object.fromEntries((qs || []).map((q: any) => [q.id, q])));
      const partIds = rows.map((r) => r.part_id).filter(Boolean) as string[];
      if (partIds.length) {
        const { data: ps } = await supabase.from("question_parts").select("*").in("id", partIds);
        setPartsMap(Object.fromEntries((ps || []).map((p: any) => [p.id, p])));
      }
      const { data: profs } = await supabase.from("profiles").select("user_id, name").in("user_id", [...new Set(rows.map((r) => r.user_id))]);
      setNames(Object.fromEntries((profs || []).map((p: any) => [p.user_id, p.name])));
    }
  };

  useEffect(() => { loadGrading(); }, [refreshKey]);

  const grade = async (row: Pending) => {
    const d = draft[row.id] || { points: "", feedback: "" };
    const pts = Number(d.points);
    if (isNaN(pts)) { toast.error("Enter a point value"); return; }
    const { error } = await supabase.from("practice_answers").update({
      points_awarded: pts, feedback: d.feedback || null, graded_by: user?.id, graded_at: new Date().toISOString(),
    }).eq("id", row.id);
    if (error) { toast.error(error.message); return; }
    // Add manual points to the session score
    const { data: s } = await supabase.from("practice_sessions").select("score").eq("id", row.session_id).maybeSingle();
    if (s) await supabase.from("practice_sessions").update({ score: Number(s.score || 0) + pts }).eq("id", row.session_id);
    toast.success("Graded");
    setRefreshKey((k) => k + 1);
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <h2 className="text-2xl font-bold text-foreground">Question Bank</h2>
        <div className="flex items-center gap-2">
          {canManageSubjects(displayRole, isAdmin) && <SubjectManagerDialog onChanged={() => setRefreshKey((k) => k + 1)} />}
          <Button size="sm" className="gap-2" onClick={() => setUploadOpen(true)}><Plus className="h-4 w-4" /> Upload question</Button>
        </div>
      </div>

      <Tabs defaultValue="bank">
        <TabsList>
          <TabsTrigger value="bank">All questions</TabsTrigger>
          <TabsTrigger value="grading">FRQ grading {pending.length > 0 && <Badge className="ml-2">{pending.length}</Badge>}</TabsTrigger>
        </TabsList>

        <TabsContent value="bank" className="pt-4">
          <QuestionBankBrowser refreshKey={refreshKey} />
        </TabsContent>

        <TabsContent value="grading" className="space-y-3 pt-4">
          {pending.length === 0 && <p className="text-sm text-muted-foreground">Nothing waiting to be graded.</p>}
          {pending.map((row) => {
            const q = questions[row.question_id];
            const part = row.part_id ? partsMap[row.part_id] : null;
            const maxPts = part?.points ?? q?.max_points ?? 1;
            const d = draft[row.id] || { points: "", feedback: "" };
            return (
              <div key={row.id} className="rounded-xl border bg-muted/10 p-4 space-y-3">
                <p className="text-sm font-medium">{names[row.user_id] || "Student"} · max {maxPts} pts</p>
                {q && <MathText text={q.stem} />}
                {part && <p className="text-sm font-medium">{part.label}: {part.prompt}</p>}
                <div className="rounded-lg border bg-background/60 p-2 prose prose-sm max-w-none"
                  dangerouslySetInnerHTML={{ __html: row.text_answer || "" }} />
                <div className="flex flex-wrap items-end gap-2">
                  <div className="w-28">
                    <Input type="number" min="0" max={maxPts} placeholder="Points" value={d.points}
                      onChange={(e) => setDraft({ ...draft, [row.id]: { ...d, points: e.target.value } })} />
                  </div>
                  <Textarea className="flex-1 min-w-[200px]" rows={2} placeholder="Feedback" value={d.feedback}
                    onChange={(e) => setDraft({ ...draft, [row.id]: { ...d, feedback: e.target.value } })} />
                  <Button size="sm" onClick={() => grade(row)}>Save grade</Button>
                </div>
              </div>
            );
          })}
        </TabsContent>
      </Tabs>

      <QuestionUploadDialog open={uploadOpen} onOpenChange={setUploadOpen} onSaved={() => setRefreshKey((k) => k + 1)} />
    </div>
  );
}
