import { useState, useEffect } from "react";
import { supabase } from "@/integrations/supabase/client";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { toast } from "sonner";
import { Plus, Trash2, ChevronDown, ChevronRight, Users } from "lucide-react";
import { Fragment } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";

type Profile = { user_id: string; name: string; avatar_url: string | null; bio: string };
type Category = { id: string; name: string; weight: number };
type Assignment = { id: string; name: string; max_score: number; category_id: string };
type Score = { id: string; student_id: string; assignment_id: string; score: number };

export default function AdminGrades() {
  const [categories, setCategories] = useState<Category[]>([]);
  const [assignments, setAssignments] = useState<Assignment[]>([]);
  const [scores, setScores] = useState<Score[]>([]);
  const [students, setStudents] = useState<Profile[]>([]);
  const [catName, setCatName] = useState("");
  const [catWeight, setCatWeight] = useState("");
  const [newAssName, setNewAssName] = useState<Record<string, string>>({});
  const [newAssMax, setNewAssMax] = useState<Record<string, string>>({});
  const [editingScores, setEditingScores] = useState<Record<string, string>>({});
  const [selectedStudent, setSelectedStudent] = useState("");
  const [expandedRow, setExpandedRow] = useState<string | null>(null);
  const [bulkAssignment, setBulkAssignment] = useState<Assignment | null>(null);
  const [bulkScores, setBulkScores] = useState<Record<string, string>>({});
  const [bulkSaving, setBulkSaving] = useState(false);

  const openBulkDialog = (a: Assignment) => {
    const initial: Record<string, string> = {};
    students.forEach((stu) => {
      const s = scores.find((sc) => sc.student_id === stu.user_id && sc.assignment_id === a.id);
      initial[stu.user_id] = s ? String(s.score) : "";
    });
    setBulkScores(initial);
    setBulkAssignment(a);
  };

  const saveBulkScores = async () => {
    if (!bulkAssignment) return;
    setBulkSaving(true);
    const rows = Object.entries(bulkScores)
      .filter(([, v]) => v.trim() !== "" && !isNaN(Number(v)))
      .map(([student_id, v]) => ({ student_id, assignment_id: bulkAssignment.id, score: Number(v) }));
    if (rows.length === 0) {
      toast.error("No valid scores to save");
      setBulkSaving(false);
      return;
    }
    const { error } = await supabase.from("scores").upsert(rows, { onConflict: "student_id,assignment_id" });
    setBulkSaving(false);
    if (error) { toast.error(error.message); return; }
    toast.success(`Saved ${rows.length} scores`);
    setBulkAssignment(null);
    fetchAll();
  };

  const fetchAll = async () => {
    const [catRes, assRes, profRes, roleRes, scoreRes] = await Promise.all([
      supabase.from("grade_categories").select("*").order("name"),
      supabase.from("assignments").select("*").order("name"),
      supabase.from("profiles").select("*").order("name"),
      supabase.from("user_roles").select("user_id, role"),
      supabase.from("scores").select("*"),
    ]);
    setCategories(catRes.data || []);
    setAssignments(assRes.data || []);
    setScores(scoreRes.data || []);
    const adminIds = new Set((roleRes.data || []).filter((r) => r.role === "admin").map((r) => r.user_id));
    // Include GeneralSecretary in the gradeable students list (they are admins but still get graded)
    const studentList = (profRes.data || []).filter((p) => !adminIds.has(p.user_id) || p.display_role === "GeneralSecretary");
    setStudents(studentList);
    if (!selectedStudent && studentList.length > 0) setSelectedStudent(studentList[0].user_id);
  };

  useEffect(() => { fetchAll(); }, []);

  const addCategory = async () => {
    if (!catName || !catWeight) return;
    await supabase.from("grade_categories").insert({ name: catName, weight: Number(catWeight) });
    setCatName(""); setCatWeight("");
    toast.success("Category added"); fetchAll();
  };

  const deleteCategory = async (id: string) => {
    await supabase.from("grade_categories").delete().eq("id", id);
    toast.success("Category deleted"); fetchAll();
  };

  const addAssignment = async (catId: string) => {
    const name = newAssName[catId];
    const max = newAssMax[catId] || "100";
    if (!name) return;
    await supabase.from("assignments").insert({ name, max_score: Number(max), category_id: catId });
    setNewAssName((p) => ({ ...p, [catId]: "" }));
    setNewAssMax((p) => ({ ...p, [catId]: "" }));
    toast.success("Assignment added"); fetchAll();
  };

  const deleteAssignment = async (id: string) => {
    await supabase.from("assignments").delete().eq("id", id);
    toast.success("Assignment deleted"); fetchAll();
  };

  const getScore = (studentId: string, assignmentId: string) => {
    return scores.find((s) => s.student_id === studentId && s.assignment_id === assignmentId);
  };

  const saveScore = async (studentId: string, assignmentId: string, value: string) => {
    let scoreNum: number;
    let maxScore: number | undefined;
    if (value.includes("/")) {
      const parts = value.split("/");
      scoreNum = Number(parts[0].trim());
      maxScore = Number(parts[1].trim());
    } else {
      scoreNum = Number(value);
    }
    if (isNaN(scoreNum)) { toast.error("Invalid score"); return; }
    if (maxScore !== undefined && !isNaN(maxScore)) {
      await supabase.from("assignments").update({ max_score: maxScore }).eq("id", assignmentId);
    }
    const { error } = await supabase.from("scores").upsert(
      { student_id: studentId, assignment_id: assignmentId, score: scoreNum },
      { onConflict: "student_id,assignment_id" }
    );
    if (error) { toast.error(error.message); return; }
    toast.success("Score saved");
    fetchAll();
  };

  // Per-student category average (% out of 100, averaging assignment percentages)
  const getCategoryAvg = (studentId: string, catId: string): number | null => {
    const catAss = assignments.filter((a) => a.category_id === catId);
    if (catAss.length === 0) return null;
    const pcts = catAss
      .map((a) => {
        const s = scores.find((sc) => sc.student_id === studentId && sc.assignment_id === a.id);
        return s ? (Number(s.score) / Number(a.max_score)) * 100 : null;
      })
      .filter((v): v is number => v !== null);
    if (pcts.length === 0) return null;
    return pcts.reduce((a, b) => a + b, 0) / pcts.length;
  };

  const getOverall = (studentId: string): number | null => {
    const totalWeight = categories.reduce((a, c) => a + Number(c.weight), 0);
    if (totalWeight === 0) return null;
    let weighted = 0;
    let counted = 0;
    categories.forEach((cat) => {
      const avg = getCategoryAvg(studentId, cat.id);
      if (avg !== null) {
        weighted += avg * (Number(cat.weight) / totalWeight);
        counted += Number(cat.weight);
      }
    });
    return counted > 0 ? weighted * (totalWeight / counted) : null;
  };

  return (
    <div className="space-y-6">
      <h2 className="text-2xl font-bold text-foreground">Grades</h2>

      <Card className="glass-card">
        <CardHeader><CardTitle>Student Totals</CardTitle></CardHeader>
        <CardContent>
          {students.length === 0 ? (
            <p className="text-sm text-muted-foreground">No students yet.</p>
          ) : (
            <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead className="sticky left-0 bg-background">Student</TableHead>
                    {categories.map((c) => (
                      <TableHead key={c.id} className="text-right whitespace-nowrap">
                        {c.name}<span className="text-muted-foreground text-xs ml-1">({c.weight}%)</span>
                      </TableHead>
                    ))}
                    <TableHead className="text-right whitespace-nowrap">Overall</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {students.map((stu) => {
                    const overall = getOverall(stu.user_id);
                    const isExpanded = expandedRow === stu.user_id;
                    const colSpan = categories.length + 2;
                    return (
                      <Fragment key={stu.user_id}>
                        <TableRow
                          className="cursor-pointer hover:bg-muted/40"
                          onClick={() => setExpandedRow(isExpanded ? null : stu.user_id)}
                        >
                          <TableCell className="sticky left-0 bg-background font-medium">
                            <div className="flex items-center gap-1">
                              {isExpanded ? <ChevronDown className="h-3.5 w-3.5" /> : <ChevronRight className="h-3.5 w-3.5" />}
                              {stu.name}
                            </div>
                          </TableCell>
                          {categories.map((c) => {
                            const avg = getCategoryAvg(stu.user_id, c.id);
                            return (
                              <TableCell key={c.id} className="text-right tabular-nums">
                                {avg === null ? <span className="text-muted-foreground">—</span> : `${avg.toFixed(1)}%`}
                              </TableCell>
                            );
                          })}
                          <TableCell className="text-right">
                            {overall === null ? (
                              <span className="text-muted-foreground">—</span>
                            ) : (
                              <Badge variant={overall >= 90 ? "default" : "secondary"} className="tabular-nums">
                                {overall.toFixed(2)}%
                              </Badge>
                            )}
                          </TableCell>
                        </TableRow>
                        {isExpanded && (
                          <TableRow>
                            <TableCell colSpan={colSpan} className="bg-muted/20 p-4">
                              <div className="space-y-4">
                                {categories.map((c) => {
                                  const catAss = assignments.filter((a) => a.category_id === c.id);
                                  if (catAss.length === 0) return null;
                                  return (
                                    <div key={c.id}>
                                      <div className="font-semibold text-sm mb-2 text-foreground">
                                        {c.name} <span className="text-muted-foreground font-normal">({c.weight}%)</span>
                                      </div>
                                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-x-6 gap-y-1.5">
                                        {catAss.map((a) => {
                                          const s = getScore(stu.user_id, a.id);
                                          const key = `tot-${stu.user_id}-${a.id}`;
                                          const isEditing = key in editingScores;
                                          return (
                                            <div key={a.id} className="flex items-center justify-between gap-2 py-1 border-b border-border/40">
                                              <span className="text-sm text-muted-foreground truncate flex-1">{a.name}</span>
                                              {isEditing ? (
                                                <Input
                                                  className="w-24 text-right h-7 text-sm"
                                                  placeholder={`e.g. 85/${a.max_score}`}
                                                  value={editingScores[key]}
                                                  onChange={(e) => setEditingScores((p) => ({ ...p, [key]: e.target.value }))}
                                                  onKeyDown={(e) => {
                                                    if (e.key === "Enter") {
                                                      saveScore(stu.user_id, a.id, editingScores[key]);
                                                      setEditingScores((p) => { const n = { ...p }; delete n[key]; return n; });
                                                    }
                                                    if (e.key === "Escape") {
                                                      setEditingScores((p) => { const n = { ...p }; delete n[key]; return n; });
                                                    }
                                                  }}
                                                  onBlur={() => {
                                                    if (editingScores[key]) saveScore(stu.user_id, a.id, editingScores[key]);
                                                    setEditingScores((p) => { const n = { ...p }; delete n[key]; return n; });
                                                  }}
                                                  autoFocus
                                                />
                                              ) : (
                                                <button
                                                  className="text-sm hover:bg-muted px-2 py-0.5 rounded text-primary tabular-nums"
                                                  onClick={(e) => {
                                                    e.stopPropagation();
                                                    setEditingScores((p) => ({ ...p, [key]: s ? `${s.score}/${a.max_score}` : `/${a.max_score}` }));
                                                  }}
                                                >
                                                  {s ? `${s.score}/${a.max_score}` : `—/${a.max_score}`}
                                                </button>
                                              )}
                                            </div>
                                          );
                                        })}
                                      </div>
                                    </div>
                                  );
                                })}
                              </div>
                            </TableCell>
                          </TableRow>
                        )}
                      </Fragment>
                    );
                  })}
                </TableBody>
              </Table>
            </div>
          )}
        </CardContent>
      </Card>

      <Card className="glass-card">
        <CardHeader><CardTitle>Grade Categories</CardTitle></CardHeader>
        <CardContent className="space-y-4">
          <div className="flex gap-2">
            <Input placeholder="Category name (e.g. Quiz & Reflection)" value={catName} onChange={(e) => setCatName(e.target.value)} />
            <Input placeholder="Weight %" type="number" className="w-24" value={catWeight} onChange={(e) => setCatWeight(e.target.value)} />
            <Button onClick={addCategory}><Plus className="h-4 w-4" /></Button>
          </div>
        </CardContent>
      </Card>

      {categories.map((cat) => {
        const catAssignments = assignments.filter((a) => a.category_id === cat.id);
        return (
          <Card key={cat.id} className="glass-card">
            <CardHeader>
              <CardTitle className="flex items-center justify-between">
                <span>{cat.name}</span>
                <div className="flex items-center gap-2">
                  <Badge variant="outline">{cat.weight}%</Badge>
                  <Button variant="ghost" size="icon" onClick={() => deleteCategory(cat.id)}>
                    <Trash2 className="h-4 w-4 text-destructive" />
                  </Button>
                </div>
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex gap-2">
                <Input placeholder="New assignment name" value={newAssName[cat.id] || ""} onChange={(e) => setNewAssName((p) => ({ ...p, [cat.id]: e.target.value }))} />
                <Input placeholder="Max" type="number" className="w-20" value={newAssMax[cat.id] || ""} onChange={(e) => setNewAssMax((p) => ({ ...p, [cat.id]: e.target.value }))} />
                <Button size="sm" onClick={() => addAssignment(cat.id)}><Plus className="h-4 w-4" /></Button>
              </div>

              {catAssignments.length > 0 && (
                <>
                  <div className="flex items-center gap-2">
                    <Label className="text-sm shrink-0">Student:</Label>
                    <Select value={selectedStudent} onValueChange={setSelectedStudent}>
                      <SelectTrigger className="w-48"><SelectValue placeholder="Select student" /></SelectTrigger>
                      <SelectContent>{students.map((s) => <SelectItem key={s.user_id} value={s.user_id}>{s.name}</SelectItem>)}</SelectContent>
                    </Select>
                  </div>
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>Assignment</TableHead>
                        <TableHead className="text-right w-28">Score</TableHead>
                        <TableHead className="text-right w-20">Max</TableHead>
                        <TableHead className="text-right w-20">%</TableHead>
                        <TableHead className="w-12"></TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {catAssignments.map((a) => {
                        const s = selectedStudent ? getScore(selectedStudent, a.id) : undefined;
                        const key = `${selectedStudent}-${a.id}`;
                        const isEditing = key in editingScores;
                        const pct = s ? ((s.score / a.max_score) * 100).toFixed(1) : "—";
                        return (
                          <TableRow key={a.id}>
                            <TableCell>{a.name}</TableCell>
                            <TableCell className="text-right">
                              {isEditing ? (
                                <Input
                                  className="w-24 ml-auto text-right h-8"
                                  placeholder={`e.g. 85/${a.max_score}`}
                                  value={editingScores[key]}
                                  onChange={(e) => setEditingScores((p) => ({ ...p, [key]: e.target.value }))}
                                  onKeyDown={(e) => {
                                    if (e.key === "Enter") {
                                      saveScore(selectedStudent, a.id, editingScores[key]);
                                      setEditingScores((p) => { const n = { ...p }; delete n[key]; return n; });
                                    }
                                    if (e.key === "Escape") {
                                      setEditingScores((p) => { const n = { ...p }; delete n[key]; return n; });
                                    }
                                  }}
                                  onBlur={() => {
                                    if (editingScores[key]) saveScore(selectedStudent, a.id, editingScores[key]);
                                    setEditingScores((p) => { const n = { ...p }; delete n[key]; return n; });
                                  }}
                                  autoFocus
                                />
                              ) : (
                                <button
                                  className="text-right hover:underline cursor-pointer text-primary hover:bg-muted px-2 py-0.5 rounded"
                                  onClick={() => setEditingScores((p) => ({ ...p, [key]: s ? `${s.score}/${a.max_score}` : "" }))}
                                >
                                  {s ? `${s.score}/${a.max_score}` : "点击输入"}
                                </button>
                              )}
                            </TableCell>
                            <TableCell className="text-right">{a.max_score}</TableCell>
                            <TableCell className="text-right">{pct}{pct !== "—" ? "%" : ""}</TableCell>
                            <TableCell>
                              <div className="flex items-center justify-end gap-1">
                                <Button variant="ghost" size="icon" title="Bulk fill all students" onClick={() => openBulkDialog(a)}>
                                  <Users className="h-3.5 w-3.5" />
                                </Button>
                                <Button variant="ghost" size="icon" onClick={() => deleteAssignment(a.id)}>
                                  <Trash2 className="h-3.5 w-3.5 text-destructive" />
                                </Button>
                              </div>
                            </TableCell>
                          </TableRow>
                        );
                      })}
                    </TableBody>
                  </Table>
                </>
              )}
            </CardContent>
          </Card>
        );
      })}

      <Dialog open={!!bulkAssignment} onOpenChange={(o) => !o && setBulkAssignment(null)}>
        <DialogContent className="max-w-lg max-h-[80vh] flex flex-col">
          <DialogHeader>
            <DialogTitle>Bulk Score: {bulkAssignment?.name}</DialogTitle>
            <p className="text-sm text-muted-foreground">Max: {bulkAssignment?.max_score} • Leave blank to skip</p>
          </DialogHeader>
          <div className="flex-1 overflow-y-auto space-y-2 py-2">
            {students.map((stu) => (
              <div key={stu.user_id} className="flex items-center gap-3">
                <Label className="flex-1 text-sm font-normal truncate">{stu.name}</Label>
                <Input
                  type="number"
                  className="w-24 h-8 text-right"
                  placeholder="—"
                  value={bulkScores[stu.user_id] ?? ""}
                  onChange={(e) => setBulkScores((p) => ({ ...p, [stu.user_id]: e.target.value }))}
                />
                <span className="text-xs text-muted-foreground w-12">/{bulkAssignment?.max_score}</span>
              </div>
            ))}
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setBulkAssignment(null)}>Cancel</Button>
            <Button onClick={saveBulkScores} disabled={bulkSaving}>{bulkSaving ? "Saving..." : "Save All"}</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
