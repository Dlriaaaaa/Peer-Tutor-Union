import { useState, useEffect } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/contexts/AuthContext";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { toast } from "sonner";
import { Trash2, Plus, FileText, Upload, Loader2, Bot, Pencil, Save, X } from "lucide-react";
import { Switch } from "@/components/ui/switch";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import AvatarCropDialog from "@/components/AvatarCropDialog";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";

interface TrainingEntry {
  id: string;
  title: string;
  content: string;
  source_type: string;
  created_at: string;
}

interface BotPersona {
  id: string;
  name: string;
  avatar_url: string | null;
  system_prompt: string;
  created_at: string;
  is_enabled: boolean;
}

export default function AdminAITraining() {
  const { user } = useAuth();
  const [entries, setEntries] = useState<TrainingEntry[]>([]);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [title, setTitle] = useState("");
  const [content, setContent] = useState("");
  const [uploading, setUploading] = useState(false);

  // Persona state
  const [personas, setPersonas] = useState<BotPersona[]>([]);
  const [personaLoading, setPersonaLoading] = useState(true);
  const [newPersonaName, setNewPersonaName] = useState("");
  const [newPersonaPrompt, setNewPersonaPrompt] = useState("");
  const [editingPersona, setEditingPersona] = useState<string | null>(null);
  const [editName, setEditName] = useState("");
  const [editPrompt, setEditPrompt] = useState("");
  const [avatarUploading, setAvatarUploading] = useState(false);
  const [cropDialogOpen, setCropDialogOpen] = useState(false);
  const [cropImageSrc, setCropImageSrc] = useState("");
  const [cropPersonaId, setCropPersonaId] = useState<string | null>(null);

  const fetchEntries = async () => {
    const { data } = await supabase
      .from("ai_training_data")
      .select("id, title, content, source_type, created_at")
      .order("created_at", { ascending: false });
    setEntries(data || []);
    setLoading(false);
  };

  const fetchPersonas = async () => {
    const { data } = await supabase
      .from("bot_personas")
      .select("id, name, avatar_url, system_prompt, created_at, is_enabled")
      .order("created_at", { ascending: true });
    setPersonas((data as any[]) || []);
    setPersonaLoading(false);
  };

  useEffect(() => {
    fetchEntries();
    fetchPersonas();
  }, []);

  const handleAddText = async () => {
    if (!title.trim() || !content.trim()) { toast.error("请填写标题和内容"); return; }
    setSaving(true);
    const { error } = await supabase.from("ai_training_data").insert({
      title: title.trim(), content: content.trim(), source_type: "text", created_by: user!.id,
    });
    if (error) { toast.error("保存失败"); } else {
      toast.success("训练数据已添加"); setTitle(""); setContent(""); fetchEntries();
    }
    setSaving(false);
  };

  const handleFileUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    if (file.size > 5 * 1024 * 1024) { toast.error("文件大小不能超过5MB"); return; }
    const allowedTypes = ["text/plain", "text/markdown", "text/csv", "application/json"];
    if (!allowedTypes.includes(file.type) && !file.name.match(/\.(txt|md|csv|json)$/i)) {
      toast.error("仅支持 .txt, .md, .csv, .json 文件"); return;
    }
    setUploading(true);
    try {
      const text = await file.text();
      if (text.length > 50000) { toast.error("文件内容过长，最多支持50000字符"); setUploading(false); return; }
      const { error } = await supabase.from("ai_training_data").insert({
        title: file.name, content: text, source_type: "file", created_by: user!.id,
      });
      if (error) throw error;
      toast.success(`已导入文件: ${file.name}`); fetchEntries();
    } catch { toast.error("文件导入失败"); }
    setUploading(false); e.target.value = "";
  };

  const handleDelete = async (id: string) => {
    const { error } = await supabase.from("ai_training_data").delete().eq("id", id);
    if (error) { toast.error("删除失败"); } else {
      toast.success("已删除"); setEntries(prev => prev.filter(e => e.id !== id));
    }
  };

  // Persona CRUD
  const handleAddPersona = async () => {
    if (!newPersonaName.trim()) { toast.error("请输入智能体名称"); return; }
    const { error } = await supabase.from("bot_personas").insert({
      name: newPersonaName.trim(),
      system_prompt: newPersonaPrompt.trim() || "你是一个热情友好的AI助手。",
      created_by: user!.id,
    } as any);
    if (error) { toast.error("创建失败"); return; }
    toast.success("智能体已创建");
    setNewPersonaName(""); setNewPersonaPrompt(""); fetchPersonas();
  };

  const handleUpdatePersona = async (id: string) => {
    const { error } = await supabase.from("bot_personas").update({
      name: editName.trim(), system_prompt: editPrompt.trim(),
    } as any).eq("id", id);
    if (error) { toast.error("更新失败"); return; }
    toast.success("已更新"); setEditingPersona(null); fetchPersonas();
  };

  const handleTogglePersona = async (id: string, enabled: boolean) => {
    const { error } = await supabase.from("bot_personas").update({ is_enabled: enabled } as any).eq("id", id);
    if (error) { toast.error("更新失败"); return; }
    setPersonas(prev => prev.map(p => p.id === id ? { ...p, is_enabled: enabled } : p));
    toast.success(enabled ? "智能体已启用" : "智能体已关闭");
  };

  const handleDeletePersona = async (id: string) => {
    const { error } = await supabase.from("bot_personas").delete().eq("id", id);
    if (error) { toast.error("删除失败"); return; }
    toast.success("已删除"); setPersonas(prev => prev.filter(p => p.id !== id));
  };

  const handleAvatarSelect = (personaId: string, e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = () => {
      setCropImageSrc(reader.result as string);
      setCropPersonaId(personaId);
      setCropDialogOpen(true);
    };
    reader.readAsDataURL(file);
    e.target.value = "";
  };

  const handleAvatarCropComplete = async (blob: Blob) => {
    if (!cropPersonaId) return;
    setCropDialogOpen(false);
    setAvatarUploading(true);
    const path = `bot-avatars/${cropPersonaId}.jpg`;
    const { error: uploadErr } = await supabase.storage.from("avatars").upload(path, blob, { upsert: true, contentType: "image/jpeg" });
    if (uploadErr) { toast.error("上传失败"); setAvatarUploading(false); return; }
    const { data: urlData } = supabase.storage.from("avatars").getPublicUrl(path);
    await supabase.from("bot_personas").update({ avatar_url: urlData.publicUrl + "?t=" + Date.now() } as any).eq("id", cropPersonaId);
    toast.success("头像已更新"); fetchPersonas(); setAvatarUploading(false);
  };

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold">AI 训练 & 智能体</h1>
        <p className="text-muted-foreground text-sm mt-1">管理训练数据和Bot智能体配置</p>
      </div>

      <Tabs defaultValue="personas" className="w-full">
        <TabsList>
          <TabsTrigger value="personas"><Bot className="h-4 w-4 mr-1" />智能体</TabsTrigger>
          <TabsTrigger value="training"><FileText className="h-4 w-4 mr-1" />训练数据</TabsTrigger>
        </TabsList>

        <TabsContent value="personas" className="space-y-4 mt-4">
          {/* Add persona */}
          <Card>
            <CardHeader><CardTitle className="text-base flex items-center gap-2"><Plus className="h-4 w-4" /> 创建智能体</CardTitle></CardHeader>
            <CardContent className="space-y-3">
              <Input placeholder="智能体名称（例如：数学老师、PTC助手）" value={newPersonaName} onChange={e => setNewPersonaName(e.target.value)} maxLength={50} />
              <Textarea placeholder="系统提示词（定义AI的角色和行为）" value={newPersonaPrompt} onChange={e => setNewPersonaPrompt(e.target.value)} rows={4} maxLength={5000} />
              <Button onClick={handleAddPersona} disabled={!newPersonaName.trim()}><Plus className="h-4 w-4 mr-1" /> 创建</Button>
            </CardContent>
          </Card>

          {/* Persona list */}
          <h2 className="font-semibold text-lg">已有智能体 ({personas.length})</h2>
          {personaLoading ? <p className="text-sm text-muted-foreground">加载中...</p> : personas.length === 0 ? <p className="text-sm text-muted-foreground">暂无智能体</p> : (
            personas.map(p => (
              <Card key={p.id}>
                <CardContent className="py-4 space-y-3">
                  <div className="flex items-center gap-3">
                    <label className="cursor-pointer relative group">
                      <Avatar className="h-12 w-12">
                        <AvatarImage src={p.avatar_url || undefined} />
                        <AvatarFallback className="bg-primary/10 text-primary"><Bot className="h-5 w-5" /></AvatarFallback>
                      </Avatar>
                      <div className="absolute inset-0 bg-black/50 rounded-full flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity">
                        <Upload className="h-4 w-4 text-white" />
                      </div>
                      <input type="file" accept="image/*" className="hidden" onChange={e => handleAvatarSelect(p.id, e)} disabled={avatarUploading} />
                    </label>
                    <div className="flex-1 min-w-0">
                      {editingPersona === p.id ? (
                        <Input value={editName} onChange={e => setEditName(e.target.value)} className="h-8" />
                      ) : (
                        <p className="font-medium">{p.name}</p>
                      )}
                      <p className="text-[10px] text-muted-foreground/60">{new Date(p.created_at).toLocaleDateString("zh-CN")}</p>
                    </div>
                    <div className="flex items-center gap-1">
                      <Switch checked={p.is_enabled} onCheckedChange={(v) => handleTogglePersona(p.id, v)} />
                      {editingPersona === p.id ? (
                        <>
                          <Button size="icon" variant="ghost" onClick={() => handleUpdatePersona(p.id)}><Save className="h-4 w-4" /></Button>
                          <Button size="icon" variant="ghost" onClick={() => setEditingPersona(null)}><X className="h-4 w-4" /></Button>
                        </>
                      ) : (
                        <>
                          <Button size="icon" variant="ghost" onClick={() => { setEditingPersona(p.id); setEditName(p.name); setEditPrompt(p.system_prompt); }}>
                            <Pencil className="h-4 w-4" />
                          </Button>
                          <Button size="icon" variant="ghost" className="text-destructive" onClick={() => handleDeletePersona(p.id)}>
                            <Trash2 className="h-4 w-4" />
                          </Button>
                        </>
                      )}
                    </div>
                  </div>
                  {editingPersona === p.id ? (
                    <Textarea value={editPrompt} onChange={e => setEditPrompt(e.target.value)} rows={4} />
                  ) : (
                    <p className="text-xs text-muted-foreground line-clamp-3 bg-muted/50 rounded p-2">{p.system_prompt}</p>
                  )}
                </CardContent>
              </Card>
            ))
          )}
        </TabsContent>

        <TabsContent value="training" className="space-y-4 mt-4">
          <Card>
            <CardHeader><CardTitle className="text-base flex items-center gap-2"><Plus className="h-4 w-4" /> 添加训练数据</CardTitle></CardHeader>
            <CardContent className="space-y-4">
              <Input placeholder="标题（例如：社团章程、活动规则...）" value={title} onChange={e => setTitle(e.target.value)} maxLength={200} />
              <Textarea placeholder="输入内容，PTC AI 会学习并记住..." value={content} onChange={e => setContent(e.target.value)} rows={6} maxLength={50000} />
              <div className="flex gap-3">
                <Button onClick={handleAddText} disabled={saving}>
                  {saving ? <Loader2 className="h-4 w-4 animate-spin mr-2" /> : <FileText className="h-4 w-4 mr-2" />} 保存文本
                </Button>
                <Button variant="outline" asChild disabled={uploading}>
                  <label className="cursor-pointer">
                    {uploading ? <Loader2 className="h-4 w-4 animate-spin mr-2" /> : <Upload className="h-4 w-4 mr-2" />} 上传文件
                    <input type="file" className="hidden" accept=".txt,.md,.csv,.json" onChange={handleFileUpload} />
                  </label>
                </Button>
              </div>
            </CardContent>
          </Card>
          <h2 className="font-semibold text-lg">已有训练数据 ({entries.length})</h2>
          {loading ? <p className="text-sm text-muted-foreground">加载中...</p> : entries.length === 0 ? <p className="text-sm text-muted-foreground">暂无训练数据</p> : (
            entries.map(entry => (
              <Card key={entry.id}>
                <CardContent className="py-4 flex items-start justify-between gap-4">
                  <div className="min-w-0 flex-1">
                    <div className="flex items-center gap-2">
                      <span className="font-medium text-sm">{entry.title}</span>
                      <span className="text-[10px] px-1.5 py-0.5 rounded bg-muted text-muted-foreground">{entry.source_type === "file" ? "文件" : "文本"}</span>
                    </div>
                    <p className="text-xs text-muted-foreground mt-1 line-clamp-2">{entry.content.slice(0, 200)}</p>
                    <p className="text-[10px] text-muted-foreground/60 mt-1">{new Date(entry.created_at).toLocaleDateString("zh-CN")}</p>
                  </div>
                  <Button size="icon" variant="ghost" className="text-destructive hover:text-destructive" onClick={() => handleDelete(entry.id)}>
                    <Trash2 className="h-4 w-4" />
                  </Button>
                </CardContent>
              </Card>
            ))
          )}
        </TabsContent>
      </Tabs>
      <AvatarCropDialog
        open={cropDialogOpen}
        imageSrc={cropImageSrc}
        onClose={() => setCropDialogOpen(false)}
        onCropComplete={handleAvatarCropComplete}
      />
    </div>
  );
}
