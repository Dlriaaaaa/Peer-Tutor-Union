import { useState, useEffect } from "react";
import { supabase } from "@/integrations/supabase/client";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { toast } from "sonner";
import { UserCheck, Check, X } from "lucide-react";
import { fetchClubs, fetchSchools, type Club, type School } from "@/lib/schools";

const NO_SCHOOL = "__none";

type Pending = {
  user_id: string;
  name: string;
  ip_address: string | null;
  created_at: string;
  school_id: string | null;
};

export default function AdminApprovals() {
  const [pending, setPending] = useState<Pending[]>([]);
  const [schools, setSchools] = useState<School[]>([]);
  const [clubs, setClubs] = useState<Club[]>([]);
  const [loading, setLoading] = useState(true);

  const fetchPending = async () => {
    setLoading(true);
    const { data: profiles } = await supabase
      .from("profiles")
      .select("user_id, name, created_at, school_id")
      .eq("is_approved", false)
      .order("created_at", { ascending: false });
    const { data: roles } = await supabase.from("user_roles").select("user_id, role");
    const adminIds = new Set((roles || []).filter(r => r.role === "admin").map(r => r.user_id));
    const filtered = (profiles || []).filter(p => !adminIds.has(p.user_id));

    // Fetch IPs from registration_ips table
    const userIds = filtered.map(p => p.user_id);
    const { data: ips } = userIds.length > 0
      ? await supabase.from("registration_ips").select("user_id, ip_address").in("user_id", userIds)
      : { data: [] };
    const ipMap: Record<string, string | null> = {};
    (ips || []).forEach(r => { ipMap[r.user_id] = r.ip_address; });

    setPending(filtered.map((p: any) => ({ ...p, ip_address: ipMap[p.user_id] || null })));
    setLoading(false);
  };

  useEffect(() => {
    fetchPending();
    Promise.all([fetchSchools(false), fetchClubs()]).then(([s, c]) => { setSchools(s); setClubs(c); });
  }, []);

  const changeSchool = async (userId: string, value: string) => {
    const schoolId = value === NO_SCHOOL ? null : value;
    const { error } = await supabase.from("profiles").update({ school_id: schoolId } as any).eq("user_id", userId);
    if (error) { toast.error(error.message); return; }
    setPending((rows) => rows.map((r) => (r.user_id === userId ? { ...r, school_id: schoolId } : r)));
    toast.success("School updated");
  };

  const handleApprove = async (row: Pending) => {
    const { error } = await supabase
      .from("profiles")
      .update({ is_approved: true, school_id: row.school_id } as any)
      .eq("user_id", row.user_id);
    if (error) { toast.error(error.message); return; }

    // Put the member into their school's club so club leaders don't see a stale application
    if (row.school_id) {
      const club = clubs.find((c) => c.school_id === row.school_id);
      if (club) {
        const { data: existing } = await supabase
          .from("club_members").select("id").eq("club_id", club.id).eq("user_id", row.user_id).maybeSingle();
        if (existing) {
          await supabase.from("club_members").update({ status: "approved" }).eq("id", existing.id);
        } else {
          await supabase.from("club_members")
            .insert({ club_id: club.id, user_id: row.user_id, club_role: "Member", status: "approved" });
        }
      }
    }
    toast.success("User approved");
    fetchPending();
  };

  const handleReject = async (userId: string, name: string) => {
    if (!confirm(`Are you sure you want to reject ${name}'s application?`)) return;
    await supabase.from("club_members").delete().eq("user_id", userId);
    await supabase.from("user_roles").delete().eq("user_id", userId);
    await supabase.from("profiles").delete().eq("user_id", userId);
    toast.success("Application rejected");
    fetchPending();
  };

  return (
    <div className="space-y-6">
      <h2 className="text-2xl font-bold text-foreground">Approvals</h2>
      <Card className="glass-card">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <UserCheck className="h-5 w-5" /> Pending Registrations
            {pending.length > 0 && <Badge variant="destructive" className="ml-2">{pending.length}</Badge>}
          </CardTitle>
          <CardDescription>Check the school a member picked, adjust it if needed, then approve</CardDescription>
        </CardHeader>
        <CardContent>
          {loading ? (
            <p className="text-muted-foreground text-center py-8">Loading...</p>
          ) : pending.length === 0 ? (
            <p className="text-muted-foreground text-center py-8">No pending registrations ✓</p>
          ) : (
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Name</TableHead>
                  <TableHead>School</TableHead>
                  <TableHead>Registration IP</TableHead>
                  <TableHead>Registered At</TableHead>
                  <TableHead className="w-32">Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {pending.map((p) => (
                  <TableRow key={p.user_id}>
                    <TableCell className="font-medium">{p.name}</TableCell>
                    <TableCell>
                      <Select value={p.school_id || NO_SCHOOL} onValueChange={(v) => changeSchool(p.user_id, v)}>
                        <SelectTrigger className="w-52 h-8"><SelectValue /></SelectTrigger>
                        <SelectContent>
                          <SelectItem value={NO_SCHOOL}>No school</SelectItem>
                          {schools.map((s) => <SelectItem key={s.id} value={s.id}>{s.name}</SelectItem>)}
                        </SelectContent>
                      </Select>
                    </TableCell>
                    <TableCell className="font-mono text-xs text-muted-foreground">{p.ip_address || "N/A"}</TableCell>
                    <TableCell className="text-sm">{new Date(p.created_at).toLocaleString()}</TableCell>
                    <TableCell>
                      <div className="flex gap-2">
                        <Button size="sm" onClick={() => handleApprove(p)}>
                          <Check className="h-4 w-4 mr-1" /> Approve
                        </Button>
                        <Button size="sm" variant="destructive" onClick={() => handleReject(p.user_id, p.name)}>
                          <X className="h-4 w-4 mr-1" /> Reject
                        </Button>
                      </div>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
