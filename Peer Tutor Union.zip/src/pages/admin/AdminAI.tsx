/**
 * AdminAI — Admin tool to allocate AI token credits to users.
 * Search by user name, then add/deduct balance and adjust per-1K-token pricing.
 */
import { useEffect, useState, useCallback } from "react";
import { supabase } from "@/integrations/supabase/client";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { toast } from "sonner";
import { Sparkles, Search, Plus, Minus, Save } from "lucide-react";

interface Row {
  user_id: string;
  name: string;
  display_role: string;
  balance: number;
  price_per_1k_input: number;
  price_per_1k_output: number;
  has_record: boolean;
}

export default function AdminAI() {
  const [search, setSearch] = useState("");
  const [rows, setRows] = useState<Row[]>([]);
  const [loading, setLoading] = useState(false);
  const [amounts, setAmounts] = useState<Record<string, string>>({});
  const [inputPrices, setInputPrices] = useState<Record<string, string>>({});
  const [outputPrices, setOutputPrices] = useState<Record<string, string>>({});
  const [busyId, setBusyId] = useState<string | null>(null);

  const load = useCallback(async (query: string) => {
    setLoading(true);
    let req = supabase
      .from("profiles")
      .select("user_id, name, display_role")
      .order("name")
      .limit(100);
    if (query.trim()) req = req.ilike("name", `%${query.trim()}%`);

    const { data: profs, error } = await req;
    if (error) {
      toast.error(error.message);
      setLoading(false);
      return;
    }

    const ids = (profs ?? []).map((p) => p.user_id);
    let creditsByUser: Record<string, { balance: number; price_per_1k_input: number; price_per_1k_output: number }> = {};
    if (ids.length) {
      const { data: credits } = await supabase
        .from("ai_credits")
        .select("user_id, balance, price_per_1k_input, price_per_1k_output")
        .in("user_id", ids);
      creditsByUser = Object.fromEntries(
        (credits ?? []).map((c: any) => [c.user_id, {
          balance: Number(c.balance),
          price_per_1k_input: Number(c.price_per_1k_input),
          price_per_1k_output: Number(c.price_per_1k_output),
        }]),
      );
    }

    setRows(
      (profs ?? []).map((p) => {
        const c = creditsByUser[p.user_id];
        return {
          user_id: p.user_id,
          name: p.name || "—",
          display_role: p.display_role || "Student",
          balance: c?.balance ?? 0,
          price_per_1k_input: c?.price_per_1k_input ?? 1,
          price_per_1k_output: c?.price_per_1k_output ?? 3,
          has_record: !!c,
        };
      }),
    );
    setLoading(false);
  }, []);

  useEffect(() => {
    load("");
  }, [load]);

  const ensureRow = async (userId: string): Promise<boolean> => {
    const { error } = await supabase
      .from("ai_credits")
      .insert({ user_id: userId, balance: 0 });
    if (error && !error.message.toLowerCase().includes("duplicate")) {
      toast.error(error.message);
      return false;
    }
    return true;
  };

  const adjustBalance = async (row: Row, delta: number) => {
    if (!Number.isFinite(delta) || delta === 0) {
      toast.error("Enter a non-zero amount");
      return;
    }
    setBusyId(row.user_id);
    if (!row.has_record) {
      const ok = await ensureRow(row.user_id);
      if (!ok) {
        setBusyId(null);
        return;
      }
    }
    const newBalance = Math.max(0, row.balance + delta);
    const { error } = await supabase
      .from("ai_credits")
      .update({ balance: newBalance })
      .eq("user_id", row.user_id);
    setBusyId(null);
    if (error) {
      toast.error(error.message);
      return;
    }
    toast.success(`${delta > 0 ? "Added" : "Deducted"} $${Math.abs(delta)} — ${row.name} now has $${newBalance.toFixed(2)}`);
    setRows((prev) => prev.map((r) => (r.user_id === row.user_id ? { ...r, balance: newBalance, has_record: true } : r)));
    setAmounts((prev) => ({ ...prev, [row.user_id]: "" }));
  };

  const savePrices = async (row: Row) => {
    const inRaw = inputPrices[row.user_id];
    const outRaw = outputPrices[row.user_id];
    const inPrice = inRaw ? parseFloat(inRaw) : row.price_per_1k_input;
    const outPrice = outRaw ? parseFloat(outRaw) : row.price_per_1k_output;
    if (!Number.isFinite(inPrice) || inPrice < 0 || !Number.isFinite(outPrice) || outPrice < 0) {
      toast.error("Prices must be ≥ 0");
      return;
    }
    setBusyId(row.user_id);
    if (!row.has_record) {
      const ok = await ensureRow(row.user_id);
      if (!ok) {
        setBusyId(null);
        return;
      }
    }
    const { error } = await supabase
      .from("ai_credits")
      .update({ price_per_1k_input: inPrice, price_per_1k_output: outPrice })
      .eq("user_id", row.user_id);
    setBusyId(null);
    if (error) {
      toast.error(error.message);
      return;
    }
    toast.success(`${row.name}: 输入 $${inPrice}/1K · 输出 $${outPrice}/1K`);
    setRows((prev) =>
      prev.map((r) => (r.user_id === row.user_id ? { ...r, price_per_1k_input: inPrice, price_per_1k_output: outPrice, has_record: true } : r)),
    );
    setInputPrices((prev) => ({ ...prev, [row.user_id]: "" }));
    setOutputPrices((prev) => ({ ...prev, [row.user_id]: "" }));
  };

  return (
    <div className="space-y-4 py-4">
      <div>
        <h2 className="text-2xl font-bold flex items-center gap-2">
          <Sparkles className="h-6 w-6 text-primary" /> AI 额度管理
        </h2>
        <p className="text-sm text-muted-foreground mt-1">
          为普通学生分配 AI 余额。按 token 计费：输入 token 与输出 token 单价独立可调（每 1000 tokens 的价格）。VIP / 教职工不受限制。
        </p>
      </div>

      <Card>
        <CardContent className="p-4">
          <form
            className="flex gap-2"
            onSubmit={(e) => {
              e.preventDefault();
              load(search);
            }}
          >
            <Input
              placeholder="按姓名搜索..."
              value={search}
              onChange={(e) => setSearch(e.target.value)}
            />
            <Button type="submit" disabled={loading} className="gap-1.5">
              <Search className="h-4 w-4" /> Search
            </Button>
          </form>
        </CardContent>
      </Card>

      <div className="space-y-2">
        {loading ? (
          <p className="text-sm text-muted-foreground text-center py-6">Loading…</p>
        ) : rows.length === 0 ? (
          <p className="text-sm text-muted-foreground text-center py-6">No users found.</p>
        ) : (
          rows.map((row) => {
            const amountStr = amounts[row.user_id] ?? "";
            const delta = parseFloat(amountStr);
            const isBusy = busyId === row.user_id;
            return (
              <Card key={row.user_id}>
                <CardContent className="p-3 space-y-2">
                  <div className="flex flex-wrap items-center gap-3">
                    <div className="flex-1 min-w-[180px]">
                      <div className="font-semibold truncate">{row.name}</div>
                      <div className="text-xs text-muted-foreground truncate">{row.display_role}</div>
                      <div className="text-sm font-bold text-yellow-500 tabular-nums mt-0.5">
                        余额 ${row.balance.toFixed(2)}
                      </div>
                      <div className="text-[10px] text-muted-foreground tabular-nums">
                        输入 ${row.price_per_1k_input}/1K · 输出 ${row.price_per_1k_output}/1K
                      </div>
                    </div>
                    <div className="flex items-center gap-1.5">
                      <Input
                        type="number"
                        step="0.01"
                        placeholder="额度"
                        className="w-24 h-9"
                        value={amountStr}
                        onChange={(e) =>
                          setAmounts((prev) => ({ ...prev, [row.user_id]: e.target.value }))
                        }
                        disabled={isBusy}
                      />
                      <Button
                        size="sm"
                        className="gap-1 bg-green-600 hover:bg-green-700"
                        disabled={isBusy || !Number.isFinite(delta) || delta <= 0}
                        onClick={() => adjustBalance(row, Math.abs(delta))}
                      >
                        <Plus className="h-3.5 w-3.5" /> Add
                      </Button>
                      <Button
                        size="sm"
                        variant="destructive"
                        className="gap-1"
                        disabled={isBusy || !Number.isFinite(delta) || delta <= 0}
                        onClick={() => adjustBalance(row, -Math.abs(delta))}
                      >
                        <Minus className="h-3.5 w-3.5" /> Deduct
                      </Button>
                    </div>
                  </div>
                  <div className="flex flex-wrap items-center gap-2 pl-1">
                    <span className="text-xs text-muted-foreground">单价 /1K tokens:</span>
                    <div className="flex items-center gap-1">
                      <span className="text-[10px] text-muted-foreground">输入</span>
                      <Input
                        type="number"
                        step="0.01"
                        min={0}
                        placeholder={`${row.price_per_1k_input}`}
                        className="w-20 h-8"
                        value={inputPrices[row.user_id] ?? ""}
                        onChange={(e) =>
                          setInputPrices((prev) => ({ ...prev, [row.user_id]: e.target.value }))
                        }
                        disabled={isBusy}
                      />
                    </div>
                    <div className="flex items-center gap-1">
                      <span className="text-[10px] text-muted-foreground">输出</span>
                      <Input
                        type="number"
                        step="0.01"
                        min={0}
                        placeholder={`${row.price_per_1k_output}`}
                        className="w-20 h-8"
                        value={outputPrices[row.user_id] ?? ""}
                        onChange={(e) =>
                          setOutputPrices((prev) => ({ ...prev, [row.user_id]: e.target.value }))
                        }
                        disabled={isBusy}
                      />
                    </div>
                    <Button
                      size="sm"
                      variant="outline"
                      className="gap-1 h-8"
                      disabled={isBusy || (!inputPrices[row.user_id] && !outputPrices[row.user_id])}
                      onClick={() => savePrices(row)}
                    >
                      <Save className="h-3.5 w-3.5" /> Save
                    </Button>
                  </div>
                </CardContent>
              </Card>
            );
          })
        )}
      </div>
    </div>
  );
}
