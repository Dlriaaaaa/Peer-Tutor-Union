import { useState, useEffect, useCallback } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/contexts/AuthContext";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { toast } from "sonner";
import { Plus, Trash2, FolderPlus, Pencil, Folder, ChevronRight, ChevronDown } from "lucide-react";
import { cn } from "@/lib/utils";
import ResourceTree, { FolderItem, ResourceItem } from "@/components/resources/ResourceTree";
import { handleResourceDrop } from "@/lib/resourceDrop";
import FileViewerDialog from "@/components/FileViewerDialog";
import { uploadResourceFile } from "@/lib/resourceUpload";
import { Badge } from "@/components/ui/badge";

type Folder = { id: string; name: string; sort_order: number; parent_id: string | null; color: string };

const FOLDER_COLORS = [
  { value: "blue", label: "Blue", className: "text-blue-500" },
  { value: "red", label: "Red", className: "text-red-500" },
  { value: "green", label: "Green", className: "text-green-500" },
  { value: "yellow", label: "Yellow", className: "text-yellow-500" },
  { value: "purple", label: "Purple", className: "text-purple-500" },
  { value: "pink", label: "Pink", className: "text-pink-500" },
  { value: "orange", label: "Orange", className: "text-orange-500" },
  { value: "teal", label: "Teal", className: "text-teal-500" },
  { value: "gray", label: "Gray", className: "text-gray-500" },
];

const colorClass = (c: string) => FOLDER_COLORS.find(f => f.value === c)?.className || "text-blue-500";

// Build full path label like "Parent / Child / Grandchild"
const buildPath = (folder: Folder, all: Folder[]): string => {
  const parts: string[] = [folder.name];
  let cur = folder;
  while (cur.parent_id) {
    const p = all.find(f => f.id === cur.parent_id);
    if (!p) break;
    parts.unshift(p.name);
    cur = p;
  }
  return parts.join(" / ");
};

export default function AdminResources() {
  const { user } = useAuth();
  const [title, setTitle] = useState("");
  const [description, setDescription] = useState("");
  const [category, setCategory] = useState("");
  const [file, setFile] = useState<File | null>(null);
  const [resources, setResources] = useState<any[]>([]);
  const [folders, setFolders] = useState<Folder[]>([]);
  const [newFolder, setNewFolder] = useState("");
  const [newFolderParent, setNewFolderParent] = useState<string>("__root__");
  const [newFolderColor, setNewFolderColor] = useState("blue");
  const [editingFolder, setEditingFolder] = useState<string | null>(null);
  const [editFolderName, setEditFolderName] = useState("");
  const [editFolderColor, setEditFolderColor] = useState("blue");
  const [expanded, setExpanded] = useState<Set<string>>(new Set());
  const [loading, setLoading] = useState(false);
  const [previewing, setPreviewing] = useState<ResourceItem | null>(null);

  const fetchAll = async () => {
    const [resRes, folderRes] = await Promise.all([
      supabase.from("resources").select("*").order("created_at", { ascending: false }),
      supabase.from("resource_folders").select("*").order("sort_order"),
    ]);
    setResources(resRes.data || []);
    const f = (folderRes.data as Folder[]) || [];
    setFolders(f);
    if (!category && f.length > 0) setCategory(buildPath(f[0], f));
  };

  useEffect(() => { fetchAll(); }, []);

  const toggleExpand = (id: string) => {
    setExpanded(prev => {
      const next = new Set(prev);
      next.has(id) ? next.delete(id) : next.add(id);
      return next;
    });
  };

  const handleAddFolder = async () => {
    if (!newFolder.trim()) return;
    const parent_id = newFolderParent === "__root__" ? null : newFolderParent;
    const siblings = folders.filter(f => f.parent_id === parent_id);
    const { error } = await supabase.from("resource_folders").insert({
      name: newFolder.trim(),
      sort_order: siblings.length,
      parent_id,
      color: newFolderColor,
    });
    if (error) { toast.error(error.message); return; }
    toast.success("Folder added");
    setNewFolder("");
    fetchAll();
  };

  const handleRenameFolder = async (id: string) => {
    if (!editFolderName.trim()) return;
    const folder = folders.find(f => f.id === id);
    if (!folder) return;
    const oldPath = buildPath(folder, folders);
    const updated = { ...folder, name: editFolderName.trim() };
    const newPath = buildPath(updated, folders.map(f => f.id === id ? updated : f));

    const { error } = await supabase.from("resource_folders")
      .update({ name: editFolderName.trim(), color: editFolderColor })
      .eq("id", id);
    if (error) { toast.error(error.message); return; }
    if (oldPath !== newPath) {
      // Update all resources whose category starts with oldPath (covers descendants too)
      const affected = resources.filter(r => r.category === oldPath || r.category.startsWith(oldPath + " / "));
      for (const r of affected) {
        const newCat = newPath + r.category.slice(oldPath.length);
        await supabase.from("resources").update({ category: newCat }).eq("id", r.id);
      }
    }
    toast.success("Folder updated");
    setEditingFolder(null);
    fetchAll();
  };

  const handleDeleteFolder = async (id: string) => {
    const folder = folders.find(f => f.id === id);
    if (!folder) return;
    const path = buildPath(folder, folders);
    // Block delete if any file in this folder OR descendants
    const hasFiles = resources.some(r => r.category === path || r.category.startsWith(path + " / "));
    if (hasFiles) {
      toast.error("Cannot delete: folder (or sub-folders) still contains files. Move or delete them first.");
      return;
    }
    await supabase.from("resource_folders").delete().eq("id", id);
    toast.success("Folder deleted");
    fetchAll();
  };

  const handleCreate = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user) { toast.error("Not logged in"); return; }
    if (!file) { toast.error("Please select a file"); return; }
    if (!category) { toast.error("Please select a folder (create one above first)"); return; }
    setLoading(true);
    try {
      const existing = resources.filter(r => r.category === category);
      await uploadResourceFile({
        file, category, authorId: user.id,
        title: title || undefined,
        description,
        sortOrder: existing.length,
      });
      toast.success("Resource added");
      setTitle(""); setDescription(""); setFile(null);
      fetchAll();
    } catch (err: any) {
      toast.error(err.message);
    } finally {
      setLoading(false);
    }
  };

  const handleDelete = async (id: string) => {
    await supabase.from("resources").delete().eq("id", id);
    toast.success("Resource deleted");
    fetchAll();
  };

  // Render tree recursively
  const renderFolderTree = (parentId: string | null, depth: number = 0): JSX.Element[] => {
    const children = folders.filter(f => f.parent_id === parentId);
    return children.flatMap(f => {
      const isOpen = expanded.has(f.id);
      const path = buildPath(f, folders);
      const fileCount = resources.filter(r => r.category === path).length;
      const hasChildren = folders.some(c => c.parent_id === f.id);
      const rows: JSX.Element[] = [
        <div
          key={f.id}
          className="flex items-center gap-2 py-1.5 px-2 rounded-md hover:bg-muted/50"
          style={{ paddingLeft: `${depth * 20 + 8}px` }}
        >
          {hasChildren ? (
            <button onClick={() => toggleExpand(f.id)} className="text-muted-foreground hover:text-foreground">
              {isOpen ? <ChevronDown className="h-3.5 w-3.5" /> : <ChevronRight className="h-3.5 w-3.5" />}
            </button>
          ) : (
            <span className="w-3.5" />
          )}
          {editingFolder === f.id ? (
            <>
              <Folder className={cn("h-4 w-4 shrink-0", colorClass(editFolderColor))} />
              <Input value={editFolderName} onChange={e => setEditFolderName(e.target.value)} className="h-8 text-sm flex-1" autoFocus />
              <Select value={editFolderColor} onValueChange={setEditFolderColor}>
                <SelectTrigger className="h-8 w-28 text-xs"><SelectValue /></SelectTrigger>
                <SelectContent>
                  {FOLDER_COLORS.map(c => (
                    <SelectItem key={c.value} value={c.value}>
                      <div className="flex items-center gap-2"><Folder className={cn("h-3.5 w-3.5", c.className)} /> {c.label}</div>
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
              <Button size="sm" variant="outline" onClick={() => handleRenameFolder(f.id)}>Save</Button>
              <Button size="sm" variant="ghost" onClick={() => setEditingFolder(null)}>Cancel</Button>
            </>
          ) : (
            <>
              <Folder className={cn("h-4 w-4 shrink-0", colorClass(f.color))} />
              <span className="text-sm flex-1">{f.name}</span>
              <Badge variant="outline" className="text-[10px]">{fileCount} files</Badge>
              <Button size="icon" variant="ghost" className="h-7 w-7" onClick={() => { setEditingFolder(f.id); setEditFolderName(f.name); setEditFolderColor(f.color); }}><Pencil className="h-3.5 w-3.5" /></Button>
              <Button size="icon" variant="ghost" className="h-7 w-7" onClick={() => handleDeleteFolder(f.id)}><Trash2 className="h-3.5 w-3.5 text-destructive" /></Button>
            </>
          )}
        </div>
      ];
      if (isOpen && hasChildren) rows.push(...renderFolderTree(f.id, depth + 1));
      return rows;
    });
  };

  // Flat list for select dropdowns (showing hierarchy)
  const folderOptions = folders.map(f => ({ id: f.id, path: buildPath(f, folders) }))
    .sort((a, b) => a.path.localeCompare(b.path));

  return (
    <div className="space-y-6">
      <h2 className="text-2xl font-bold text-foreground">Resources</h2>

      {/* Folder Management */}
      <Card className="glass-card">
        <CardHeader><CardTitle className="flex items-center gap-2"><FolderPlus className="h-5 w-5" /> Manage Folders</CardTitle></CardHeader>
        <CardContent className="space-y-3">
          <div className="grid gap-2 md:grid-cols-[1fr_180px_140px_auto]">
            <Input placeholder="New folder name..." value={newFolder} onChange={e => setNewFolder(e.target.value)} onKeyDown={e => e.key === "Enter" && handleAddFolder()} />
            <Select value={newFolderParent} onValueChange={setNewFolderParent}>
              <SelectTrigger><SelectValue placeholder="Parent folder" /></SelectTrigger>
              <SelectContent>
                <SelectItem value="__root__">📁 Root (top level)</SelectItem>
                {folderOptions.map(o => <SelectItem key={o.id} value={o.id}>{o.path}</SelectItem>)}
              </SelectContent>
            </Select>
            <Select value={newFolderColor} onValueChange={setNewFolderColor}>
              <SelectTrigger><SelectValue /></SelectTrigger>
              <SelectContent>
                {FOLDER_COLORS.map(c => (
                  <SelectItem key={c.value} value={c.value}>
                    <div className="flex items-center gap-2"><Folder className={cn("h-4 w-4", c.className)} /> {c.label}</div>
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
            <Button onClick={handleAddFolder} size="sm"><Plus className="h-4 w-4 mr-1" /> Add</Button>
          </div>
          <div className="space-y-1 border-t pt-2">
            {folders.length === 0 ? (
              <p className="text-sm text-muted-foreground text-center py-4">No folders yet. Create one above.</p>
            ) : renderFolderTree(null)}
          </div>
        </CardContent>
      </Card>

      {/* Add Resource */}
      <Card className="glass-card">
        <CardHeader><CardTitle>Add Resource</CardTitle></CardHeader>
        <CardContent>
          <form onSubmit={handleCreate} className="grid gap-4 md:grid-cols-2">
            <div><Label>Title</Label><Input value={title} onChange={(e) => setTitle(e.target.value)} required /></div>
            <div>
              <Label>Folder</Label>
              <Select value={category} onValueChange={setCategory}>
                <SelectTrigger><SelectValue placeholder="Select folder" /></SelectTrigger>
                <SelectContent>
                  {folderOptions.map(o => <SelectItem key={o.id} value={o.path}>{o.path}</SelectItem>)}
                </SelectContent>
              </Select>
            </div>
            <div className="md:col-span-2"><Label>Description</Label><Textarea value={description} onChange={(e) => setDescription(e.target.value)} rows={2} /></div>
            <div className="md:col-span-2"><Label>File</Label><Input type="file" onChange={(e) => setFile(e.target.files?.[0] || null)} required /></div>
            <div><Button type="submit" disabled={loading}><Plus className="h-4 w-4 mr-1" /> {loading ? "Uploading..." : "Add Resource"}</Button></div>
          </form>
        </CardContent>
      </Card>

      {/* Browse & Reorder (drag-and-drop) */}
      <Card className="glass-card">
        <CardHeader>
          <CardTitle>Browse & Organize</CardTitle>
          <p className="text-xs text-muted-foreground">
            Drag files / folders to reorder or move · Drop files from your computer onto a folder to upload · Click a file to preview
          </p>
        </CardHeader>
        <CardContent className="p-2">
          {folders.length === 0 ? (
            <p className="text-sm text-muted-foreground text-center py-6">Create a folder above to get started.</p>
          ) : (
            <ResourceTree
              folders={folders as FolderItem[]}
              resources={resources as ResourceItem[]}
              search=""
              expanded={expanded}
              toggleExpand={toggleExpand}
              onPreview={setPreviewing}
              draggable
              onDropAction={(target, payload, files) =>
                handleResourceDrop({
                  target, payload, files,
                  folders: folders as FolderItem[],
                  resources: resources as ResourceItem[],
                  authorId: user!.id,
                  onChanged: fetchAll,
                })
              }
            />
          )}
        </CardContent>
      </Card>

      {/* Delete files list */}
      <Card className="glass-card">
        <CardHeader><CardTitle className="text-base">Delete Files</CardTitle></CardHeader>
        <CardContent>
          <div className="space-y-1 max-h-80 overflow-y-auto">
            {resources.length === 0 ? (
              <p className="text-sm text-muted-foreground text-center py-4">No files yet.</p>
            ) : resources.map((r) => (
              <div key={r.id} className="flex items-center gap-2 py-1.5 px-2 rounded-md hover:bg-muted/50">
                <span className="text-sm flex-1 truncate">{r.title}</span>
                <Badge variant="outline" className="text-[10px]">{r.category}</Badge>
                <Button variant="ghost" size="icon" className="h-7 w-7" onClick={() => handleDelete(r.id)}>
                  <Trash2 className="h-3.5 w-3.5 text-destructive" />
                </Button>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      {previewing && (
        <FileViewerDialog
          open={!!previewing}
          onOpenChange={(o) => !o && setPreviewing(null)}
          fileUrl={previewing.file_url}
          fileName={previewing.file_name}
          title={previewing.title}
        />
      )}
    </div>
  );
}
