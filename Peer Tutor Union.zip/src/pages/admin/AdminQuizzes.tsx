import QuizTab from "@/components/admin/QuizTab";
import QuizAssembly from "@/components/admin/QuizAssembly";
import QuestionBankBrowser from "@/components/questions/QuestionBankBrowser";
import QuestionUploadDialog from "@/components/questions/QuestionUploadDialog";
import SubjectManagerDialog from "@/components/questions/SubjectManagerDialog";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Button } from "@/components/ui/button";
import { Plus } from "lucide-react";
import { useState } from "react";
import { useAuth } from "@/contexts/AuthContext";
import { canManageSubjects } from "@/lib/questionBank";

export default function AdminQuizzes() {
  const { displayRole, isAdmin } = useAuth();
  const [uploadOpen, setUploadOpen] = useState(false);
  const [refreshKey, setRefreshKey] = useState(0);

  return (
    <div className="space-y-6">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <h2 className="text-2xl font-bold text-foreground">Quizzes</h2>
        <div className="flex items-center gap-2">
          {canManageSubjects(displayRole, isAdmin) && <SubjectManagerDialog onChanged={() => setRefreshKey((k) => k + 1)} />}
          <Button size="sm" className="gap-2" onClick={() => setUploadOpen(true)}><Plus className="h-4 w-4" /> Upload question</Button>
        </div>
      </div>

      <Tabs defaultValue="quizzes">
        <TabsList>
          <TabsTrigger value="quizzes">Quizzes</TabsTrigger>
          <TabsTrigger value="assembly">Paper assembly</TabsTrigger>
          <TabsTrigger value="bank">Question bank</TabsTrigger>
        </TabsList>
        <TabsContent value="quizzes" className="pt-4"><QuizTab /></TabsContent>
        <TabsContent value="assembly" className="pt-4"><QuizAssembly /></TabsContent>
        <TabsContent value="bank" className="pt-4"><QuestionBankBrowser refreshKey={refreshKey} /></TabsContent>
      </Tabs>

      <QuestionUploadDialog open={uploadOpen} onOpenChange={setUploadOpen} onSaved={() => setRefreshKey((k) => k + 1)} />
    </div>
  );
}
