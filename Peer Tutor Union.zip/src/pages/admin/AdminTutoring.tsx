import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { toast } from "sonner";
import { Check, X, Pencil, Trash2 } from "lucide-react";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle } from "@/components/ui/alert-dialog";

type TutoringRequest = {
  id: string;
  user_id: string;
  subject: string;
  session_type: string;
  requested_date: string;
  start_time: string;
  end_time: string;
  tutor_name: string | null;
  location: string | null;
  student_note: string | null;
  admin_note: string | null;
  status: string;
  parent_request_id: string | null;
};

export default function AdminTutoring() {
  const [requests, setRequests] = useState<TutoringRequest[]>([]);
  const [edits, setEdits] = useState<Record<string, Partial<TutoringRequest>>>({});
  const [names, setNames] = useState<Record<string, string>>({});
  const [tutors, setTutors] = useState<string[]>([]);
  const [editing, setEditing] = useState<TutoringRequest | null>(null);
  const [deleting, setDeleting] = useState<TutoringRequest | null>(null);

  const load = async () => {
    const [{ data: p }, { data: r }] = await Promise.all([
      supabase.from("profiles").select("user_id,name,display_role"),
      supabase.from("tutoring_requests").select("*").order("requested_date", { ascending: true }),
    ]);
    setRequests((r as TutoringRequest[]) || []);
    const profiles = (p as { user_id: string; name: string; display_role: string }[]) || [];
    const map: Record<string, string> = {};
    profiles.forEach((x) => { map[x.user_id] = x.name; });
    setNames(map);
    setTutors(profiles.filter((x) => x.display_role === "Teacher").map((x) => x.name).filter(Boolean));
  };

  const reqField = (r: TutoringRequest, k: keyof TutoringRequest) =>
    (edits[r.id]?.[k] as string | null | undefined) ?? (r[k] as string | null) ?? "";

  const setReqField = (id: string, k: keyof TutoringRequest, v: string) =>
    setEdits((e) => ({ ...e, [id]: { ...e[id], [k]: v } }));

  const saveRequest = async (r: TutoringRequest, status?: string) => {
    const patch: Record<string, unknown> = { ...(edits[r.id] || {}) };
    if (status) patch.status = status;
    if (Object.keys(patch).length === 0) return;
    const { error } = await supabase.from("tutoring_requests").update(patch as any).eq("id", r.id);
    if (error) return toast.error(error.message);
    toast.success(status ? `Request ${status}` : "Request updated");
    setEdits((e) => { const n = { ...e }; delete n[r.id]; return n; });
    load();
  };

  const editField = (k: keyof TutoringRequest) => (editing?.[k] as string | null) ?? "";
  const setEditField = (k: keyof TutoringRequest, v: string) =>
    setEditing((e) => (e ? { ...e, [k]: v } : e));

  const saveEditing = async () => {
    if (!editing) return;
    const { error } = await supabase
      .from("tutoring_requests")
      .update({
        subject: editing.subject,
        session_type: editing.session_type,
        requested_date: editing.requested_date,
        start_time: editing.start_time,
        end_time: editing.end_time,
        tutor_name: editing.tutor_name,
        location: editing.location,
        admin_note: editing.admin_note,
      })
      .eq("id", editing.id);
    if (error) return toast.error(error.message);
    toast.success("Session updated");
    setEditing(null);
    load();
  };

  const deleteRequest = async () => {
    if (!deleting) return;
    const { error } = await supabase.from("tutoring_requests").delete().eq("id", deleting.id);
    if (error) return toast.error(error.message);
    toast.success("Session deleted");
    setDeleting(null);
    load();
  };

  useEffect(() => { load(); }, []);

  const pendingRequests = requests.filter((r) => r.status === "pending");
  const approvedRequests = requests.filter((r) => r.status === "approved" && !r.parent_request_id);
  const studentsByCourse = requests.reduce<Record<string, string[]>>((acc, r) => {
    if (r.parent_request_id && r.status === "approved") {
      (acc[r.parent_request_id] ||= []).push(names[r.user_id] || "Member");
    }
    return acc;
  }, {});
  const courseLabel = (id: string | null) => {
    const c = requests.find((x) => x.id === id);
    return c ? `${c.subject} · ${c.requested_date} ${c.start_time}–${c.end_time}${c.tutor_name ? ` · ${c.tutor_name}` : ""}` : "—";
  };


  return (
    <div className="space-y-6">
      <h2 className="text-2xl font-bold text-foreground">Tutoring</h2>

      <Card className="glass-card">
        <CardHeader><CardTitle>Timetable</CardTitle><CardDescription>Approved sessions, scheduled automatically from student requests</CardDescription></CardHeader>
        <CardContent>
          {approvedRequests.length === 0 ? <p className="text-sm text-muted-foreground">No scheduled sessions yet.</p> : (
            <Table>
              <TableHeader><TableRow><TableHead>Date</TableHead><TableHead>Time</TableHead><TableHead>Requested by</TableHead><TableHead>Subject</TableHead><TableHead>Type</TableHead><TableHead>Tutor</TableHead><TableHead>Location</TableHead><TableHead>Students</TableHead><TableHead>Note</TableHead><TableHead className="w-24">Actions</TableHead></TableRow></TableHeader>
              <TableBody>
                {approvedRequests.map((r) => (
                  <TableRow key={r.id}>
                    <TableCell>{r.requested_date}</TableCell>
                    <TableCell>{r.start_time}–{r.end_time}</TableCell>
                    <TableCell>{names[r.user_id] || "Member"}</TableCell>
                    <TableCell>{r.subject}</TableCell>
                    <TableCell>{r.session_type === "tutorial" ? "Tutorial" : "Study Group"}</TableCell>
                    <TableCell>{r.tutor_name || "—"}</TableCell>
                    <TableCell>{r.location || "—"}</TableCell>
                    <TableCell className="text-xs">{(studentsByCourse[r.id] || []).join(", ") || "—"}</TableCell>
                    <TableCell className="text-xs text-muted-foreground">{r.admin_note || "—"}</TableCell>

                    <TableCell>
                      <div className="flex gap-1">
                        <Button size="icon" variant="ghost" className="h-8 w-8" onClick={() => setEditing(r)}><Pencil className="h-3.5 w-3.5" /></Button>
                        <Button size="icon" variant="ghost" className="h-8 w-8 text-destructive" onClick={() => setDeleting(r)}><Trash2 className="h-3.5 w-3.5" /></Button>
                      </div>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          )}
        </CardContent>
      </Card>

      <Card className="glass-card">
        <CardHeader>
          <CardTitle>Tutorial Requests</CardTitle>
          <CardDescription>Pending requests — approve, reject, or adjust the date, time and subject</CardDescription>
        </CardHeader>
        <CardContent className="space-y-3">
          {pendingRequests.length === 0 ? <p className="text-sm text-muted-foreground">No pending requests.</p> : pendingRequests.map((r) => (
            <div key={r.id} className="rounded-xl border border-border/60 bg-card/50 p-3 space-y-3">
              <div className="flex items-center justify-between gap-2">
                <p className="font-medium text-foreground">{names[r.user_id] || "Member"}</p>
                <div className="flex gap-2">
                  {r.parent_request_id && <Badge>Join course</Badge>}
                  <Badge variant="secondary">{r.status}</Badge>
                </div>
              </div>
              {r.parent_request_id && (
                <p className="text-xs text-muted-foreground">Course: {courseLabel(r.parent_request_id)}</p>
              )}
              {r.student_note && <p className="text-xs text-muted-foreground">Note: {r.student_note}</p>}
              <div className="grid gap-3 md:grid-cols-3">

                <div><Label>Subject</Label><Input value={reqField(r, "subject")} onChange={(e) => setReqField(r.id, "subject", e.target.value)} /></div>
                <div>
                  <Label>Type</Label>
                  <Select value={reqField(r, "session_type")} onValueChange={(v) => setReqField(r.id, "session_type", v)}>
                    <SelectTrigger><SelectValue /></SelectTrigger>
                    <SelectContent>
                      <SelectItem value="tutorial">Tutorial</SelectItem>
                      <SelectItem value="study_group">Study Group</SelectItem>
                      <SelectItem value="student">Student (course)</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div><Label>Date</Label><Input type="date" value={reqField(r, "requested_date")} onChange={(e) => setReqField(r.id, "requested_date", e.target.value)} /></div>
                <div><Label>Start</Label><Input type="time" value={reqField(r, "start_time")} onChange={(e) => setReqField(r.id, "start_time", e.target.value)} /></div>
                <div><Label>End</Label><Input type="time" value={reqField(r, "end_time")} onChange={(e) => setReqField(r.id, "end_time", e.target.value)} /></div>
                <div>
                  <Label>Tutor</Label>
                  <Select value={reqField(r, "tutor_name")} onValueChange={(v) => setReqField(r.id, "tutor_name", v)}>
                    <SelectTrigger><SelectValue placeholder="Select a tutor" /></SelectTrigger>
                    <SelectContent>
                      {tutors.map((t) => <SelectItem key={t} value={t}>{t}</SelectItem>)}
                    </SelectContent>
                  </Select>
                </div>
                <div><Label>Location</Label><Input value={reqField(r, "location")} onChange={(e) => setReqField(r.id, "location", e.target.value)} /></div>
                <div className="md:col-span-2"><Label>Admin note</Label><Input value={reqField(r, "admin_note")} onChange={(e) => setReqField(r.id, "admin_note", e.target.value)} /></div>
              </div>
              <div className="flex flex-wrap gap-2">
                <Button size="sm" onClick={() => saveRequest(r, "approved")}><Check className="h-4 w-4 mr-1" /> Approve</Button>
                <Button size="sm" variant="destructive" onClick={() => saveRequest(r, "rejected")}><X className="h-4 w-4 mr-1" /> Reject</Button>
                <Button size="sm" variant="outline" onClick={() => saveRequest(r)}>Save changes</Button>
              </div>
            </div>
          ))}
        </CardContent>
      </Card>

      <Dialog open={!!editing} onOpenChange={(v) => !v && setEditing(null)}>
        <DialogContent className="sm:max-w-lg">
          <DialogHeader><DialogTitle>Edit session</DialogTitle></DialogHeader>
          {editing && (
            <div className="grid gap-3 md:grid-cols-2">
              <div><Label>Subject</Label><Input value={editField("subject")} onChange={(e) => setEditField("subject", e.target.value)} /></div>
              <div>
                <Label>Type</Label>
                <Select value={editField("session_type")} onValueChange={(v) => setEditField("session_type", v)}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="tutorial">Tutorial</SelectItem>
                    <SelectItem value="study_group">Study Group</SelectItem>
                      <SelectItem value="student">Student (course)</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div><Label>Date</Label><Input type="date" value={editField("requested_date")} onChange={(e) => setEditField("requested_date", e.target.value)} /></div>
              <div className="grid grid-cols-2 gap-2">
                <div><Label>Start</Label><Input type="time" value={editField("start_time")} onChange={(e) => setEditField("start_time", e.target.value)} /></div>
                <div><Label>End</Label><Input type="time" value={editField("end_time")} onChange={(e) => setEditField("end_time", e.target.value)} /></div>
              </div>
              <div>
                <Label>Tutor</Label>
                <Select value={editField("tutor_name")} onValueChange={(v) => setEditField("tutor_name", v)}>
                  <SelectTrigger><SelectValue placeholder="Select a tutor" /></SelectTrigger>
                  <SelectContent>
                    {tutors.map((t) => <SelectItem key={t} value={t}>{t}</SelectItem>)}
                  </SelectContent>
                </Select>
              </div>
              <div><Label>Location</Label><Input value={editField("location")} onChange={(e) => setEditField("location", e.target.value)} /></div>
              <div className="md:col-span-2"><Label>Admin note</Label><Input value={editField("admin_note")} onChange={(e) => setEditField("admin_note", e.target.value)} /></div>
            </div>
          )}
          <DialogFooter>
            <Button variant="outline" onClick={() => setEditing(null)}>Cancel</Button>
            <Button onClick={saveEditing}>Save</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      <AlertDialog open={!!deleting} onOpenChange={(v) => !v && setDeleting(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Delete this session?</AlertDialogTitle>
            <AlertDialogDescription>
              This removes the session from the timetable and the student's schedule. This cannot be undone.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction onClick={deleteRequest}>Delete</AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}
