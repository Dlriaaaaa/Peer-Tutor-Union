import { useState, useEffect } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/contexts/AuthContext";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { toast } from "sonner";
import { Award, Trash2 } from "lucide-react";

type Profile = { user_id: string; name: string; avatar_url: string | null; bio: string };

export default function AdminAwards() {
  const { user } = useAuth();
  const [students, setStudents] = useState<Profile[]>([]);
  const [awards, setAwards] = useState<any[]>([]);
  const [studentId, setStudentId] = useState("");
  const [title, setTitle] = useState("");
  const [description, setDescription] = useState("");

  const fetchAll = async () => {
    const [profRes, roleRes, awardRes] = await Promise.all([
      supabase.from("profiles").select("*").order("name"),
      supabase.from("user_roles").select("user_id, role"),
      supabase.from("awards").select("*").order("granted_at", { ascending: false }),
    ]);
    const adminIds = new Set((roleRes.data || []).filter((r) => r.role === "admin").map((r) => r.user_id));
    setStudents((profRes.data || []).filter((p) => !adminIds.has(p.user_id)));
    const nameMap = new Map((profRes.data || []).map((p) => [p.user_id, p.name]));
    setAwards((awardRes.data || []).map((a: any) => ({ ...a, student_name: nameMap.get(a.student_id) || "Unknown" })));
  };

  useEffect(() => { fetchAll(); }, []);

  const addAward = async () => {
    if (!studentId || !title || !user) return;
    const { error } = await supabase.from("awards").insert({ student_id: studentId, title, description, granted_by: user.id });
    if (!error) {
      // Notify the student about their new award
      await supabase.from("notifications").insert({
        user_id: studentId,
        actor_id: user.id,
        type: "award",
      });
    }
    toast.success("Award granted");
    setTitle(""); setDescription(""); setStudentId("");
    fetchAll();
  };

  const deleteAward = async (id: string) => {
    await supabase.from("awards").delete().eq("id", id);
    toast.success("Award removed"); fetchAll();
  };

  return (
    <div className="space-y-6">
      <h2 className="text-2xl font-bold text-foreground">Awards</h2>
      <Card className="glass-card">
        <CardHeader><CardTitle>Grant Award</CardTitle></CardHeader>
        <CardContent>
          <div className="grid gap-4 md:grid-cols-2">
            <div>
              <Label>Student</Label>
              <Select value={studentId} onValueChange={setStudentId}>
                <SelectTrigger><SelectValue placeholder="Select student" /></SelectTrigger>
                <SelectContent>{students.map((s) => <SelectItem key={s.user_id} value={s.user_id}>{s.name}</SelectItem>)}</SelectContent>
              </Select>
            </div>
            <div><Label>Title</Label><Input value={title} onChange={(e) => setTitle(e.target.value)} placeholder="e.g. Best Presenter" /></div>
            <div className="md:col-span-2"><Label>Description (optional)</Label><Textarea value={description} onChange={(e) => setDescription(e.target.value)} rows={2} /></div>
            <div><Button onClick={addAward}><Award className="h-4 w-4 mr-1" /> Grant Award</Button></div>
          </div>
        </CardContent>
      </Card>
      <Card className="glass-card">
        <CardHeader><CardTitle>All Awards</CardTitle></CardHeader>
        <CardContent>
          <Table>
            <TableHeader><TableRow><TableHead>Student</TableHead><TableHead>Award</TableHead><TableHead className="w-20"></TableHead></TableRow></TableHeader>
            <TableBody>
              {awards.map((a: any) => (
                <TableRow key={a.id}>
                  <TableCell>{a.student_name}</TableCell>
                  <TableCell className="font-medium">{a.title}</TableCell>
                  <TableCell><Button variant="ghost" size="icon" onClick={() => deleteAward(a.id)}><Trash2 className="h-4 w-4 text-destructive" /></Button></TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </CardContent>
      </Card>
    </div>
  );
}
