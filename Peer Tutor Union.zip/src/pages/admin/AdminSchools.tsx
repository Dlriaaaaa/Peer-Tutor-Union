import { useEffect, useMemo, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/contexts/AuthContext";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { toast } from "sonner";
import { Plus, Power, Trash2 } from "lucide-react";
import {
  CLUB_ROLES, clubRoleLabel, fetchClubs, fetchSchools,
  type Club, type ClubRole, type School,
} from "@/lib/schools";

type MemberRow = {
  id: string;
  club_id: string;
  user_id: string;
  club_role: ClubRole;
  status: "pending" | "approved" | "rejected";
};

export default function AdminSchools() {
  const { isSuperAdmin } = useAuth();
  const [schools, setSchools] = useState<School[]>([]);
  const [clubs, setClubs] = useState<Club[]>([]);
  const [members, setMembers] = useState<MemberRow[]>([]);
  const [names, setNames] = useState<Record<string, string>>({});
  const [schoolFilter, setSchoolFilter] = useState("all");

  const [form, setForm] = useState({ country: "", region: "", city: "", name: "" });
  const [clubForm, setClubForm] = useState({ school_id: "", name: "", description: "" });

  const load = async () => {
    const [s, c] = await Promise.all([fetchSchools(false), fetchClubs()]);
    setSchools(s);
    setClubs(c);
    const { data: m } = await supabase.from("club_members").select("*");
    const rows = (m as MemberRow[]) || [];
    setMembers(rows);
    if (rows.length) {
      const { data: profs } = await supabase.from("profiles").select("user_id, name")
        .in("user_id", [...new Set(rows.map((r) => r.user_id))]);
      setNames(Object.fromEntries((profs || []).map((p: any) => [p.user_id, p.name])));
    }
  };

  useEffect(() => { load(); }, []);

  const schoolName = useMemo(() => Object.fromEntries(schools.map((s) => [s.id, s.name])), [schools]);

  if (!isSuperAdmin) {
    return <p className="text-sm text-muted-foreground">This area is only available to the platform owner.</p>;
  }

  const addSchool = async () => {
    const { country, region, city, name } = form;
    if (!country.trim() || !region.trim() || !city.trim() || !name.trim()) {
      toast.error("Fill in country, region, city and school name"); return;
    }
    const dup = schools.some(
      (s) => s.name.trim().toLowerCase() === name.trim().toLowerCase() &&
             s.city.trim().toLowerCase() === city.trim().toLowerCase()
    );
    if (dup) { toast.error("That school already exists in this city"); return; }
    const { error } = await supabase.from("schools").insert({
      country: country.trim(), region: region.trim(), city: city.trim(), name: name.trim(),
    });
    if (error) { toast.error(error.message); return; }
    setForm({ country: "", region: "", city: "", name: "" });
    toast.success("School added");
    load();
  };

  const toggleSchool = async (s: School) => {
    await supabase.from("schools").update({ is_active: !s.is_active }).eq("id", s.id);
    load();
  };

  const addClub = async () => {
    if (!clubForm.school_id || !clubForm.name.trim()) { toast.error("Pick a school and name the club"); return; }
    const { error } = await supabase.from("clubs").insert({
      school_id: clubForm.school_id, name: clubForm.name.trim(),
      description: clubForm.description.trim() || null,
    });
    if (error) { toast.error(error.message); return; }
    setClubForm({ school_id: "", name: "", description: "" });
    toast.success("Club created");
    load();
  };

  const removeClub = async (id: string) => {
    if (!confirm("Delete this club?")) return;
    const { error } = await supabase.from("clubs").delete().eq("id", id);
    if (error) { toast.error(error.message); return; }
    load();
  };

  const setMemberRole = async (row: MemberRow, role: ClubRole) => {
    const { error } = await supabase.from("club_members").update({ club_role: role }).eq("id", row.id);
    if (error) { toast.error(error.message); return; }
    toast.success("Role updated");
    load();
  };

  const setMemberStatus = async (row: MemberRow, status: MemberRow["status"]) => {
    const { error } = await supabase.from("club_members").update({ status }).eq("id", row.id);
    if (error) { toast.error(error.message); return; }
    load();
  };

  const shownClubs = schoolFilter === "all" ? clubs : clubs.filter((c) => c.school_id === schoolFilter);

  return (
    <div className="space-y-6">
      <h2 className="text-2xl font-bold text-foreground">Schools & Clubs</h2>

      <Tabs defaultValue="schools">
        <TabsList>
          <TabsTrigger value="schools">School registry</TabsTrigger>
          <TabsTrigger value="clubs">Clubs & roles</TabsTrigger>
        </TabsList>

        <TabsContent value="schools" className="space-y-4 pt-4">
          <Card className="glass-card">
            <CardHeader><CardTitle className="text-base">Add a school</CardTitle></CardHeader>
            <CardContent className="grid gap-3 sm:grid-cols-5">
              <div><Label className="text-xs">Country</Label><Input value={form.country} onChange={(e) => setForm({ ...form, country: e.target.value })} /></div>
              <div><Label className="text-xs">Region</Label><Input value={form.region} onChange={(e) => setForm({ ...form, region: e.target.value })} /></div>
              <div><Label className="text-xs">City</Label><Input value={form.city} onChange={(e) => setForm({ ...form, city: e.target.value })} /></div>
              <div><Label className="text-xs">School</Label><Input value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} /></div>
              <div className="flex items-end"><Button className="gap-2" onClick={addSchool}><Plus className="h-4 w-4" /> Add</Button></div>
            </CardContent>
          </Card>

          <div className="space-y-2">
            {schools.map((s) => (
              <div key={s.id} className="flex items-center justify-between rounded-xl border bg-muted/10 p-3">
                <div>
                  <p className="text-sm font-medium">{s.name}</p>
                  <p className="text-xs text-muted-foreground">{s.city} · {s.region} · {s.country}</p>
                </div>
                <div className="flex items-center gap-2">
                  <Badge variant={s.is_active ? "default" : "secondary"}>{s.is_active ? "Active" : "Hidden"}</Badge>
                  <Button size="sm" variant="outline" className="gap-1" onClick={() => toggleSchool(s)}>
                    <Power className="h-3.5 w-3.5" /> {s.is_active ? "Hide" : "Activate"}
                  </Button>
                </div>
              </div>
            ))}
            {schools.length === 0 && <p className="text-sm text-muted-foreground">No schools yet.</p>}
          </div>
        </TabsContent>

        <TabsContent value="clubs" className="space-y-4 pt-4">
          <Card className="glass-card">
            <CardHeader><CardTitle className="text-base">Create a club</CardTitle></CardHeader>
            <CardContent className="grid gap-3 sm:grid-cols-4">
              <div>
                <Label className="text-xs">School</Label>
                <Select value={clubForm.school_id} onValueChange={(v) => setClubForm({ ...clubForm, school_id: v })}>
                  <SelectTrigger><SelectValue placeholder="Select school" /></SelectTrigger>
                  <SelectContent>
                    {schools.map((s) => <SelectItem key={s.id} value={s.id}>{s.name}</SelectItem>)}
                  </SelectContent>
                </Select>
              </div>
              <div><Label className="text-xs">Club name</Label><Input value={clubForm.name} onChange={(e) => setClubForm({ ...clubForm, name: e.target.value })} /></div>
              <div><Label className="text-xs">Description</Label><Input value={clubForm.description} onChange={(e) => setClubForm({ ...clubForm, description: e.target.value })} /></div>
              <div className="flex items-end"><Button className="gap-2" onClick={addClub}><Plus className="h-4 w-4" /> Create</Button></div>
            </CardContent>
          </Card>

          <div className="w-56">
            <Label className="text-xs">Filter by school</Label>
            <Select value={schoolFilter} onValueChange={setSchoolFilter}>
              <SelectTrigger><SelectValue /></SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All schools</SelectItem>
                {schools.map((s) => <SelectItem key={s.id} value={s.id}>{s.name}</SelectItem>)}
              </SelectContent>
            </Select>
          </div>

          {shownClubs.map((c) => {
            const rows = members.filter((m) => m.club_id === c.id);
            return (
              <Card key={c.id} className="glass-card">
                <CardHeader className="flex flex-row items-center justify-between">
                  <div>
                    <CardTitle className="text-base">{c.name}</CardTitle>
                    <p className="text-xs text-muted-foreground">{schoolName[c.school_id]}</p>
                  </div>
                  <Button variant="ghost" size="icon" onClick={() => removeClub(c.id)}>
                    <Trash2 className="h-4 w-4 text-destructive" />
                  </Button>
                </CardHeader>
                <CardContent className="space-y-2">
                  {rows.length === 0 && <p className="text-sm text-muted-foreground">No members yet.</p>}
                  {rows.map((m) => (
                    <div key={m.id} className="flex flex-wrap items-center gap-2 rounded-lg border bg-muted/10 p-2">
                      <span className="text-sm flex-1 min-w-[120px]">{names[m.user_id] || "Member"}</span>
                      <Badge variant={m.status === "approved" ? "default" : "secondary"}>{m.status}</Badge>
                      <Select value={m.club_role} onValueChange={(v) => setMemberRole(m, v as ClubRole)}>
                        <SelectTrigger className="h-8 w-40 text-xs"><SelectValue /></SelectTrigger>
                        <SelectContent>
                          {CLUB_ROLES.map((r) => <SelectItem key={r} value={r}>{clubRoleLabel[r]}</SelectItem>)}
                        </SelectContent>
                      </Select>
                      {m.status !== "approved" && (
                        <Button size="sm" variant="outline" onClick={() => setMemberStatus(m, "approved")}>Approve</Button>
                      )}
                      {m.status !== "rejected" && (
                        <Button size="sm" variant="ghost" onClick={() => setMemberStatus(m, "rejected")}>Reject</Button>
                      )}
                    </div>
                  ))}
                </CardContent>
              </Card>
            );
          })}
        </TabsContent>
      </Tabs>
    </div>
  );
}
