import { useState, useEffect } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/contexts/AuthContext";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { toast } from "sonner";
import { Plus, Trash2 } from "lucide-react";

export default function AdminEvents() {
  const { user } = useAuth();
  const [title, setTitle] = useState("");
  const [description, setDescription] = useState("");
  const [eventDate, setEventDate] = useState("");
  const [location, setLocation] = useState("");
  const [maxParticipants, setMaxParticipants] = useState("");
  const [deadline, setDeadline] = useState("");
  const [registrationLink, setRegistrationLink] = useState("");
  const [events, setEvents] = useState<any[]>([]);
  const [loading, setLoading] = useState(false);

  const fetchEvents = async () => {
    const { data } = await supabase.from("events").select("*").order("created_at", { ascending: false });
    setEvents(data || []);
  };

  useEffect(() => { fetchEvents(); }, []);

  const handleCreate = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user) return;
    setLoading(true);
    const { error } = await supabase.from("events").insert({
      title, description,
      event_date: eventDate || null,
      location,
      max_participants: maxParticipants ? Number(maxParticipants) : null,
      registration_deadline: deadline || null,
      registration_link: registrationLink || null,
      created_by: user.id,
    } as any);
    if (error) { toast.error(error.message); setLoading(false); return; }
    toast.success("Event created");
    setTitle(""); setDescription(""); setEventDate(""); setLocation(""); setMaxParticipants(""); setDeadline(""); setRegistrationLink("");
    fetchEvents();
    setLoading(false);
  };

  const handleDelete = async (id: string) => {
    await supabase.from("events").delete().eq("id", id);
    toast.success("Event deleted");
    fetchEvents();
  };

  const toggleStatus = async (id: string, current: string) => {
    const newStatus = current === "open" ? "closed" : "open";
    await supabase.from("events").update({ status: newStatus } as any).eq("id", id);
    toast.success(`Event ${newStatus}`);
    fetchEvents();
  };

  return (
    <div className="space-y-6">
      <h2 className="text-2xl font-bold text-foreground">Events</h2>
      <Card className="glass-card">
        <CardHeader><CardTitle>Create Event</CardTitle><CardDescription>Publish an activity for students to register</CardDescription></CardHeader>
        <CardContent>
          <form onSubmit={handleCreate} className="grid gap-4 md:grid-cols-2">
            <div><Label>Title</Label><Input value={title} onChange={(e) => setTitle(e.target.value)} required /></div>
            <div><Label>Location</Label><Input value={location} onChange={(e) => setLocation(e.target.value)} /></div>
            <div><Label>Event Date</Label><Input type="datetime-local" value={eventDate} onChange={(e) => setEventDate(e.target.value)} /></div>
            <div><Label>Registration Deadline</Label><Input type="datetime-local" value={deadline} onChange={(e) => setDeadline(e.target.value)} /></div>
            <div><Label>Max Participants</Label><Input type="number" value={maxParticipants} onChange={(e) => setMaxParticipants(e.target.value)} placeholder="Leave empty for unlimited" /></div>
            <div><Label>Registration Link (optional)</Label><Input value={registrationLink} onChange={(e) => setRegistrationLink(e.target.value)} placeholder="https://..." /></div>
            <div className="md:col-span-2"><Label>Description</Label><Textarea value={description} onChange={(e) => setDescription(e.target.value)} rows={3} /></div>
            <div><Button type="submit" disabled={loading}><Plus className="h-4 w-4 mr-1" /> {loading ? "Creating..." : "Create Event"}</Button></div>
          </form>
        </CardContent>
      </Card>
      <Card className="glass-card">
        <CardHeader><CardTitle>All Events</CardTitle></CardHeader>
        <CardContent>
          <Table>
            <TableHeader><TableRow><TableHead>Title</TableHead><TableHead>Date</TableHead><TableHead>Status</TableHead><TableHead className="w-32">Actions</TableHead></TableRow></TableHeader>
            <TableBody>
              {events.map((ev) => (
                <TableRow key={ev.id}>
                  <TableCell className="font-medium">{ev.title}</TableCell>
                  <TableCell>{ev.event_date ? new Date(ev.event_date).toLocaleDateString() : "—"}</TableCell>
                  <TableCell><Badge variant={ev.status === "open" ? "default" : "secondary"}>{ev.status}</Badge></TableCell>
                  <TableCell className="flex gap-1">
                    <Button variant="outline" size="sm" onClick={() => toggleStatus(ev.id, ev.status)}>
                      {ev.status === "open" ? "Close" : "Open"}
                    </Button>
                    <Button variant="ghost" size="icon" onClick={() => handleDelete(ev.id)}><Trash2 className="h-4 w-4 text-destructive" /></Button>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </CardContent>
      </Card>
    </div>
  );
}
