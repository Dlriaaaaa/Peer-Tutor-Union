import { useState, useEffect } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/contexts/AuthContext";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Switch } from "@/components/ui/switch";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { toast } from "sonner";
import { UserPlus, Trash2, Users } from "lucide-react";
import { fetchClubs, fetchSchools, type Club, type School } from "@/lib/schools";

type DisplayRole = "President" | "VicePresident" | "Teacher" | "GeneralSecretary" | "VIPStudent" | "Student" | "Mascot" | "BadStudent" | "Deadbeat" | "Gay";
type Profile = { user_id: string; name: string; avatar_url: string | null; bio: string; display_role?: string; school_id?: string | null };

const NO_SCHOOL = "__none";

export default function AdminMembers() {
  const { user, isAdmin, isSuperAdmin, displayRole, memberships } = useAuth();
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [name, setName] = useState("");
  const [role, setRole] = useState<DisplayRole>("Student");
  const [newSchoolId, setNewSchoolId] = useState<string>(NO_SCHOOL);
  const [members, setMembers] = useState<(Profile & { role?: string })[]>([]);
  const [schools, setSchools] = useState<School[]>([]);
  const [clubs, setClubs] = useState<Club[]>([]);
  const [grants, setGrants] = useState<Record<string, boolean>>({});
  const [applications, setApplications] = useState<{ id: string; user_id: string; club_id: string; status: string }[]>([]);
  const [loading, setLoading] = useState(false);

  const canReviewClub = isAdmin || isSuperAdmin ||
    ["President", "VicePresident"].includes(displayRole || "") ||
    memberships.some((m) => m.status === "approved" && ["President", "VicePresident"].includes(m.club_role));

  const fetchMembers = async () => {
    const [{ data: profiles, error: profilesError }, { data: roles, error: rolesError }] = await Promise.all([
      supabase.from("profiles").select("*").order("name"),
      supabase.from("user_roles").select("user_id, role"),
    ]);
    if (profilesError || rolesError) {
      toast.error(profilesError?.message || rolesError?.message || "Unable to load members");
      return;
    }
    const roleMap = new Map(roles?.map((r) => [r.user_id, r.role]) || []);
    setMembers((profiles || []).map((p: any) => ({ ...p, role: roleMap.get(p.user_id) || "student", display_role: p.display_role || "Student" })));

    const { data: grantRows } = await supabase.from("question_upload_grants").select("user_id, is_active");
    setGrants(Object.fromEntries((grantRows || []).map((g: any) => [g.user_id, g.is_active])));

    const { data: apps } = await supabase.from("club_members").select("id, user_id, club_id, status").eq("status", "pending");
    setApplications((apps as any[]) || []);
  };

  const loadRegistry = async () => {
    const [s, c] = await Promise.all([fetchSchools(false), fetchClubs()]);
    setSchools(s);
    setClubs(c);
  };

  useEffect(() => { fetchMembers(); loadRegistry(); }, []);

  const schoolLabel = (id?: string | null) => schools.find((s) => s.id === id)?.name || "—";

  const setMemberSchool = async (userId: string, schoolId: string) => {
    const value = schoolId === NO_SCHOOL ? null : schoolId;
    const { error } = await supabase.from("profiles").update({ school_id: value } as any).eq("user_id", userId);
    if (error) { toast.error(error.message); return; }
    toast.success("School updated");
    fetchMembers();
  };

  const toggleGrant = async (userId: string, next: boolean) => {
    const { error } = await supabase
      .from("question_upload_grants")
      .upsert({ user_id: userId, granted_by: user?.id ?? null, is_active: next }, { onConflict: "user_id" });
    if (error) { toast.error(error.message); return; }
    setGrants((g) => ({ ...g, [userId]: next }));
    toast.success(next ? "Temporary upload access granted" : "Temporary upload access removed");
  };

  const reviewApplication = async (row: { id: string; user_id: string; club_id: string }, approve: boolean) => {
    const { error } = await supabase
      .from("club_members")
      .update({ status: approve ? "approved" : "rejected" })
      .eq("id", row.id);
    if (error) { toast.error(error.message); return; }
    if (approve) {
      const club = clubs.find((c) => c.id === row.club_id);
      await supabase
        .from("profiles")
        .update({ is_approved: true, ...(club ? { school_id: club.school_id } : {}) } as any)
        .eq("user_id", row.user_id);
    }
    toast.success(approve ? "Application approved" : "Application rejected");
    fetchMembers();
  };

  const handleAddMember = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    const schoolId = newSchoolId === NO_SCHOOL ? null : newSchoolId;
    const { data, error } = await supabase.functions.invoke("create-member", {
      body: { email, password, name, displayRole: role, schoolId },
    });
    const functionError = data?.error;
    if (error || functionError) {
      toast.error(functionError || error?.message || "Unable to create member");
      setLoading(false);
      return;
    }
    toast.success(`Member ${name} added successfully`);
    setEmail(""); setPassword(""); setName(""); setRole("Student"); setNewSchoolId(NO_SCHOOL);
    await fetchMembers();
    setLoading(false);
  };

  const memberName = (id: string) => members.find((m) => m.user_id === id)?.name || "Member";

  return (
    <div className="space-y-6">
      <h2 className="text-2xl font-bold text-foreground">Members</h2>
      <Card className="glass-card">
        <CardHeader>
          <CardTitle>Add New Member</CardTitle>
          <CardDescription>Create a new account for a student or teacher</CardDescription>
        </CardHeader>
        <CardContent>
          <form onSubmit={handleAddMember} className="grid gap-4 md:grid-cols-2">
            <div><Label>Name</Label><Input value={name} onChange={(e) => setName(e.target.value)} required /></div>
            <div><Label>Email</Label><Input type="email" value={email} onChange={(e) => setEmail(e.target.value)} required /></div>
            <div><Label>Temporary Password</Label><Input type="text" value={password} onChange={(e) => setPassword(e.target.value)} required minLength={6} /></div>
            <div>
              <Label>Role</Label>
              <Select value={role} onValueChange={(v) => setRole(v as DisplayRole)}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="President">President</SelectItem>
                  <SelectItem value="VicePresident">Vice President</SelectItem>
                  <SelectItem value="Teacher">Teacher</SelectItem>
                  <SelectItem value="GeneralSecretary">General Secretary</SelectItem>
                  <SelectItem value="VIPStudent">VIP Student</SelectItem>
                  <SelectItem value="Student">Student</SelectItem>
                  <SelectItem value="Mascot">吉祥物</SelectItem>
                  <SelectItem value="BadStudent">Bad Student</SelectItem>
                  <SelectItem value="Deadbeat">老赖</SelectItem>
                  <SelectItem value="Gay">Gay</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div>
              <Label>School</Label>
              <Select value={newSchoolId} onValueChange={setNewSchoolId}>
                <SelectTrigger><SelectValue placeholder="Select a school" /></SelectTrigger>
                <SelectContent>
                  <SelectItem value={NO_SCHOOL}>No school</SelectItem>
                  {schools.map((s) => <SelectItem key={s.id} value={s.id}>{s.name}</SelectItem>)}
                </SelectContent>
              </Select>
            </div>
            <div className="md:col-span-2">
              <Button type="submit" disabled={loading}><UserPlus className="h-4 w-4 mr-1" /> {loading ? "Adding..." : "Add Member"}</Button>
            </div>
          </form>
        </CardContent>
      </Card>

      {canReviewClub && (
        <Card className="glass-card">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Users className="h-5 w-5" /> Club applications
              {applications.length > 0 && <Badge className="ml-2">{applications.length}</Badge>}
            </CardTitle>
            <CardDescription>Approve members into their club and school</CardDescription>
          </CardHeader>
          <CardContent className="space-y-2">
            {applications.length === 0 && <p className="text-sm text-muted-foreground">No pending club applications.</p>}
            {applications.map((a) => {
              const club = clubs.find((c) => c.id === a.club_id);
              return (
                <div key={a.id} className="flex flex-wrap items-center gap-2 rounded-lg border bg-muted/10 p-2">
                  <span className="flex-1 min-w-[140px] text-sm">{memberName(a.user_id)}</span>
                  <span className="text-xs text-muted-foreground">
                    {club?.name || "Club"} · {schoolLabel(club?.school_id)}
                  </span>
                  <Button size="sm" onClick={() => reviewApplication(a, true)}>Approve</Button>
                  <Button size="sm" variant="ghost" onClick={() => reviewApplication(a, false)}>Reject</Button>
                </div>
              );
            })}
          </CardContent>
        </Card>
      )}

      <Card className="glass-card">
        <CardHeader><CardTitle>All Members ({members.length})</CardTitle></CardHeader>
        <CardContent>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Name</TableHead>
                <TableHead>Role</TableHead>
                <TableHead>Change Role</TableHead>
                <TableHead>School</TableHead>
                <TableHead>Temp upload access</TableHead>
                <TableHead className="w-20">Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {members.map((m) => {
                const dr = (m as any).display_role || "Student";
                const roleLabel: Record<string, string> = { President: "President", VicePresident: "Vice President", Teacher: "Teacher", GeneralSecretary: "General Secretary", VIPStudent: "VIP Student", Student: "Student", Mascot: "吉祥物", BadStudent: "Bad Student", Deadbeat: "老赖", Gay: "Gay" };
                return (
                <TableRow key={m.user_id}>
                  <TableCell className="font-medium">{m.name}</TableCell>
                  <TableCell><Badge variant={dr !== "Student" ? "default" : "secondary"}>{roleLabel[dr] || dr}</Badge></TableCell>
                  <TableCell>
                    <Select value={dr} onValueChange={async (v) => {
                      const appRole = v === "President" || ["VicePresident", "Teacher", "GeneralSecretary"].includes(v) ? "admin" : "student";
                      await supabase.from("profiles").update({ display_role: v } as any).eq("user_id", m.user_id);
                      await supabase.from("user_roles").delete().eq("user_id", m.user_id);
                      await supabase.from("user_roles").insert({ user_id: m.user_id, role: appRole });
                      toast.success(`${m.name} role updated to ${roleLabel[v] || v}`);
                      fetchMembers();
                    }}>
                      <SelectTrigger className="w-40 h-8"><SelectValue /></SelectTrigger>
                      <SelectContent>
                        <SelectItem value="Teacher">Teacher</SelectItem>
                        <SelectItem value="President">President</SelectItem>
                        <SelectItem value="VicePresident">Vice President</SelectItem>
                        <SelectItem value="VIPStudent">VIP Student</SelectItem>
                        <SelectItem value="Student">Student</SelectItem>

                      </SelectContent>
                    </Select>
                  </TableCell>
                  <TableCell>
                    <Select value={m.school_id || NO_SCHOOL} onValueChange={(v) => setMemberSchool(m.user_id, v)}>
                      <SelectTrigger className="w-48 h-8"><SelectValue /></SelectTrigger>
                      <SelectContent>
                        <SelectItem value={NO_SCHOOL}>No school</SelectItem>
                        {schools.map((s) => <SelectItem key={s.id} value={s.id}>{s.name}</SelectItem>)}
                      </SelectContent>
                    </Select>
                  </TableCell>
                  <TableCell>
                    <div className="flex items-center gap-2">
                      <Switch checked={!!grants[m.user_id]} onCheckedChange={(v) => toggleGrant(m.user_id, v)} />
                      <span className="text-xs text-muted-foreground">upload only</span>
                    </div>
                  </TableCell>
                  <TableCell>
                    <Button variant="ghost" size="icon" onClick={async () => {
                       if (!confirm(`Delete ${m.name}'s account?`)) return;
                       const { data, error } = await supabase.functions.invoke("delete-member", { body: { userId: m.user_id } });
                       if (error || data?.error) {
                         toast.error(data?.error || error?.message || "Unable to delete member");
                         return;
                       }
                      toast.success(`${m.name} removed`);
                       await fetchMembers();
                    }}>
                      <Trash2 className="h-4 w-4 text-destructive" />
                    </Button>
                  </TableCell>
                </TableRow>
                );
              })}
            </TableBody>
          </Table>
        </CardContent>
      </Card>
    </div>
  );
}
