import { useEffect, useMemo, useState } from "react";
import { useNavigate } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Checkbox } from "@/components/ui/checkbox";
import { toast } from "sonner";
import logo from "@/assets/logo.png";
import {
  citiesOf,
  countriesOf,
  fetchClubs,
  fetchSchools,
  regionsOf,
  schoolsOf,
  type Club,
  type School,
} from "@/lib/schools";

export default function LoginPage() {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [loading, setLoading] = useState(false);
  const [signupEmail, setSignupEmail] = useState("");
  const [signupPassword, setSignupPassword] = useState("");
  const [signupName, setSignupName] = useState("");
  const [signupLoading, setSignupLoading] = useState(false);
  const navigate = useNavigate();

  const [schools, setSchools] = useState<School[]>([]);
  const [country, setCountry] = useState("");
  const [region, setRegion] = useState("");
  const [city, setCity] = useState("");
  const [schoolId, setSchoolId] = useState("");
  const [clubs, setClubs] = useState<Club[]>([]);
  const [selectedClubs, setSelectedClubs] = useState<string[]>([]);

  useEffect(() => { fetchSchools().then(setSchools); }, []);

  useEffect(() => {
    setSelectedClubs([]);
    if (!schoolId) { setClubs([]); return; }
    fetchClubs(schoolId).then(setClubs);
  }, [schoolId]);

  const countries = useMemo(() => countriesOf(schools), [schools]);
  const regions = useMemo(() => regionsOf(schools, country), [schools, country]);
  const cities = useMemo(() => citiesOf(schools, country, region), [schools, country, region]);
  const schoolOptions = useMemo(() => schoolsOf(schools, country, region, city), [schools, country, region, city]);

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    const { error } = await supabase.auth.signInWithPassword({ email, password });
    setLoading(false);
    if (error) {
      toast.error(error.message);
    } else {
      navigate("/schedule");
    }
  };

  const handleSignup = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!schoolId) { toast.error("请选择你的学校"); return; }
    setSignupLoading(true);
    const { data, error } = await supabase.auth.signUp({
      email: signupEmail,
      password: signupPassword,
      options: {
        emailRedirectTo: window.location.origin,
        data: { name: signupName, school_id: schoolId },
      },
    });
    if (error) {
      setSignupLoading(false);
      toast.error(error.message);
      return;
    }

    if (data.session && data.user) {
      await supabase.from("profiles").update({ school_id: schoolId }).eq("user_id", data.user.id);
      if (selectedClubs.length > 0) {
        await supabase.from("club_members").insert(
          selectedClubs.map((club_id) => ({ club_id, user_id: data.user!.id, club_role: "Member", status: "pending" }))
        );
      }
      setSignupLoading(false);
      toast.success("注册成功，请等待管理员审核");
      navigate("/schedule");
      return;
    }

    setSignupLoading(false);
    toast.success("注册成功，请查收确认邮件后登录，并等待管理员审核");
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-background p-4">
      <div className="w-full max-w-md space-y-8">
        <div className="flex flex-col items-center text-center space-y-4">
          <img src={logo} alt="PTC Logo" className="h-24 w-24 object-contain" />
          <div>
            <h1 className="text-2xl font-bold text-foreground">Peer Tutor Club</h1>
            <p className="text-lg font-semibold text-primary mt-1">Student tutoring &amp; study groups</p>
          </div>
        </div>

        <Card>
          <CardHeader>
            <CardTitle>Welcome</CardTitle>
          </CardHeader>
          <CardContent>
            <Tabs defaultValue="login">
              <TabsList className="grid w-full grid-cols-2 mb-4">
                <TabsTrigger value="login">Sign In</TabsTrigger>
                <TabsTrigger value="signup">Sign Up</TabsTrigger>
              </TabsList>

              <TabsContent value="login">
                <form onSubmit={handleLogin} className="space-y-4">
                  <div className="space-y-2">
                    <Label htmlFor="login-email">Email</Label>
                    <Input id="login-email" type="email" value={email} onChange={(e) => setEmail(e.target.value)} placeholder="you@example.com" required />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="login-password">Password</Label>
                    <Input id="login-password" type="password" value={password} onChange={(e) => setPassword(e.target.value)} placeholder="••••••••" required />
                  </div>
                  <Button type="submit" className="w-full" disabled={loading}>
                    {loading ? "Signing in..." : "Sign In"}
                  </Button>
                </form>
              </TabsContent>

              <TabsContent value="signup">
                <form onSubmit={handleSignup} className="space-y-4">
                  <div className="space-y-2">
                    <Label htmlFor="signup-name">Name</Label>
                    <Input id="signup-name" value={signupName} onChange={(e) => setSignupName(e.target.value)} placeholder="你的名字" required />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="signup-email">Email</Label>
                    <Input id="signup-email" type="email" value={signupEmail} onChange={(e) => setSignupEmail(e.target.value)} placeholder="you@example.com" required />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="signup-password">Password</Label>
                    <Input id="signup-password" type="password" value={signupPassword} onChange={(e) => setSignupPassword(e.target.value)} placeholder="至少 6 位" minLength={6} required />
                  </div>

                  <div className="grid grid-cols-2 gap-2">
                    <div className="space-y-1">
                      <Label className="text-xs">Country</Label>
                      <Select value={country} onValueChange={(v) => { setCountry(v); setRegion(""); setCity(""); setSchoolId(""); }}>
                        <SelectTrigger><SelectValue placeholder="选择国家" /></SelectTrigger>
                        <SelectContent>
                          {countries.map((c) => <SelectItem key={c} value={c}>{c}</SelectItem>)}
                        </SelectContent>
                      </Select>
                    </div>
                    <div className="space-y-1">
                      <Label className="text-xs">Region / State</Label>
                      <Select value={region} disabled={!country} onValueChange={(v) => { setRegion(v); setCity(""); setSchoolId(""); }}>
                        <SelectTrigger><SelectValue placeholder="选择省/州" /></SelectTrigger>
                        <SelectContent>
                          {regions.map((r) => <SelectItem key={r} value={r}>{r}</SelectItem>)}
                        </SelectContent>
                      </Select>
                    </div>
                    <div className="space-y-1">
                      <Label className="text-xs">City</Label>
                      <Select value={city} disabled={!region} onValueChange={(v) => { setCity(v); setSchoolId(""); }}>
                        <SelectTrigger><SelectValue placeholder="选择城市" /></SelectTrigger>
                        <SelectContent>
                          {cities.map((c) => <SelectItem key={c} value={c}>{c}</SelectItem>)}
                        </SelectContent>
                      </Select>
                    </div>
                    <div className="space-y-1">
                      <Label className="text-xs">School</Label>
                      <Select value={schoolId} disabled={!city} onValueChange={setSchoolId}>
                        <SelectTrigger><SelectValue placeholder="选择学校" /></SelectTrigger>
                        <SelectContent>
                          {schoolOptions.map((s) => <SelectItem key={s.id} value={s.id}>{s.name}</SelectItem>)}
                        </SelectContent>
                      </Select>
                    </div>
                  </div>
                  <p className="text-[11px] text-muted-foreground">
                    学校只能从已有列表中选择。若没有你的学校，请联系总管理员添加。
                  </p>

                  {schoolId && (
                    <div className="rounded-xl border p-3 space-y-2">
                      <p className="text-xs font-medium">加入社团（可多选，需社长审核）</p>
                      {clubs.length === 0 && <p className="text-xs text-muted-foreground">该学校暂无社团。</p>}
                      {clubs.map((c) => (
                        <label key={c.id} className="flex items-center gap-2 text-sm">
                          <Checkbox
                            checked={selectedClubs.includes(c.id)}
                            onCheckedChange={(v) =>
                              setSelectedClubs((prev) => (v ? [...prev, c.id] : prev.filter((x) => x !== c.id)))
                            }
                          />
                          {c.name}
                        </label>
                      ))}
                    </div>
                  )}

                  <Button type="submit" className="w-full" disabled={signupLoading}>
                    {signupLoading ? "Creating account..." : "Sign Up"}
                  </Button>
                  <p className="text-xs text-muted-foreground text-center">注册后账号需管理员审核通过才能使用完整功能。</p>
                </form>
              </TabsContent>
            </Tabs>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
