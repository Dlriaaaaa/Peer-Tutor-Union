import { useState, useEffect } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/contexts/AuthContext";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";
import { toast } from "sonner";
import { UserPlus, UserCheck, UserX, Users } from "lucide-react";
import { useNavigate } from "react-router-dom";

type Profile = { user_id: string; name: string; avatar_url: string | null };
type Friendship = { id: string; requester_id: string; addressee_id: string; status: string };

export default function Contacts() {
  const { user } = useAuth();
  const navigate = useNavigate();
  const [profiles, setProfiles] = useState<Profile[]>([]);
  const [friendships, setFriendships] = useState<Friendship[]>([]);
  const [loading, setLoading] = useState(true);

  const fetchData = async () => {
    const [profRes, friendRes] = await Promise.all([
      supabase.from("profiles").select("user_id, name, avatar_url").order("name"),
      supabase.from("friendships").select("*"),
    ]);
    setProfiles((profRes.data || []).filter((p) => p.user_id !== user?.id));
    setFriendships(friendRes.data || []);
    setLoading(false);
  };

  useEffect(() => { if (user) fetchData(); }, [user]);

  const getFriendship = (otherUserId: string) => {
    return friendships.find(
      (f) => (f.requester_id === user?.id && f.addressee_id === otherUserId) ||
             (f.addressee_id === user?.id && f.requester_id === otherUserId)
    );
  };

  const sendRequest = async (otherUserId: string) => {
    const { error } = await supabase.from("friendships").insert({ requester_id: user!.id, addressee_id: otherUserId });
    if (error) { toast.error(error.message); return; }
    toast.success("Friend request sent");
    fetchData();
  };

  const acceptRequest = async (friendshipId: string) => {
    await supabase.from("friendships").update({ status: "accepted" }).eq("id", friendshipId);
    toast.success("Friend request accepted");
    fetchData();
  };

  const removeFriend = async (friendshipId: string) => {
    await supabase.from("friendships").delete().eq("id", friendshipId);
    toast.success("Removed");
    fetchData();
  };

  const pendingRequests = friendships.filter((f) => f.addressee_id === user?.id && f.status === "pending");
  const friends = friendships.filter((f) => f.status === "accepted");
  const friendIds = friends.map((f) => f.requester_id === user?.id ? f.addressee_id : f.requester_id);

  if (loading) return <div className="flex items-center justify-center py-12 text-muted-foreground">Loading...</div>;

  return (
    <div className="max-w-3xl mx-auto space-y-6">
      <h2 className="text-2xl font-bold text-foreground">Contacts</h2>

      {pendingRequests.length > 0 && (
        <Card>
          <CardHeader><CardTitle className="text-base">Pending Friend Requests</CardTitle></CardHeader>
          <CardContent className="space-y-2">
            {pendingRequests.map((req) => {
              const p = profiles.find((pr) => pr.user_id === req.requester_id);
              return (
                <div key={req.id} className="flex items-center gap-3 p-2 rounded-lg hover:bg-muted">
                  <Avatar className="h-10 w-10">
                    <AvatarImage src={p?.avatar_url || undefined} />
                    <AvatarFallback>{p?.name?.charAt(0) || "?"}</AvatarFallback>
                  </Avatar>
                  <span className="flex-1 font-medium text-sm">{p?.name || "Unknown"}</span>
                  <Button size="sm" onClick={() => acceptRequest(req.id)}><UserCheck className="h-4 w-4 mr-1" /> Accept</Button>
                  <Button size="sm" variant="ghost" onClick={() => removeFriend(req.id)}><UserX className="h-4 w-4" /></Button>
                </div>
              );
            })}
          </CardContent>
        </Card>
      )}

      <Card>
        <CardHeader><CardTitle className="text-base flex items-center gap-2"><Users className="h-5 w-5" /> My Friends ({friendIds.length})</CardTitle></CardHeader>
        <CardContent>
          {friendIds.length === 0 ? (
            <p className="text-sm text-muted-foreground">No friends yet. Add some below!</p>
          ) : (
            <div className="space-y-2">
              {friendIds.map((fid) => {
                const p = profiles.find((pr) => pr.user_id === fid);
                const friendship = getFriendship(fid);
                return (
                  <div key={fid} className="flex items-center gap-3 p-2 rounded-lg hover:bg-muted cursor-pointer"
                    onClick={() => navigate(`/profile/${fid}`)}>
                    <Avatar className="h-10 w-10">
                      <AvatarImage src={p?.avatar_url || undefined} />
                      <AvatarFallback>{p?.name?.charAt(0) || "?"}</AvatarFallback>
                    </Avatar>
                    <span className="flex-1 font-medium text-sm">{p?.name || "Unknown"}</span>
                    <Badge variant="secondary">Friend</Badge>
                    <Button size="sm" variant="ghost" onClick={(e) => { e.stopPropagation(); removeFriend(friendship!.id); }}>
                      <UserX className="h-4 w-4 text-destructive" />
                    </Button>
                  </div>
                );
              })}
            </div>
          )}
        </CardContent>
      </Card>

      <Card>
        <CardHeader><CardTitle className="text-base">All Members</CardTitle></CardHeader>
        <CardContent>
          <div className="space-y-2">
            {profiles.filter((p) => !friendIds.includes(p.user_id)).map((p) => {
              const friendship = getFriendship(p.user_id);
              const isPending = friendship?.status === "pending";
              return (
                <div key={p.user_id} className="flex items-center gap-3 p-2 rounded-lg hover:bg-muted">
                  <Avatar className="h-10 w-10 cursor-pointer" onClick={() => navigate(`/profile/${p.user_id}`)}>
                    <AvatarImage src={p.avatar_url || undefined} />
                    <AvatarFallback>{p.name.charAt(0)}</AvatarFallback>
                  </Avatar>
                  <span className="flex-1 font-medium text-sm cursor-pointer" onClick={() => navigate(`/profile/${p.user_id}`)}>{p.name}</span>
                  {isPending ? (
                    <Badge variant="outline">Pending</Badge>
                  ) : (
                    <Button size="sm" variant="outline" onClick={() => sendRequest(p.user_id)}>
                      <UserPlus className="h-4 w-4 mr-1" /> Add Friend
                    </Button>
                  )}
                </div>
              );
            })}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
