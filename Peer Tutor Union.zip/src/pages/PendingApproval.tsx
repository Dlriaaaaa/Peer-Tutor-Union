import { useAuth } from "@/contexts/AuthContext";
import { Navigate } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Clock, LogOut } from "lucide-react";
import logo from "@/assets/logo.png";

export default function PendingApproval() {
  const { user, loading, isApproved, isAdmin, signOut } = useAuth();

  if (loading) return <div className="min-h-screen flex items-center justify-center text-muted-foreground">Loading...</div>;
  if (!user) return <Navigate to="/login" replace />;
  if (isApproved || isAdmin) return <Navigate to="/schedule" replace />;

  return (
    <div className="min-h-screen flex items-center justify-center bg-background p-4">
      <div className="w-full max-w-md text-center space-y-6">
        <img src={logo} alt="PTC Logo" className="h-20 w-20 mx-auto object-contain" />
        <div className="glass-card p-8 rounded-2xl space-y-4">
          <div className="mx-auto w-16 h-16 rounded-full bg-amber-500/10 flex items-center justify-center">
            <Clock className="h-8 w-8 text-amber-500" />
          </div>
          <h1 className="text-xl font-bold text-foreground">Pending Admin Approval</h1>
          <p className="text-muted-foreground text-sm">
            Your registration has been submitted. Please wait for an administrator to approve your account.
          </p>
          <p className="text-muted-foreground text-xs">
            You will be able to access the platform once your request is reviewed.
          </p>
          <Button variant="outline" onClick={signOut} className="mt-4">
            <LogOut className="h-4 w-4 mr-2" /> Sign Out
          </Button>
        </div>
      </div>
    </div>
  );
}
