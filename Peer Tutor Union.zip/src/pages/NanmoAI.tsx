import { useState, useRef, useEffect, useCallback, DragEvent } from "react";
import { Send, Loader2, Sparkles, Bot, ChevronDown, DollarSign, Paperclip, X, FileText, Image as ImageIcon, PanelLeft } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu";
import { useAuth } from "@/contexts/AuthContext";
import { useSignedUrl } from "@/hooks/useSignedUrl";
import { supabase } from "@/integrations/supabase/client";
import nanmoLogo from "@/assets/nanmo-logo.png";
import { toast } from "sonner";
import { ChatMessage } from "@/components/nanmo-ai/ChatMessage";
import { ChatHistorySidebar } from "@/components/nanmo-ai/ChatHistorySidebar";
import RestrictedAccess from "@/components/RestrictedAccess";
import { canUseAI, canUseAIUnlimited } from "@/lib/roleUtils";
import RechargeDialog from "@/components/team/RechargeDialog";
import { extractTutorRequest, submitTutorRequest } from "@/lib/aiTutorRequest";

type Msg = { role: "user" | "assistant"; content: string };
type ChatRecord = { id: string; title: string; messages: Msg[]; updated_at: string; persona_id?: string | null };
type BotPersona = { id: string; name: string; avatar_url: string | null; system_prompt: string };

type Attachment = {
  id: string;
  name: string;
  kind: "image" | "text";
  // image: data URL (base64). text: full extracted text content.
  data: string;
  size: number;
};

const CHAT_URL = `${import.meta.env.VITE_SUPABASE_URL}/functions/v1/nanmo-ai`;
const MAX_CHATS = 30;
const MAX_FILE_SIZE = 10 * 1024 * 1024; // 10MB
const MAX_TEXT_CHARS = 50000; // truncate large text files

const upsertAssistantMessage = (msgs: Msg[], content: string): Msg[] => {
  const assistantMsg: Msg = { role: "assistant", content };
  return msgs[msgs.length - 1]?.role === "assistant"
    ? [...msgs.slice(0, -1), assistantMsg]
    : [...msgs, assistantMsg];
};

const fileToDataUrl = (file: File): Promise<string> =>
  new Promise((resolve, reject) => {
    const r = new FileReader();
    r.onload = () => resolve(r.result as string);
    r.onerror = reject;
    r.readAsDataURL(file);
  });

const fileToText = (file: File): Promise<string> =>
  new Promise((resolve, reject) => {
    const r = new FileReader();
    r.onload = () => resolve(r.result as string);
    r.onerror = reject;
    r.readAsText(file);
  });

export default function NanmoAI() {
  const { profile, user, displayRole } = useAuth();
  const avatarUrl = useSignedUrl(profile?.avatar_url);
  const [messages, setMessages] = useState<Msg[]>([]);
  const [input, setInput] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const [chats, setChats] = useState<ChatRecord[]>([]);
  const [activeChatId, setActiveChatId] = useState<string | null>(null);
  const [attachments, setAttachments] = useState<Attachment[]>([]);
  const [isDragging, setIsDragging] = useState(false);
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const scrollRef = useRef<HTMLDivElement>(null);
  const textareaRef = useRef<HTMLTextAreaElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  // Persona selection
  const [personas, setPersonas] = useState<BotPersona[]>([]);
  const [selectedPersona, setSelectedPersona] = useState<BotPersona | null>(null);

  // AI credit balance (only relevant for non-unlimited users)
  const unlimited = canUseAIUnlimited(displayRole);
  const [balance, setBalance] = useState<number | null>(null);
  const [pricePerKInput, setPricePerKInput] = useState<number>(1);
  const [pricePerKOutput, setPricePerKOutput] = useState<number>(3);
  const [rechargeOpen, setRechargeOpen] = useState(false);

  const loadBalance = useCallback(async () => {
    if (!user || unlimited) return;
    const { data } = await supabase
      .from("ai_credits")
      .select("balance, price_per_1k_input, price_per_1k_output")
      .eq("user_id", user.id)
      .maybeSingle();
    setBalance(data?.balance ?? 0);
    setPricePerKInput(Number(data?.price_per_1k_input ?? 1));
    setPricePerKOutput(Number(data?.price_per_1k_output ?? 3));
  }, [user, unlimited]);

  useEffect(() => {
    loadBalance();
  }, [loadBalance]);

  const scrollToBottom = useCallback(() => {
    setTimeout(() => {
      scrollRef.current?.scrollTo({ top: scrollRef.current.scrollHeight, behavior: "smooth" });
    }, 50);
  }, []);

  useEffect(scrollToBottom, [messages, scrollToBottom]);

  // Load personas
  useEffect(() => {
    supabase.from("bot_personas").select("id, name, avatar_url, system_prompt").order("created_at").then(({ data }) => {
      setPersonas((data as BotPersona[]) || []);
    });
  }, []);

  useEffect(() => {
    if (!user) return;
    const load = async () => {
      const { data } = await supabase
        .from("nanmo_ai_chats")
        .select("id, title, messages, updated_at, persona_id")
        .eq("user_id", user.id)
        .order("updated_at", { ascending: false })
        .limit(MAX_CHATS);
      if (data) setChats(data as unknown as ChatRecord[]);
    };
    load();
  }, [user]);

  const saveChat = useCallback(async (msgs: Msg[], chatId: string | null) => {
    if (!user || msgs.length === 0) return null;
    const title = msgs[0]?.content?.slice(0, 30) || "新对话";
    const updatedAt = new Date().toISOString();
    const personaId = selectedPersona?.id || null;

    if (chatId) {
      await supabase
        .from("nanmo_ai_chats")
        .update({ messages: msgs as unknown as any, title, updated_at: updatedAt, persona_id: personaId } as any)
        .eq("id", chatId);
      const record: ChatRecord = { id: chatId, title, messages: msgs, updated_at: updatedAt, persona_id: personaId };
      setChats((prev) => [record, ...prev.filter((c) => c.id !== chatId)].slice(0, MAX_CHATS));
      return record;
    }

    const { data } = await supabase
      .from("nanmo_ai_chats")
      .insert({ user_id: user.id, messages: msgs as unknown as any, title, persona_id: personaId } as any)
      .select("id, title, messages, updated_at, persona_id")
      .single();
    if (!data) return null;
    const record = data as unknown as ChatRecord;
    setActiveChatId(record.id);
    setChats((prev) => [record, ...prev.filter((c) => c.id !== record.id)].slice(0, MAX_CHATS));
    return record;
  }, [user, selectedPersona]);

  const addFiles = useCallback(async (files: FileList | File[]) => {
    const arr = Array.from(files);
    for (const file of arr) {
      if (file.size > MAX_FILE_SIZE) {
        toast.error(`${file.name} 超过 10MB 上限`);
        continue;
      }
      try {
        const isImage = file.type.startsWith("image/");
        if (isImage) {
          const dataUrl = await fileToDataUrl(file);
          setAttachments((prev) => [...prev, {
            id: crypto.randomUUID(), name: file.name, kind: "image", data: dataUrl, size: file.size,
          }]);
        } else {
          // Treat as text file (txt, md, csv, json, code, etc.)
          const text = await fileToText(file);
          const truncated = text.length > MAX_TEXT_CHARS
            ? text.slice(0, MAX_TEXT_CHARS) + "\n\n[文件被截断，仅显示前 50000 字符]"
            : text;
          setAttachments((prev) => [...prev, {
            id: crypto.randomUUID(), name: file.name, kind: "text", data: truncated, size: file.size,
          }]);
        }
      } catch (e) {
        console.error(e);
        toast.error(`读取 ${file.name} 失败`);
      }
    }
  }, []);

  const handleDrop = useCallback((e: DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setIsDragging(false);
    if (e.dataTransfer.files?.length) addFiles(e.dataTransfer.files);
  }, [addFiles]);

  const handleDragOver = useCallback((e: DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setIsDragging(true);
  }, []);

  const handleDragLeave = useCallback((e: DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    if (e.currentTarget === e.target) setIsDragging(false);
  }, []);

  const removeAttachment = (id: string) =>
    setAttachments((prev) => prev.filter((a) => a.id !== id));

  // Build a serialized text blob to display in chat history (since the stored Msg is text-only)
  const buildDisplayContent = (text: string, atts: Attachment[]) => {
    if (atts.length === 0) return text;
    const lines = atts.map(a => `📎 ${a.name}${a.kind === "image" ? " (图片)" : ""}`);
    return [text, "", ...lines].filter(Boolean).join("\n");
  };

  // Build the multimodal user message payload for the API
  const buildApiUserMessage = (text: string, atts: Attachment[]) => {
    if (atts.length === 0) return { role: "user", content: text };
    const parts: any[] = [];
    let textContent = text;
    const textFiles = atts.filter(a => a.kind === "text");
    if (textFiles.length) {
      const fileBlock = textFiles.map(f => `\n\n--- 文件: ${f.name} ---\n${f.data}\n--- 结束 ---`).join("");
      textContent = (text || "请阅读以下文件：") + fileBlock;
    }
    parts.push({ type: "text", text: textContent });
    for (const att of atts) {
      if (att.kind === "image") {
        parts.push({ type: "image_url", image_url: { url: att.data } });
      }
    }
    return { role: "user", content: parts };
  };

  const send = async () => {
    const text = input.trim();
    if ((!text && attachments.length === 0) || isLoading) return;

    // Gate by AI credit balance for non-unlimited users (need at least some balance)
    if (!unlimited) {
      if (balance === null || balance <= 0) {
        setRechargeOpen(true);
        toast.error("AI 余额不足，请充值后再使用");
        return;
      }
    }

    const displayContent = buildDisplayContent(text || "(发送文件)", attachments);
    const userDisplayMsg: Msg = { role: "user", content: displayContent };

    // Real API messages: rebuild from prior text-only history + multimodal current
    const apiMessagesForCall = [
      ...messages.map(m => ({ role: m.role, content: m.content })),
      buildApiUserMessage(text, attachments),
    ];

    let responseMessages = [...messages, userDisplayMsg];
    setMessages(responseMessages);
    setInput("");
    const sentAttachments = attachments;
    setAttachments([]);
    setIsLoading(true);

    let assistantSoFar = "";
    let usage: { prompt_tokens?: number; completion_tokens?: number } | null = null;
    const currentChatId = activeChatId;

    try {
      const chatHistory = chats.slice(0, 5).map((c) => ({
        title: c.title,
        messages: (c.messages || []).slice(0, 6),
      }));

      const body: any = { messages: apiMessagesForCall, chatHistory };
      if (selectedPersona) body.persona_id = selectedPersona.id;

      const resp = await fetch(CHAT_URL, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${import.meta.env.VITE_SUPABASE_PUBLISHABLE_KEY}`,
        },
        body: JSON.stringify(body),
      });

      if (!resp.ok) {
        const errData = await resp.json().catch(() => ({}));
        throw new Error(errData.error || `Error ${resp.status}`);
      }
      if (!resp.body) throw new Error("No response body");

      const reader = resp.body.getReader();
      const decoder = new TextDecoder();
      let buffer = "";

      while (true) {
        const { done, value } = await reader.read();
        if (done) break;
        buffer += decoder.decode(value, { stream: true });

        let newlineIndex: number;
        while ((newlineIndex = buffer.indexOf("\n")) !== -1) {
          let line = buffer.slice(0, newlineIndex);
          buffer = buffer.slice(newlineIndex + 1);
          if (line.endsWith("\r")) line = line.slice(0, -1);
          if (line.startsWith(":") || line.trim() === "") continue;
          if (!line.startsWith("data: ")) continue;

          const jsonStr = line.slice(6).trim();
          if (jsonStr === "[DONE]") break;

          try {
            const parsed = JSON.parse(jsonStr);
            const content = parsed.choices?.[0]?.delta?.content;
            if (parsed.usage) usage = parsed.usage;
            if (!content) continue;
            assistantSoFar += content;
            responseMessages = upsertAssistantMessage(responseMessages, assistantSoFar);
            setMessages(responseMessages);
          } catch {
            buffer = line + "\n" + buffer;
            break;
          }
        }
      }

      // AI 代办：如果回复里包含 tutor-request 指令块，直接替用户提交申请
      const { request: tutorReq, cleaned } = extractTutorRequest(assistantSoFar);
      if (tutorReq && user) {
        let resultLine: string;
        try {
          await submitTutorRequest(user.id, tutorReq);
          resultLine = `✅ 已帮你提交${tutorReq.session_type === "tutorial" ? "辅导" : "学习小组"}申请：${tutorReq.subject} · ${tutorReq.requested_date} ${tutorReq.start_time}–${tutorReq.end_time}${tutorReq.tutor_name ? ` · 导师 ${tutorReq.tutor_name}` : ""}${tutorReq.location ? ` · ${tutorReq.location}` : ""}。等待管理员审批，可在 Tutoring 页面查看进度。`;
          toast.success("申请已提交，等待审批");
        } catch (err: any) {
          resultLine = `❌ 申请提交失败：${err.message || "未知错误"}，你可以到 Tutoring 页面手动提交。`;
          toast.error(err.message || "申请提交失败");
        }
        assistantSoFar = `${cleaned}\n\n${resultLine}`;
        responseMessages = upsertAssistantMessage(responseMessages, assistantSoFar);
        setMessages(responseMessages);
      }

      await saveChat(responseMessages, currentChatId);

      // Deduct AI tokens for non-unlimited users (atomic RPC)
      if (!unlimited && usage) {
        const inTok = usage.prompt_tokens ?? 0;
        const outTok = usage.completion_tokens ?? 0;
        if (inTok > 0 || outTok > 0) {
          const { data: deductData, error: deductErr } = await supabase.rpc("deduct_ai_tokens", {
            _input_tokens: inTok,
            _output_tokens: outTok,
          });
          if (deductErr) {
            toast.error(deductErr.message);
          } else if (deductData && typeof deductData === "object" && "balance" in deductData) {
            setBalance(Number((deductData as any).balance));
          }

        }
      }
    } catch (e: any) {
      // Restore attachments so user can retry
      setAttachments(sentAttachments);
      toast.error(e.message || "Failed to get response");
    } finally {
      setIsLoading(false);
    }
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      send();
    }
  };

  const handleNewChat = () => {
    setActiveChatId(null);
    setMessages([]);
    setAttachments([]);
  };

  const handleSelectChat = async (id: string) => {
    const { data } = await supabase
      .from("nanmo_ai_chats")
      .select("id, title, messages, updated_at, persona_id")
      .eq("id", id)
      .single();
    if (data) {
      const record = data as unknown as ChatRecord;
      setActiveChatId(id);
      setMessages(record.messages || []);
      setAttachments([]);
      if (record.persona_id) {
        const p = personas.find(pp => pp.id === record.persona_id);
        if (p) setSelectedPersona(p);
      } else {
        setSelectedPersona(null);
      }
      setChats((prev) => prev.map((c) => (c.id === id ? record : c)));
    }
  };

  const handleDeleteChat = async (id: string) => {
    await supabase.from("nanmo_ai_chats").delete().eq("id", id);
    setChats((prev) => prev.filter((c) => c.id !== id));
    if (activeChatId === id) {
      setActiveChatId(null);
      setMessages([]);
    }
  };

  useEffect(() => {
    if (!user || chats.length <= MAX_CHATS) return;
    const toDelete = chats.slice(MAX_CHATS);
    toDelete.forEach((c) => supabase.from("nanmo_ai_chats").delete().eq("id", c.id));
    setChats((prev) => prev.slice(0, MAX_CHATS));
  }, [chats.length, user]);

  // Filter chats by selected persona
  const filteredChats = chats.filter(c => {
    if (!selectedPersona) return !c.persona_id;
    return c.persona_id === selectedPersona.id;
  });

  const activeName = selectedPersona?.name || "NanmoAI";
  const activeAvatar = selectedPersona?.avatar_url || nanmoLogo;

  if (!canUseAI(displayRole)) {
    return <RestrictedAccess message="AI tools are only available to VIP students and staff. Please contact an administrator to upgrade your access." />;
  }

  return (
    <div
      className="max-w-5xl mx-auto flex h-[calc(100vh-8rem)] rounded-xl border border-border/40 overflow-hidden bg-card/10 relative"
      onDragOver={handleDragOver}
      onDragLeave={handleDragLeave}
      onDrop={handleDrop}
    >
      {sidebarOpen && (
        <div
          className="md:hidden absolute inset-0 z-20 bg-background/60 backdrop-blur-sm"
          onClick={() => setSidebarOpen(false)}
        />
      )}
      <div
        className={`${sidebarOpen ? "absolute inset-y-0 left-0 z-30 flex" : "hidden"} md:relative md:z-auto md:flex bg-background md:bg-transparent`}
      >
        <ChatHistorySidebar
          chats={filteredChats}
          activeChatId={activeChatId}
          onSelect={(id) => { handleSelectChat(id); setSidebarOpen(false); }}
          onNew={() => { handleNewChat(); setSidebarOpen(false); }}
          onDelete={handleDeleteChat}
        />
      </div>

      <div className="flex-1 flex flex-col min-w-0">
        <div className="flex items-center gap-3 px-4 py-3 border-b border-border/40">
          <Button
            variant="ghost"
            size="icon"
            className="h-8 w-8 shrink-0"
            onClick={() => setSidebarOpen((v) => !v)}
            aria-label="切换对话列表"
          >
            {sidebarOpen ? <X className="h-4 w-4" /> : <PanelLeft className="h-4 w-4" />}
          </Button>
          <Avatar className="h-8 w-8">
            <AvatarImage src={activeAvatar} alt={activeName} className="object-contain bg-white p-0.5" />
            <AvatarFallback className="bg-primary/10 text-primary text-xs">
              {selectedPersona ? <Bot className="h-4 w-4" /> : <Sparkles className="h-4 w-4" />}
            </AvatarFallback>
          </Avatar>
          <div className="flex-1">
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <button className="flex items-center gap-1 hover:text-primary transition-colors">
                  <h2 className="text-base font-bold text-foreground">{activeName}</h2>
                  <ChevronDown className="h-3.5 w-3.5 text-muted-foreground" />
                </button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="start">
                <DropdownMenuItem onClick={() => setSelectedPersona(null)}>
                  <div className="h-5 w-5 rounded-full bg-gradient-to-br from-primary to-primary/60 flex items-center justify-center mr-2">
                    <Sparkles className="h-3 w-3 text-primary-foreground" />
                  </div>
                  PTC AI（默认）
                </DropdownMenuItem>
                {personas.map(p => (
                  <DropdownMenuItem key={p.id} onClick={() => setSelectedPersona(p)}>
                    <Avatar className="h-5 w-5 mr-2">
                      <AvatarImage src={p.avatar_url || undefined} />
                      <AvatarFallback className="text-[8px]"><Bot className="h-3 w-3" /></AvatarFallback>
                    </Avatar>
                    {p.name}
                  </DropdownMenuItem>
                ))}
              </DropdownMenuContent>
            </DropdownMenu>
            <p className="text-[10px] text-muted-foreground">
              {selectedPersona ? "自定义智能体" : "PTC 智能助手 · 了解互助学习一切"}
            </p>
          </div>
          {!unlimited && (
            <button
              onClick={() => setRechargeOpen(true)}
              className="flex items-center gap-1 px-2.5 py-1 rounded-full text-xs font-semibold bg-yellow-500/10 text-yellow-500 border border-yellow-500/30 hover:bg-yellow-500/20 transition-colors shrink-0"
              title={`输入 $${pricePerKInput}/1K tokens · 输出 $${pricePerKOutput}/1K tokens`}
            >
              <DollarSign className="h-3 w-3" />
              <span className="tabular-nums">{(balance ?? 0).toFixed(2)}</span>
            </button>
          )}
        </div>

        <div ref={scrollRef} className="flex-1 overflow-auto p-4 space-y-4">
          {messages.length === 0 && (
            <div className="flex flex-col items-center justify-center h-full text-center space-y-4 py-12">
              <Avatar className="h-16 w-16">
                <AvatarImage src={activeAvatar} alt={activeName} className="object-contain bg-white p-1" />
                <AvatarFallback className="bg-primary/10 text-primary">
                  {selectedPersona ? <Bot className="h-8 w-8" /> : <Sparkles className="h-8 w-8" />}
                </AvatarFallback>
              </Avatar>
              <div>
                <p className="text-lg font-semibold text-foreground/80">Hi {profile?.name || ""}! 👋</p>
                <p className="text-sm text-muted-foreground mt-1 max-w-sm">
                  我是 {activeName}，{selectedPersona ? "随时为你服务！" : "Peer Tutor Club 的智能助手。问我任何问题吧！"}
                </p>
                <p className="text-xs text-muted-foreground mt-2">💡 可以直接拖拽图片或文件到对话框</p>
              </div>
              {!selectedPersona && (
                <div className="flex flex-wrap gap-2 justify-center mt-4">
                  {["有哪些辅导科目？", "最近有什么活动？", "解方程 x²+3x-4=0", "介绍一下社团"].map((q) => (
                    <button
                      key={q}
                      onClick={() => {
                        setInput(q);
                        setTimeout(() => textareaRef.current?.focus(), 50);
                      }}
                      className="text-xs px-3 py-1.5 rounded-full border border-border/60 bg-card/50 text-foreground/70 hover:bg-card hover:text-foreground transition-colors"
                    >
                      {q}
                    </button>
                  ))}
                </div>
              )}
            </div>
          )}

          {messages.map((msg, i) => (
            <ChatMessage key={i} msg={msg} avatarUrl={avatarUrl} userName={profile?.name}
              botAvatar={activeAvatar} botName={activeName}
              onDelete={() => {
                const next = messages.filter((_, idx) => idx !== i);
                setMessages(next);
                if (activeChatId) {
                  if (next.length === 0) {
                    handleDeleteChat(activeChatId);
                  } else {
                    saveChat(next, activeChatId);
                  }
                }
              }} />
          ))}

          {isLoading && messages[messages.length - 1]?.role !== "assistant" && (
            <div className="flex gap-3">
              <Avatar className="h-7 w-7 shrink-0">
                <AvatarImage src={activeAvatar} alt={activeName} className="object-contain bg-white p-0.5" />
                <AvatarFallback className="bg-primary/10 text-primary text-xs">AI</AvatarFallback>
              </Avatar>
              <div className="bg-muted/50 rounded-2xl rounded-bl-md px-4 py-2.5">
                <Loader2 className="h-4 w-4 animate-spin text-muted-foreground" />
              </div>
            </div>
          )}
        </div>

        {/* Attachment chips */}
        {attachments.length > 0 && (
          <div className="flex flex-wrap gap-2 px-4 pt-3 border-t border-border/40">
            {attachments.map(a => (
              <div key={a.id} className="flex items-center gap-2 px-2 py-1 rounded-md bg-muted/60 border border-border/40 text-xs max-w-[200px]">
                {a.kind === "image" ? (
                  <img src={a.data} alt={a.name} className="h-8 w-8 rounded object-cover shrink-0" />
                ) : (
                  <FileText className="h-4 w-4 shrink-0 text-muted-foreground" />
                )}
                <span className="truncate flex-1" title={a.name}>{a.name}</span>
                <button onClick={() => removeAttachment(a.id)} className="text-muted-foreground hover:text-destructive shrink-0">
                  <X className="h-3.5 w-3.5" />
                </button>
              </div>
            ))}
          </div>
        )}

        <div className={`flex gap-2 p-4 ${attachments.length === 0 ? "border-t border-border/40" : ""}`}>
          <input
            ref={fileInputRef}
            type="file"
            multiple
            className="hidden"
            accept="image/*,.txt,.md,.csv,.json,.html,.css,.js,.ts,.jsx,.tsx,.py,.java,.cpp,.c,.go,.rb,.php,.xml,.yaml,.yml,.log"
            onChange={(e) => {
              if (e.target.files) addFiles(e.target.files);
              e.target.value = "";
            }}
          />
          <Button
            type="button"
            variant="outline"
            size="icon"
            className="h-[44px] w-[44px] shrink-0"
            onClick={() => fileInputRef.current?.click()}
            disabled={isLoading}
            title="上传图片或文件"
          >
            <Paperclip className="h-4 w-4" />
          </Button>
          <Textarea
            ref={textareaRef}
            value={input}
            onChange={(e) => setInput(e.target.value)}
            onKeyDown={handleKeyDown}
            placeholder="输入消息… (Enter 发送, Shift+Enter 换行, 拖入图片/文件)"
            className="min-h-[44px] max-h-[120px] resize-none"
            rows={1}
          />
          <Button onClick={send} disabled={isLoading || (!input.trim() && attachments.length === 0)} size="icon" className="h-[44px] w-[44px] shrink-0">
            {isLoading ? <Loader2 className="h-4 w-4 animate-spin" /> : <Send className="h-4 w-4" />}
          </Button>
        </div>
      </div>

      {/* Drag overlay */}
      {isDragging && (
        <div className="absolute inset-0 z-50 flex items-center justify-center bg-primary/20 backdrop-blur-sm border-2 border-dashed border-primary rounded-xl pointer-events-none">
          <div className="flex flex-col items-center gap-2 text-primary font-semibold">
            <ImageIcon className="h-12 w-12" />
            <span>松开以上传图片或文件</span>
          </div>
        </div>
      )}

      <RechargeDialog open={rechargeOpen} onOpenChange={setRechargeOpen} />
    </div>
  );
}
