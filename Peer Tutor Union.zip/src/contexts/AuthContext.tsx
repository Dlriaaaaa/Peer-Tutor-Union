import React, { createContext, useContext, useEffect, useState } from "react";
import { User, Session } from "@supabase/supabase-js";
import { supabase } from "@/integrations/supabase/client";

import type { DisplayRole } from "@/lib/roleUtils";
import { SUPER_ADMIN_EMAIL, type ClubMembership, type ClubRole } from "@/lib/schools";

type ProfileShape = {
  name: string;
  avatar_url: string | null;
  bio: string;
  display_role?: string;
  school_id?: string | null;
};

type AuthContextType = {
  user: User | null;
  session: Session | null;
  loading: boolean;
  isAdmin: boolean;
  isSuperAdmin: boolean;
  isApproved: boolean;
  displayRole: DisplayRole;
  profile: ProfileShape | null;
  schoolId: string | null;
  memberships: ClubMembership[];
  activeClubId: string | null;
  clubRole: ClubRole | null;
  hasUploadGrant: boolean;
  setActiveClubId: (id: string | null) => void;
  signOut: () => Promise<void>;
  refreshProfile: () => Promise<void>;
};

const AuthContext = createContext<AuthContextType>({
  user: null,
  session: null,
  loading: true,
  isAdmin: false,
  isSuperAdmin: false,
  isApproved: false,
  displayRole: "Student",
  profile: null,
  schoolId: null,
  memberships: [],
  activeClubId: null,
  clubRole: null,
  hasUploadGrant: false,
  setActiveClubId: () => {},
  signOut: async () => {},
  refreshProfile: async () => {},
});

export const useAuth = () => useContext(AuthContext);

const PROFILE_COLUMNS = "name, avatar_url, bio, is_approved, display_role, school_id";

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [user, setUser] = useState<User | null>(null);
  const [session, setSession] = useState<Session | null>(null);
  const [loading, setLoading] = useState(true);
  const [isAdmin, setIsAdmin] = useState(false);
  const [isApproved, setIsApproved] = useState(false);
  const [displayRole, setDisplayRole] = useState<DisplayRole>("Student");
  const [profile, setProfile] = useState<ProfileShape | null>(null);
  const [memberships, setMemberships] = useState<ClubMembership[]>([]);
  const [activeClubId, setActiveClubId] = useState<string | null>(null);
  const [hasUploadGrant, setHasUploadGrant] = useState(false);

  const fetchUploadGrant = async (userId: string) => {
    const { data } = await supabase
      .from("question_upload_grants")
      .select("is_active")
      .eq("user_id", userId)
      .maybeSingle();
    setHasUploadGrant(!!data?.is_active);
  };

  const isSuperAdmin = (user?.email || "").toLowerCase() === SUPER_ADMIN_EMAIL;

  const applyProfile = (data: any) => {
    setProfile(data);
    setIsApproved(data.is_approved ?? false);
    setDisplayRole((data.display_role as DisplayRole) || "Student");
  };

  const fetchProfile = async (userId: string) => {
    const { data } = await supabase.from("profiles").select(PROFILE_COLUMNS).eq("user_id", userId).maybeSingle();

    if (!data) {
      // Self-heal: ensure every signed-in user has a profile so admins can see them
      const { data: userRes } = await supabase.auth.getUser();
      const meta = userRes?.user?.user_metadata as { name?: string; school_id?: string } | undefined;
      const fallbackName = meta?.name || userRes?.user?.email?.split("@")[0] || "New Member";
      await supabase
        .from("profiles")
        .insert({ user_id: userId, name: fallbackName, is_approved: false, school_id: meta?.school_id ?? null });
      const { data: created } = await supabase.from("profiles").select(PROFILE_COLUMNS).eq("user_id", userId).maybeSingle();
      if (created) applyProfile(created);
      return;
    }

    applyProfile(data);
  };

  const fetchMemberships = async (userId: string) => {
    const { data } = await supabase.from("club_members").select("*").eq("user_id", userId);
    const rows = (data as ClubMembership[]) || [];
    setMemberships(rows);
    setActiveClubId((prev) => {
      if (prev && rows.some((r) => r.club_id === prev)) return prev;
      return rows.find((r) => r.status === "approved")?.club_id ?? rows[0]?.club_id ?? null;
    });
  };

  const fetchRole = async (userId: string) => {
    const { data } = await supabase
      .from("user_roles")
      .select("role")
      .eq("user_id", userId)
      .eq("role", "admin")
      .maybeSingle();
    setIsAdmin(!!data);
  };

  const refreshProfile = async () => {
    if (user) {
      await fetchProfile(user.id);
      await fetchMemberships(user.id);
      await fetchUploadGrant(user.id);
    }
  };

  useEffect(() => {
    const { data: { subscription } } = supabase.auth.onAuthStateChange((_event, session) => {
      setSession(session);
      setUser(session?.user ?? null);
      if (session?.user) {
        setTimeout(() => {
          fetchProfile(session.user.id);
          fetchRole(session.user.id);
          fetchMemberships(session.user.id);
          fetchUploadGrant(session.user.id);
        }, 0);
      } else {
        setProfile(null);
        setIsAdmin(false);
        setIsApproved(false);
        setDisplayRole("Student");
        setMemberships([]);
        setActiveClubId(null);
        setHasUploadGrant(false);
      }
      setLoading(false);
    });

    supabase.auth.getSession().then(({ data: { session } }) => {
      setSession(session);
      setUser(session?.user ?? null);
      if (session?.user) {
        fetchProfile(session.user.id);
        fetchRole(session.user.id);
        fetchMemberships(session.user.id);
        fetchUploadGrant(session.user.id);
      }
      setLoading(false);
    });

    return () => subscription.unsubscribe();
  }, []);

  const signOut = async () => {
    await supabase.auth.signOut();
  };

  const clubRole =
    (memberships.find((m) => m.club_id === activeClubId && m.status === "approved")?.club_role as ClubRole) || null;

  return (
    <AuthContext.Provider
      value={{
        user,
        session,
        loading,
        isAdmin,
        isSuperAdmin,
        isApproved,
        displayRole,
        profile,
        schoolId: profile?.school_id ?? null,
        memberships,
        activeClubId,
        clubRole,
        hasUploadGrant,
        setActiveClubId,
        signOut,
        refreshProfile,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
};
