import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter, Route, Routes, Navigate } from "react-router-dom";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { AuthProvider, useAuth } from "@/contexts/AuthContext";
import AppLayout from "@/components/AppLayout";
import Index from "./pages/Index";
import LoginPage from "./pages/Login";
import PendingApproval from "./pages/PendingApproval";
import Dashboard from "./pages/Dashboard";
import Schedule from "./pages/Schedule";
import Resources from "./pages/Resources";
import Quizzes from "./pages/Quizzes";
import Practice from "./pages/Practice";
import PracticeRun from "./pages/PracticeRun";
import QuizTake from "./pages/QuizTake";
import Grades from "./pages/Grades";
import Members from "./pages/Members";
import ProfilePage from "./pages/Profile";
import AdminLayout from "./pages/Admin";
import AdminApprovals from "./pages/admin/AdminApprovals";
import AdminMembers from "./pages/admin/AdminMembers";
import AdminResources from "./pages/admin/AdminResources";
import AdminQuizzes from "./pages/admin/AdminQuizzes";
import AdminQuestionBank from "./pages/admin/AdminQuestionBank";
import AdminGrades from "./pages/admin/AdminGrades";
import AdminEvents from "./pages/admin/AdminEvents";
import AdminAwards from "./pages/admin/AdminAwards";
import AdminAITraining from "./pages/admin/AdminAITraining";
import AdminAI from "./pages/admin/AdminAI";
import Events from "./pages/Events";
import Chat from "./pages/Chat";
import Tutoring from "./pages/Tutoring";
import StudyGroupsPage from "./pages/StudyGroupsPage";
import AdminTutoring from "./pages/admin/AdminTutoring";
import AdminSchools from "./pages/admin/AdminSchools";

import CalculatorPage from "./pages/Calculator";
import TagPosts from "./pages/TagPosts";
import Translate from "./pages/Translate";
import NanmoAI from "./pages/NanmoAI";
import Subway from "./pages/Subway";
import NotFound from "./pages/NotFound";

const queryClient = new QueryClient();

function ProtectedRoute({ children }: { children: React.ReactNode }) {
  const { user, loading, isApproved, isAdmin } = useAuth();
  if (loading) return <div className="min-h-screen flex items-center justify-center text-muted-foreground">Loading...</div>;
  if (!user) return <Navigate to="/login" replace />;
  if (!isApproved && !isAdmin) return <Navigate to="/pending" replace />;
  return <>{children}</>;
}

function GuestRoute({ children }: { children: React.ReactNode }) {
  const { user, loading } = useAuth();
  if (loading) return <div className="min-h-screen flex items-center justify-center text-muted-foreground">Loading...</div>;
  if (user) return <Navigate to="/schedule" replace />;
  return <>{children}</>;
}

const App = () => (
  <QueryClientProvider client={queryClient}>
    <TooltipProvider>
      <Toaster />
      <Sonner />
      <BrowserRouter>
        <AuthProvider>
          <Routes>
            <Route path="/" element={<Index />} />
            <Route path="/login" element={<GuestRoute><LoginPage /></GuestRoute>} />
            <Route path="/pending" element={<PendingApproval />} />
            <Route element={<ProtectedRoute><AppLayout /></ProtectedRoute>}>
              <Route path="/schedule" element={<Schedule />} />
              <Route path="/dashboard" element={<Dashboard />} />
              <Route path="/resources" element={<Resources />} />
              <Route path="/quizzes" element={<Quizzes />} />
              <Route path="/practice" element={<Practice />} />
              <Route path="/practice/:sessionId" element={<PracticeRun />} />
              <Route path="/quiz/:quizId" element={<QuizTake />} />
              <Route path="/members" element={<Members />} />
              <Route path="/grades" element={<Grades />} />
              <Route path="/events" element={<Events />} />
              <Route path="/chat" element={<Chat />} />
              <Route path="/tutoring" element={<Tutoring />} />
              <Route path="/study-groups" element={<StudyGroupsPage />} />

              <Route path="/calculator" element={<CalculatorPage />} />
              <Route path="/translate" element={<Translate />} />
              <Route path="/nanmo-ai" element={<NanmoAI />} />
              <Route path="/subway" element={<Subway />} />
              <Route path="/profile" element={<ProfilePage />} />
              <Route path="/profile/:userId" element={<ProfilePage />} />
              <Route path="/tags/:tag" element={<TagPosts />} />
              <Route path="/admin" element={<AdminLayout />}>
                <Route index element={<Navigate to="/admin/approvals" replace />} />
                <Route path="approvals" element={<AdminApprovals />} />
                <Route path="members" element={<AdminMembers />} />
                <Route path="resources" element={<AdminResources />} />
                <Route path="quizzes" element={<AdminQuizzes />} />
                <Route path="question-bank" element={<AdminQuestionBank />} />
                <Route path="grades" element={<AdminGrades />} />
                <Route path="events" element={<AdminEvents />} />
                <Route path="tutoring" element={<AdminTutoring />} />
                <Route path="schools" element={<AdminSchools />} />

                <Route path="awards" element={<AdminAwards />} />
                <Route path="ai-training" element={<AdminAITraining />} />
                <Route path="ai-credits" element={<AdminAI />} />
              </Route>
            </Route>
            <Route path="*" element={<NotFound />} />
          </Routes>
        </AuthProvider>
      </BrowserRouter>
    </TooltipProvider>
  </QueryClientProvider>
);

export default App;
