import { useThree, useFrame } from "@react-three/fiber";
import { useEffect, useRef } from "react";
import * as THREE from "three";
import { CAMERA_PRESETS } from "./sceneTypes";
import type { CameraView } from "./sceneTypes";

interface Props {
  view: CameraView;
}

/**
 * Smooth-lerp camera that transitions between POV presets.
 */
export default function CameraRig({ view }: Props) {
  const { camera } = useThree();
  const targetPos = useRef(new THREE.Vector3());
  const targetLook = useRef(new THREE.Vector3());
  const currentLook = useRef(new THREE.Vector3(0, 0, -8));

  useEffect(() => {
    const preset = CAMERA_PRESETS[view];
    targetPos.current.set(...preset.position);
    targetLook.current.set(...preset.lookAt);
    (camera as any).fov = preset.fov;
    camera.updateProjectionMatrix();
  }, [view, camera]);

  // On first mount, snap immediately
  useEffect(() => {
    const preset = CAMERA_PRESETS[view];
    camera.position.set(...preset.position);
    currentLook.current.set(...preset.lookAt);
    camera.lookAt(...preset.lookAt);
    (camera as any).fov = preset.fov;
    camera.updateProjectionMatrix();
  }, []);

  useFrame(() => {
    // Smooth lerp to target
    camera.position.lerp(targetPos.current, 0.05);
    currentLook.current.lerp(targetLook.current, 0.05);
    camera.lookAt(currentLook.current);
  });

  return null;
}
