import { useLoader } from "@react-three/fiber";
import * as THREE from "three";
import { FIELD } from "./sceneTypes";
import type { BillboardConfig } from "./sceneTypes";

interface Props {
  config: BillboardConfig;
}

export default function Billboard3D({ config }: Props) {
  const { logoUrl, opacity, scale, offsetX, offsetY } = config;

  const wallZ = -(FIELD.WALL_RADIUS - 1);
  const baseY = FIELD.WALL_HEIGHT + 1.0;

  const boardW = 6 * scale;
  const boardH = 2.5 * scale;
  const postHeight = boardH / 2 + 0.8;

  return (
    <group position={[offsetX, 0, wallZ]}>
      {/* Support posts */}
      <mesh position={[-boardW / 2 + 0.15, postHeight / 2, 0]} castShadow>
        <cylinderGeometry args={[0.08, 0.1, postHeight, 8]} />
        <meshStandardMaterial color="#888" metalness={0.5} roughness={0.4} />
      </mesh>
      <mesh position={[boardW / 2 - 0.15, postHeight / 2, 0]} castShadow>
        <cylinderGeometry args={[0.08, 0.1, postHeight, 8]} />
        <meshStandardMaterial color="#888" metalness={0.5} roughness={0.4} />
      </mesh>

      {/* Board frame (border) */}
      <mesh position={[0, baseY + offsetY, 0]} castShadow receiveShadow>
        <boxGeometry args={[boardW + 0.4, boardH + 0.4, 0.12]} />
        <meshStandardMaterial color="#666" metalness={0.4} roughness={0.5} />
      </mesh>

      {/* White background panel */}
      <mesh position={[0, baseY + offsetY, 0.07]}>
        <boxGeometry args={[boardW, boardH, 0.02]} />
        <meshStandardMaterial color="#ffffff" roughness={0.3} />
      </mesh>

      {/* Logo */}
      {logoUrl ? (
        <LogoPlane url={logoUrl} opacity={opacity} boardW={boardW} boardH={boardH} y={baseY + offsetY} />
      ) : (
        <mesh position={[0, baseY + offsetY, 0.1]}>
          <planeGeometry args={[boardW * 0.85, boardH * 0.7]} />
          <meshStandardMaterial color="#f0f0f0" transparent opacity={opacity} />
        </mesh>
      )}

      {/* Top light bar */}
      <mesh position={[0, baseY + offsetY + boardH / 2 + 0.25, 0.1]}>
        <boxGeometry args={[boardW * 0.6, 0.08, 0.08]} />
        <meshStandardMaterial color="#ffdd44" emissive="#ffdd44" emissiveIntensity={0.4} />
      </mesh>
    </group>
  );
}

function LogoPlane({ url, opacity, boardW, boardH, y }: { url: string; opacity: number; boardW: number; boardH: number; y: number }) {
  let texture: THREE.Texture | null = null;
  try {
    // eslint-disable-next-line react-hooks/rules-of-hooks
    texture = useLoader(THREE.TextureLoader, url);
  } catch {
    // loading
  }

  if (!texture) {
    return (
      <mesh position={[0, y, 0.1]}>
        <planeGeometry args={[boardW * 0.85, boardH * 0.7]} />
        <meshStandardMaterial color="#f0f0f0" transparent opacity={opacity} />
      </mesh>
    );
  }

  const img = texture.image as HTMLImageElement | undefined;
  const imgAspect = img && img.width && img.height ? img.width / img.height : 1;
  const maxW = boardW * 0.85;
  const maxH = boardH * 0.7;
  const boardAspect = maxW / maxH;

  let w: number, h: number;
  if (imgAspect > boardAspect) {
    w = maxW;
    h = maxW / imgAspect;
  } else {
    h = maxH;
    w = maxH * imgAspect;
  }

  return (
    <mesh position={[0, y, 0.1]}>
      <planeGeometry args={[w, h]} />
      <meshBasicMaterial map={texture} transparent opacity={opacity} />
    </mesh>
  );
}
