import { useMemo } from "react";
import * as THREE from "three";
import { FIELD } from "./sceneTypes";

function createFanShape(radius: number, segments = 64): THREE.Shape {
  const shape = new THREE.Shape();
  shape.moveTo(0, 0);
  const startAngle = -Math.PI / 4;
  const endAngle = Math.PI / 4;
  for (let i = 0; i <= segments; i++) {
    const a = startAngle + (endAngle - startAngle) * (i / segments);
    shape.lineTo(Math.sin(a) * radius, Math.cos(a) * radius);
  }
  shape.closePath();
  return shape;
}

function createFanRingShape(innerR: number, outerR: number, segments = 64): THREE.Shape {
  const shape = new THREE.Shape();
  const startAngle = -Math.PI / 4;
  const endAngle = Math.PI / 4;
  shape.moveTo(Math.sin(startAngle) * outerR, Math.cos(startAngle) * outerR);
  for (let i = 1; i <= segments; i++) {
    const a = startAngle + (endAngle - startAngle) * (i / segments);
    shape.lineTo(Math.sin(a) * outerR, Math.cos(a) * outerR);
  }
  for (let i = segments; i >= 0; i--) {
    const a = startAngle + (endAngle - startAngle) * (i / segments);
    shape.lineTo(Math.sin(a) * innerR, Math.cos(a) * innerR);
  }
  shape.closePath();
  return shape;
}

export default function Field3D() {
  const groundFanGeo = useMemo(() => new THREE.ShapeGeometry(createFanShape(FIELD.WALL_RADIUS + 8), 64), []);
  const grassFanGeo = useMemo(() => new THREE.ShapeGeometry(createFanShape(FIELD.WALL_RADIUS - FIELD.WARNING_TRACK_WIDTH), 64), []);
  const warningTrackGeo = useMemo(() => new THREE.ShapeGeometry(createFanRingShape(FIELD.WALL_RADIUS - FIELD.WARNING_TRACK_WIDTH, FIELD.WALL_RADIUS), 64), []);
  const wallTopGeo = useMemo(() => new THREE.ShapeGeometry(createFanRingShape(FIELD.WALL_RADIUS - 0.12, FIELD.WALL_RADIUS + 0.12), 64), []);

  const wallGeo = useMemo(() => new THREE.CylinderGeometry(FIELD.WALL_RADIUS, FIELD.WALL_RADIUS, FIELD.WALL_HEIGHT, 64, 1, true, Math.PI * 0.25, Math.PI * 0.5), []);
  const paddingGeo = useMemo(() => new THREE.CylinderGeometry(FIELD.WALL_RADIUS + FIELD.WALL_THICKNESS, FIELD.WALL_RADIUS + FIELD.WALL_THICKNESS, FIELD.WALL_HEIGHT + 0.02, 64, 1, true, Math.PI * 0.25, Math.PI * 0.5), []);

  const stripeMat = useMemo(() => new THREE.ShaderMaterial({
    uniforms: {
      color1: { value: new THREE.Color("#2F8C3B") },
      color2: { value: new THREE.Color("#267A32") },
      stripeWidth: { value: 2.5 },
    },
    vertexShader: `
      varying vec3 vWorldPos;
      void main() {
        vec4 wp = modelMatrix * vec4(position, 1.0);
        vWorldPos = wp.xyz;
        gl_Position = projectionMatrix * viewMatrix * wp;
      }
    `,
    fragmentShader: `
      uniform vec3 color1;
      uniform vec3 color2;
      uniform float stripeWidth;
      varying vec3 vWorldPos;
      void main() {
        float stripe = step(0.5, fract(vWorldPos.z / stripeWidth));
        vec3 col = mix(color1, color2, stripe);
        gl_FragColor = vec4(col, 1.0);
      }
    `,
  }), []);

  return (
    <group>
      {/* Ground */}
      <mesh geometry={groundFanGeo} rotation-x={-Math.PI / 2} position={[0, -0.05, 0]} receiveShadow>
        <meshStandardMaterial color="#1a3320" />
      </mesh>

      {/* Foul territory behind home */}
      <mesh rotation-x={-Math.PI / 2} position={[0, -0.04, 0]} receiveShadow>
        <circleGeometry args={[8, 32, -Math.PI / 4 - Math.PI / 2, Math.PI / 2]} />
        <meshStandardMaterial color="#8B6914" roughness={0.9} />
      </mesh>

      {/* Grass with stripes */}
      <mesh geometry={grassFanGeo} rotation-x={-Math.PI / 2} position={[0, 0.001, 0]} receiveShadow material={stripeMat} />

      {/* Warning track */}
      <mesh geometry={warningTrackGeo} rotation-x={-Math.PI / 2} position={[0, 0.003, 0]}>
        <meshStandardMaterial color="#8B6914" roughness={0.9} />
      </mesh>

      {/* Infield dirt */}
      <InfieldDirt />

      {/* Infield grass cutout */}
      <mesh rotation-x={-Math.PI / 2} position={[0, 0.008, -6.36]}>
        <ringGeometry args={[2.8, 7.5, 64]} />
        <meshStandardMaterial color="#2F8C3B" roughness={0.8} />
      </mesh>

      {/* Base paths (dirt) */}
      <BasePath from={FIELD.HOME} to={FIELD.FIRST} />
      <BasePath from={FIELD.HOME} to={FIELD.THIRD} />
      <BasePath from={FIELD.FIRST} to={FIELD.SECOND} />
      <BasePath from={FIELD.THIRD} to={FIELD.SECOND} />

      {/* ── Diamond baseline markings (white lines) ── */}
      <BaselineMark from={FIELD.HOME} to={FIELD.FIRST} />
      <BaselineMark from={FIELD.FIRST} to={FIELD.SECOND} />
      <BaselineMark from={FIELD.SECOND} to={FIELD.THIRD} />
      <BaselineMark from={FIELD.THIRD} to={FIELD.HOME} />

      {/* Home plate dirt */}
      <mesh rotation-x={-Math.PI / 2} position={[0, 0.004, 0]}>
        <circleGeometry args={[2.5, 32]} />
        <meshStandardMaterial color="#B8763B" roughness={0.85} />
      </mesh>

      {/* Foul lines */}
      <FoulLine angle={Math.PI / 4} />
      <FoulLine angle={-Math.PI / 4} />

      {/* Pitcher's mound */}
      <mesh position={[FIELD.MOUND[0], 0.1, FIELD.MOUND[2]]} castShadow>
        <cylinderGeometry args={[0.8, 1.2, 0.22, 32]} />
        <meshStandardMaterial color="#A0693A" roughness={0.9} />
      </mesh>
      <mesh position={[0, 0.22, -6.05]} rotation-x={-Math.PI / 2}>
        <planeGeometry args={[0.25, 0.06]} />
        <meshStandardMaterial color="#f0f0f0" roughness={0.4} />
      </mesh>

      {/* Home plate */}
      <HomePlate />

      {/* Bases */}
      <BaseMarker position={FIELD.FIRST} />
      <BaseMarker position={FIELD.SECOND} />
      <BaseMarker position={FIELD.THIRD} />

      {/* Batter's boxes */}
      <BatterBox side={1} />
      <BatterBox side={-1} />

      {/* Outfield wall */}
      <mesh geometry={wallGeo} position={[0, FIELD.WALL_HEIGHT / 2, -14]} rotation-y={Math.PI * 0.75} castShadow receiveShadow>
        <meshStandardMaterial color="#1a5c2a" roughness={0.7} metalness={0.1} />
      </mesh>
      <mesh geometry={paddingGeo} position={[0, FIELD.WALL_HEIGHT / 2 - 0.01, -14]} rotation-y={Math.PI * 0.75}>
        <meshStandardMaterial color="#0e3d18" roughness={0.8} side={THREE.BackSide} />
      </mesh>
      <mesh geometry={wallTopGeo} rotation-x={-Math.PI / 2} position={[0, FIELD.WALL_HEIGHT + 0.005, 0]}>
        <meshStandardMaterial color="#e6c619" roughness={0.5} />
      </mesh>
    </group>
  );
}

/** Diamond baselines as white lines */
function BaselineMark({ from, to }: { from: readonly [number, number, number]; to: readonly [number, number, number] }) {
  const midX = (from[0] + to[0]) / 2;
  const midZ = (from[2] + to[2]) / 2;
  const dx = to[0] - from[0];
  const dz = to[2] - from[2];
  const len = Math.sqrt(dx * dx + dz * dz);
  const angle = Math.atan2(dx, dz);

  return (
    <mesh position={[midX, 0.012, midZ]} rotation-y={-angle} rotation-x={-Math.PI / 2}>
      <planeGeometry args={[0.06, len]} />
      <meshStandardMaterial color="white" />
    </mesh>
  );
}

function InfieldDirt() {
  const geo = useMemo(() => {
    const shape = new THREE.Shape();
    shape.moveTo(FIELD.HOME[0], 0);
    shape.lineTo(FIELD.FIRST[0], -FIELD.FIRST[2]);
    shape.lineTo(FIELD.SECOND[0], -FIELD.SECOND[2]);
    shape.lineTo(FIELD.THIRD[0], -FIELD.THIRD[2]);
    shape.closePath();
    return new THREE.ShapeGeometry(shape);
  }, []);

  return (
    <mesh geometry={geo} rotation-x={-Math.PI / 2} position={[0, 0.005, 0]} receiveShadow>
      <meshStandardMaterial color="#B8763B" roughness={0.85} metalness={0.05} />
    </mesh>
  );
}

function HomePlate() {
  const geo = useMemo(() => {
    const shape = new THREE.Shape();
    const s = 0.22;
    shape.moveTo(0, s);
    shape.lineTo(s, s * 0.4);
    shape.lineTo(s, -s * 0.4);
    shape.lineTo(-s, -s * 0.4);
    shape.lineTo(-s, s * 0.4);
    shape.closePath();
    return new THREE.ExtrudeGeometry(shape, { depth: 0.02, bevelEnabled: false });
  }, []);

  return (
    <mesh geometry={geo} position={[0, 0.01, 0]} rotation-x={-Math.PI / 2} receiveShadow>
      <meshStandardMaterial color="white" roughness={0.3} />
    </mesh>
  );
}

function BaseMarker({ position }: { position: readonly [number, number, number] }) {
  return (
    <mesh position={[position[0], 0.06, position[2]]} castShadow>
      <boxGeometry args={[0.38, 0.12, 0.38]} />
      <meshStandardMaterial color="#f5f5f0" roughness={0.3} />
    </mesh>
  );
}

function BasePath({ from, to }: { from: readonly [number, number, number]; to: readonly [number, number, number] }) {
  const midX = (from[0] + to[0]) / 2;
  const midZ = (from[2] + to[2]) / 2;
  const dx = to[0] - from[0];
  const dz = to[2] - from[2];
  const len = Math.sqrt(dx * dx + dz * dz);
  const angle = Math.atan2(dx, dz);

  return (
    <mesh position={[midX, 0.006, midZ]} rotation-y={-angle} rotation-x={-Math.PI / 2}>
      <planeGeometry args={[0.65, len]} />
      <meshStandardMaterial color="#A5683A" roughness={0.85} />
    </mesh>
  );
}

function FoulLine({ angle }: { angle: number }) {
  const len = FIELD.WALL_RADIUS + 2;
  const x = (Math.sin(angle) * len) / 2;
  const z = (-Math.cos(angle) * len) / 2;

  return (
    <mesh position={[x, 0.007, z]} rotation-y={-angle} rotation-x={-Math.PI / 2}>
      <planeGeometry args={[0.07, len]} />
      <meshStandardMaterial color="white" />
    </mesh>
  );
}

function BatterBox({ side }: { side: 1 | -1 }) {
  return (
    <lineSegments position={[side * 0.6, 0.008, 0]}>
      <edgesGeometry args={[new THREE.PlaneGeometry(0.5, 0.85)]} />
      <lineBasicMaterial color="white" />
    </lineSegments>
  );
}
