import { useRef } from "react";
import { useFrame } from "@react-three/fiber";
import * as THREE from "three";
import type { Pitch } from "@/game/types";
import { FIELD } from "./sceneTypes";

interface Props {
  ballProgress: number | null;
  currentPitch: Pitch | null;
  hitBall: { x: number; y: number; visible: boolean } | null;
}

export default function Ball3D({ ballProgress, currentPitch, hitBall }: Props) {
  const ref = useRef<THREE.Mesh>(null);

  useFrame(() => {
    if (!ref.current) return;

    // Hit ball takes priority
    if (hitBall?.visible) {
      const nx = ((hitBall.x - 400) / 400) * 20;
      const nz = ((hitBall.y - 400) / 400) * -30;
      const height = Math.max(0.2, 3 - Math.abs(nz) * 0.08);
      ref.current.position.set(nx, height, nz);
      ref.current.visible = true;
      return;
    }

    // Pitch in flight
    if (ballProgress !== null && currentPitch) {
      const t = ballProgress;
      const startZ = FIELD.MOUND[2];
      const endZ = 0;
      const z = startZ + (endZ - startZ) * t;
      const breakX = (currentPitch.breakH / 12) * t * t;
      const baseY = 0.9;
      const arcY = Math.sin(t * Math.PI) * 0.4;
      const y = baseY + arcY + (currentPitch.breakV / 24) * t;

      ref.current.position.set(breakX, y, z);
      ref.current.visible = true;
      return;
    }

    ref.current.visible = false;
  });

  return (
    <mesh ref={ref} visible={false} castShadow>
      <sphereGeometry args={[0.08, 16, 16]} />
      <meshStandardMaterial color="#f5f5f0" roughness={0.3} metalness={0.05} />
    </mesh>
  );
}
