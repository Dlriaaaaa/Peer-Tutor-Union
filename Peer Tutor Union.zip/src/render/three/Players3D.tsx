import { useRef, useMemo } from "react";
import { useFrame } from "@react-three/fiber";
import * as THREE from "three";
import type { Bases } from "@/game/types";
import { FIELDER_POSITIONS, FIELD } from "./sceneTypes";

interface Props {
  bases: Bases;
  phase: string;
  hitBall: { x: number; y: number; visible: boolean } | null;
}

const SKIN = "#d4a574";
const TEAM_HOME = "#1a3d7a";
const TEAM_AWAY = "#c0392b";
const PANTS_HOME = "#e0e0e0";
const PANTS_AWAY = "#e8e8e8";
const SHOE = "#222";

/** Convert hitBall 2D coords to 3D world XZ */
function hitBallToWorld(hb: { x: number; y: number }): [number, number] {
  const nx = ((hb.x - 400) / 400) * 20;
  const nz = ((hb.y - 400) / 400) * -30;
  return [nx, nz];
}

/** Find nearest fielder key to a world position */
function findNearestFielder(wx: number, wz: number): string {
  let best = "center";
  let bestDist = Infinity;
  for (const [key, pos] of Object.entries(FIELDER_POSITIONS)) {
    if (key === "pitcher" || key === "catcher") continue;
    const d = (pos[0] - wx) ** 2 + (pos[2] - wz) ** 2;
    if (d < bestDist) { bestDist = d; best = key; }
  }
  return best;
}

function PlayerModel({
  position: initPos,
  teamColor,
  pantsColor,
  facingAngle = 0,
  withGlove = false,
  withBat = false,
  role = "fielder",
  phase = "idle",
  chaseTarget,
  runTarget,
}: {
  position: [number, number, number];
  teamColor: string;
  pantsColor: string;
  facingAngle?: number;
  withGlove?: boolean;
  withBat?: boolean;
  role?: "pitcher" | "catcher" | "batter" | "fielder" | "runner";
  phase?: string;
  chaseTarget?: [number, number] | null;
  runTarget?: [number, number, number] | null;
}) {
  const groupRef = useRef<THREE.Group>(null);
  const torsoRef = useRef<THREE.Mesh>(null);
  const leftArmRef = useRef<THREE.Mesh>(null);
  const rightArmRef = useRef<THREE.Mesh>(null);
  const headRef = useRef<THREE.Mesh>(null);
  const leftLegRef = useRef<THREE.Mesh>(null);
  const rightLegRef = useRef<THREE.Mesh>(null);
  const batRef = useRef<THREE.Mesh>(null);
  const offset = useMemo(() => Math.random() * Math.PI * 2, []);
  const swingStartRef = useRef<number | null>(null);
  useFrame(({ clock }) => {
    const t = clock.getElapsedTime() + offset;
    if (!groupRef.current) return;

    const breathe = Math.sin(t * 2) * 0.012;
    if (torsoRef.current) torsoRef.current.position.y = 0.62 + breathe;
    if (headRef.current) headRef.current.position.y = 0.9 + breathe;

    if (role === "pitcher") {
      if (phase === "pitching") {
        if (rightArmRef.current) {
          rightArmRef.current.rotation.z = -0.15 + Math.sin(t * 6) * 0.8;
          rightArmRef.current.rotation.x = Math.sin(t * 8) * 0.5;
        }
        if (leftArmRef.current) leftArmRef.current.rotation.z = 0.3;
        if (leftLegRef.current) leftLegRef.current.rotation.x = Math.sin(t * 6) * 0.3;
      } else {
        if (rightArmRef.current) { rightArmRef.current.rotation.z = -0.15 + Math.sin(t * 1.2) * 0.05; rightArmRef.current.rotation.x = 0; }
        if (leftArmRef.current) leftArmRef.current.rotation.z = 0.15 + Math.sin(t * 1.2 + 1) * 0.05;
        if (leftLegRef.current) leftLegRef.current.rotation.x = 0;
        groupRef.current.position.x = initPos[0] + Math.sin(t * 0.7) * 0.05;
        groupRef.current.position.z = initPos[2] + Math.cos(t * 0.5) * 0.03;
      }
    } else if (role === "batter") {
      if (phase === "deciding") {
        swingStartRef.current = null;
        groupRef.current.position.y = Math.sin(t * 4) * 0.02;
        if (batRef.current) batRef.current.rotation.z = -0.5 + Math.sin(t * 3) * 0.08;
      } else if (phase === "result") {
        // Record swing start time
        if (swingStartRef.current === null) swingStartRef.current = t;
        const elapsed = t - swingStartRef.current;
        const SWING_DURATION = 0.3;
        const RUN_DELAY = 0.35;

        if (elapsed < SWING_DURATION) {
          // Swing the bat
          const swing = elapsed / SWING_DURATION;
          if (batRef.current) batRef.current.rotation.z = -0.5 + swing * 2.5;
          if (torsoRef.current) torsoRef.current.rotation.y = swing * 1.2;
        } else if (runTarget && elapsed >= RUN_DELAY) {
          // Drop bat, run along the baseline (Home → First)
          if (batRef.current) batRef.current.visible = false;
          if (torsoRef.current) torsoRef.current.rotation.y = 0;

          // Baseline path: follow the diamond edge
          // Home(0,0) → First(FIELD.FIRST)
          // Use elapsed time to compute progress along the baseline
          const RUN_SPEED = 0.6; // fraction per second
          const runProgress = Math.min((elapsed - RUN_DELAY) * RUN_SPEED, 1);

          // Interpolate along the baseline from home to first
          const homeX = initPos[0];
          const homeZ = initPos[2];
          const firstX = FIELD.FIRST[0];
          const firstZ = FIELD.FIRST[2];

          const posX = homeX + (firstX - homeX) * runProgress;
          const posZ = homeZ + (firstZ - homeZ) * runProgress;
          groupRef.current.position.x = posX;
          groupRef.current.position.z = posZ;

          // Face direction of the baseline
          groupRef.current.rotation.y = Math.atan2(-(firstX - homeX), -(firstZ - homeZ));

          if (runProgress < 1) {
            // Running limb animation
            if (leftLegRef.current) leftLegRef.current.rotation.x = Math.sin(t * 10) * 0.4;
            if (rightLegRef.current) rightLegRef.current.rotation.x = Math.sin(t * 10 + Math.PI) * 0.4;
            if (leftArmRef.current) leftArmRef.current.rotation.x = Math.sin(t * 10 + Math.PI) * 0.3;
            if (rightArmRef.current) rightArmRef.current.rotation.x = Math.sin(t * 10) * 0.3;
            groupRef.current.position.y = Math.abs(Math.sin(t * 10)) * 0.03;
          }
        }
      } else {
        // idle - reset
        swingStartRef.current = null;
        if (batRef.current) batRef.current.visible = true;
        if (batRef.current) batRef.current.rotation.z = -0.5 + Math.sin(t * 0.8) * 0.1;
        if (torsoRef.current) torsoRef.current.rotation.y = 0;
        groupRef.current.position.set(initPos[0], initPos[1], initPos[2]);
        groupRef.current.rotation.y = facingAngle;
      }
    } else if (role === "catcher") {
      if (leftArmRef.current) {
        leftArmRef.current.rotation.z = 0.6 + Math.sin(t * 1.5) * 0.08;
        leftArmRef.current.rotation.x = -0.3 + Math.sin(t * 2) * 0.05;
      }
      groupRef.current.position.x = initPos[0] + Math.sin(t * 0.6) * 0.04;
    } else if (role === "fielder") {
      // Chase ball if this fielder is the target
      if (chaseTarget) {
        const [tx, tz] = chaseTarget;
        const cx = groupRef.current.position.x;
        const cz = groupRef.current.position.z;
        const dx = tx - cx;
        const dz = tz - cz;
        const dist = Math.sqrt(dx * dx + dz * dz);
        if (dist > 0.3) {
          const speed = 0.15;
          groupRef.current.position.x += (dx / dist) * speed;
          groupRef.current.position.z += (dz / dist) * speed;
          // Face direction of movement
          groupRef.current.rotation.y = Math.atan2(-dx, -dz);
          // Running legs
          if (leftLegRef.current) leftLegRef.current.rotation.x = Math.sin(t * 8) * 0.35;
          if (rightLegRef.current) rightLegRef.current.rotation.x = Math.sin(t * 8 + Math.PI) * 0.35;
          if (leftArmRef.current) leftArmRef.current.rotation.x = Math.sin(t * 8 + Math.PI) * 0.25;
          if (rightArmRef.current) rightArmRef.current.rotation.x = Math.sin(t * 8) * 0.25;
        }
      } else {
        // Return to home position
        const cx = groupRef.current.position.x;
        const cz = groupRef.current.position.z;
        const dx = initPos[0] - cx;
        const dz = initPos[2] - cz;
        const dist = Math.sqrt(dx * dx + dz * dz);
        if (dist > 0.2) {
          groupRef.current.position.x += (dx / dist) * 0.08;
          groupRef.current.position.z += (dz / dist) * 0.08;
          if (leftLegRef.current) leftLegRef.current.rotation.x = Math.sin(t * 5) * 0.2;
          if (rightLegRef.current) rightLegRef.current.rotation.x = Math.sin(t * 5 + Math.PI) * 0.2;
        } else {
          // Idle shuffle
          groupRef.current.position.x = initPos[0] + Math.sin(t * 0.6) * 0.12;
          groupRef.current.position.z = initPos[2] + Math.cos(t * 0.4) * 0.08;
          if (leftLegRef.current) leftLegRef.current.rotation.x = Math.sin(t * 1.5) * 0.06;
          if (rightLegRef.current) rightLegRef.current.rotation.x = Math.sin(t * 1.5 + Math.PI) * 0.06;
        }
        if (leftArmRef.current) leftArmRef.current.rotation.z = 0.15 + Math.sin(t * 1.5) * 0.06;
        if (rightArmRef.current) rightArmRef.current.rotation.z = -0.15 + Math.sin(t * 1.5 + 1) * 0.06;
      }
    } else if (role === "runner") {
      if (leftLegRef.current) leftLegRef.current.rotation.x = Math.sin(t * 5) * 0.25;
      if (rightLegRef.current) rightLegRef.current.rotation.x = Math.sin(t * 5 + Math.PI) * 0.25;
      if (leftArmRef.current) leftArmRef.current.rotation.x = Math.sin(t * 5 + Math.PI) * 0.2;
      if (rightArmRef.current) rightArmRef.current.rotation.x = Math.sin(t * 5) * 0.2;
      groupRef.current.position.y = Math.abs(Math.sin(t * 5)) * 0.03;
      groupRef.current.position.x = initPos[0] + Math.sin(t * 0.8) * 0.12;
    }
  });

  return (
    <group ref={groupRef} position={initPos} rotation-y={facingAngle} castShadow>
      <mesh position={[-0.08, 0.04, 0]}>
        <boxGeometry args={[0.08, 0.08, 0.14]} />
        <meshStandardMaterial color={SHOE} />
      </mesh>
      <mesh position={[0.08, 0.04, 0]}>
        <boxGeometry args={[0.08, 0.08, 0.14]} />
        <meshStandardMaterial color={SHOE} />
      </mesh>
      <mesh ref={leftLegRef} position={[-0.08, 0.28, 0]}>
        <capsuleGeometry args={[0.06, 0.3, 6, 12]} />
        <meshStandardMaterial color={pantsColor} roughness={0.7} />
      </mesh>
      <mesh ref={rightLegRef} position={[0.08, 0.28, 0]}>
        <capsuleGeometry args={[0.06, 0.3, 6, 12]} />
        <meshStandardMaterial color={pantsColor} roughness={0.7} />
      </mesh>
      <mesh ref={torsoRef} position={[0, 0.62, 0]}>
        <capsuleGeometry args={[0.14, 0.28, 8, 16]} />
        <meshStandardMaterial color={teamColor} roughness={0.6} />
      </mesh>
      <mesh ref={leftArmRef} position={[-0.22, 0.6, 0]} rotation-z={0.15}>
        <capsuleGeometry args={[0.05, 0.28, 6, 12]} />
        <meshStandardMaterial color={teamColor} roughness={0.6} />
      </mesh>
      <mesh ref={rightArmRef} position={[0.22, 0.6, 0]} rotation-z={-0.15}>
        <capsuleGeometry args={[0.05, 0.28, 6, 12]} />
        <meshStandardMaterial color={teamColor} roughness={0.6} />
      </mesh>
      <mesh position={[-0.24, 0.42, 0]}>
        <sphereGeometry args={[0.05, 8, 8]} />
        <meshStandardMaterial color={SKIN} />
      </mesh>
      <mesh position={[0.24, 0.42, 0]}>
        <sphereGeometry args={[0.05, 8, 8]} />
        <meshStandardMaterial color={SKIN} />
      </mesh>
      <mesh ref={headRef} position={[0, 0.9, 0]} castShadow>
        <sphereGeometry args={[0.12, 16, 16]} />
        <meshStandardMaterial color={SKIN} roughness={0.8} />
      </mesh>
      <mesh position={[0, 0.99, 0]}>
        <cylinderGeometry args={[0.13, 0.13, 0.05, 16]} />
        <meshStandardMaterial color={teamColor} />
      </mesh>
      <mesh position={[0, 0.97, -0.1]}>
        <boxGeometry args={[0.18, 0.02, 0.12]} />
        <meshStandardMaterial color={teamColor} />
      </mesh>
      {withGlove && (
        <mesh position={[-0.28, 0.4, 0.05]}>
          <sphereGeometry args={[0.08, 8, 8]} />
          <meshStandardMaterial color="#5c3317" roughness={0.8} />
        </mesh>
      )}
      {withBat && (
        <mesh ref={batRef} position={[0.3, 0.65, -0.1]} rotation-z={-0.5} rotation-x={0.2}>
          <cylinderGeometry args={[0.02, 0.035, 0.7, 8]} />
          <meshStandardMaterial color="#8B6914" roughness={0.5} />
        </mesh>
      )}
    </group>
  );
}

export default function Players3D({ bases, phase, hitBall }: Props) {
  // Determine which fielder chases the ball
  const chaseFielder = useMemo(() => {
    if (!hitBall?.visible) return null;
    const [wx, wz] = hitBallToWorld(hitBall);
    return { key: findNearestFielder(wx, wz), target: [wx, wz] as [number, number] };
  }, [hitBall?.visible ? `${hitBall.x.toFixed(0)},${hitBall.y.toFixed(0)}` : null]);

  return (
    <group>
      {Object.entries(FIELDER_POSITIONS).map(([key, pos]) => {
        const angle = Math.atan2(-pos[0], -pos[2]);
        const role = key === "pitcher" ? "pitcher" : key === "catcher" ? "catcher" : "fielder";
        const isChasing = chaseFielder && chaseFielder.key === key;
        return (
          <PlayerModel
            key={key}
            position={[pos[0], pos[1], pos[2]]}
            teamColor={TEAM_HOME}
            pantsColor={PANTS_HOME}
            facingAngle={key === "catcher" ? Math.PI : angle}
            withGlove
            role={role as any}
            phase={phase}
            chaseTarget={isChasing ? chaseFielder.target : null}
          />
        );
      })}

      <PlayerModel
        position={[-0.55, 0, 0.1]}
        teamColor={TEAM_AWAY}
        pantsColor={PANTS_AWAY}
        facingAngle={-Math.PI / 2}
        withBat
        role="batter"
        phase={phase}
        runTarget={hitBall?.visible ? [FIELD.FIRST[0], 0, FIELD.FIRST[2]] : null}
      />

      {bases[1] && (
        <PlayerModel
          position={[FIELD.FIRST[0] + 0.4, 0, FIELD.FIRST[2]]}
          teamColor={TEAM_AWAY}
          pantsColor={PANTS_AWAY}
          facingAngle={-Math.PI / 4}
          role="runner"
          phase={phase}
        />
      )}
      {bases[2] && (
        <PlayerModel
          position={[FIELD.SECOND[0] + 0.3, 0, FIELD.SECOND[2] + 0.3]}
          teamColor={TEAM_AWAY}
          pantsColor={PANTS_AWAY}
          facingAngle={Math.PI}
          role="runner"
          phase={phase}
        />
      )}
      {bases[3] && (
        <PlayerModel
          position={[FIELD.THIRD[0] - 0.4, 0, FIELD.THIRD[2]]}
          teamColor={TEAM_AWAY}
          pantsColor={PANTS_AWAY}
          facingAngle={(3 * Math.PI) / 4}
          role="runner"
          phase={phase}
        />
      )}
    </group>
  );
}
