import type { Bases, Pitch } from "@/game/types";

export type CameraView = "broadcast" | "catcher" | "umpire" | "pitcher";

export interface SceneState {
  bases: Bases;
  ballProgress: number | null;
  currentPitch: Pitch | null;
  hitBall: { x: number; y: number; visible: boolean } | null;
  phaseLabel: string;
  billboard: BillboardConfig;
  phase: string;
  cameraView: CameraView;
}

export interface BillboardConfig {
  logoUrl?: string;
  opacity: number;
  scale: number;
  offsetX: number;
  offsetY: number;
}

export const CAMERA_PRESETS: Record<CameraView, { position: [number, number, number]; lookAt: [number, number, number]; fov: number }> = {
  broadcast: { position: [0, 12, 10], lookAt: [0, 0, -8], fov: 45 },
  catcher:   { position: [0, 1.4, 2.2], lookAt: [0, 1.0, -6.05], fov: 55 },
  umpire:    { position: [0, 1.6, 1.8], lookAt: [0, 0.9, -6.05], fov: 50 },
  pitcher:   { position: [0, 1.6, -7.5], lookAt: [0, 0.8, 0], fov: 50 },
};

export const FIELD = {
  HOME: [0, 0, 0] as const,
  MOUND: [0, 0.15, -6.05] as const,
  FIRST: [6.36, 0, -6.36] as const,
  SECOND: [0, 0, -12.73] as const,
  THIRD: [-6.36, 0, -6.36] as const,
  WALL_RADIUS: 33,
  WALL_HEIGHT: 1.2,
  WALL_THICKNESS: 0.25,
  INFIELD_RADIUS: 9.5,
  WARNING_TRACK_WIDTH: 2.5,
} as const;

export const FIELDER_POSITIONS: Record<string, [number, number, number]> = {
  pitcher: [0, 0, -6.05],
  catcher: [0, 0, 1.5],
  first: [7, 0, -6],
  second: [3, 0, -10],
  shortstop: [-3, 0, -10],
  third: [-7, 0, -6],
  left: [-14, 0, -24],
  center: [0, 0, -28],
  right: [14, 0, -24],
};
