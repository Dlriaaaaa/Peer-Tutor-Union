/**
 * Sprite Drawing Utilities
 *
 * All drawing functions take a CanvasRenderingContext2D and draw at specified positions.
 * Designed to be swapped with image-based sprites later.
 */

// ─── Field Positions (top-down view, 800x500 canvas) ────

export const FIELD = {
  width: 800,
  height: 500,
  homePlate: { x: 400, y: 430 },
  mound: { x: 400, y: 280 },
  firstBase: { x: 520, y: 310 },
  secondBase: { x: 400, y: 200 },
  thirdBase: { x: 280, y: 310 },
  // Outfield wall arc center and radius
  wallCenter: { x: 400, y: 430 },
  wallRadius: 380,
  // Billboard / scoreboard area on the outfield wall
  billboard: { x: 320, y: 60, width: 160, height: 50 },
} as const;

// ─── Player Drawing ──────────────────────────────────────

/**
 * Draw a player as a colored circle with optional label.
 * Replace this function with sprite image drawing later.
 */
export function drawPlayer(
  ctx: CanvasRenderingContext2D,
  x: number,
  y: number,
  color: string,
  radius: number = 12,
  label?: string,
) {
  ctx.save();
  ctx.beginPath();
  ctx.arc(x, y, radius, 0, Math.PI * 2);
  ctx.fillStyle = color;
  ctx.fill();
  ctx.strokeStyle = "#222";
  ctx.lineWidth = 2;
  ctx.stroke();

  if (label) {
    ctx.fillStyle = "#fff";
    ctx.font = "bold 9px monospace";
    ctx.textAlign = "center";
    ctx.textBaseline = "middle";
    ctx.fillText(label, x, y);
  }
  ctx.restore();
}

// ─── Ball Drawing ────────────────────────────────────────

export function drawBall(
  ctx: CanvasRenderingContext2D,
  x: number,
  y: number,
  radius: number = 6,
) {
  ctx.save();
  ctx.beginPath();
  ctx.arc(x, y, radius, 0, Math.PI * 2);
  ctx.fillStyle = "#FFFEF6";
  ctx.fill();
  ctx.strokeStyle = "#CC0000";
  ctx.lineWidth = 1.5;
  ctx.stroke();
  // Seam lines
  ctx.beginPath();
  ctx.arc(x - 1, y, radius * 0.6, -0.8, 0.8);
  ctx.strokeStyle = "#CC0000";
  ctx.lineWidth = 0.8;
  ctx.stroke();
  ctx.beginPath();
  ctx.arc(x + 1, y, radius * 0.6, Math.PI - 0.8, Math.PI + 0.8);
  ctx.stroke();
  ctx.restore();
}

// ─── Base Drawing ────────────────────────────────────────

export function drawBase(
  ctx: CanvasRenderingContext2D,
  x: number,
  y: number,
  occupied: boolean,
  size: number = 14,
) {
  ctx.save();
  ctx.translate(x, y);
  ctx.rotate(Math.PI / 4);
  ctx.fillStyle = occupied ? "#FFD700" : "#F5F5DC";
  ctx.fillRect(-size / 2, -size / 2, size, size);
  ctx.strokeStyle = occupied ? "#DAA520" : "#8B8B6B";
  ctx.lineWidth = 2;
  ctx.strokeRect(-size / 2, -size / 2, size, size);
  ctx.restore();
}

// ─── Home Plate ──────────────────────────────────────────

export function drawHomePlate(ctx: CanvasRenderingContext2D, x: number, y: number) {
  ctx.save();
  ctx.beginPath();
  ctx.moveTo(x, y + 10);
  ctx.lineTo(x - 10, y + 3);
  ctx.lineTo(x - 10, y - 5);
  ctx.lineTo(x + 10, y - 5);
  ctx.lineTo(x + 10, y + 3);
  ctx.closePath();
  ctx.fillStyle = "#F5F5DC";
  ctx.fill();
  ctx.strokeStyle = "#333";
  ctx.lineWidth = 1.5;
  ctx.stroke();
  ctx.restore();
}

// ─── Billboard / Scoreboard ─────────────────────────────

export interface BillboardConfig {
  logoImage?: HTMLImageElement | null;
  opacity?: number;
  scale?: number;
  offsetX?: number;
  offsetY?: number;
}

/**
 * Draw the billboard area on the outfield wall.
 * Accepts a BillboardConfig for full customization.
 */
export function drawBillboard(
  ctx: CanvasRenderingContext2D,
  config: BillboardConfig = {},
) {
  const {
    logoImage = null,
    opacity = 1,
    scale = 1,
    offsetX = 0,
    offsetY = 0,
  } = config;

  const baseX = FIELD.billboard.x + offsetX;
  const baseY = FIELD.billboard.y + offsetY;
  const w = FIELD.billboard.width * scale;
  const h = FIELD.billboard.height * scale;
  // Center the scaled billboard around the original center
  const x = baseX + (FIELD.billboard.width - w) / 2;
  const y = baseY + (FIELD.billboard.height - h) / 2;

  ctx.save();
  ctx.globalAlpha = opacity;

  if (logoImage && logoImage.complete && logoImage.naturalWidth > 0) {
    ctx.drawImage(logoImage, x, y, w, h);
  } else {
    // Placeholder billboard
    ctx.fillStyle = "#1a2744";
    ctx.fillRect(x, y, w, h);
    ctx.strokeStyle = "#FFD700";
    ctx.lineWidth = 2;
    ctx.strokeRect(x, y, w, h);
    ctx.fillStyle = "#FFD700";
    ctx.font = "bold 14px sans-serif";
    ctx.textAlign = "center";
    ctx.textBaseline = "middle";
    ctx.fillText("⚾ YOUR AD HERE", x + w / 2, y + h / 2);
  }

  ctx.restore();
}

// ─── Strike Zone Overlay ─────────────────────────────────

export function drawStrikeZone(
  ctx: CanvasRenderingContext2D,
  x: number,
  y: number,
  width: number = 60,
  height: number = 70,
  alpha: number = 0.3,
) {
  ctx.save();
  ctx.strokeStyle = `rgba(255, 255, 255, ${alpha})`;
  ctx.lineWidth = 1;
  ctx.setLineDash([4, 4]);
  ctx.strokeRect(x - width / 2, y - height / 2, width, height);
  ctx.setLineDash([]);
  ctx.restore();
}
