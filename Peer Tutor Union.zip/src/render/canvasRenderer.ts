/**
 * Canvas Renderer
 *
 * Pure rendering functions — no game state mutation.
 * Draws the field, players, ball animation, bases, and billboard.
 */

import type { Bases, Pitch } from "../game/types";
import {
  FIELD,
  drawPlayer, drawBall, drawBase, drawHomePlate,
  drawBillboard, drawStrikeZone,
  type BillboardConfig,
} from "./sprites";

export interface RenderState {
  bases: Bases;
  /** Ball animation progress: 0 = at mound, 1 = at plate. null = no ball visible */
  ballProgress: number | null;
  /** The pitch being thrown (for trajectory) */
  currentPitch: Pitch | null;
  /** Billboard configuration */
  billboard: BillboardConfig;
  /** Hit ball animation (after contact) */
  hitBall: { x: number; y: number; visible: boolean } | null;
  /** Current phase label to display */
  phaseLabel?: string;
}

// ─── Main Render Function ────────────────────────────────

export function renderFrame(
  ctx: CanvasRenderingContext2D,
  state: RenderState,
) {
  const { width, height } = FIELD;
  ctx.clearRect(0, 0, width, height);

  drawSky(ctx);
  drawOutfieldWall(ctx);
  drawBillboard(ctx, state.billboard);
  drawOutfield(ctx);
  drawInfield(ctx);
  drawBaseLines(ctx);
  drawHomePlate(ctx, FIELD.homePlate.x, FIELD.homePlate.y);

  // Bases with occupancy
  drawBase(ctx, FIELD.firstBase.x, FIELD.firstBase.y, state.bases[1]);
  drawBase(ctx, FIELD.secondBase.x, FIELD.secondBase.y, state.bases[2]);
  drawBase(ctx, FIELD.thirdBase.x, FIELD.thirdBase.y, state.bases[3]);

  // Pitcher's mound
  drawMound(ctx);

  // Players
  drawPlayer(ctx, FIELD.mound.x, FIELD.mound.y - 8, "#2563EB", 10, "P");
  drawPlayer(ctx, FIELD.homePlate.x, FIELD.homePlate.y + 18, "#666", 10, "C");
  // Batter — always at home plate, centered
  drawPlayer(ctx, FIELD.homePlate.x - 22, FIELD.homePlate.y, "#DC2626", 11, "B");

  // Fielders
  drawPlayer(ctx, FIELD.firstBase.x + 18, FIELD.firstBase.y - 10, "#2563EB", 8, "1B");
  drawPlayer(ctx, FIELD.secondBase.x + 40, FIELD.secondBase.y + 30, "#2563EB", 8, "2B");
  drawPlayer(ctx, FIELD.secondBase.x - 40, FIELD.secondBase.y + 30, "#2563EB", 8, "SS");
  drawPlayer(ctx, FIELD.thirdBase.x - 18, FIELD.thirdBase.y - 10, "#2563EB", 8, "3B");
  // Outfielders
  drawPlayer(ctx, 180, 140, "#2563EB", 7, "LF");
  drawPlayer(ctx, 400, 110, "#2563EB", 7, "CF");
  drawPlayer(ctx, 620, 140, "#2563EB", 7, "RF");

  // Runners on base
  if (state.bases[1]) drawPlayer(ctx, FIELD.firstBase.x + 12, FIELD.firstBase.y - 5, "#DC2626", 8, "R");
  if (state.bases[2]) drawPlayer(ctx, FIELD.secondBase.x, FIELD.secondBase.y - 14, "#DC2626", 8, "R");
  if (state.bases[3]) drawPlayer(ctx, FIELD.thirdBase.x - 12, FIELD.thirdBase.y - 5, "#DC2626", 8, "R");

  // Strike zone (subtle)
  drawStrikeZone(ctx, FIELD.homePlate.x, FIELD.homePlate.y - 30, 50, 60, 0.2);

  // Ball in flight
  if (state.ballProgress !== null && state.currentPitch) {
    const pos = getBallPosition(state.ballProgress, state.currentPitch);
    const size = 4 + state.ballProgress * 4; // grows as it approaches
    drawBall(ctx, pos.x, pos.y, size);
  }

  // Hit ball animation
  if (state.hitBall?.visible) {
    drawBall(ctx, state.hitBall.x, state.hitBall.y, 5);
  }

  // Phase label overlay
  if (state.phaseLabel) {
    drawPhaseLabel(ctx, state.phaseLabel);
  }
}

// ─── Phase Label ─────────────────────────────────────────

function drawPhaseLabel(ctx: CanvasRenderingContext2D, label: string) {
  ctx.save();
  ctx.fillStyle = "rgba(0,0,0,0.5)";
  const metrics = ctx.measureText(label);
  const w = Math.max(metrics.width + 24, 120);
  ctx.fillRect(FIELD.width / 2 - w / 2, 460, w, 28);
  ctx.fillStyle = "#fff";
  ctx.font = "bold 13px sans-serif";
  ctx.textAlign = "center";
  ctx.textBaseline = "middle";
  ctx.fillText(label, FIELD.width / 2, 474);
  ctx.restore();
}

// ─── Ball Position Interpolation ─────────────────────────

export function getBallPosition(
  progress: number, // 0..1
  pitch: Pitch,
): { x: number; y: number } {
  const startX = FIELD.mound.x;
  const startY = FIELD.mound.y;
  const endX = FIELD.homePlate.x + pitch.location.x * 25;
  const endY = FIELD.homePlate.y - 30 + pitch.location.y * -20;

  // Add break curve (quadratic)
  const t = progress;
  const breakX = pitch.breakH * 0.8 * t * t;
  const breakY = pitch.breakV * -0.3 * t * t;

  return {
    x: startX + (endX - startX) * t + breakX,
    y: startY + (endY - startY) * t + breakY,
  };
}

// ─── Field Drawing ───────────────────────────────────────

function drawSky(ctx: CanvasRenderingContext2D) {
  const grad = ctx.createLinearGradient(0, 0, 0, 120);
  grad.addColorStop(0, "#1a2a4a");
  grad.addColorStop(1, "#2d4a2d");
  ctx.fillStyle = grad;
  ctx.fillRect(0, 0, FIELD.width, 120);
}

function drawOutfieldWall(ctx: CanvasRenderingContext2D) {
  ctx.save();
  ctx.beginPath();
  ctx.arc(FIELD.wallCenter.x, FIELD.wallCenter.y, FIELD.wallRadius, Math.PI + 0.35, -0.35);
  ctx.strokeStyle = "#1a3a1a";
  ctx.lineWidth = 16;
  ctx.stroke();
  // Wall top edge (yellow line)
  ctx.beginPath();
  ctx.arc(FIELD.wallCenter.x, FIELD.wallCenter.y, FIELD.wallRadius + 7, Math.PI + 0.35, -0.35);
  ctx.strokeStyle = "#FFD700";
  ctx.lineWidth = 3;
  ctx.stroke();
  ctx.restore();
}

function drawOutfield(ctx: CanvasRenderingContext2D) {
  ctx.save();
  ctx.beginPath();
  ctx.arc(FIELD.wallCenter.x, FIELD.wallCenter.y, FIELD.wallRadius - 8, Math.PI + 0.35, -0.35);
  ctx.lineTo(FIELD.homePlate.x, FIELD.homePlate.y);
  ctx.closePath();
  ctx.fillStyle = "#2d6b2d";
  ctx.fill();
  ctx.restore();
}

function drawInfield(ctx: CanvasRenderingContext2D) {
  ctx.save();
  ctx.beginPath();
  ctx.moveTo(FIELD.homePlate.x, FIELD.homePlate.y - 5);
  ctx.lineTo(FIELD.firstBase.x + 20, FIELD.firstBase.y);
  ctx.lineTo(FIELD.secondBase.x, FIELD.secondBase.y - 20);
  ctx.lineTo(FIELD.thirdBase.x - 20, FIELD.thirdBase.y);
  ctx.closePath();
  ctx.fillStyle = "#8B6914";
  ctx.fill();

  // Infield grass
  ctx.beginPath();
  ctx.arc(FIELD.mound.x, FIELD.mound.y + 30, 80, 0, Math.PI * 2);
  ctx.fillStyle = "#3a8a3a";
  ctx.fill();
  ctx.restore();
}

function drawBaseLines(ctx: CanvasRenderingContext2D) {
  ctx.save();
  ctx.strokeStyle = "#F5F5DC";
  ctx.lineWidth = 2;

  ctx.beginPath();
  ctx.moveTo(FIELD.homePlate.x, FIELD.homePlate.y);
  ctx.lineTo(FIELD.firstBase.x, FIELD.firstBase.y);
  ctx.stroke();

  ctx.beginPath();
  ctx.moveTo(FIELD.homePlate.x, FIELD.homePlate.y);
  ctx.lineTo(FIELD.thirdBase.x, FIELD.thirdBase.y);
  ctx.stroke();

  ctx.beginPath();
  ctx.moveTo(FIELD.firstBase.x, FIELD.firstBase.y);
  ctx.lineTo(FIELD.secondBase.x, FIELD.secondBase.y);
  ctx.stroke();

  ctx.beginPath();
  ctx.moveTo(FIELD.thirdBase.x, FIELD.thirdBase.y);
  ctx.lineTo(FIELD.secondBase.x, FIELD.secondBase.y);
  ctx.stroke();

  // Foul lines extending to outfield
  ctx.setLineDash([6, 6]);
  ctx.beginPath();
  ctx.moveTo(FIELD.firstBase.x, FIELD.firstBase.y);
  ctx.lineTo(FIELD.width - 30, 80);
  ctx.stroke();
  ctx.beginPath();
  ctx.moveTo(FIELD.thirdBase.x, FIELD.thirdBase.y);
  ctx.lineTo(30, 80);
  ctx.stroke();
  ctx.setLineDash([]);

  ctx.restore();
}

function drawMound(ctx: CanvasRenderingContext2D) {
  ctx.save();
  ctx.beginPath();
  ctx.ellipse(FIELD.mound.x, FIELD.mound.y, 18, 10, 0, 0, Math.PI * 2);
  ctx.fillStyle = "#9B7B3B";
  ctx.fill();
  // Rubber
  ctx.fillStyle = "#F5F5DC";
  ctx.fillRect(FIELD.mound.x - 10, FIELD.mound.y - 2, 20, 4);
  ctx.restore();
}
