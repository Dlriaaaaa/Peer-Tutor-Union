/**
 * Baseball Rules Engine — State Machine
 * Handles inning transitions, walk-off detection, extra innings.
 */

import type { GameState, Bases } from "./types";
import { REGULATION_INNINGS, OUTS_PER_HALF } from "./constants";

const emptyBases = (): Bases => ({ 1: false, 2: false, 3: false });
const resetCount = () => ({ balls: 0, strikes: 0 });

/**
 * Called after an out is recorded and outs >= 3.
 * Transitions to the next half-inning or ends the game.
 */
export function checkInningTransition(state: GameState): GameState {
  const { inning, half, score } = state;

  // ── Top of inning just ended ──
  if (half === "top") {
    // After top of 9th (or later): if home team is already ahead, game over
    // (home team doesn't need to bat)
    if (inning >= REGULATION_INNINGS && score.home > score.away) {
      return {
        ...state,
        outs: OUTS_PER_HALF,
        status: "over",
        winner: "home",
        log: [
          ...state.log,
          `End of top ${inning}. Home leads ${score.home}-${score.away}. Game over!`,
        ],
      };
    }

    // Move to bottom of same inning
    return {
      ...state,
      half: "bottom",
      outs: 0,
      count: resetCount(),
      bases: emptyBases(),
      log: [
        ...state.log,
        `── End of top ${inning}. Score: Away ${score.away} - Home ${score.home} ──`,
      ],
    };
  }

  // ── Bottom of inning just ended ──
  // Check if regulation is complete (inning >= 9)
  if (inning >= REGULATION_INNINGS) {
    if (score.away !== score.home) {
      // Game decided
      const winner = score.home > score.away ? "home" : "away";
      return {
        ...state,
        outs: OUTS_PER_HALF,
        status: "over",
        winner,
        log: [
          ...state.log,
          `End of inning ${inning}. Final: Away ${score.away} - Home ${score.home}. ${winner === "home" ? "Home" : "Away"} wins!`,
        ],
      };
    }
    // Tie → extra inning
    return {
      ...state,
      inning: inning + 1,
      half: "top",
      outs: 0,
      count: resetCount(),
      bases: emptyBases(),
      log: [
        ...state.log,
        `── Tied ${score.away}-${score.home} after ${inning}. Extra innings! ──`,
      ],
    };
  }

  // Before regulation ends: move to next inning
  return {
    ...state,
    inning: inning + 1,
    half: "top",
    outs: 0,
    count: resetCount(),
    bases: emptyBases(),
    log: [
      ...state.log,
      `── End of inning ${inning}. Score: Away ${score.away} - Home ${score.home} ──`,
    ],
  };
}

/**
 * Called after any scoring play during the bottom half.
 * Detects walk-off: if home team takes the lead in bottom of 9th+ → game immediately over.
 */
export function checkWalkoff(state: GameState): GameState {
  if (state.status === "over") return state;

  const { inning, half, score } = state;

  // Walk-off only possible in bottom of 9th or later
  if (half === "bottom" && inning >= REGULATION_INNINGS && score.home > score.away) {
    return {
      ...state,
      status: "over",
      winner: "home",
      log: [
        ...state.log,
        `WALK-OFF! Home wins ${score.home}-${score.away} in the bottom of the ${inning}${ordinalSuffix(inning)}!`,
      ],
    };
  }

  return state;
}

/** Ordinal suffix helper */
function ordinalSuffix(n: number): string {
  const s = ["th", "st", "nd", "rd"];
  const v = n % 100;
  return s[(v - 20) % 10] || s[v] || s[0];
}
