/**
 * Baseball Rules Engine — Constants
 */

export const REGULATION_INNINGS = 9;
export const BALLS_FOR_WALK = 4;
export const STRIKES_FOR_K = 3;
export const OUTS_PER_HALF = 3;
export const MAX_FOUL_STRIKES = 2;

// ─── Pitch Constants ─────────────────────────────────────

/** Strike zone boundaries in normalized coords */
export const STRIKE_ZONE = {
  xMin: -0.5,
  xMax: 0.5,
  yMin: -0.5,
  yMax: 0.5,
} as const;

/**
 * Pitch profiles: base speed (mph), typical horizontal & vertical break (inches).
 * Actual values get jittered by the pitcher module.
 */
export const PITCH_PROFILES = {
  fastball:  { speed: 93, breakH: 3,  breakV: 14, speedVar: 3 },
  curveball: { speed: 78, breakH: -4, breakV: -8, speedVar: 3 },
  slider:    { speed: 85, breakH: -6, breakV: 2,  speedVar: 2 },
  changeup:  { speed: 83, breakH: 5,  breakV: 6,  speedVar: 3 },
} as const;

// ─── Hitting Constants ───────────────────────────────────

/** Perfect timing window (±ms) */
export const PERFECT_TIMING_WINDOW = 8;

/** Max timing deviation before guaranteed miss (ms) */
export const MAX_TIMING_DEVIATION = 40;

/** Base error probability for fielding */
export const BASE_ERROR_RATE = 0.03;

/** Distance thresholds for hit categorization (feet) */
export const DISTANCE_THRESHOLDS = {
  infield: 150,
  shallow_outfield: 250,
  deep_outfield: 350,
  home_run_fence: 400,
} as const;
