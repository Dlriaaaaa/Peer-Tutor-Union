/**
 * Pitching Module
 *
 * Generates realistic pitches with type-specific speed, break, and location.
 * Provides a seeded-random helper so results are reproducible when needed.
 */

import type { Pitch, PitchType, PitchLocation } from "./types";
import { PITCH_PROFILES, STRIKE_ZONE } from "./constants";

// ─── RNG Helper ──────────────────────────────────────────

/**
 * Simple seedable PRNG (xoshiro128**).
 * If no seed provided, uses Math.random.
 */
export function createRng(seed?: number): () => number {
  if (seed === undefined) return Math.random;
  let s = seed | 0 || 1;
  return () => {
    s ^= s << 13;
    s ^= s >> 17;
    s ^= s << 5;
    return (s >>> 0) / 4294967296;
  };
}

/** Gaussian-ish random via Box-Muller, mean 0 stddev 1 */
export function gaussRandom(rng: () => number): number {
  const u1 = rng() || 0.0001;
  const u2 = rng();
  return Math.sqrt(-2 * Math.log(u1)) * Math.cos(2 * Math.PI * u2);
}

// ─── Pitch Generation ────────────────────────────────────

/**
 * Generate a pitch of a given type aimed at a target location.
 * The actual location deviates from the target based on pitcher control.
 *
 * @param type       - Pitch type
 * @param target     - Where the pitcher intends to throw
 * @param control    - Pitcher's control rating 0..1 (1 = pinpoint)
 * @param rng        - Random function
 */
export function generatePitch(
  type: PitchType,
  target: PitchLocation,
  control: number = 0.7,
  rng: () => number = Math.random,
): Pitch {
  const profile = PITCH_PROFILES[type];

  // Speed jitter
  const speed = profile.speed + gaussRandom(rng) * profile.speedVar;

  // Break jitter (±20%)
  const breakH = profile.breakH * (1 + gaussRandom(rng) * 0.2);
  const breakV = profile.breakV * (1 + gaussRandom(rng) * 0.2);

  // Location: target + control-based scatter + break influence
  // Lower control → more scatter
  const scatter = (1 - control) * 0.6;
  const breakInfluence = 0.02; // break moves the final location slightly

  const location: PitchLocation = {
    x: clamp(target.x + gaussRandom(rng) * scatter + breakH * breakInfluence, -1.2, 1.2),
    y: clamp(target.y + gaussRandom(rng) * scatter + breakV * breakInfluence, -1.2, 1.2),
  };

  return { type, speed, location, breakH, breakV };
}

/**
 * Is this pitch location inside the strike zone?
 */
export function isInStrikeZone(loc: PitchLocation): boolean {
  return (
    loc.x >= STRIKE_ZONE.xMin &&
    loc.x <= STRIKE_ZONE.xMax &&
    loc.y >= STRIKE_ZONE.yMin &&
    loc.y <= STRIKE_ZONE.yMax
  );
}

/**
 * How far is this pitch from the center of the strike zone?
 * 0 = right down the middle, higher = further away.
 */
export function distanceFromCenter(loc: PitchLocation): number {
  return Math.sqrt(loc.x * loc.x + loc.y * loc.y);
}

/**
 * Is the pitch close enough to the batter to be a hit-by-pitch?
 * HBP zone: very inside (x < -0.8) and within vertical body range.
 */
export function isHBPZone(loc: PitchLocation): boolean {
  return loc.x < -0.85 && loc.y > -0.6 && loc.y < 0.6;
}

// ─── Utilities ───────────────────────────────────────────

function clamp(v: number, min: number, max: number): number {
  return Math.max(min, Math.min(max, v));
}
