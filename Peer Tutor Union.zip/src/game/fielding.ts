/**
 * Fielding Module
 *
 * Given a HitBall and the current game state (outs, bases),
 * determines the defensive result: out, hit, error, double play, etc.
 * Output is an InPlayResult compatible with rulesEngine.applyPitchOutcome.
 */

import type { HitBall, InPlayResult, Bases, FieldingChance } from "./types";
import { BASE_ERROR_RATE, DISTANCE_THRESHOLDS } from "./constants";
import { runnersOnBase } from "./rulesEngine";

// ─── Main Entry Point ────────────────────────────────────

/**
 * Resolve a batted ball into an InPlayResult.
 *
 * @param hitBall - Properties of the batted ball
 * @param outs    - Current out count (0-2)
 * @param bases   - Current base occupancy
 * @param rng     - Random function
 */
export function resolveFielding(
  hitBall: HitBall,
  outs: number,
  bases: Bases,
  rng: () => number = Math.random,
): InPlayResult {
  const chance = evaluateFieldingChance(hitBall, outs, bases);

  // ── Error check first ──
  if (rng() < chance.errorProbability) {
    return { type: "error" };
  }

  // ── Out or hit? ──
  const isOut = rng() < chance.outProbability;

  if (isOut) {
    return resolveOut(hitBall, chance, outs, bases, rng);
  }

  // ── Hit: determine how far batter reaches ──
  return resolveHit(hitBall, rng);
}

// ─── Fielding Chance Evaluation ──────────────────────────

/**
 * Evaluate the probability of various fielding outcomes.
 * This is the "brain" of the fielding module — deterministic given inputs.
 */
export function evaluateFieldingChance(
  hitBall: HitBall,
  outs: number,
  bases: Bases,
): FieldingChance {
  const { battedBallType, exitVelocity, distance, pullAngle } = hitBall;
  let outProb: number;

  switch (battedBallType) {
    case "popup":
      // Popups are almost always caught
      outProb = 0.95;
      break;

    case "fly_ball":
      // Fly balls: distance matters — routine fly vs deep fly
      if (distance < DISTANCE_THRESHOLDS.shallow_outfield) {
        outProb = 0.85; // routine
      } else if (distance < DISTANCE_THRESHOLDS.deep_outfield) {
        outProb = 0.65; // playable
      } else if (distance >= DISTANCE_THRESHOLDS.home_run_fence) {
        outProb = 0.0;  // home run — not catchable
      } else {
        outProb = 0.35; // deep warning track
      }
      break;

    case "line_drive":
      // Line drives: exit velocity matters most
      if (exitVelocity > 100) {
        outProb = 0.20; // screamer
      } else if (exitVelocity > 90) {
        outProb = 0.35;
      } else {
        outProb = 0.55; // softer liner, fielders can react
      }
      break;

    case "ground_ball":
      // Ground balls: speed and direction matter
      if (exitVelocity > 95) {
        outProb = 0.45; // hard grounder through the hole
      } else if (exitVelocity > 75) {
        outProb = 0.65; // routine grounder
      } else {
        outProb = 0.75; // soft roller
      }
      // Up the middle or sharp pull = harder to field
      if (Math.abs(pullAngle) < 10) outProb -= 0.1;
      break;

    default:
      outProb = 0.5;
  }

  // Clamp
  outProb = Math.max(0, Math.min(1, outProb));

  // ── Double play assessment ──
  const dpPossible =
    battedBallType === "ground_ball" &&
    outs < 2 &&
    bases[1]; // runner on 1st required

  const dpProb = dpPossible
    ? 0.4 * (exitVelocity < 90 ? 1.2 : 0.8) // slower grounders → easier DP
    : 0;

  // ── Sac fly assessment ──
  const sacFlyPossible =
    (battedBallType === "fly_ball" || battedBallType === "line_drive") &&
    bases[3] &&
    outs < 2 &&
    distance > DISTANCE_THRESHOLDS.shallow_outfield;

  // ── Error rate: slightly higher on hard-hit balls ──
  const errorProb = BASE_ERROR_RATE + (exitVelocity > 95 ? 0.02 : 0);

  return {
    outProbability: outProb,
    doublePlayPossible: dpPossible,
    doublePlayProbability: Math.min(dpProb, 0.5),
    sacFlyPossible,
    errorProbability: Math.min(errorProb, 0.08),
  };
}

// ─── Resolve an Out ──────────────────────────────────────

function resolveOut(
  hitBall: HitBall,
  chance: FieldingChance,
  outs: number,
  bases: Bases,
  rng: () => number,
): InPlayResult {
  const { battedBallType } = hitBall;

  // Double play?
  if (chance.doublePlayPossible && rng() < chance.doublePlayProbability) {
    return { type: "ground_out", doublePlay: true };
  }

  // Sac fly?
  if (chance.sacFlyPossible && (battedBallType === "fly_ball" || battedBallType === "popup")) {
    return { type: "sac_fly" };
  }

  // Fielder's choice: ground ball with runners, sometimes get the lead runner instead
  if (
    battedBallType === "ground_ball" &&
    runnersOnBase(bases) > 0 &&
    !bases[1] === false && // there is a force situation
    rng() < 0.25
  ) {
    return { type: "fielders_choice" };
  }

  // Standard outs by batted ball type
  switch (battedBallType) {
    case "ground_ball":
      return { type: "ground_out" };
    case "line_drive":
      return { type: "line_out" };
    case "fly_ball":
    case "popup":
      return { type: "fly_out" };
    default:
      return { type: "fly_out" };
  }
}

// ─── Resolve a Hit ───────────────────────────────────────

function resolveHit(hitBall: HitBall, rng: () => number): InPlayResult {
  const { distance, battedBallType, exitVelocity } = hitBall;

  // Home run: ball clears the fence
  if (distance >= DISTANCE_THRESHOLDS.home_run_fence) {
    return { type: "home_run" };
  }

  // Deep fly that wasn't caught → could be extra bases
  if (distance > DISTANCE_THRESHOLDS.deep_outfield) {
    // Deep hit = likely triple or double
    return rng() < 0.3 ? { type: "triple" } : { type: "double" };
  }

  if (distance > DISTANCE_THRESHOLDS.shallow_outfield) {
    // Outfield hit
    if (battedBallType === "line_drive" && exitVelocity > 95) {
      // Hard line drive to gap → double
      return rng() < 0.5 ? { type: "double" } : { type: "single" };
    }
    return rng() < 0.2 ? { type: "double" } : { type: "single" };
  }

  // Infield hit (rare — ground ball that gets through)
  return { type: "single" };
}
