/**
 * Baseball Rules Engine — Type Definitions
 * Extended with simulation types for pitching, hitting, fielding, baserunning.
 */

// ─── Existing Core Types (unchanged) ─────────────────────

export type HalfInning = "top" | "bottom";
export type GameStatus = "playing" | "over";

export type Bases = {
  1: boolean;
  2: boolean;
  3: boolean;
};

export type Score = {
  away: number;
  home: number;
};

export type Count = {
  balls: number;
  strikes: number;
};

export interface GameState {
  inning: number;
  half: HalfInning;
  outs: number;
  count: Count;
  bases: Bases;
  score: Score;
  status: GameStatus;
  winner: "away" | "home" | null;
  log: string[];
}

export type PitchOutcome =
  | "ball"
  | "strike"
  | "foul"
  | "hit_by_pitch"
  | "in_play";

export type InPlayResult =
  | { type: "single" }
  | { type: "double" }
  | { type: "triple" }
  | { type: "home_run" }
  | { type: "fly_out" }
  | { type: "ground_out"; doublePlay?: boolean }
  | { type: "line_out" }
  | { type: "sac_fly" }
  | { type: "fielders_choice" }
  | { type: "error" };

// ─── Simulation Types ────────────────────────────────────

/** Pitch type thrown by the pitcher */
export type PitchType = "fastball" | "curveball" | "slider" | "changeup";

/**
 * 2D pitch location in normalized coordinates.
 * x: -1 (far inside to LHB) to +1 (far outside)
 * y: -1 (low, dirt) to +1 (high, above head)
 * The strike zone is roughly x ∈ [-0.5, 0.5], y ∈ [-0.5, 0.5].
 */
export interface PitchLocation {
  x: number; // horizontal: -1..+1
  y: number; // vertical:   -1..+1
}

/** A fully described pitch */
export interface Pitch {
  type: PitchType;
  speed: number;          // mph (65–100)
  location: PitchLocation;
  /** How much the ball breaks from its initial trajectory (inches) */
  breakH: number;         // horizontal break (+ = arm-side)
  breakV: number;         // vertical break (+ = rises relative to gravity)
}

/** Player's swing decision */
export type SwingDecision =
  | { action: "take" }    // don't swing
  | {
      action: "swing";
      /** Timing offset in ms: 0 = perfect, negative = early, positive = late */
      timing: number;
      /** Aim point: where the batter targets the bat head */
      aimPoint: PitchLocation;
    };

/** Quality of contact when bat meets ball */
export interface ContactResult {
  made: boolean;          // did the bat make contact?
  quality: number;        // 0..1 (0 = weak foul-tip, 1 = barrel)
  launchAngle: number;    // degrees: negative = ground ball, 10-25 = line drive, 25-50 = fly ball
  exitVelocity: number;   // mph
  pullAngle: number;      // -45 = pull, 0 = center, +45 = opposite field (degrees)
  isFoul: boolean;        // did it go foul?
}

/** Categorized batted ball for fielding evaluation */
export type BattedBallType = "ground_ball" | "line_drive" | "fly_ball" | "popup";

export interface HitBall {
  battedBallType: BattedBallType;
  exitVelocity: number;
  launchAngle: number;
  pullAngle: number;      // field direction
  distance: number;       // estimated distance in feet
}

/**
 * Result from the at-bat resolution layer before it hits rulesEngine.
 * This tells us what PitchOutcome + optional InPlayResult to feed to applyPitchOutcome.
 */
export interface AtBatOutcome {
  pitchOutcome: PitchOutcome;
  inPlayResult?: InPlayResult;
  /** For display / logging */
  description: string;
}

/** Fielding difficulty evaluation */
export interface FieldingChance {
  /** Probability of an out (0..1) */
  outProbability: number;
  /** Can attempt double play? */
  doublePlayPossible: boolean;
  doublePlayProbability: number;
  /** Could this be a sac fly situation? */
  sacFlyPossible: boolean;
  /** Is there a chance of a fielding error? */
  errorProbability: number;
}

/** AI pitcher strategy context */
export interface PitcherContext {
  count: Count;
  outs: number;
  bases: Bases;
  inning: number;
  scoreDiff: number; // positive = pitcher's team leading
}
