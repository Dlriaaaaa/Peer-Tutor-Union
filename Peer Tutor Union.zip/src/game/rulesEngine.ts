/**
 * Baseball Rules Engine — Pure functions for game logic.
 * Every function is (state, input) => newState with no side effects.
 */

import type {
  GameState, Bases, Count, PitchOutcome, InPlayResult, HalfInning,
} from "./types";
import {
  BALLS_FOR_WALK, STRIKES_FOR_K, OUTS_PER_HALF, MAX_FOUL_STRIKES,
} from "./constants";
import { checkInningTransition, checkWalkoff } from "./stateMachine";

// ─── Helpers ─────────────────────────────────────────────

/** Deep-clone bases */
const cloneBases = (b: Bases): Bases => ({ 1: b[1], 2: b[2], 3: b[3] });

/** Count runners on base */
export const runnersOnBase = (b: Bases): number =>
  (b[1] ? 1 : 0) + (b[2] ? 1 : 0) + (b[3] ? 1 : 0);

/** Are the bases loaded? */
export const basesLoaded = (b: Bases): boolean => b[1] && b[2] && b[3];

/** Empty bases */
const emptyBases = (): Bases => ({ 1: false, 2: false, 3: false });

/** Reset the pitch count */
const resetCount = (): Count => ({ balls: 0, strikes: 0 });

/** Which team is batting? */
export const battingTeam = (half: HalfInning): "away" | "home" =>
  half === "top" ? "away" : "home";

// ─── Core State Builders ─────────────────────────────────

/** Create the initial game state for a new game */
export function createInitialGameState(): GameState {
  return {
    inning: 1,
    half: "top",
    outs: 0,
    count: resetCount(),
    bases: emptyBases(),
    score: { away: 0, home: 0 },
    status: "playing",
    winner: null,
    log: [],
  };
}

// ─── Runner Advancement ──────────────────────────────────

/**
 * Advance all runners by `n` bases. Returns new bases and runs scored.
 * Batter is implicitly placed at base `n` (or scores if n >= 4).
 */
export function advanceRunners(
  bases: Bases,
  advanceBy: number,
): { newBases: Bases; runsScored: number } {
  let runs = 0;
  const newBases = emptyBases();

  // Move existing runners
  for (const baseNum of [3, 2, 1] as const) {
    if (!bases[baseNum]) continue;
    const dest = baseNum + advanceBy;
    if (dest >= 4) {
      runs++;
    } else {
      newBases[dest as 1 | 2 | 3] = true;
    }
  }

  // Place batter
  if (advanceBy >= 4) {
    runs++; // home run
  } else if (advanceBy >= 1) {
    newBases[advanceBy as 1 | 2 | 3] = true;
  }

  return { newBases, runsScored: runs };
}

/**
 * Walk / HBP: advance only forced runners (batter gets 1st).
 * If bases loaded, runner on 3rd scores (squeeze).
 */
export function advanceForWalk(bases: Bases): { newBases: Bases; runsScored: number } {
  let runs = 0;
  const newBases = cloneBases(bases);

  if (bases[1] && bases[2] && bases[3]) {
    // Bases loaded — runner on 3rd scores
    runs = 1;
    // 3rd ← 2nd, 2nd ← 1st, 1st ← batter (all stay occupied)
    // newBases stays all true
  } else if (bases[1] && bases[2]) {
    newBases[3] = true;
  } else if (bases[1]) {
    newBases[2] = true;
  }
  newBases[1] = true;

  return { newBases, runsScored: runs };
}

// ─── Recording an Out ────────────────────────────────────

function recordOuts(
  state: GameState,
  numOuts: number,
  log: string,
  runsOnPlay: number = 0,
): GameState {
  const newOuts = state.outs + numOuts;
  const team = battingTeam(state.half);
  const newScore = { ...state.score };

  // Runs only count if scored before the 3rd out (except on home runs handled elsewhere)
  if (newOuts < OUTS_PER_HALF) {
    newScore[team] += runsOnPlay;
  }

  const partial: GameState = {
    ...state,
    outs: newOuts,
    count: resetCount(),
    score: newScore,
    log: [...state.log, log],
  };

  if (newOuts >= OUTS_PER_HALF) {
    return checkInningTransition(partial);
  }
  return checkWalkoff(partial);
}

// ─── Apply Pitch Outcome ─────────────────────────────────

/**
 * Main entry point: apply a single pitch outcome to the current state.
 * For "in_play", you must also provide an InPlayResult.
 */
export function applyPitchOutcome(
  state: GameState,
  outcome: PitchOutcome,
  inPlayResult?: InPlayResult,
): GameState {
  if (state.status === "over") return state;

  switch (outcome) {
    case "ball":
      return handleBall(state);
    case "strike":
      return handleStrike(state);
    case "foul":
      return handleFoul(state);
    case "hit_by_pitch":
      return handleHBP(state);
    case "in_play":
      if (!inPlayResult) throw new Error("in_play requires an InPlayResult");
      return resolveInPlay(state, inPlayResult);
    default:
      return state;
  }
}

// ─── Pitch Handlers ──────────────────────────────────────

function handleBall(state: GameState): GameState {
  const newBalls = state.count.balls + 1;
  if (newBalls >= BALLS_FOR_WALK) {
    // Walk (base on balls)
    const { newBases, runsScored } = advanceForWalk(state.bases);
    const team = battingTeam(state.half);
    const newScore = { ...state.score, [team]: state.score[team] + runsScored };
    const logMsg = runsScored > 0
      ? `Walk (BB). ${runsScored} run(s) score on bases-loaded walk!`
      : "Walk (BB). Batter takes first base.";
    const next: GameState = {
      ...state,
      count: resetCount(),
      bases: newBases,
      score: newScore,
      log: [...state.log, logMsg],
    };
    return checkWalkoff(next);
  }
  return {
    ...state,
    count: { ...state.count, balls: newBalls },
    log: [...state.log, `Ball ${newBalls}.`],
  };
}

function handleStrike(state: GameState): GameState {
  const newStrikes = state.count.strikes + 1;
  if (newStrikes >= STRIKES_FOR_K) {
    // Strikeout
    return recordOuts(state, 1, "Strikeout! (K)");
  }
  return {
    ...state,
    count: { ...state.count, strikes: newStrikes },
    log: [...state.log, `Strike ${newStrikes}.`],
  };
}

function handleFoul(state: GameState): GameState {
  // Foul ball: adds a strike only if current strikes < 2
  if (state.count.strikes < MAX_FOUL_STRIKES) {
    const newStrikes = state.count.strikes + 1;
    return {
      ...state,
      count: { ...state.count, strikes: newStrikes },
      log: [...state.log, `Foul ball. Strike ${newStrikes}.`],
    };
  }
  // With 2 strikes, foul just stays at 2
  return {
    ...state,
    log: [...state.log, "Foul ball. (count unchanged at 2 strikes)"],
  };
}

function handleHBP(state: GameState): GameState {
  const { newBases, runsScored } = advanceForWalk(state.bases);
  const team = battingTeam(state.half);
  const newScore = { ...state.score, [team]: state.score[team] + runsScored };
  const logMsg = runsScored > 0
    ? `Hit by pitch! Batter takes 1st. ${runsScored} run(s) scored.`
    : "Hit by pitch! Batter takes first base.";
  const next: GameState = {
    ...state,
    count: resetCount(),
    bases: newBases,
    score: newScore,
    log: [...state.log, logMsg],
  };
  return checkWalkoff(next);
}

// ─── In-Play Resolution ──────────────────────────────────

/**
 * Resolve a ball put in play. Pure function.
 */
export function resolveInPlay(state: GameState, result: InPlayResult): GameState {
  switch (result.type) {
    case "single": {
      const { newBases, runsScored } = advanceRunners(state.bases, 1);
      const team = battingTeam(state.half);
      const s: GameState = {
        ...state,
        count: resetCount(),
        bases: newBases,
        score: { ...state.score, [team]: state.score[team] + runsScored },
        log: [...state.log, `Single! ${runsScored} run(s) scored.`],
      };
      return checkWalkoff(s);
    }

    case "double": {
      const { newBases, runsScored } = advanceRunners(state.bases, 2);
      const team = battingTeam(state.half);
      const s: GameState = {
        ...state,
        count: resetCount(),
        bases: newBases,
        score: { ...state.score, [team]: state.score[team] + runsScored },
        log: [...state.log, `Double! ${runsScored} run(s) scored.`],
      };
      return checkWalkoff(s);
    }

    case "triple": {
      const { newBases, runsScored } = advanceRunners(state.bases, 3);
      const team = battingTeam(state.half);
      const s: GameState = {
        ...state,
        count: resetCount(),
        bases: newBases,
        score: { ...state.score, [team]: state.score[team] + runsScored },
        log: [...state.log, `Triple! ${runsScored} run(s) scored.`],
      };
      return checkWalkoff(s);
    }

    case "home_run": {
      // All runners + batter score
      const runs = runnersOnBase(state.bases) + 1;
      const team = battingTeam(state.half);
      const s: GameState = {
        ...state,
        count: resetCount(),
        bases: emptyBases(),
        score: { ...state.score, [team]: state.score[team] + runs },
        log: [...state.log, `HOME RUN! ${runs} run(s) scored!`],
      };
      return checkWalkoff(s);
    }

    case "fly_out":
      return recordOuts(state, 1, "Fly out!");

    case "line_out":
      return recordOuts(state, 1, "Line out!");

    case "ground_out": {
      if (result.doublePlay && state.outs < 2 && runnersOnBase(state.bases) > 0) {
        // Double play: lead runner and batter both out, no advancement
        const newBases = cloneBases(state.bases);
        // Remove lead runner
        if (newBases[3]) newBases[3] = false;
        else if (newBases[2]) newBases[2] = false;
        else if (newBases[1]) newBases[1] = false;
        return recordOuts(
          { ...state, bases: newBases },
          2,
          "Ground ball — Double play!",
        );
      }
      return recordOuts(state, 1, "Ground out.");
    }

    case "sac_fly": {
      // Out recorded; runner on 3rd scores if < 2 outs before this out
      if (state.bases[3] && state.outs < 2) {
        const newBases = cloneBases(state.bases);
        newBases[3] = false;
        return recordOuts(
          { ...state, bases: newBases },
          1,
          "Sacrifice fly! Runner scores from 3rd.",
          1,
        );
      }
      return recordOuts(state, 1, "Fly out (attempted sac fly, no runner scored).");
    }

    case "fielders_choice": {
      // Batter reaches 1st, lead runner is out
      const newBases = cloneBases(state.bases);
      // Remove lead runner
      if (newBases[3]) newBases[3] = false;
      else if (newBases[2]) newBases[2] = false;
      else if (newBases[1]) newBases[1] = false;
      newBases[1] = true;
      return recordOuts(
        { ...state, bases: newBases },
        1,
        "Fielder's choice. Lead runner out, batter reaches 1st.",
      );
    }

    case "error": {
      // Batter reaches safely, all runners advance 1
      const { newBases, runsScored } = advanceRunners(state.bases, 1);
      const team = battingTeam(state.half);
      const s: GameState = {
        ...state,
        count: resetCount(),
        bases: newBases,
        score: { ...state.score, [team]: state.score[team] + runsScored },
        log: [...state.log, `Error! Batter safe. ${runsScored} run(s) scored.`],
      };
      return checkWalkoff(s);
    }

    default:
      return state;
  }
}
