/**
 * Hitting Module
 *
 * Resolves what happens when a pitch arrives and the batter makes a decision.
 * Contact quality is deterministic given timing + aim accuracy + pitch properties.
 * The output is an AtBatOutcome that can feed directly into rulesEngine.applyPitchOutcome.
 */

import type {
  Pitch, SwingDecision, ContactResult, HitBall,
  BattedBallType, AtBatOutcome, PitchLocation,
} from "./types";
import {
  PERFECT_TIMING_WINDOW, MAX_TIMING_DEVIATION, DISTANCE_THRESHOLDS,
} from "./constants";
import { isInStrikeZone, isHBPZone, distanceFromCenter } from "./pitching";

// ─── Core Resolution ─────────────────────────────────────

/**
 * Resolve a single pitch + batter decision into an AtBatOutcome.
 * This is the main entry point for the hitting system.
 *
 * @param pitch   - The incoming pitch
 * @param decision - Player's swing/take decision
 * @param rng     - Random function for stochastic elements
 */
export function resolveSwing(
  pitch: Pitch,
  decision: SwingDecision,
  rng: () => number = Math.random,
): AtBatOutcome {
  // ── Hit by pitch check (before swing decision matters) ──
  if (isHBPZone(pitch.location)) {
    // HBP only if batter doesn't swing out of the way
    if (decision.action === "take" || Math.abs(decision.timing) > 20) {
      return { pitchOutcome: "hit_by_pitch", description: "Hit by pitch!" };
    }
  }

  // ── Batter takes (no swing) ──
  if (decision.action === "take") {
    if (isInStrikeZone(pitch.location)) {
      return { pitchOutcome: "strike", description: "Called strike." };
    }
    return { pitchOutcome: "ball", description: "Ball." };
  }

  // ── Batter swings ──
  const contact = calculateContact(pitch, decision, rng);

  if (!contact.made) {
    return { pitchOutcome: "strike", description: "Swinging strike!" };
  }

  if (contact.isFoul) {
    return { pitchOutcome: "foul", description: "Foul ball." };
  }

  // Ball is in play — build the hit ball descriptor
  const hitBall = buildHitBall(contact);

  return {
    pitchOutcome: "in_play",
    // NOTE: inPlayResult is NOT set here — it's determined by fielding.ts
    // We attach the hitBall data via description for the pipeline to use
    description: `In play — ${hitBall.battedBallType}, ${hitBall.exitVelocity.toFixed(0)} mph, ${hitBall.distance.toFixed(0)} ft.`,
    // We extend AtBatOutcome at runtime with hitBall for the pipeline
    ...({ hitBall } as any),
  };
}

// ─── Contact Calculation ─────────────────────────────────

/**
 * Determine contact quality based on timing, aim accuracy, and pitch properties.
 * NOT random — purely derived from inputs (with small rng for foul/miss edge cases).
 */
export function calculateContact(
  pitch: Pitch,
  swing: Extract<SwingDecision, { action: "swing" }>,
  rng: () => number = Math.random,
): ContactResult {
  const { timing, aimPoint } = swing;

  // ── 1. Timing quality (0..1) ──
  const absTime = Math.abs(timing);
  const timingQuality = absTime <= PERFECT_TIMING_WINDOW
    ? 1.0
    : Math.max(0, 1 - (absTime - PERFECT_TIMING_WINDOW) / (MAX_TIMING_DEVIATION - PERFECT_TIMING_WINDOW));

  // ── 2. Aim accuracy: distance between aim point and actual pitch location ──
  const aimDist = Math.sqrt(
    (aimPoint.x - pitch.location.x) ** 2 +
    (aimPoint.y - pitch.location.y) ** 2,
  );
  // Aim quality: 1.0 if perfect, drops off with distance
  const aimQuality = Math.max(0, 1 - aimDist / 1.2);

  // ── 3. Pitch difficulty modifier ──
  // Breaking balls with more movement are harder to square up
  const breakDifficulty = (Math.abs(pitch.breakH) + Math.abs(pitch.breakV)) / 30;
  const pitchModifier = Math.max(0.5, 1 - breakDifficulty * 0.3);

  // ── 4. Overall contact quality ──
  const rawQuality = timingQuality * aimQuality * pitchModifier;

  // ── 5. Did the bat make contact? ──
  // Miss if combined quality is very low
  const contactThreshold = 0.15 + rng() * 0.1; // slight randomness on edge
  const made = rawQuality > contactThreshold;

  if (!made) {
    return {
      made: false,
      quality: 0,
      launchAngle: 0,
      exitVelocity: 0,
      pullAngle: 0,
      isFoul: false,
    };
  }

  // ── 6. Launch angle ──
  // Base angle from pitch height: low pitch → ground ball, high pitch → fly ball
  const baseAngle = pitch.location.y * 25; // -25 (ground) to +25 (fly)
  // Timing influence: early = pull + more loft, late = opposite + ground
  const timingAngleShift = -timing * 0.3; // early (negative timing) → positive angle
  // Quality influence: poor contact → more extreme angles
  const qualityAngleNoise = (1 - rawQuality) * (rng() - 0.5) * 30;
  const launchAngle = clamp(baseAngle + timingAngleShift + qualityAngleNoise, -20, 60);

  // ── 7. Exit velocity ──
  // Better contact = higher exit velo; pitch speed contributes
  const baseVelo = 50 + rawQuality * 55; // 50-105 mph range
  const pitchSpeedBonus = (pitch.speed - 80) * 0.15; // faster pitch = harder hit
  const exitVelocity = clamp(baseVelo + pitchSpeedBonus, 40, 115);

  // ── 8. Pull angle ──
  // Early timing = pull (-45), late = opposite field (+45)
  const pullAngle = clamp(timing * 1.5 + (rng() - 0.5) * 15, -45, 45);

  // ── 9. Foul ball check ──
  // Extreme pull angles or very poor quality contact → foul
  const isFoul =
    Math.abs(pullAngle) > 38 ||
    (rawQuality < 0.35 && Math.abs(pullAngle) > 25 && rng() < 0.5);

  return {
    made: true,
    quality: rawQuality,
    launchAngle,
    exitVelocity,
    pullAngle,
    isFoul,
  };
}

// ─── Hit Ball Construction ───────────────────────────────

/**
 * Build a HitBall descriptor from contact results.
 */
export function buildHitBall(contact: ContactResult): HitBall {
  const battedBallType = categorizeBattedBall(contact.launchAngle, contact.exitVelocity);

  // Distance estimation (simplified physics)
  // Higher exit velo + optimal angle (25-35°) = more distance
  const angleRad = (contact.launchAngle * Math.PI) / 180;
  const sinA = Math.sin(angleRad);
  const cosA = Math.cos(angleRad);
  // Rough trajectory: d = v² * sin(2θ) / g, scaled to feet
  const rawDist = (contact.exitVelocity ** 2 * Math.abs(sinA * cosA) * 2) / 32.17;
  // Scale factor to get realistic baseball distances
  const distance = clamp(rawDist * 0.45 + 30, 10, 480);

  return {
    battedBallType,
    exitVelocity: contact.exitVelocity,
    launchAngle: contact.launchAngle,
    pullAngle: contact.pullAngle,
    distance,
  };
}

/**
 * Categorize the batted ball type from launch angle and exit velocity.
 */
export function categorizeBattedBall(
  launchAngle: number,
  exitVelocity: number,
): BattedBallType {
  if (launchAngle < 0) return "ground_ball";
  if (launchAngle < 12) return exitVelocity > 80 ? "line_drive" : "ground_ball";
  if (launchAngle < 28) return exitVelocity > 70 ? "line_drive" : "fly_ball";
  if (launchAngle > 55 || (launchAngle > 40 && exitVelocity < 70)) return "popup";
  return "fly_ball";
}

// ─── Utilities ───────────────────────────────────────────

function clamp(v: number, min: number, max: number): number {
  return Math.max(min, Math.min(max, v));
}
