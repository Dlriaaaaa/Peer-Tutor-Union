/**
 * Simulation Demo & Tests
 *
 * 1. Unit tests for each module
 * 2. Full at-bat simulation demo
 * 3. Full game simulation (AI vs AI)
 */

import { describe, it, expect } from "vitest";
import { createInitialGameState, applyPitchOutcome } from "../rulesEngine";
import { generatePitch, isInStrikeZone, createRng } from "../pitching";
import { resolveSwing, calculateContact, buildHitBall } from "../hitting";
import { resolveFielding, evaluateFieldingChance } from "../fielding";
import { advanceRunnersOnPlay } from "../baserunning";
import { aiSelectPitch, aiBatterDecision, aiBaserunningDecision } from "../ai";
import type { GameState, Pitch, HitBall, Bases } from "../types";

// ─── Pitching Tests ──────────────────────────────────────

describe("Pitching", () => {
  it("generates a fastball with realistic speed", () => {
    const rng = createRng(42);
    const pitch = generatePitch("fastball", { x: 0, y: 0 }, 0.8, rng);
    expect(pitch.type).toBe("fastball");
    expect(pitch.speed).toBeGreaterThan(85);
    expect(pitch.speed).toBeLessThan(100);
  });

  it("generates a curveball slower than a fastball", () => {
    const rng = createRng(42);
    const fb = generatePitch("fastball", { x: 0, y: 0 }, 0.8, rng);
    const cb = generatePitch("curveball", { x: 0, y: 0 }, 0.8, rng);
    expect(cb.speed).toBeLessThan(fb.speed);
  });

  it("correctly identifies strike zone", () => {
    expect(isInStrikeZone({ x: 0, y: 0 })).toBe(true);         // center
    expect(isInStrikeZone({ x: 0.49, y: 0.49 })).toBe(true);   // corner
    expect(isInStrikeZone({ x: 0.6, y: 0 })).toBe(false);      // outside
    expect(isInStrikeZone({ x: 0, y: -0.8 })).toBe(false);     // low
  });

  it("lower control = more scatter", () => {
    const rng1 = createRng(99);
    const rng2 = createRng(99);
    const pitchHigh = generatePitch("fastball", { x: 0, y: 0 }, 0.95, rng1);
    const pitchLow = generatePitch("fastball", { x: 0, y: 0 }, 0.3, rng2);
    // Low control pitch should deviate more from target (on average)
    // We can't guarantee with one sample, but the mechanism is tested
    expect(pitchHigh.location).toBeDefined();
    expect(pitchLow.location).toBeDefined();
  });
});

// ─── Hitting Tests ───────────────────────────────────────

describe("Hitting", () => {
  const centerFastball: Pitch = {
    type: "fastball",
    speed: 93,
    location: { x: 0, y: 0 },
    breakH: 3,
    breakV: 14,
  };

  it("taking a pitch in the zone = called strike", () => {
    const result = resolveSwing(centerFastball, { action: "take" });
    expect(result.pitchOutcome).toBe("strike");
  });

  it("taking a pitch outside the zone = ball", () => {
    const outsidePitch: Pitch = { ...centerFastball, location: { x: 0.8, y: 0 } };
    const result = resolveSwing(outsidePitch, { action: "take" });
    expect(result.pitchOutcome).toBe("ball");
  });

  it("perfect swing on center fastball makes contact", () => {
    const rng = createRng(1);
    const contact = calculateContact(
      centerFastball,
      { action: "swing", timing: 0, aimPoint: { x: 0, y: 0 } },
      rng,
    );
    expect(contact.made).toBe(true);
    expect(contact.quality).toBeGreaterThan(0.5);
  });

  it("terrible timing = miss or poor contact", () => {
    const rng = createRng(1);
    const contact = calculateContact(
      centerFastball,
      { action: "swing", timing: 35, aimPoint: { x: 0.5, y: 0.5 } },
      rng,
    );
    // Should be very poor or no contact
    expect(contact.quality).toBeLessThan(0.3);
  });

  it("buildHitBall creates valid categorization", () => {
    const contact = {
      made: true, quality: 0.8, launchAngle: 25,
      exitVelocity: 100, pullAngle: -10, isFoul: false,
    };
    const hitBall = buildHitBall(contact);
    expect(hitBall.battedBallType).toBe("line_drive");
    expect(hitBall.distance).toBeGreaterThan(100);
  });
});

// ─── Fielding Tests ──────────────────────────────────────

describe("Fielding", () => {
  it("popup has very high out probability", () => {
    const hitBall: HitBall = {
      battedBallType: "popup", exitVelocity: 60,
      launchAngle: 55, pullAngle: 0, distance: 120,
    };
    const chance = evaluateFieldingChance(hitBall, 0, { 1: false, 2: false, 3: false });
    expect(chance.outProbability).toBeGreaterThan(0.9);
  });

  it("deep fly ball past fence = home run (0% out)", () => {
    const hitBall: HitBall = {
      battedBallType: "fly_ball", exitVelocity: 110,
      launchAngle: 30, pullAngle: -5, distance: 420,
    };
    const chance = evaluateFieldingChance(hitBall, 0, { 1: false, 2: false, 3: false });
    expect(chance.outProbability).toBe(0);
  });

  it("double play possible with runner on 1st and ground ball", () => {
    const hitBall: HitBall = {
      battedBallType: "ground_ball", exitVelocity: 80,
      launchAngle: -5, pullAngle: -15, distance: 90,
    };
    const chance = evaluateFieldingChance(hitBall, 0, { 1: true, 2: false, 3: false });
    expect(chance.doublePlayPossible).toBe(true);
    expect(chance.doublePlayProbability).toBeGreaterThan(0);
  });

  it("resolveFielding returns valid InPlayResult", () => {
    const hitBall: HitBall = {
      battedBallType: "ground_ball", exitVelocity: 85,
      launchAngle: -3, pullAngle: 10, distance: 100,
    };
    const rng = createRng(42);
    const result = resolveFielding(hitBall, 0, { 1: false, 2: false, 3: false }, rng);
    expect(result.type).toBeDefined();
  });
});

// ─── Baserunning Tests ───────────────────────────────────

describe("Baserunning", () => {
  it("single with runner on 3rd scores", () => {
    const { newBases, runsScored } = advanceRunnersOnPlay(
      { 1: false, 2: false, 3: true },
      { type: "single" },
      0,
    );
    expect(runsScored).toBe(1);
    expect(newBases[1]).toBe(true);
  });

  it("sac fly scores runner from 3rd with < 2 outs", () => {
    const { runsScored } = advanceRunnersOnPlay(
      { 1: false, 2: false, 3: true },
      { type: "sac_fly" },
      1,
    );
    expect(runsScored).toBe(1);
  });

  it("double play clears runner on 1st", () => {
    const { newBases } = advanceRunnersOnPlay(
      { 1: true, 2: false, 3: false },
      { type: "ground_out", doublePlay: true },
      0,
    );
    expect(newBases[1]).toBe(false);
  });

  it("home run clears all bases", () => {
    const { newBases, runsScored } = advanceRunnersOnPlay(
      { 1: true, 2: true, 3: true },
      { type: "home_run" },
      0,
    );
    expect(runsScored).toBe(4); // grand slam
    expect(newBases).toEqual({ 1: false, 2: false, 3: false });
  });
});

// ─── AI Tests ────────────────────────────────────────────

describe("AI", () => {
  it("pitcher AI returns a valid pitch", () => {
    const rng = createRng(42);
    const pitch = aiSelectPitch({
      count: { balls: 0, strikes: 0 },
      outs: 0,
      bases: { 1: false, 2: false, 3: false },
      inning: 1,
      scoreDiff: 0,
    }, rng);
    expect(pitch.type).toBeDefined();
    expect(pitch.speed).toBeGreaterThan(60);
    expect(pitch.location.x).toBeDefined();
  });

  it("batter AI takes on 3-0 count for borderline pitches", () => {
    const rng = createRng(42);
    const outsidePitch: Pitch = {
      type: "curveball", speed: 78,
      location: { x: 0.6, y: -0.3 },
      breakH: -4, breakV: -8,
    };
    const decision = aiBatterDecision(outsidePitch, { balls: 3, strikes: 0 }, rng);
    expect(decision.action).toBe("take");
  });

  it("baserunning AI sends runner from 2nd with 2 outs", () => {
    const rng = createRng(42);
    const decision = aiBaserunningDecision(2, -1, 8, rng);
    expect(decision.sendRunnerFromSecond).toBe(true);
  });
});

// ─── Full Pipeline Demo ──────────────────────────────────

describe("Full Pipeline: Pitch → Swing → Field → State", () => {
  it("simulates a complete strikeout via applyPitchOutcome", () => {
    let state = createInitialGameState();
    // Directly apply 3 strikes to verify pipeline
    state = applyPitchOutcome(state, "strike");
    expect(state.count.strikes).toBe(1);
    state = applyPitchOutcome(state, "strike");
    expect(state.count.strikes).toBe(2);
    state = applyPitchOutcome(state, "strike");
    expect(state.outs).toBe(1);
    expect(state.count.strikes).toBe(0); // reset after K
  });

  it("simulates a single with runner scoring from 2nd", () => {
    let state = createInitialGameState();
    state = { ...state, bases: { 1: false, 2: true, 3: false } };
    const rng = createRng(55);

    // Generate a hittable pitch
    const pitch: Pitch = {
      type: "fastball", speed: 91,
      location: { x: 0.1, y: -0.1 },
      breakH: 2, breakV: 12,
    };

    // Good swing
    const swingResult = resolveSwing(
      pitch,
      { action: "swing", timing: 2, aimPoint: { x: 0.1, y: -0.1 } },
      rng,
    );

    if (swingResult.pitchOutcome === "in_play") {
      // Resolve fielding
      const hitBall: HitBall = (swingResult as any).hitBall;
      if (hitBall) {
        const fieldResult = resolveFielding(hitBall, state.outs, state.bases, rng);
        state = applyPitchOutcome(state, "in_play", fieldResult);
      }
    }

    // The state should have been updated (exact result depends on rng)
    expect(state.log.length).toBeGreaterThan(0);
  });

  it("simulates a full AI-vs-AI game to completion", () => {
    let state = createInitialGameState();
    const rng = createRng(777);
    let pitchCount = 0;
    const maxPitches = 2000; // safety limit

    while (state.status === "playing" && pitchCount < maxPitches) {
      pitchCount++;

      // AI pitcher throws
      const ctx = {
        count: state.count,
        outs: state.outs,
        bases: state.bases,
        inning: state.inning,
        scoreDiff: state.half === "top"
          ? state.score.home - state.score.away
          : state.score.away - state.score.home,
      };
      const pitch = aiSelectPitch(ctx, rng);

      // AI batter decides
      const decision = aiBatterDecision(pitch, state.count, rng);

      // Resolve the pitch
      const swingResult = resolveSwing(pitch, decision, rng);

      if (swingResult.pitchOutcome === "in_play") {
        const hitBall: HitBall | undefined = (swingResult as any).hitBall;
        if (hitBall) {
          const fieldResult = resolveFielding(hitBall, state.outs, state.bases, rng);
          state = applyPitchOutcome(state, "in_play", fieldResult);
        } else {
          // Fallback: treat as ground out if hitBall missing
          state = applyPitchOutcome(state, "in_play", { type: "ground_out" });
        }
      } else {
        state = applyPitchOutcome(state, swingResult.pitchOutcome);
      }
    }

    // Game should finish within reasonable pitch count
    expect(state.status).toBe("over");
    expect(state.winner).not.toBeNull();
    expect(state.inning).toBeGreaterThanOrEqual(9);

    // Print summary
    console.log(`\n🏟️  AI vs AI Game Complete!`);
    console.log(`   Final: Away ${state.score.away} - Home ${state.score.home}`);
    console.log(`   Winner: ${state.winner}`);
    console.log(`   Innings: ${state.inning}`);
    console.log(`   Total pitches: ${pitchCount}`);
    console.log(`   Last 5 log entries:`);
    state.log.slice(-5).forEach((l) => console.log(`     ${l}`));
  });
});
