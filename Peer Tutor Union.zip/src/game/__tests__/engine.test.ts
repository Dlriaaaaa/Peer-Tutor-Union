/**
 * Baseball Rules Engine — Tests
 */

import { describe, it, expect } from "vitest";
import { createInitialGameState, applyPitchOutcome, advanceRunners, resolveInPlay } from "../rulesEngine";
import type { GameState } from "../types";

describe("Baseball Rules Engine", () => {
  it("creates a valid initial state", () => {
    const s = createInitialGameState();
    expect(s.inning).toBe(1);
    expect(s.half).toBe("top");
    expect(s.outs).toBe(0);
    expect(s.count).toEqual({ balls: 0, strikes: 0 });
    expect(s.bases).toEqual({ 1: false, 2: false, 3: false });
    expect(s.score).toEqual({ away: 0, home: 0 });
    expect(s.status).toBe("playing");
  });

  it("counts balls correctly", () => {
    let s = createInitialGameState();
    s = applyPitchOutcome(s, "ball");
    expect(s.count.balls).toBe(1);
    s = applyPitchOutcome(s, "ball");
    s = applyPitchOutcome(s, "ball");
    expect(s.count.balls).toBe(3);
  });

  it("walks batter on 4 balls", () => {
    let s = createInitialGameState();
    for (let i = 0; i < 4; i++) s = applyPitchOutcome(s, "ball");
    expect(s.bases[1]).toBe(true);
    expect(s.count).toEqual({ balls: 0, strikes: 0 }); // reset
  });

  it("strikes out on 3 strikes", () => {
    let s = createInitialGameState();
    for (let i = 0; i < 3; i++) s = applyPitchOutcome(s, "strike");
    expect(s.outs).toBe(1);
    expect(s.count).toEqual({ balls: 0, strikes: 0 });
  });

  it("foul ball does not increase strikes past 2", () => {
    let s = createInitialGameState();
    s = applyPitchOutcome(s, "foul"); // strike 1
    s = applyPitchOutcome(s, "foul"); // strike 2
    expect(s.count.strikes).toBe(2);
    s = applyPitchOutcome(s, "foul"); // stays at 2
    expect(s.count.strikes).toBe(2);
    s = applyPitchOutcome(s, "foul"); // stays at 2
    expect(s.count.strikes).toBe(2);
  });

  it("hit by pitch puts batter on 1st", () => {
    let s = createInitialGameState();
    s = applyPitchOutcome(s, "hit_by_pitch");
    expect(s.bases[1]).toBe(true);
  });

  it("bases loaded walk scores a run", () => {
    let s = createInitialGameState();
    // Load bases with 3 walks
    for (let w = 0; w < 3; w++) {
      for (let i = 0; i < 4; i++) s = applyPitchOutcome(s, "ball");
    }
    expect(s.bases).toEqual({ 1: true, 2: true, 3: true });
    // 4th walk
    for (let i = 0; i < 4; i++) s = applyPitchOutcome(s, "ball");
    expect(s.score.away).toBe(1); // top of inning = away team
  });

  it("home run with runners scores all", () => {
    let s = createInitialGameState();
    // Put runners on 1st and 2nd via walks
    for (let w = 0; w < 2; w++) {
      for (let i = 0; i < 4; i++) s = applyPitchOutcome(s, "ball");
    }
    s = applyPitchOutcome(s, "in_play", { type: "home_run" });
    expect(s.score.away).toBe(3); // 2 runners + batter
    expect(s.bases).toEqual({ 1: false, 2: false, 3: false });
  });

  it("3 outs switch to bottom half", () => {
    let s = createInitialGameState();
    for (let out = 0; out < 3; out++) {
      for (let i = 0; i < 3; i++) s = applyPitchOutcome(s, "strike");
    }
    expect(s.half).toBe("bottom");
    expect(s.outs).toBe(0);
    expect(s.inning).toBe(1);
  });

  it("bottom 3 outs advance to inning 2", () => {
    let s = createInitialGameState();
    // Top: 3 K
    for (let out = 0; out < 3; out++) {
      for (let i = 0; i < 3; i++) s = applyPitchOutcome(s, "strike");
    }
    // Bottom: 3 K
    for (let out = 0; out < 3; out++) {
      for (let i = 0; i < 3; i++) s = applyPitchOutcome(s, "strike");
    }
    expect(s.inning).toBe(2);
    expect(s.half).toBe("top");
  });

  it("double play records 2 outs", () => {
    let s = createInitialGameState();
    // Walk to put runner on 1st
    for (let i = 0; i < 4; i++) s = applyPitchOutcome(s, "ball");
    expect(s.bases[1]).toBe(true);
    s = applyPitchOutcome(s, "in_play", { type: "ground_out", doublePlay: true });
    expect(s.outs).toBe(2);
  });

  it("sac fly scores runner from 3rd", () => {
    let s = createInitialGameState();
    // Manually set runner on 3rd
    s = { ...s, bases: { 1: false, 2: false, 3: true } };
    s = applyPitchOutcome(s, "in_play", { type: "sac_fly" });
    expect(s.outs).toBe(1);
    expect(s.score.away).toBe(1);
    expect(s.bases[3]).toBe(false);
  });

  it("completes a 9-inning game", () => {
    let s = createInitialGameState();
    // Away scores 1 run in top of 1st via solo HR
    s = applyPitchOutcome(s, "in_play", { type: "home_run" });
    expect(s.score.away).toBe(1);

    // Simulate remaining at-bats as strikeouts to finish the game
    // We need to go through innings 1(bottom) through 9(top of 9 already partial)
    // Let's just K everyone out
    const strikeoutHalf = (state: GameState): GameState => {
      for (let out = 0; out < 3; out++) {
        for (let i = 0; i < 3; i++) state = applyPitchOutcome(state, "strike");
        if (state.status === "over") return state;
      }
      return state;
    };

    // Finish top of 1st (2 more outs needed)
    for (let out = 0; out < 2; out++) {
      for (let i = 0; i < 3; i++) s = applyPitchOutcome(s, "strike");
    }

    // Innings 1 bottom through 8 bottom = 16 half innings
    for (let h = 0; h < 16; h++) {
      s = strikeoutHalf(s);
      if (s.status === "over") break;
    }

    // Top of 9th
    s = strikeoutHalf(s);

    // After top of 9th with away leading, home team still bats
    // But if home is behind after bottom 9th, away wins
    // Home trails 0-1, game should end after bottom 9
    if (s.status !== "over") {
      s = strikeoutHalf(s);
    }

    expect(s.status).toBe("over");
    expect(s.winner).toBe("away");
    expect(s.score).toEqual({ away: 1, home: 0 });
  });

  it("walk-off home run ends game immediately", () => {
    let s = createInitialGameState();

    const strikeoutHalf = (state: GameState): GameState => {
      for (let out = 0; out < 3; out++) {
        for (let i = 0; i < 3; i++) state = applyPitchOutcome(state, "strike");
        if (state.status === "over") return state;
      }
      return state;
    };

    // Play through 8 full innings of nothing
    for (let inn = 0; inn < 16; inn++) {
      s = strikeoutHalf(s);
    }
    // Top of 9th: nothing
    s = strikeoutHalf(s);

    // Bottom of 9th: home team hits a walk-off HR
    expect(s.half).toBe("bottom");
    expect(s.inning).toBe(9);
    s = applyPitchOutcome(s, "in_play", { type: "home_run" });
    expect(s.status).toBe("over");
    expect(s.winner).toBe("home");
    expect(s.score.home).toBe(1);
  });

  it("tied game goes to extra innings", () => {
    let s = createInitialGameState();

    const strikeoutHalf = (state: GameState): GameState => {
      for (let out = 0; out < 3; out++) {
        for (let i = 0; i < 3; i++) state = applyPitchOutcome(state, "strike");
        if (state.status === "over") return state;
      }
      return state;
    };

    // 9 full scoreless innings = 18 half-innings
    for (let h = 0; h < 18; h++) {
      s = strikeoutHalf(s);
    }

    // Should be in extra innings
    expect(s.status).toBe("playing");
    expect(s.inning).toBe(10);
    expect(s.half).toBe("top");
  });

  it("advanceRunners correctly handles runner on 2nd with a single", () => {
    const { newBases, runsScored } = advanceRunners({ 1: false, 2: true, 3: false }, 1);
    expect(newBases[3]).toBe(true); // runner advances to 3rd
    expect(newBases[1]).toBe(true); // batter on 1st
    expect(runsScored).toBe(0);
  });

  it("fielder's choice removes lead runner", () => {
    let s = createInitialGameState();
    s = { ...s, bases: { 1: true, 2: false, 3: false } };
    s = applyPitchOutcome(s, "in_play", { type: "fielders_choice" });
    expect(s.outs).toBe(1);
    expect(s.bases[1]).toBe(true); // batter reaches
  });

  it("error allows batter to reach and runners advance", () => {
    let s = createInitialGameState();
    s = { ...s, bases: { 1: false, 2: false, 3: true } };
    s = applyPitchOutcome(s, "in_play", { type: "error" });
    expect(s.score.away).toBe(1); // runner from 3rd scores
    expect(s.bases[1]).toBe(true); // batter on 1st
  });
});
