/**
 * Baserunning Module
 *
 * Provides higher-level runner advancement logic on top of rulesEngine.advanceRunners.
 * Designed for future extensibility (steal, pickoff, rundown).
 */

import type { Bases, InPlayResult, GameState } from "./types";
import { advanceRunners, advanceForWalk } from "./rulesEngine";

// ─── Runner Advancement on Hits ──────────────────────────

/**
 * Determine how runners advance on a batted ball based on the fielding result.
 * This augments the base advanceRunners() with situation-aware logic.
 *
 * Returns the new bases configuration and runs scored.
 */
export function advanceRunnersOnPlay(
  bases: Bases,
  result: InPlayResult,
  outs: number,
): { newBases: Bases; runsScored: number } {
  switch (result.type) {
    case "single":
      return advanceOnSingle(bases);
    case "double":
      return advanceRunners(bases, 2);
    case "triple":
      return advanceRunners(bases, 3);
    case "home_run":
      return advanceRunners(bases, 4);
    case "error":
      // Batter reaches, runners advance 1 (conservative)
      return advanceRunners(bases, 1);
    case "sac_fly":
      return advanceOnSacFly(bases, outs);
    case "fielders_choice":
      return advanceOnFieldersChoice(bases);
    case "ground_out":
      if (result.doublePlay) {
        return advanceOnDoublePlay(bases);
      }
      return advanceOnGroundOut(bases, outs);
    case "fly_out":
    case "line_out":
      // Runners hold (unless tag-up situations, simplified here)
      return { newBases: { ...bases }, runsScored: 0 };
    default:
      return { newBases: { ...bases }, runsScored: 0 };
  }
}

// ─── Situation-Specific Advancement ──────────────────────

/**
 * Single: runners advance with some intelligence.
 * - Runner on 1st → 2nd (always)
 * - Runner on 2nd → scores (most of the time on a single)
 * - Runner on 3rd → scores (always)
 * Simplified: all runners advance 1, runner on 3rd scores.
 * More aggressive: runner on 2nd scores on a single (common in real baseball).
 */
function advanceOnSingle(bases: Bases): { newBases: Bases; runsScored: number } {
  let runs = 0;
  const newBases: Bases = { 1: true, 2: false, 3: false }; // batter takes 1st

  // Runner on 3rd → scores
  if (bases[3]) runs++;

  // Runner on 2nd → scores (aggressive baserunning, realistic)
  if (bases[2]) runs++;

  // Runner on 1st → goes to 2nd
  if (bases[1]) newBases[2] = true;

  return { newBases, runsScored: runs };
}

/**
 * Sac fly: runner on 3rd tags up and scores, others hold.
 * Only valid with < 2 outs (caller should verify).
 */
function advanceOnSacFly(
  bases: Bases,
  outs: number,
): { newBases: Bases; runsScored: number } {
  const newBases = { ...bases };
  let runs = 0;

  if (bases[3] && outs < 2) {
    newBases[3] = false;
    runs = 1;
  }

  return { newBases, runsScored: runs };
}

/**
 * Fielder's choice: lead runner is retired, batter reaches 1st.
 */
function advanceOnFieldersChoice(
  bases: Bases,
): { newBases: Bases; runsScored: number } {
  const newBases = { ...bases };

  // Remove lead runner (in order: 3rd, 2nd, 1st)
  if (newBases[3]) {
    newBases[3] = false;
  } else if (newBases[2]) {
    newBases[2] = false;
  } else if (newBases[1]) {
    newBases[1] = false;
  }

  // Batter reaches 1st
  newBases[1] = true;

  return { newBases, runsScored: 0 };
}

/**
 * Double play: two outs recorded.
 * Lead runner and batter are out. Middle runners may advance on force.
 */
function advanceOnDoublePlay(
  bases: Bases,
): { newBases: Bases; runsScored: number } {
  const newBases = { ...bases };

  // Typical 6-4-3 or 4-6-3: runner on 1st out, batter out
  // Other runners stay put (simplified)
  if (newBases[1]) {
    newBases[1] = false;
  } else if (newBases[2]) {
    newBases[2] = false;
  }
  // Batter is also out (handled by rulesEngine recording 2 outs)

  return { newBases, runsScored: 0 };
}

/**
 * Ground out (not DP): force runner advancement.
 * If runner on 1st with < 2 outs, force play at 2nd — other runners may advance.
 */
function advanceOnGroundOut(
  bases: Bases,
  outs: number,
): { newBases: Bases; runsScored: number } {
  const newBases = { ...bases };
  let runs = 0;

  // With a ground out, forced runners advance
  if (bases[1]) {
    // Runner forced to 2nd
    newBases[1] = false;
    if (bases[2]) {
      // Runner forced to 3rd
      newBases[2] = false;
      if (bases[3]) {
        // Runner forced home
        newBases[3] = false;
        if (outs < 2) runs++; // scores only if this isn't the 3rd out
      }
      newBases[3] = true;
    }
    newBases[2] = true;
  }

  return { newBases, runsScored: runs };
}

// ─── Walk / HBP Runner Advancement (re-export for convenience) ──

export { advanceForWalk } from "./rulesEngine";

// ─── Future: Steal / Pickoff Stubs ──────────────────────

/**
 * Evaluate whether a runner should attempt to steal.
 * Stub for future implementation.
 */
export function shouldAttemptSteal(
  _bases: Bases,
  _outs: number,
  _pitcherAttention: number,
): { base: 1 | 2 | 3; attempt: boolean } {
  // TODO: implement steal logic based on runner speed, pitcher pickoff tendency, game situation
  return { base: 2, attempt: false };
}
