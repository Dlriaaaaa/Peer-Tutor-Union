/**
 * AI Module
 *
 * Provides AI decision-making for:
 * 1. Pitcher: pitch type + target location selection
 * 2. Batter (optional): swing/take decisions for AI-controlled batters
 * 3. Fielding: already handled by fielding.ts probabilities
 * 4. Baserunning: simple aggression-based decisions
 */

import type {
  Pitch, PitchType, PitchLocation, PitcherContext, SwingDecision,
  Count, Bases, GameState,
} from "./types";
import { generatePitch, isInStrikeZone } from "./pitching";
import { STRIKE_ZONE } from "./constants";

// ─── Pitcher AI ──────────────────────────────────────────

/**
 * AI selects a pitch type and target location based on game context.
 * Returns a fully generated Pitch.
 */
export function aiSelectPitch(
  ctx: PitcherContext,
  rng: () => number = Math.random,
): Pitch {
  const pitchType = choosePitchType(ctx, rng);
  const target = chooseTargetLocation(ctx, pitchType, rng);
  const control = 0.65 + rng() * 0.15; // 0.65–0.80 range for AI pitcher

  return generatePitch(pitchType, target, control, rng);
}

/**
 * Choose pitch type based on count and situation.
 *
 * Strategy:
 * - Ahead in count (more strikes) → throw breaking balls, waste pitches
 * - Behind in count (more balls) → throw fastball for strike
 * - First pitch → usually fastball
 * - Runners on base → more fastballs (hold runners)
 * - 3-2 count → best pitch (fastball or changeup)
 */
function choosePitchType(ctx: PitcherContext, rng: () => number): PitchType {
  const { count, bases } = ctx;
  const runnersOn = bases[1] || bases[2] || bases[3];
  const r = rng();

  // Full count (3-2): rely on best stuff
  if (count.balls === 3 && count.strikes === 2) {
    if (r < 0.45) return "fastball";
    if (r < 0.70) return "changeup";
    if (r < 0.85) return "slider";
    return "curveball";
  }

  // Pitcher ahead (0-2, 1-2): expand zone, use off-speed
  if (count.strikes === 2 && count.balls <= 1) {
    if (r < 0.25) return "slider";
    if (r < 0.50) return "curveball";
    if (r < 0.70) return "changeup";
    return "fastball";
  }

  // Pitcher behind (2-0, 3-0, 3-1): need a strike
  if (count.balls >= 2 && count.strikes <= 1) {
    if (r < 0.60) return "fastball";
    if (r < 0.80) return "changeup";
    return "slider";
  }

  // First pitch or even count
  if (runnersOn) {
    // With runners: more fastballs
    if (r < 0.55) return "fastball";
    if (r < 0.75) return "slider";
    if (r < 0.90) return "changeup";
    return "curveball";
  }

  // No runners, neutral count
  if (r < 0.40) return "fastball";
  if (r < 0.60) return "slider";
  if (r < 0.80) return "curveball";
  return "changeup";
}

/**
 * Choose target location based on situation.
 *
 * Strategy:
 * - Ahead in count → chase pitches (outside zone)
 * - Behind → center of zone
 * - Even → edges (painting corners)
 */
function chooseTargetLocation(
  ctx: PitcherContext,
  pitchType: PitchType,
  rng: () => number,
): PitchLocation {
  const { count } = ctx;

  // Behind: aim for center-ish of strike zone
  if (count.balls > count.strikes + 1) {
    return {
      x: (rng() - 0.5) * 0.4,  // tight to center
      y: (rng() - 0.5) * 0.4,
    };
  }

  // Ahead (especially 0-2): chase pitch — just off the zone
  if (count.strikes === 2 && count.balls <= 1) {
    const edge = rng();
    if (edge < 0.25) {
      // Low and away
      return { x: 0.4 + rng() * 0.3, y: -0.5 - rng() * 0.3 };
    }
    if (edge < 0.50) {
      // High
      return { x: (rng() - 0.5) * 0.5, y: 0.5 + rng() * 0.2 };
    }
    if (edge < 0.75) {
      // Inside off the plate
      return { x: -0.5 - rng() * 0.3, y: (rng() - 0.5) * 0.5 };
    }
    // Slider away
    return { x: 0.5 + rng() * 0.2, y: -0.1 + rng() * 0.3 };
  }

  // Even count or first pitch: paint corners
  const corners: PitchLocation[] = [
    { x: -0.4, y: -0.4 },  // low inside
    { x: 0.4, y: -0.4 },   // low outside
    { x: -0.4, y: 0.4 },   // high inside
    { x: 0.4, y: 0.3 },    // high outside
    { x: 0, y: -0.3 },     // low center
  ];

  const chosen = corners[Math.floor(rng() * corners.length)];
  return {
    x: chosen.x + (rng() - 0.5) * 0.2,
    y: chosen.y + (rng() - 0.5) * 0.2,
  };
}

// ─── Batter AI (for simulated / AI-vs-AI games) ─────────

/**
 * AI batter decides whether to swing or take.
 *
 * Strategy:
 * - If pitch looks like it's in the zone → swing
 * - With 2 strikes → protect the plate (swing at anything close)
 * - With 3 balls → take unless pitch is clearly a strike
 * - Swing quality is based on pitch difficulty
 */
export function aiBatterDecision(
  pitch: Pitch,
  count: Count,
  rng: () => number = Math.random,
): SwingDecision {
  const inZone = isInStrikeZone(pitch.location);
  const closeToZone =
    Math.abs(pitch.location.x) < 0.65 && Math.abs(pitch.location.y) < 0.65;

  // 3-0 count: take unless right down the middle
  if (count.balls === 3 && count.strikes === 0) {
    if (inZone && Math.abs(pitch.location.x) < 0.2 && Math.abs(pitch.location.y) < 0.2) {
      return makeSwing(pitch, 0.7, rng);
    }
    return { action: "take" };
  }

  // 2 strikes: protect the plate — swing at anything close
  if (count.strikes === 2) {
    if (inZone || (closeToZone && rng() < 0.7)) {
      return makeSwing(pitch, 0.6, rng);
    }
    // Still might chase
    if (rng() < 0.25) {
      return makeSwing(pitch, 0.4, rng);
    }
    return { action: "take" };
  }

  // Normal situation: swing at strikes
  if (inZone) {
    // More likely to swing at fastballs, might lay off breakers
    const swingProb = pitch.type === "fastball" ? 0.75 : 0.55;
    if (rng() < swingProb) {
      return makeSwing(pitch, 0.7, rng);
    }
    return { action: "take" };
  }

  // Ball: usually take, but batters chase
  if (closeToZone && rng() < 0.15) {
    return makeSwing(pitch, 0.5, rng);
  }

  return { action: "take" };
}

/**
 * Generate a swing with specified skill level.
 * Higher skill → better timing and aim.
 */
function makeSwing(
  pitch: Pitch,
  skill: number,
  rng: () => number,
): SwingDecision {
  // Timing: skill affects how close to perfect (0ms)
  // Perfect = 0, imperfect timing is offset
  const maxOffset = 40 * (1 - skill);
  const timing = (rng() - 0.5) * 2 * maxOffset;

  // Aim: try to track the pitch, imperfect tracking
  const trackError = (1 - skill) * 0.4;
  const aimPoint: PitchLocation = {
    x: pitch.location.x + (rng() - 0.5) * trackError,
    y: pitch.location.y + (rng() - 0.5) * trackError,
  };

  return { action: "swing", timing, aimPoint };
}

// ─── Baserunning AI ──────────────────────────────────────

/**
 * Simple aggression-based baserunning decisions.
 * Currently returns a modifier that affects runner advancement.
 *
 * aggression: 0..1 (0 = conservative, 1 = aggressive)
 */
export interface BaserunningDecision {
  /** Should runner on 2nd try to score on a single? */
  sendRunnerFromSecond: boolean;
  /** Should runner attempt to take an extra base? */
  extraBase: boolean;
}

export function aiBaserunningDecision(
  outs: number,
  scoreDiff: number,
  inning: number,
  rng: () => number = Math.random,
): BaserunningDecision {
  // More aggressive late in game when trailing
  const urgency = Math.max(0, (inning - 6) / 4 + (scoreDiff < 0 ? 0.2 : 0));
  const aggression = Math.min(0.9, 0.5 + urgency);

  // With 2 outs, always send runners (nothing to lose)
  if (outs === 2) {
    return { sendRunnerFromSecond: true, extraBase: rng() < 0.5 };
  }

  return {
    sendRunnerFromSecond: rng() < aggression,
    extraBase: rng() < aggression * 0.3,
  };
}
