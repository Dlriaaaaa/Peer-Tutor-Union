/**
 * Compress an image file before upload. Handles HEIC from Safari/iOS
 * and large images by converting to JPEG via canvas.
 */
export async function compressImage(file: File, maxWidth = 1600, quality = 0.85): Promise<Blob> {
  const isImage =
    file.type.startsWith("image/") ||
    /\.(heic|heif|jpg|jpeg|png|gif|webp|bmp|tiff?)$/i.test(file.name);

  // Skip non-image files
  if (!isImage) return file;

  // Skip tiny files and SVGs/GIFs (don't rasterize them)
  if (file.size < 100_000) return file;
  if (/\.(svg|gif)$/i.test(file.name)) return file;

  return new Promise((resolve) => {
    const img = new Image();
    img.onload = () => {
      const scale = Math.min(1, maxWidth / Math.max(img.width, img.height));
      const w = Math.round(img.width * scale);
      const h = Math.round(img.height * scale);
      const canvas = document.createElement("canvas");
      canvas.width = w;
      canvas.height = h;
      const ctx = canvas.getContext("2d")!;
      ctx.drawImage(img, 0, 0, w, h);
      canvas.toBlob(
        (blob) => {
          URL.revokeObjectURL(img.src);
          resolve(blob || file);
        },
        "image/jpeg",
        quality
      );
    };
    img.onerror = () => {
      URL.revokeObjectURL(img.src);
      resolve(file);
    };
    img.src = URL.createObjectURL(file);
  });
}
