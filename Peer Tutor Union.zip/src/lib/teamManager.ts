/**
 * Team Manager — domain logic for the basketball team management mode.
 * Centralizes constants (rarities, leagues, shop packs, upgrade costs) and
 * helpers for opening card packs, calculating effective player stats, and
 * processing post-match coin rewards.
 */

import { supabase } from "@/integrations/supabase/client";
import type { Tables } from "@/integrations/supabase/types";

export type Rarity = "bronze" | "silver" | "gold" | "epic" | "legendary";
export type League = "bronze" | "silver" | "gold" | "allstar" | "nba";
/** Internal AI strength tiers. `worldchampion` is kept as the peak-difficulty
 *  key (used by World Tour Finals + team-battle setup) but is no longer a
 *  league the player can grind in PTC Star. */
export type AIDifficulty = "easy" | "medium" | "hard" | "allstar" | "nba" | "worldchampion";

export type PlayerTemplate = Tables<"player_templates">;
export type PlayerCard = Tables<"player_cards">;
export type TeamManager = Tables<"team_managers">;
export type MatchHistory = Tables<"match_history">;

/** Effective stats for a card (base + bonus from leveling). */
export interface EffectiveStats {
  speed: number;
  shooting: number;
  three_point: number;
  defense: number;
  dunk: number;
  total: number;
}

export const RARITY_META: Record<Rarity, { label: string; cn: string; color: string; ring: string; bg: string }> = {
  bronze:    { label: "Bronze",    cn: "铜",   color: "text-amber-700", ring: "ring-amber-700/50", bg: "from-amber-900/30 to-amber-700/20" },
  silver:    { label: "Silver",    cn: "银",   color: "text-slate-300", ring: "ring-slate-300/60", bg: "from-slate-500/30 to-slate-300/20" },
  gold:      { label: "Gold",      cn: "金",   color: "text-yellow-400", ring: "ring-yellow-400/70", bg: "from-yellow-700/30 to-yellow-400/20" },
  epic:      { label: "Epic",      cn: "紫",   color: "text-purple-400", ring: "ring-purple-400/70", bg: "from-purple-800/40 to-purple-400/20" },
  legendary: { label: "Legendary", cn: "传奇", color: "text-orange-400", ring: "ring-orange-400/80", bg: "from-orange-700/50 to-orange-400/30" },
};

export const RARITY_ORDER: Rarity[] = ["bronze", "silver", "gold", "epic", "legendary"];

export const LEAGUE_META: Record<League, {
  label: string;
  emoji: string;
  difficulty: AIDifficulty;
  entryFee: number;
  winReward: number;
  lossPenalty: number;
  promotionWins: number;
  next: League | null;
  matchSeconds: number;
}> = {
  bronze:        { label: "Bronze League",       emoji: "🥉", difficulty: "easy",          entryFee: 50,   winReward: 100,   lossPenalty: 25,    promotionWins: 5,   next: "silver",        matchSeconds: 45  },
  silver:        { label: "Silver League",       emoji: "🥈", difficulty: "medium",        entryFee: 150,  winReward: 300,   lossPenalty: 75,    promotionWins: 5,   next: "gold",          matchSeconds: 60  },
  gold:          { label: "Gold League",         emoji: "🥇", difficulty: "hard",          entryFee: 400,  winReward: 800,   lossPenalty: 200,   promotionWins: 5,   next: "allstar",       matchSeconds: 90  },
  allstar:       { label: "All-Star League",     emoji: "🌟", difficulty: "allstar",       entryFee: 1000, winReward: 2000,  lossPenalty: 500,   promotionWins: 5,   next: "nba",           matchSeconds: 120 },
  // NBA Masters is now the top league. Clearing it unlocks the World Tour
  // (entered from TeamHQ via a dedicated CTA) instead of a single-event final.
  nba:           { label: "NBA Masters",         emoji: "👑", difficulty: "nba",           entryFee: 2500, winReward: 5000,  lossPenalty: 1250,  promotionWins: 5,   next: null,            matchSeconds: 180 },
};

export const LEAGUE_ORDER: League[] = ["bronze", "silver", "gold", "allstar", "nba"];

/** Probability table for each pack. Sum of weights = 100. */
export interface PackOdds { bronze: number; silver: number; gold: number; epic: number; legendary: number }

export const SHOP_PACKS: { key: string; name: string; cn: string; emoji: string; cost: number; cards: number; odds: PackOdds; desc: string }[] = [
  { key: "basic",      name: "Basic Pack",     cn: "普通卡包", emoji: "📦", cost: 200,  cards: 1, odds: { bronze: 65, silver: 28, gold: 6,  epic: 1,  legendary: 0  }, desc: "Mostly bronze, some silver/gold" },
  { key: "basic_x3",   name: "Basic ×3",       cn: "普通×3",   emoji: "📦", cost: 500,  cards: 3, odds: { bronze: 65, silver: 28, gold: 6,  epic: 1,  legendary: 0  }, desc: "3 draws · best value" },
  { key: "premium",    name: "Premium",        cn: "高级卡包", emoji: "🎁", cost: 600,  cards: 1, odds: { bronze: 0,  silver: 60, gold: 30, epic: 9,  legendary: 1  }, desc: "Silver guaranteed, chance of gold/epic" },
  { key: "premium_x3", name: "Premium ×3",     cn: "高级×3",   emoji: "🎁", cost: 1500, cards: 3, odds: { bronze: 0,  silver: 60, gold: 30, epic: 9,  legendary: 1  }, desc: "3 draws · best value" },
  { key: "elite",      name: "Elite Pack",     cn: "精英卡包", emoji: "💎", cost: 900,  cards: 1, odds: { bronze: 0,  silver: 25, gold: 50, epic: 20, legendary: 5  }, desc: "Silver floor, lots of gold/epic" },
  { key: "elite_x3",   name: "Elite ×3",       cn: "精英×3",   emoji: "💎", cost: 2500, cards: 3, odds: { bronze: 0,  silver: 25, gold: 50, epic: 20, legendary: 5  }, desc: "3 draws · best value" },
  { key: "legend",     name: "Legend Box",     cn: "传奇宝箱", emoji: "🏆", cost: 20000, cards: 1, odds: { bronze: 0,  silver: 0,  gold: 50, epic: 35, legendary: 15 }, desc: "Gold floor, 15% legendary" },
  { key: "legend_x3",  name: "Legend Box ×3",  cn: "传奇×3",   emoji: "🏆", cost: 50000, cards: 3, odds: { bronze: 0,  silver: 0,  gold: 50, epic: 35, legendary: 15 }, desc: "3 draws · best value" },
];

/** Max card level players can grind to. */
export const MAX_CARD_LEVEL = 100;
/** Hard cap on a single upgrade's coin cost (levels 16-79). */
export const MAX_UPGRADE_COST = 20000;
/** Flat cost per level once a card hits level 80+. */
export const ELITE_UPGRADE_COST = 100000;
/** Level at which the elite (flat 100k) cost kicks in. */
export const ELITE_UPGRADE_LEVEL = 80;
/** One-time cost (in coins) to "Super Evolve" a maxed (Lv.100) card. Adds +10 to ALL stats. */
export const SUPER_EVOLVE_COST = 10_000_000;
/** Stat boost applied to every attribute when a card super-evolves. */
export const SUPER_EVOLVE_BOOST = 10;

/** Upgrade adds +2 to one stat. Cost scales with current level, capped at MAX_UPGRADE_COST,
 *  then jumps to a flat ELITE_UPGRADE_COST at level 80+. */
export function calcUpgradeCost(currentLevel: number): number {
  if (currentLevel >= ELITE_UPGRADE_LEVEL) return ELITE_UPGRADE_COST;
  return Math.min(MAX_UPGRADE_COST, 100 * currentLevel * currentLevel);
  // L1→L2: 100, L5→L6: 2500, L10→L11: 10000, L15→L79: 20000, L80+: 100000
}

// ─── Consumables (in-match boosts) ──────────────────────────────
// Each consumable boosts ALL stats of ALL your players for ONE match.
// You can equip up to 3 different items at once; their boosts stack additively.
// Single-item boost range: ~2-3.33%. Three stacked: ~6-10%.

export const MAX_EQUIPPED_CONSUMABLES = 3;
/** Max number of staff support items equippable in addition to drinks (one of each kind). */
export const MAX_EQUIPPED_STAFF = 3;

export interface ConsumableDef {
  key: string;
  name: string;
  emoji: string;
  /** Cost per unit in coins. */
  cost: number;
  /** Additive multiplier added to ALL stats of YOUR team for one match (e.g. 0.02 = +2%). */
  boost: number;
  desc: string;
  /**
   * "drink" = single-use consumable, consumed after each match (3-slot pool).
   * "staff" = reusable support unit, NOT consumed (separate slot pool, max 1 per kind).
   */
  category?: "drink" | "staff";
}

export const CONSUMABLES: ConsumableDef[] = [
  { key: "water",         name: "Sport Water",     emoji: "💧", cost: 200,  boost: 0.020, desc: "+2.0% all stats · refreshing", category: "drink" },
  { key: "banana",        name: "Banana",          emoji: "🍌", cost: 350,  boost: 0.024, desc: "+2.4% all stats · stamina", category: "drink" },
  { key: "energy_drink",  name: "Energy Drink",    emoji: "🥤", cost: 600,  boost: 0.028, desc: "+2.8% all stats · classic boost", category: "drink" },
  { key: "protein_bar",   name: "Protein Bar",     emoji: "🍫", cost: 900,  boost: 0.031, desc: "+3.1% all stats · fuel up", category: "drink" },
  { key: "elixir",        name: "Champion Elixir", emoji: "✨", cost: 1500, boost: 0.0333, desc: "+3.33% all stats · pro tier", category: "drink" },
  // Staff support — reusable, not consumed after match. Max 1 of each kind equipped.
  { key: "cheer_squad",   name: "Cheer Squad",     emoji: "📣", cost: 5000, boost: 0.05, desc: "+5% all stats · reusable · morale boost", category: "staff" },
  { key: "medical_team",  name: "Medical Team",    emoji: "🚑", cost: 5000, boost: 0.05, desc: "+5% all stats · reusable · keeps players fresh", category: "staff" },
  { key: "ai_analytics",  name: "AI Analytics",    emoji: "🤖", cost: 5000, boost: 0.05, desc: "+5% all stats · reusable · scouts opponent", category: "staff" },
];

export function isStaffItem(key: string): boolean {
  return getConsumableDef(key)?.category === "staff";
}

export function getConsumableDef(key: string): ConsumableDef | undefined {
  return CONSUMABLES.find(c => c.key === key);
}

/** Sum of equipped item boosts → multiplier applied to each stat (e.g. 0.08 = +8%). */
export function computeEquippedBoost(equipped: string[]): number {
  return equipped.reduce((sum, k) => sum + (getConsumableDef(k)?.boost ?? 0), 0);
}

// ─── Coaches (persistent stat boost) ────────────────────────────
// A coach is a one-time hire that gives your team a permanent stat boost
// in EVERY match (stacks with equipped consumables). Hiring a new coach
// replaces the previous one; the prior hire fee is NOT refunded.

export interface CoachDef {
  key: string;
  name: string;
  emoji: string;
  cost: number;
  /** Additive multiplier added to ALL stats of YOUR team for every match. */
  boost: number;
  desc: string;
}

/** Number of matches each coach hire is good for before expiring. */
export const COACH_MATCHES_PER_HIRE = 5;
/** Discount multiplier applied when renewing the SAME coach while contract still active. */
export const COACH_RENEW_DISCOUNT = 0.8;

export const COACHES: CoachDef[] = [
  { key: "rookie",      name: "Rookie Coach",      emoji: "🧢", cost: 5000,   boost: 0.05, desc: "+5% all stats · 5 matches" },
  { key: "college",     name: "College Coach",     emoji: "🎓", cost: 20000,  boost: 0.08, desc: "+8% all stats · 5 matches" },
  { key: "burner",      name: "Burner Coach",      emoji: "🔥", cost: 50000,  boost: 0.30, desc: "+30% all stats · 5 matches · short-term firepower" },
  { key: "pro",         name: "Pro Coach",         emoji: "📋", cost: 60000,  boost: 0.11, desc: "+11% all stats · 5 matches" },
  { key: "championship",name: "Championship Coach",emoji: "🏆", cost: 150000, boost: 0.15, desc: "+15% all stats · 5 matches" },
  { key: "legendary",   name: "Legendary Coach",   emoji: "👑", cost: 300000, boost: 0.20, desc: "+20% all stats · 5 matches" },
];

/**
 * Cost to hire/renew a coach for the given team. If the same coach is already
 * active with ≥1 match left, the renew discount applies. Otherwise full price.
 */
export function getCoachHireCost(team: TeamManager, coachKey: string): number {
  const def = getCoachDef(coachKey);
  if (!def) return 0;
  const isRenew = (team as any).coach_key === coachKey && getCoachMatchesLeft(team) >= 1;
  return isRenew ? Math.round(def.cost * COACH_RENEW_DISCOUNT) : def.cost;
}

export function getCoachDef(key: string | null | undefined): CoachDef | undefined {
  if (!key) return undefined;
  return COACHES.find(c => c.key === key);
}

/** Boost from the team's currently-hired coach (0 if none, or contract expired). */
export function computeCoachBoost(team: TeamManager): number {
  const matchesLeft = ((team as any).coach_matches_left ?? 0) as number;
  if (matchesLeft <= 0) return 0;
  return getCoachDef((team as any).coach_key as string | undefined)?.boost ?? 0;
}

/** Matches remaining on current coach contract. */
export function getCoachMatchesLeft(team: TeamManager): number {
  return ((team as any).coach_matches_left ?? 0) as number;
}

/**
 * Hire (or renew) the team's coach. If renewing the SAME coach with ≥1 match
 * remaining, the cost is discounted (COACH_RENEW_DISCOUNT) and matches-left
 * is RESET to a fresh contract length (renewing early forfeits remaining games
 * but is cheaper). Otherwise full price and replaces previous coach.
 */
export async function hireCoach(team: TeamManager, coachKey: string): Promise<TeamManager> {
  const def = getCoachDef(coachKey);
  if (!def) throw new Error("Unknown coach");
  const cost = getCoachHireCost(team, coachKey);
  if (team.coins < cost) throw new Error("Not enough $");
  const { data, error } = await supabase
    .from("team_managers")
    .update({
      coins: team.coins - cost,
      coach_key: coachKey,
      coach_matches_left: COACH_MATCHES_PER_HIRE,
    } as any)
    .eq("id", team.id)
    .select()
    .single();
  if (error || !data) throw error ?? new Error("Hire failed");
  return data as TeamManager;
}

/** Decrement coach contract by one match. Clears coach_key when contract reaches zero. */
export async function consumeCoachMatch(team: TeamManager): Promise<TeamManager> {
  const left = getCoachMatchesLeft(team);
  if (left <= 0 || !(team as any).coach_key) return team;
  const next = left - 1;
  const { data, error } = await supabase
    .from("team_managers")
    .update({
      coach_matches_left: next,
      coach_key: next <= 0 ? null : (team as any).coach_key,
    } as any)
    .eq("id", team.id)
    .select()
    .single();
  if (error || !data) throw error ?? new Error("Coach update failed");
  return data as TeamManager;
}

// ─── Special bundles ────────────────────────────────────────────
// One-shot bundle purchases that combine consumables + a free pack draw.

export interface SpecialBundleDef {
  key: string;
  name: string;
  emoji: string;
  cost: number;
  desc: string;
  /** Item key + quantity to grant. */
  consumables: { key: string; qty: number }[];
  /** Optional free pack to roll alongside. */
  freePackKey?: string;
}

export const SPECIAL_BUNDLES: SpecialBundleDef[] = [
  {
    key: "wc_energy_box",
    name: "World Champion Energy Box",
    emoji: "🎁",
    cost: 5000,
    desc: "✨ Champion Elixir ×5 + 🎁 1 free Basic Pack draw · LIMITED",
    consumables: [{ key: "elixir", qty: 5 }],
    freePackKey: "basic",
  },
];

export function getBundleDef(key: string): SpecialBundleDef | undefined {
  return SPECIAL_BUNDLES.find(b => b.key === key);
}

/**
 * Buy a special bundle: deducts coins, grants the consumables, and rolls
 * the bundled pack (if any) for free. Returns the updated team plus any
 * cards drawn from the bundled pack so the UI can show the open animation.
 */
export async function buySpecialBundle(
  team: TeamManager,
  bundleKey: string,
): Promise<{ updatedTeam: TeamManager; drawn: DrawResult[] }> {
  const def = getBundleDef(bundleKey);
  if (!def) throw new Error("Unknown bundle");
  if (team.coins < def.cost) throw new Error("Not enough $");

  // Deduct cost first.
  let { data: updatedTeam, error: tErr } = await supabase
    .from("team_managers")
    .update({ coins: team.coins - def.cost })
    .eq("id", team.id)
    .select()
    .single();
  if (tErr || !updatedTeam) throw tErr ?? new Error("Failed to deduct $");
  let workingTeam = updatedTeam as TeamManager;

  // Grant consumables.
  for (const grant of def.consumables) {
    const { data: existing } = await supabase
      .from("consumables" as any)
      .select("*")
      .eq("user_id", workingTeam.user_id)
      .eq("item_key", grant.key)
      .maybeSingle();
    if (existing) {
      await supabase
        .from("consumables" as any)
        .update({ quantity: (existing as any).quantity + grant.qty })
        .eq("id", (existing as any).id);
    } else {
      await supabase
        .from("consumables" as any)
        .insert({ user_id: workingTeam.user_id, item_key: grant.key, quantity: grant.qty });
    }
  }

  // Free pack draw (re-uses openPack but with cost temporarily zeroed via a
  // direct draw — to avoid double-deducting, we inline a no-cost draw).
  let drawn: DrawResult[] = [];
  if (def.freePackKey) {
    const pack = SHOP_PACKS.find(p => p.key === def.freePackKey);
    if (pack) {
      const allTemplates = await loadAllTemplates();
      const owned = await loadOwnedCards(workingTeam.user_id);
      const ownedTemplateIds = new Set(owned.map(o => o.template.id));
      const ownedCardByTemplate = new Map<string, PlayerCard>(owned.map(o => [o.template.id, o.card]));
      const STATS = ["speed", "shooting", "three_point", "defense", "dunk"] as const;

      for (let i = 0; i < pack.cards; i++) {
        const rarity = rollRarity(pack.odds);
        let template = allTemplates.filter(t => t.rarity === rarity).sort(() => Math.random() - 0.5)[0]
          ?? allTemplates[Math.floor(Math.random() * allTemplates.length)];
        if (!template) continue;
        if (ownedTemplateIds.has(template.id)) {
          const existing = ownedCardByTemplate.get(template.id)!;
          const stat = STATS[Math.floor(Math.random() * STATS.length)];
          const bonusField = `bonus_${stat}` as
            | "bonus_speed" | "bonus_shooting" | "bonus_three_point" | "bonus_defense" | "bonus_dunk";
          const newLevel = Math.min(MAX_CARD_LEVEL, existing.level + 1);
          const updates: any = { level: newLevel };
          updates[bonusField] = (existing[bonusField] as number) + 4;
          const { data: updated } = await supabase
            .from("player_cards").update(updates).eq("id", existing.id).select().single();
          if (updated) {
            ownedCardByTemplate.set(template.id, updated as PlayerCard);
            drawn.push({ kind: "upgrade", card: updated as PlayerCard, template, upgradedStat: stat });
          }
        } else {
          const { data: inserted } = await supabase
            .from("player_cards")
            .insert({ user_id: workingTeam.user_id, template_id: template.id })
            .select().single();
          if (inserted) {
            ownedTemplateIds.add(template.id);
            ownedCardByTemplate.set(template.id, inserted as PlayerCard);
            drawn.push({ kind: "new", card: inserted as PlayerCard, template });
          }
        }
      }
    }
  }

  return { updatedTeam: workingTeam, drawn };
}

export type ConsumableInventoryRow = {
  id: string;
  user_id: string;
  item_key: string;
  quantity: number;
};

export async function loadInventory(userId: string): Promise<ConsumableInventoryRow[]> {
  const { data } = await supabase
    .from("consumables" as any)
    .select("*")
    .eq("user_id", userId);
  return ((data ?? []) as unknown) as ConsumableInventoryRow[];
}

/** Buy 1 of the given consumable (deducts coins, increments quantity). */
export async function buyConsumable(team: TeamManager, itemKey: string): Promise<TeamManager> {
  const def = getConsumableDef(itemKey);
  if (!def) throw new Error("Unknown item");
  if (team.coins < def.cost) throw new Error("Not enough $");

  const { data: existing } = await supabase
    .from("consumables" as any)
    .select("*")
    .eq("user_id", team.user_id)
    .eq("item_key", itemKey)
    .maybeSingle();

  if (existing) {
    const { error } = await supabase
      .from("consumables" as any)
      .update({ quantity: (existing as any).quantity + 1 })
      .eq("id", (existing as any).id);
    if (error) throw error;
  } else {
    const { error } = await supabase
      .from("consumables" as any)
      .insert({ user_id: team.user_id, item_key: itemKey, quantity: 1 });
    if (error) throw error;
  }

  const { data: updated, error: tErr } = await supabase
    .from("team_managers")
    .update({ coins: team.coins - def.cost })
    .eq("id", team.id)
    .select()
    .single();
  if (tErr || !updated) throw tErr ?? new Error("Failed to deduct $");
  return updated as TeamManager;
}

/**
 * Save the equipped slot list. Drinks and staff have separate caps:
 *   drinks → MAX_EQUIPPED_CONSUMABLES (3) total slots
 *   staff  → MAX_EQUIPPED_STAFF (3) slots, max 1 of each kind (deduped)
 */
export async function setEquippedConsumables(team: TeamManager, equipped: string[]): Promise<TeamManager> {
  const drinks: string[] = [];
  const staffSeen = new Set<string>();
  const staff: string[] = [];
  for (const k of equipped) {
    if (isStaffItem(k)) {
      if (!staffSeen.has(k) && staff.length < MAX_EQUIPPED_STAFF) {
        staffSeen.add(k);
        staff.push(k);
      }
    } else if (drinks.length < MAX_EQUIPPED_CONSUMABLES) {
      drinks.push(k);
    }
  }
  const trimmed = [...drinks, ...staff];
  const { data, error } = await supabase
    .from("team_managers")
    .update({ equipped_consumables: trimmed } as any)
    .eq("id", team.id)
    .select()
    .single();
  if (error || !data) throw error ?? new Error("Failed to equip");
  return data as TeamManager;
}

/**
 * Consume the currently equipped DRINK items: decrement each item's quantity by 1,
 * remove rows that hit 0, and clear ONLY the drink slots on the team. Staff items
 * stay equipped (they are reusable support).
 * Returns the updated team with staff slots preserved.
 */
export async function consumeEquippedConsumables(team: TeamManager): Promise<TeamManager> {
  const equipped = (team as any).equipped_consumables as string[] | undefined;
  if (!equipped || equipped.length === 0) return team;

  // Split into drinks (consumed) vs staff (preserved).
  const drinks = equipped.filter(k => !isStaffItem(k));
  const staff  = equipped.filter(k =>  isStaffItem(k));

  // Tally how many of each drink we need to consume.
  const counts = new Map<string, number>();
  for (const k of drinks) counts.set(k, (counts.get(k) ?? 0) + 1);

  if (counts.size > 0) {
    const inv = await loadInventory(team.user_id);
    const byKey = new Map(inv.map(r => [r.item_key, r]));

    await Promise.all(
      [...counts.entries()].map(async ([key, used]) => {
        const row = byKey.get(key);
        if (!row) return;
        const newQty = Math.max(0, row.quantity - used);
        if (newQty === 0) {
          await supabase.from("consumables" as any).delete().eq("id", row.id);
        } else {
          await supabase.from("consumables" as any).update({ quantity: newQty }).eq("id", row.id);
        }
      }),
    );
  }

  const { data, error } = await supabase
    .from("team_managers")
    .update({ equipped_consumables: staff } as any)
    .eq("id", team.id)
    .select()
    .single();
  if (error || !data) return team;
  return data as TeamManager;
}

/** Roll a rarity from a pack's odds table. */
export function rollRarity(odds: PackOdds): Rarity {
  const r = Math.random() * 100;
  let cum = 0;
  for (const rarity of RARITY_ORDER) {
    cum += odds[rarity];
    if (r < cum) return rarity;
  }
  return "bronze";
}

/** Compute effective stats from a card + its template. Applies a *gentle* stamina debuff:
 *  ≥40 stamina = full power; below that, stats scale linearly down to 0.8× at 0 stamina.
 *  (Previously: 0.6× floor — too punishing in late-game tournaments.) */
export function getEffectiveStats(card: PlayerCard, template: PlayerTemplate): EffectiveStats {
  const stamina = (card as any).stamina ?? 100;
  // Gentler curve: full power at 40+; only ~20% reduction even at 0 stamina.
  const debuff = stamina >= 40 ? 1 : 0.8 + 0.2 * (stamina / 40); // 1.0 → 0.8 at 0 stamina
  const r = (n: number) => Math.round(n * debuff);
  const speed       = r(template.speed       + card.bonus_speed);
  const shooting    = r(template.shooting    + card.bonus_shooting);
  const three_point = r(template.three_point + card.bonus_three_point);
  const defense     = r(template.defense     + card.bonus_defense);
  const dunk        = r(template.dunk        + card.bonus_dunk);
  return { speed, shooting, three_point, defense, dunk, total: speed + shooting + three_point + defense + dunk };
}

// ─── Stamina / durability ───────────────────────────────────────
// Each player card has a stamina value (0-100). Playing matches drains it;
// idle bench time and the paid "Rest" action restore it. Low stamina
// reduces effective stats (see getEffectiveStats above).

/** Stamina lost per match for each player in the lineup. */
export const STAMINA_DRAIN_PER_MATCH = 18;
/** Below this stamina the player is flagged as "needs rest" — UI warns the user. */
export const STAMINA_REST_THRESHOLD = 25;
/** Legacy flat per-point cost — kept for backward compat where template is unknown.
 *  Prefer `restCostPerPoint(template)` which scales by OVR. */
export const REST_COST_PER_POINT = 50;

/** Cost (coins) to restore +1 stamina for this card — scales with OVR.
 *  Formula: round(OVR × 0.2). Stronger players cost more to recover. */
export function restCostPerPoint(template: PlayerTemplate): number {
  const ovr = (template.speed ?? 0) + (template.shooting ?? 0) + (template.three_point ?? 0)
            + (template.defense ?? 0) + (template.dunk ?? 0);
  return Math.max(1, Math.round(ovr * 0.2));
}

export function getStamina(card: PlayerCard): number {
  return Math.max(0, Math.min(100, ((card as any).stamina ?? 100) as number));
}

export function needsRest(card: PlayerCard): boolean {
  return getStamina(card) < STAMINA_REST_THRESHOLD;
}

/** Drain stamina for the cards that just played a match. */
export async function drainLineupStamina(cardIds: string[]): Promise<void> {
  if (cardIds.length === 0) return;
  await supabase.rpc("drain_lineup_stamina" as any, {
    _card_ids: cardIds,
    _amount: STAMINA_DRAIN_PER_MATCH,
  });
}

/** Drain another team's starting-lineup stamina (e.g. after winning a
 *  leaderboard challenge). Server-side RPC enforces auth + cap. */
export async function drainOpponentLineupStamina(targetUserId: string, amount: number): Promise<void> {
  if (!targetUserId || amount <= 0) return;
  await supabase.rpc("drain_opponent_lineup_stamina" as any, {
    _target_user_id: targetUserId,
    _amount: amount,
  });
}

/** Restore one card's stamina by `points`. Cost = points × restCostPerPoint(template).
 *  Returns the updated team and the new stamina value. */
export async function restCard(
  team: TeamManager,
  card: PlayerCard,
  template: PlayerTemplate,
  points: number,
): Promise<{ team: TeamManager; newStamina: number }> {
  const perPoint = restCostPerPoint(template);
  const cost = points * perPoint;
  if (team.coins < cost) throw new Error("Not enough $");
  const { data: newStamina, error: rpcErr } = await supabase.rpc(
    "restore_card_stamina" as any,
    { _card_id: card.id, _amount: points },
  );
  if (rpcErr) throw rpcErr;
  const { data: updated, error: tErr } = await supabase
    .from("team_managers")
    .update({ coins: team.coins - cost })
    .eq("id", team.id).select().single();
  if (tErr || !updated) throw tErr ?? new Error("Failed to deduct $");
  return { team: updated as TeamManager, newStamina: (newStamina as number) ?? getStamina(card) + points };
}

/** Trigger passive idle recovery server-side (call on team load). Bench players
 *  recover 1 stamina per 30s; lineup players do not recover passively. */
export async function recoverIdleStamina(lineupIds: string[]): Promise<void> {
  await supabase.rpc("recover_idle_stamina" as any, { _lineup_ids: lineupIds });
}

/** Cost to fully refill the given (card, template) pairs back to 100 stamina. */
export function lineupRestCost(entries: { card: PlayerCard; template: PlayerTemplate }[]): number {
  return entries.reduce((sum, { card, template }) =>
    sum + (100 - getStamina(card)) * restCostPerPoint(template), 0);
}

/** Spend coins to refill EVERY card in `cards` back to 100 stamina.
 *  Throws if the team can't afford the full bill. Returns the updated team
 *  and a map of card-id → new stamina. */
export async function restLineup(
  team: TeamManager,
  entries: { card: PlayerCard; template: PlayerTemplate }[],
): Promise<{ team: TeamManager; newStamina: Record<string, number> }> {
  const cost = lineupRestCost(entries);
  if (cost <= 0) return { team, newStamina: {} };
  if (team.coins < cost) throw new Error("Not enough $");
  const newStamina: Record<string, number> = {};
  for (const { card } of entries) {
    const missing = 100 - getStamina(card);
    if (missing <= 0) { newStamina[card.id] = 100; continue; }
    const { data, error } = await supabase.rpc(
      "restore_card_stamina" as any,
      { _card_id: card.id, _amount: missing },
    );
    if (error) throw error;
    newStamina[card.id] = (data as number) ?? 100;
  }
  const { data: updated, error: tErr } = await supabase
    .from("team_managers")
    .update({ coins: team.coins - cost })
    .eq("id", team.id).select().single();
  if (tErr || !updated) throw tErr ?? new Error("Failed to deduct $");
  return { team: updated as TeamManager, newStamina };
}

/**
 * How many times this card has been Super-Evolved. Each evolve adds
 * SUPER_EVOLVE_BOOST to ALL five bonus stats; normal upgrades only ever add
 * to one stat at a time, so the minimum bonus across all five stats divided
 * by SUPER_EVOLVE_BOOST is a reliable evolution counter.
 */
export function getEvolutionTier(card: PlayerCard): number {
  const minBonus = Math.min(
    card.bonus_speed, card.bonus_shooting, card.bonus_three_point,
    card.bonus_defense, card.bonus_dunk,
  );
  return Math.floor(minBonus / SUPER_EVOLVE_BOOST);
}

/** True if the card has been Super-Evolved at least once. */
export function isEvolved(card: PlayerCard): boolean {
  return getEvolutionTier(card) >= 1;
}

/** Map league → AI difficulty for matchmaking. */
export function leagueToAIDifficulty(league: League): AIDifficulty {
  return LEAGUE_META[league].difficulty;
}

// ─── Server actions ─────────────────────────────────────────────

/** Load (and lazily initialize) the user's team. Returns null if unauthenticated. */
export async function loadOrInitTeam(): Promise<TeamManager | null> {
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) return null;

  let { data: team } = await supabase.from("team_managers").select("*").eq("user_id", user.id).maybeSingle();
  if (!team) {
    await supabase.rpc("initialize_team_for_user", { _user_id: user.id });
    const r = await supabase.from("team_managers").select("*").eq("user_id", user.id).maybeSingle();
    team = r.data;
  }
  return team;
}

/** Load all owned cards joined with their templates. */
export async function loadOwnedCards(userId: string): Promise<{ card: PlayerCard; template: PlayerTemplate }[]> {
  const { data } = await supabase
    .from("player_cards")
    .select("*, template:player_templates(*)")
    .eq("user_id", userId)
    .order("acquired_at", { ascending: false });
  return (data ?? []).map((row: any) => ({ card: row, template: row.template as PlayerTemplate }));
}

export async function loadAllTemplates(): Promise<PlayerTemplate[]> {
  const { data } = await supabase.from("player_templates").select("*").order("rarity").order("name");
  return data ?? [];
}

/** Custom avatar overrides keyed by template name (for hand-drawn portraits). */
import sandelaWuAvatar     from "@/assets/sandela-wu.png";
import mrPrincipleAvatar   from "@/assets/avatars/mr-principle.jpg";
import generalAvatar       from "@/assets/avatars/general.jpg";
import jeffreySupermanAvatar from "@/assets/avatars/jeffrey-superman.jpg";
import thomasWuAvatar      from "@/assets/avatars/thomas-wu.jpg";
const CUSTOM_AVATARS: Record<string, string> = {
  "Sandela Wu":       sandelaWuAvatar,
  "Mr. Principle":    mrPrincipleAvatar,
  "将军":             generalAvatar,
  "Jeffrey Superman": jeffreySupermanAvatar,
  "Thomas Wu":        thomasWuAvatar,
};

/** DiceBear personas-style avatar fallback (deterministic by name). */
export function getPlayerAvatarUrl(template: PlayerTemplate): string {
  if (CUSTOM_AVATARS[template.name]) return CUSTOM_AVATARS[template.name];
  if (template.avatar_url) return template.avatar_url;
  const seed = encodeURIComponent(template.name);
  return `https://api.dicebear.com/9.x/personas/svg?seed=${seed}&backgroundColor=transparent`;
}

/**
 * Per-name keep-chance for "ultra-rare" templates. After a normal weighted
 * pick, if one of these is selected, we keep it with the listed probability
 * and otherwise re-roll from a pool that excludes ultra-rares.
 */
const ULTRA_RARE_KEEP_CHANCE: Record<string, number> = {
  "Sandela Wu":       0.01,  // 1%
  "Mr. Principle":    0.05,  // 5%
  "将军":             0.01,  // 1%
  "Jeffrey Superman": 0.005, // 0.5%
};
const ULTRA_RARE_NAMES = new Set<string>(Object.keys(ULTRA_RARE_KEEP_CHANCE));

/**
 * Apply ultra-rare guard: if `picked` is in {@link ULTRA_RARE_NAMES}, keep
 * it with its per-name probability; otherwise return `fallback()` which
 * should pick from a pool that excludes the ultra-rare templates.
 */
function applyUltraRareGuard(
  picked: PlayerTemplate | null,
  fallback: () => PlayerTemplate | null,
): PlayerTemplate | null {
  if (!picked) return picked;
  if (!ULTRA_RARE_NAMES.has(picked.name)) return picked;
  const keep = ULTRA_RARE_KEEP_CHANCE[picked.name] ?? 0.01;
  if (Math.random() < keep) return picked;
  return fallback() ?? picked;
}

/**
 * Simulate an AI-vs-AI matchup using only player stat totals (no live game).
 * Returns realistic-looking final scores for a friend challenge.
 */
export function simulateAIMatch(
  teamAStats: { total: number }[],
  teamBStats: { total: number }[],
): { aScore: number; bScore: number } {
  const totalA = teamAStats.reduce((s, p) => s + p.total, 0) / Math.max(1, teamAStats.length);
  const totalB = teamBStats.reduce((s, p) => s + p.total, 0) / Math.max(1, teamBStats.length);
  const ratio = totalA / (totalA + totalB);
  // Base 30-50 points per side, weighted by ratio + jitter
  const base = 30 + Math.random() * 20;
  const aScore = Math.round(base * (0.7 + ratio * 0.6) + Math.random() * 10);
  const bScore = Math.round(base * (0.7 + (1 - ratio) * 0.6) + Math.random() * 10);
  // Avoid ties
  if (aScore === bScore) return { aScore: aScore + 1, bScore };
  return { aScore, bScore };
}

/**
 * Settle a friend challenge. Payout is asymmetric by OVR gap so beating
 * a stronger team is more lucrative and losing to a weaker team hurts more:
 *   - winning vs higher OVR → 1.0..2.0× bet
 *   - winning vs lower OVR  → 0.3..1.0× bet
 *   - losing  to higher OVR → 0.5..1.0× bet
 *   - losing  to lower OVR  → 1.0..2.0× bet
 * `ovrGap` = myOVR - oppOVR (positive = I'm stronger).
 *
 * Coins are *transferred* between the two players: the winner gains exactly
 * what the loser pays (capped at the loser's current balance — no negatives).
 */
export async function applyFriendChallenge(
  team: TeamManager,
  outcome: { won: boolean; bet: number; ovrGap?: number; opponentUserId: string },
): Promise<TeamManager> {
  const gap = outcome.ovrGap ?? 0;
  // Normalize gap to [-1, +1] over a 200-OVR spread (3 players × ~67 each)
  const norm = Math.max(-1, Math.min(1, gap / 200));
  // Multiplier: +1 boost when fighting up, -0.7 cut when stomping down.
  let mult = 1;
  if (outcome.won) {
    mult = norm <= 0 ? 1 + Math.min(1, -norm * 1.0) : Math.max(0.3, 1 - norm * 0.7);
  } else {
    mult = norm >= 0 ? 1 + Math.min(1, norm * 1.0) : Math.max(0.5, 1 + norm * 0.5);
  }
  const delta = Math.round(outcome.bet * mult);

  // Atomic two-sided transfer via SECURITY DEFINER RPC (bypasses RLS safely).
  const { error: rpcErr } = await supabase.rpc("settle_friend_challenge" as never, {
    _opponent_id: outcome.opponentUserId,
    _amount: delta,
    _challenger_won: outcome.won,
  } as never);
  if (rpcErr) throw rpcErr;

  // Re-fetch our team for the fresh coin balance to return to the caller.
  const { data, error } = await supabase
    .from("team_managers")
    .select()
    .eq("id", team.id)
    .single();
  if (error || !data) throw error ?? new Error("Settlement failed");
  return data as TeamManager;
}

/** Result of one slot in a pack: a brand-new card, or an upgrade applied to an owned duplicate. */
export type DrawResult =
  | { kind: "new"; card: PlayerCard; template: PlayerTemplate }
  | { kind: "upgrade"; card: PlayerCard; template: PlayerTemplate; upgradedStat: "speed" | "shooting" | "three_point" | "defense" | "dunk" }
  | { kind: "duplicate_max"; card: PlayerCard; template: PlayerTemplate };

/** Open a pack: deduct coins, draw N cards. Owned templates auto-upgrade instead of duplicating. */
export async function openPack(
  team: TeamManager,
  packKey: string,
): Promise<{ updatedTeam: TeamManager; drawn: DrawResult[] }> {
  const pack = SHOP_PACKS.find(p => p.key === packKey);
  if (!pack) throw new Error("Unknown pack");
  if (team.coins < pack.cost) throw new Error("Not enough coins");

  const allTemplates = await loadAllTemplates();
  const owned = await loadOwnedCards(team.user_id);
  const ownedTemplateIds = new Set(owned.map(o => o.template.id));
  const ownedCardByTemplate = new Map<string, PlayerCard>(owned.map(o => [o.template.id, o.card]));

  // Per-template weight overrides (default = 1). Higher = more likely within its rarity pool.
  const TEMPLATE_WEIGHTS: Record<string, number> = {
    "Jeffrey Flying": 5,
  };
  const STATS = ["speed", "shooting", "three_point", "defense", "dunk"] as const;

  /** Weighted pick from a pool, preferring unowned templates. */
  function pickFromPool(pool: PlayerTemplate[]): PlayerTemplate | null {
    if (pool.length === 0) return null;
    const unowned = pool.filter(t => !ownedTemplateIds.has(t.id));
    const candidates = unowned.length > 0 ? unowned : pool;
    const weights = candidates.map(t => TEMPLATE_WEIGHTS[t.name] ?? 1);
    const totalW = weights.reduce((s, w) => s + w, 0);
    let roll = Math.random() * totalW;
    for (let j = 0; j < candidates.length; j++) {
      roll -= weights[j];
      if (roll <= 0) return candidates[j];
    }
    return candidates[candidates.length - 1];
  }

  const drawn: DrawResult[] = [];

  for (let i = 0; i < pack.cards; i++) {
    const rarity = rollRarity(pack.odds);
    const rarityPool = allTemplates.filter(t => t.rarity === rarity);
    let template = pickFromPool(rarityPool);
    template = applyUltraRareGuard(template, () =>
      pickFromPool(rarityPool.filter(t => !ULTRA_RARE_NAMES.has(t.name))),
    );
    if (!template) template = pickFromPool(allTemplates);
    if (!template) continue;

    if (ownedTemplateIds.has(template.id)) {
      // Duplicate → upgrade a random stat on the existing card
      const existing = ownedCardByTemplate.get(template.id)!;
      if (existing.level >= MAX_CARD_LEVEL) {
        drawn.push({ kind: "duplicate_max", card: existing, template });
        continue;
      }
      const stat = STATS[Math.floor(Math.random() * STATS.length)];
      const bonusField = `bonus_${stat}` as
        | "bonus_speed" | "bonus_shooting" | "bonus_three_point" | "bonus_defense" | "bonus_dunk";
      const newLevel = Math.min(MAX_CARD_LEVEL, existing.level + 1);
      const updates: any = { level: newLevel };
      updates[bonusField] = (existing[bonusField] as number) + 4;
      const { data: updated, error } = await supabase
        .from("player_cards")
        .update(updates)
        .eq("id", existing.id)
        .select()
        .single();
      if (error || !updated) throw error ?? new Error("Auto-upgrade failed");
      ownedCardByTemplate.set(template.id, updated as PlayerCard);
      drawn.push({ kind: "upgrade", card: updated as PlayerCard, template, upgradedStat: stat });
    } else {
      const { data: inserted, error } = await supabase
        .from("player_cards")
        .insert({ user_id: team.user_id, template_id: template.id })
        .select()
        .single();
      if (error || !inserted) throw error ?? new Error("Card insert failed");
      ownedTemplateIds.add(template.id);
      ownedCardByTemplate.set(template.id, inserted as PlayerCard);
      drawn.push({ kind: "new", card: inserted as PlayerCard, template });
    }
  }

  // Deduct coins
  const newCoins = team.coins - pack.cost;
  const { data: updatedTeam, error: updErr } = await supabase
    .from("team_managers")
    .update({ coins: newCoins })
    .eq("id", team.id)
    .select()
    .single();
  if (updErr || !updatedTeam) throw updErr ?? new Error("Failed to deduct coins");

  return { updatedTeam: updatedTeam as TeamManager, drawn };
}

/** Promotion reward mapping: cleared league → free pack contents granted on promotion. */
export const PROMOTION_REWARDS: Record<League, { count: number; odds: PackOdds; label: string; emoji: string } | null> = {
  bronze:        { count: 2, odds: { bronze: 0, silver: 60, gold: 30, epic: 9,  legendary: 1  }, label: "2× Premium",   emoji: "🎁" },
  silver:        { count: 2, odds: { bronze: 0, silver: 60, gold: 30, epic: 9,  legendary: 1  }, label: "2× Premium",   emoji: "🎁" },
  gold:          { count: 2, odds: { bronze: 0, silver: 0,  gold: 50, epic: 35, legendary: 15 }, label: "2× Legend Box", emoji: "🏆" },
  allstar:       { count: 4, odds: { bronze: 0, silver: 0,  gold: 50, epic: 35, legendary: 15 }, label: "4× Legend Box", emoji: "🏆" },
  nba:           { count: 6, odds: { bronze: 0, silver: 0,  gold: 50, epic: 35, legendary: 15 }, label: "6× Legend Box", emoji: "🏆" },
};

/**
 * Grant a free promotion-reward pack: draws `count` cards by `odds` and writes them
 * (or auto-upgrades duplicates), without deducting any coins. Returns the new draws.
 */
export async function grantPromotionReward(
  team: TeamManager,
  clearedLeague: League,
): Promise<DrawResult[]> {
  const reward = PROMOTION_REWARDS[clearedLeague];
  if (!reward) return [];

  const allTemplates = await loadAllTemplates();
  const owned = await loadOwnedCards(team.user_id);
  const ownedTemplateIds = new Set(owned.map(o => o.template.id));
  const ownedCardByTemplate = new Map<string, PlayerCard>(owned.map(o => [o.template.id, o.card]));

  const TEMPLATE_WEIGHTS: Record<string, number> = { "Jeffrey Flying": 5 };
  const STATS = ["speed", "shooting", "three_point", "defense", "dunk"] as const;

  function pickFromPool(pool: PlayerTemplate[]): PlayerTemplate | null {
    if (pool.length === 0) return null;
    const unowned = pool.filter(t => !ownedTemplateIds.has(t.id));
    const candidates = unowned.length > 0 ? unowned : pool;
    const weights = candidates.map(t => TEMPLATE_WEIGHTS[t.name] ?? 1);
    const totalW = weights.reduce((s, w) => s + w, 0);
    let roll = Math.random() * totalW;
    for (let j = 0; j < candidates.length; j++) {
      roll -= weights[j];
      if (roll <= 0) return candidates[j];
    }
    return candidates[candidates.length - 1];
  }

  const drawn: DrawResult[] = [];
  for (let i = 0; i < reward.count; i++) {
    const rarity = rollRarity(reward.odds);
    const rarityPool = allTemplates.filter(t => t.rarity === rarity);
    let template = pickFromPool(rarityPool);
    template = applyUltraRareGuard(template, () =>
      pickFromPool(rarityPool.filter(t => !ULTRA_RARE_NAMES.has(t.name))),
    );
    if (!template) template = pickFromPool(allTemplates);
    if (!template) continue;

    if (ownedTemplateIds.has(template.id)) {
      const existing = ownedCardByTemplate.get(template.id)!;
      if (existing.level >= MAX_CARD_LEVEL) {
        drawn.push({ kind: "duplicate_max", card: existing, template });
        continue;
      }
      const stat = STATS[Math.floor(Math.random() * STATS.length)];
      const bonusField = `bonus_${stat}` as
        | "bonus_speed" | "bonus_shooting" | "bonus_three_point" | "bonus_defense" | "bonus_dunk";
      const newLevel = Math.min(MAX_CARD_LEVEL, existing.level + 1);
      const updates: any = { level: newLevel };
      updates[bonusField] = (existing[bonusField] as number) + 4;
      const { data: updated, error } = await supabase
        .from("player_cards")
        .update(updates)
        .eq("id", existing.id)
        .select()
        .single();
      if (error || !updated) throw error ?? new Error("Auto-upgrade failed");
      ownedCardByTemplate.set(template.id, updated as PlayerCard);
      drawn.push({ kind: "upgrade", card: updated as PlayerCard, template, upgradedStat: stat });
    } else {
      const { data: inserted, error } = await supabase
        .from("player_cards")
        .insert({ user_id: team.user_id, template_id: template.id })
        .select()
        .single();
      if (error || !inserted) throw error ?? new Error("Card insert failed");
      ownedTemplateIds.add(template.id);
      ownedCardByTemplate.set(template.id, inserted as PlayerCard);
      drawn.push({ kind: "new", card: inserted as PlayerCard, template });
    }
  }
  return drawn;
}

/** Apply +4 to one stat on a card. Deducts coin cost. */
export async function upgradeCard(
  team: TeamManager,
  card: PlayerCard,
  stat: "speed" | "shooting" | "three_point" | "defense" | "dunk",
): Promise<{ updatedTeam: TeamManager; updatedCard: PlayerCard }> {
  const cost = calcUpgradeCost(card.level);
  if (team.coins < cost) throw new Error("Not enough $");
  if (card.level >= MAX_CARD_LEVEL) throw new Error("Max level reached");

  const bonusField = `bonus_${stat}` as
    | "bonus_speed" | "bonus_shooting" | "bonus_three_point" | "bonus_defense" | "bonus_dunk";

  const updates: any = { level: card.level + 1 };
  updates[bonusField] = (card[bonusField] as number) + 4;

  const { data: updatedCard, error: cardErr } = await supabase
    .from("player_cards")
    .update(updates)
    .eq("id", card.id)
    .select()
    .single();
  if (cardErr || !updatedCard) throw cardErr ?? new Error("Upgrade failed");

  const { data: updatedTeam, error: teamErr } = await supabase
    .from("team_managers")
    .update({ coins: team.coins - cost })
    .eq("id", team.id)
    .select()
    .single();
  if (teamErr || !updatedTeam) throw teamErr ?? new Error("Failed to deduct $");

  return { updatedTeam: updatedTeam as TeamManager, updatedCard: updatedCard as PlayerCard };
}

/**
 * Super-Evolve a Lv.100 card: deducts SUPER_EVOLVE_COST coins and adds
 * SUPER_EVOLVE_BOOST to ALL five bonus stats. There is no level change —
 * a card can be super-evolved repeatedly as long as the manager can afford
 * the cost. Throws if the card isn't maxed or funds are insufficient.
 */
export async function superEvolveCard(
  team: TeamManager,
  card: PlayerCard,
): Promise<{ updatedTeam: TeamManager; updatedCard: PlayerCard }> {
  if (card.level < MAX_CARD_LEVEL) throw new Error("Reach Lv.100 first");
  if (team.coins < SUPER_EVOLVE_COST) throw new Error("Not enough $");

  const updates: any = {
    bonus_speed:       (card.bonus_speed       as number) + SUPER_EVOLVE_BOOST,
    bonus_shooting:    (card.bonus_shooting    as number) + SUPER_EVOLVE_BOOST,
    bonus_three_point: (card.bonus_three_point as number) + SUPER_EVOLVE_BOOST,
    bonus_defense:     (card.bonus_defense     as number) + SUPER_EVOLVE_BOOST,
    bonus_dunk:        (card.bonus_dunk        as number) + SUPER_EVOLVE_BOOST,
  };

  const { data: updatedCard, error: cardErr } = await supabase
    .from("player_cards")
    .update(updates)
    .eq("id", card.id)
    .select()
    .single();
  if (cardErr || !updatedCard) throw cardErr ?? new Error("Evolve failed");

  const { data: updatedTeam, error: teamErr } = await supabase
    .from("team_managers")
    .update({ coins: team.coins - SUPER_EVOLVE_COST })
    .eq("id", team.id)
    .select()
    .single();
  if (teamErr || !updatedTeam) throw teamErr ?? new Error("Failed to deduct $");

  return { updatedTeam: updatedTeam as TeamManager, updatedCard: updatedCard as PlayerCard };
}

export async function setStartingLineup(team: TeamManager, cardIds: string[]): Promise<TeamManager> {
  const { data, error } = await supabase
    .from("team_managers")
    .update({ starting_lineup: cardIds })
    .eq("id", team.id)
    .select()
    .single();
  if (error || !data) throw error ?? new Error("Update failed");
  return data as TeamManager;
}

export async function updateTeamMeta(team: TeamManager, patch: Partial<Pick<TeamManager, "team_name" | "team_emoji" | "team_logo_url" | "jersey_primary" | "jersey_secondary" | "jersey_style">>): Promise<TeamManager> {
  const { data, error } = await supabase
    .from("team_managers")
    .update(patch)
    .eq("id", team.id)
    .select()
    .single();
  if (error || !data) throw error ?? new Error("Update failed");
  return data as TeamManager;
}

export interface MatchOutcome {
  league: League;
  won: boolean;
  playerScore: number;
  aiScore: number;
}

/** Apply post-match: deduct entry fee, award/deduct prize, update wins, possibly promote. */
export async function applyMatchResult(team: TeamManager, outcome: MatchOutcome): Promise<{
  updatedTeam: TeamManager;
  coinsChange: number;
  promoted: boolean;
  /** True if this win earned a new "World Champion" title. */
  wcTitleEarned: boolean;
}> {
  // The server recomputes fees, rewards, promotion and records the match,
  // so the client cannot fabricate a payout.
  const { data, error } = await supabase.rpc("settle_league_match" as any, {
    _league: outcome.league,
    _player_score: outcome.playerScore,
    _ai_score: outcome.aiScore,
    _won: outcome.won,
  });
  if (error) throw new Error(error.message);
  const res = data as any;
  return {
    updatedTeam: res.team as TeamManager,
    coinsChange: Number(res.coins_change ?? 0),
    promoted: !!res.promoted,
    wcTitleEarned: false,
  };
}


// ─── Player Marketplace ────────────────────────────────────────
// Two paths to get rid of an unwanted player card:
//   1) Quick-sell: instant cash from the system, card deleted.
//   2) List on marketplace: any other team can buy with their coins. NOT cancellable.

/** Coin payout for instantly recycling a card. Scales with rarity + level. */
export function getQuickSellPrice(card: PlayerCard, template: PlayerTemplate): number {
  const rarityBase: Record<string, number> = {
    bronze: 50, silver: 200, gold: 600, epic: 1500, legendary: 5000,
  };
  const base = rarityBase[template.rarity] ?? 50;
  // Each upgrade level adds ~15% on top of the base, capped at 4× base.
  const levelMul = 1 + Math.min(3, (card.level - 1) * 0.15);
  return Math.round(base * levelMul);
}

/**
 * Quick-sell a card: instant coins, card removed from collection and any
 * lineup slot it was in. Refuses if the card is currently listed.
 */
export async function quickSellCard(
  team: TeamManager,
  card: PlayerCard,
  template: PlayerTemplate,
): Promise<TeamManager> {
  const { data: existingListing } = await supabase
    .from("player_listings" as any)
    .select("id")
    .eq("card_id", card.id)
    .eq("status", "active")
    .maybeSingle();
  if (existingListing) throw new Error("Card is already listed on the marketplace");

  const payout = getQuickSellPrice(card, template);
  const newLineup = (team.starting_lineup ?? []).filter(id => id !== card.id);

  const { error: delErr } = await supabase.from("player_cards").delete().eq("id", card.id);
  if (delErr) throw delErr;

  const { data: updated, error: tErr } = await supabase
    .from("team_managers")
    .update({ coins: team.coins + payout, starting_lineup: newLineup })
    .eq("id", team.id)
    .select()
    .single();
  if (tErr || !updated) throw tErr ?? new Error("Quick-sell failed");
  return updated as TeamManager;
}

/** Post a card to the marketplace at a fixed price. Once listed, it cannot be cancelled. */
export async function listCardForSale(card: PlayerCard, price: number): Promise<void> {
  if (price < 1 || price > 10_000_000 || !Number.isFinite(price)) {
    throw new Error("Price must be between $1 and $10,000,000");
  }
  // Refuse if already listed.
  const { data: existing } = await supabase
    .from("player_listings" as any)
    .select("id")
    .eq("card_id", card.id)
    .eq("status", "active")
    .maybeSingle();
  if (existing) throw new Error("Card is already listed");

  const { error } = await supabase
    .from("player_listings" as any)
    .insert({ seller_id: card.user_id, card_id: card.id, price: Math.round(price) });
  if (error) throw error;
}

export interface MarketplaceListing {
  id: string;
  seller_id: string;
  card_id: string;
  price: number;
  created_at: string;
  card: PlayerCard;
  template: PlayerTemplate;
  seller: { name: string; avatar_url: string | null; team_name: string; team_emoji: string } | null;
}

/** All currently-active listings, joined with card + template + seller team info. */
export async function loadActiveListings(): Promise<MarketplaceListing[]> {
  const { data: listings } = await supabase
    .from("player_listings" as any)
    .select("id, seller_id, card_id, price, created_at, card:player_cards(*, template:player_templates(*))")
    .eq("status", "active")
    .order("created_at", { ascending: false })
    .limit(200);
  if (!listings) return [];
  const sellerIds = Array.from(new Set((listings as any[]).map(r => r.seller_id)));
  const [profilesRes, teamsRes] = await Promise.all([
    supabase.from("profiles").select("user_id, name, avatar_url").in("user_id", sellerIds),
    supabase.from("team_managers").select("user_id, team_name, team_emoji").in("user_id", sellerIds),
  ]);
  const profileMap = new Map((profilesRes.data ?? []).map(p => [p.user_id, p]));
  const teamMap = new Map((teamsRes.data ?? []).map(t => [t.user_id, t]));
  return (listings as any[]).map(r => ({
    id: r.id,
    seller_id: r.seller_id,
    card_id: r.card_id,
    price: r.price,
    created_at: r.created_at,
    card: r.card as PlayerCard,
    template: r.card.template as PlayerTemplate,
    seller: profileMap.has(r.seller_id) || teamMap.has(r.seller_id) ? {
      name: profileMap.get(r.seller_id)?.name ?? "Unknown",
      avatar_url: profileMap.get(r.seller_id)?.avatar_url ?? null,
      team_name: teamMap.get(r.seller_id)?.team_name ?? "—",
      team_emoji: teamMap.get(r.seller_id)?.team_emoji ?? "🏀",
    } : null,
  }));
}

/** Buy a listing. Atomic via the buy_player_listing RPC. */
export async function buyListing(listingId: string): Promise<void> {
  const { error } = await supabase.rpc("buy_player_listing" as any, { _listing_id: listingId });
  if (error) throw error;
}

/** Active listings that the given user has posted (so they can see what they have for sale). */
export async function loadMyListings(userId: string): Promise<MarketplaceListing[]> {
  const { data } = await supabase
    .from("player_listings" as any)
    .select("id, seller_id, card_id, price, created_at, card:player_cards(*, template:player_templates(*))")
    .eq("seller_id", userId)
    .eq("status", "active")
    .order("created_at", { ascending: false });
  return (data ?? []).map((r: any) => ({
    id: r.id,
    seller_id: r.seller_id,
    card_id: r.card_id,
    price: r.price,
    created_at: r.created_at,
    card: r.card as PlayerCard,
    template: r.card.template as PlayerTemplate,
    seller: null,
  }));
}

export async function loadMatchHistory(userId: string, limit = 20): Promise<MatchHistory[]> {
  const { data } = await supabase
    .from("match_history")
    .select("*")
    .eq("user_id", userId)
    .order("created_at", { ascending: false })
    .limit(limit);
  return data ?? [];
}

// ─── Per-card career stats ──────────────────────────────────────

export type PlayerCardStats = Tables<"player_card_stats">;

export async function loadCardStats(cardId: string): Promise<PlayerCardStats | null> {
  const { data } = await supabase
    .from("player_card_stats")
    .select("*")
    .eq("card_id", cardId)
    .maybeSingle();
  return data ?? null;
}

/**
 * Distribute a team's total points across the cards in its lineup,
 * weighted by offensive stats (shooting + three_point + dunk).
 * Picks the top scorer on the winning side as MVP.
 * Writes one row per card via the `record_match_contribution` RPC.
 */
export async function recordLineupContributions(
  userId: string,
  lineup: { card: PlayerCard; template: PlayerTemplate }[],
  teamScore: number,
  won: boolean,
): Promise<void> {
  if (lineup.length === 0) return;
  const offensiveWeight = (s: EffectiveStats) => s.shooting + s.three_point + s.dunk;
  const stats = lineup.map(({ card, template }) => ({
    cardId: card.id,
    weight: offensiveWeight(getEffectiveStats(card, template)),
  }));
  const totalW = stats.reduce((s, p) => s + p.weight, 0) || 1;

  const points = stats.map(s => Math.round((s.weight / totalW) * teamScore));
  const drift = teamScore - points.reduce((a, b) => a + b, 0);
  if (drift !== 0 && points.length > 0) {
    const topIdx = points.indexOf(Math.max(...points));
    points[topIdx] += drift;
  }
  const mvpIdx = won ? points.indexOf(Math.max(...points)) : -1;

  await Promise.all(
    stats.map((s, i) =>
      supabase.rpc("record_match_contribution", {
        _user_id: userId,
        _card_id: s.cardId,
        _points: Math.max(0, points[i]),
        _won: won,
        _is_mvp: i === mvpIdx,
      }),
    ),
  );
}
