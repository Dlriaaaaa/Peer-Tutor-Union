import React from "react";
import { Link } from "react-router-dom";

/**
 * Extract hashtags from plain text or HTML content.
 * Returns unique lowercase tags without the # symbol.
 */
export function extractHashtags(html: string): string[] {
  // Strip HTML tags to get plain text
  const text = html.replace(/<[^>]*>/g, " ");
  const matches = text.match(/#([\w\u4e00-\u9fff]+)/g);
  if (!matches) return [];
  return [...new Set(matches.map((m) => m.slice(1).toLowerCase()))];
}

/**
 * Extract @mentions from plain text or HTML content.
 * Returns unique names (without @).
 */
export function extractMentions(html: string): string[] {
  const text = html.replace(/<[^>]*>/g, " ");
  const matches = text.match(/@([\w\u4e00-\u9fff]+)/g);
  if (!matches) return [];
  return [...new Set(matches.map((m) => m.slice(1)))];
}

type ProfileLookup = Record<string, { name: string; user_id?: string }>;

/**
 * Renders HTML content with clickable #hashtags and @mentions.
 * Hashtags link to /tags/:tag, mentions link to /profile/:userId.
 */
export function RichContentRenderer({
  html,
  profiles,
  className = "",
}: {
  html: string;
  profiles?: ProfileLookup;
  className?: string;
}) {
  // Build a name->userId map from profiles
  const nameToUserId: Record<string, string> = {};
  if (profiles) {
    Object.entries(profiles).forEach(([userId, p]) => {
      if (p.name) {
        nameToUserId[p.name.toLowerCase()] = userId;
      }
    });
  }

  // Process the HTML: replace #tags and @mentions with link elements
  const processed = html
    .replace(
      /#([\w\u4e00-\u9fff]+)/g,
      '<a class="hashtag-link" href="/tags/$1" data-hashtag="$1">#$1</a>'
    )
    .replace(/@([\w\u4e00-\u9fff]+)/g, (match, name) => {
      const uid = nameToUserId[name.toLowerCase()];
      if (uid) {
        return `<a class="mention-link" href="/profile/${uid}" data-mention="${name}">@${name}</a>`;
      }
      return `<span class="mention-unresolved">@${name}</span>`;
    });

  return (
    <div
      className={className}
      dangerouslySetInnerHTML={{ __html: processed }}
    />
  );
}
