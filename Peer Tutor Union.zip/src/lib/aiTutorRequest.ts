import { supabase } from "@/integrations/supabase/client";
import { AP_SUBJECTS } from "@/lib/subjects";

export type ParsedTutorRequest = {
  subject: string;
  session_type: "tutorial" | "study_group";
  requested_date: string;
  start_time: string;
  end_time: string;
  tutor_name?: string | null;
  location?: string | null;
  student_note?: string | null;
};

const BLOCK_RE = /```tutor-request\s*([\s\S]*?)```/i;

/** Extracts a tutor-request JSON block from an assistant reply, if present. */
export function extractTutorRequest(text: string): { request: ParsedTutorRequest | null; cleaned: string } {
  const match = text.match(BLOCK_RE);
  if (!match) return { request: null, cleaned: text };

  const cleaned = text.replace(BLOCK_RE, "").trim();
  try {
    const raw = JSON.parse(match[1].trim());
    const subject = String(raw.subject || "").trim();
    const date = String(raw.requested_date || "").trim();
    const start = String(raw.start_time || "").trim();
    const end = String(raw.end_time || "").trim();
    if (!subject || !/^\d{4}-\d{2}-\d{2}$/.test(date) || !start || !end) {
      return { request: null, cleaned };
    }
    const type = raw.session_type === "study_group" ? "study_group" : "tutorial";
    // Tutorials must use one of the official AP subjects
    const normalized =
      type === "tutorial"
        ? AP_SUBJECTS.find((s) => s.toLowerCase() === subject.toLowerCase()) ?? null
        : subject;
    if (!normalized) return { request: null, cleaned };

    return {
      request: {
        subject: normalized,
        session_type: type,
        requested_date: date,
        start_time: start,
        end_time: end,
        tutor_name: raw.tutor_name ? String(raw.tutor_name).trim() : null,
        location: raw.location ? String(raw.location).trim() : null,
        student_note: raw.student_note ? String(raw.student_note).trim() : null,
      },
      cleaned,
    };
  } catch {
    return { request: null, cleaned };
  }
}

/** Submits a tutoring request on behalf of the signed-in user. */
export async function submitTutorRequest(userId: string, req: ParsedTutorRequest) {
  const { error } = await supabase.from("tutoring_requests").insert({
    user_id: userId,
    subject: req.subject,
    session_type: req.session_type,
    requested_date: req.requested_date,
    start_time: req.start_time,
    end_time: req.end_time,
    tutor_name: req.tutor_name,
    location: req.location,
    student_note: req.student_note,
    status: "pending",
  });
  if (error) throw error;
}
