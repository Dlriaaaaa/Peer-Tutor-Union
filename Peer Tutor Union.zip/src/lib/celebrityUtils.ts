/**
 * Virtual likes & followers growth for celebrity users.
 *
 * Likes per post (each post independently):
 *   - Target at 1x: random in [300_000, 1_000_000] seeded by post id
 *   - At Nx multiplier the target becomes N * base target
 *   - Duration: fast-then-slow curve over ~24 hours
 *     - First 6 hours: reach 70% of target
 *     - Remaining 18 hours: logarithmic tail to 100%
 *   - Multiplier only applies to growth AFTER multiplierChangedAt
 *
 * Followers:
 *   - Each day since becoming celebrity adds 3_000–50_000 (seeded random)
 *   - Multiplier only applies to growth AFTER multiplierChangedAt
 *   - No upper limit
 */

/** Simple deterministic hash from a string to [0,1) */
function hashSeed(s: string): number {
  let h = 0;
  for (let i = 0; i < s.length; i++) {
    h = ((h << 5) - h + s.charCodeAt(i)) | 0;
  }
  return Math.abs(h % 1_000_000) / 1_000_000;
}

/** Internal: calculate raw progress (0-1) for a post given elapsed seconds */
function likesProgress(elapsed: number): number {
  if (elapsed <= 0) return 0;
  const sixHours = 6 * 3600;
  const oneDay = 24 * 3600;
  if (elapsed >= oneDay) return 1;
  if (elapsed <= sixHours) return 0.7 * (elapsed / sixHours);
  const remaining = (elapsed - sixHours) / (oneDay - sixHours);
  return 0.7 + 0.3 * (Math.log(1 + remaining * 9) / Math.log(10));
}

/**
 * Calculate virtual like count for a post by a celebrity.
 * Multiplier only applies to growth after multiplierChangedAt.
 */
export function getVirtualLikes(
  postId: string,
  createdAt: string,
  multiplier: number = 1,
  multiplierChangedAt?: string
): number {
  const seed = hashSeed(postId);
  const target = Math.round(300_000 + seed * 700_000);
  const postTime = new Date(createdAt).getTime();
  const now = Date.now();

  if (multiplier <= 1 || !multiplierChangedAt) {
    // Simple path: no multiplier effect
    const elapsed = (now - postTime) / 1000;
    return Math.round(target * likesProgress(elapsed) * multiplier);
  }

  // Split calculation: 1x before change, Nx after change
  const changeTime = new Date(multiplierChangedAt).getTime();
  const elapsedAtChange = Math.max(0, (changeTime - postTime) / 1000);
  const elapsedNow = (now - postTime) / 1000;

  const progressAtChange = likesProgress(elapsedAtChange);
  const progressNow = likesProgress(elapsedNow);
  const growthBefore = progressAtChange;
  const growthAfter = progressNow - progressAtChange;

  return Math.round(target * (growthBefore + growthAfter * multiplier));
}

/**
 * Format a number for display: 1.2M, 523K, etc.
 */
export function formatCount(n: number): string {
  if (n >= 1_000_000) return (n / 1_000_000).toFixed(1).replace(/\.0$/, "") + "M";
  if (n >= 1_000) return (n / 1_000).toFixed(1).replace(/\.0$/, "") + "K";
  return n.toLocaleString();
}

/** Internal: raw follower count at 1x for given elapsed seconds (5K-30K per day) */
function rawFollowers(userId: string, elapsedSec: number): number {
  if (elapsedSec <= 0) return 0;
  const days = Math.floor(elapsedSec / 86400);
  let total = 0;
  for (let d = 0; d <= days; d++) {
    const daySeed = hashSeed(userId + "-day-" + d);
    total += Math.round(5_000 + daySeed * 25_000);
  }
  const partialDay = (elapsedSec % 86400) / 86400;
  const todaySeed = hashSeed(userId + "-day-" + (days + 1));
  total += Math.round((5_000 + todaySeed * 25_000) * partialDay);
  return total;
}

/**
 * Calculate virtual follower growth since becoming celebrity.
 * Multiplier only applies to growth AFTER multiplierChangedAt.
 */
export function getVirtualFollowers(
  userId: string,
  celebritySince: string,
  multiplier: number = 1,
  multiplierChangedAt?: string,
  baseFollowers: number = 0
): number {
  const startTime = new Date(celebritySince).getTime();
  const now = Date.now();
  const totalElapsed = (now - startTime) / 1000;

  let computed: number;
  if (multiplier <= 1 || !multiplierChangedAt) {
    computed = Math.round(rawFollowers(userId, totalElapsed) * multiplier);
  } else {
    const changeTime = new Date(multiplierChangedAt).getTime();
    const elapsedAtChange = Math.max(0, (changeTime - startTime) / 1000);
    const followersAtChange = rawFollowers(userId, elapsedAtChange);
    const followersNow = rawFollowers(userId, totalElapsed);
    const growthAfter = followersNow - followersAtChange;
    computed = Math.round(followersAtChange + growthAfter * multiplier);
  }
  return computed + baseFollowers;
}

export type CelebrityInfo = {
  user_id: string;
  title: string;
  badge_color: string;
  badge_icon: string;
  badge_style: string;
  created_at: string;
  likes_multiplier?: number;
  follower_multiplier?: number;
  likes_multiplier_changed_at?: string;
  follower_multiplier_changed_at?: string;
  virtual_follower_seed?: number;
};

/** Badge color presets */
export const BADGE_COLORS = [
  { value: "gold", label: "Gold", class: "bg-yellow-500/20 text-yellow-400 border-yellow-500/30" },
  { value: "purple", label: "Purple", class: "bg-purple-500/20 text-purple-400 border-purple-500/30" },
  { value: "blue", label: "Blue", class: "bg-blue-500/20 text-blue-400 border-blue-500/30" },
  { value: "red", label: "Red", class: "bg-red-500/20 text-red-400 border-red-500/30" },
  { value: "green", label: "Green", class: "bg-emerald-500/20 text-emerald-400 border-emerald-500/30" },
  { value: "pink", label: "Pink", class: "bg-pink-500/20 text-pink-400 border-pink-500/30" },
];

export const BADGE_ICONS = [
  { value: "star", label: "⭐ Star" },
  { value: "crown", label: "👑 Crown" },
  { value: "fire", label: "🔥 Fire" },
  { value: "diamond", label: "💎 Diamond" },
  { value: "sparkle", label: "✨ Sparkle" },
  { value: "trophy", label: "🏆 Trophy" },
];

export const BADGE_STYLES = [
  { value: "default", label: "Default" },
  { value: "outline", label: "Outline" },
  { value: "glow", label: "Glow" },
];

export function getBadgeColorClass(color: string): string {
  return BADGE_COLORS.find(c => c.value === color)?.class || BADGE_COLORS[0].class;
}

export function getBadgeIconEmoji(icon: string): string {
  const map: Record<string, string> = {
    star: "⭐", crown: "👑", fire: "🔥", diamond: "💎", sparkle: "✨", trophy: "🏆"
  };
  return map[icon] || "⭐";
}
