import { supabase } from "@/integrations/supabase/client";

/**
 * Upload a blob to storage with automatic retries.
 * Network hiccups ("Failed to fetch") are common on slow/mobile connections,
 * so we retry a few times with exponential backoff before giving up.
 */
export async function uploadWithRetry(
  bucket: string,
  path: string,
  blob: Blob,
  contentType: string,
  attempts = 3
): Promise<{ error: string | null }> {
  let lastError = "Upload failed";
  for (let i = 0; i < attempts; i++) {
    try {
      const { error } = await supabase.storage.from(bucket).upload(path, blob, {
        contentType,
        upsert: true,
      });
      if (!error) return { error: null };
      lastError = error.message;
      // Permission / validation errors won't succeed on retry
      if (/exists|not authorized|violates|policy|payload too large/i.test(error.message)) {
        return { error: error.message };
      }
    } catch (e: any) {
      lastError = e?.message || String(e);
    }
    await new Promise((r) => setTimeout(r, 800 * (i + 1)));
  }
  return { error: lastError };
}
