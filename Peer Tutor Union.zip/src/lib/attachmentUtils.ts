import { supabase } from "@/integrations/supabase/client";

const SUPABASE_URL = import.meta.env.VITE_SUPABASE_URL;
const PUBLIC_PREFIX = `${SUPABASE_URL}/storage/v1/object/public/attachments/`;
const SIGNED_PREFIX = `${SUPABASE_URL}/storage/v1/object/sign/attachments/`;

/**
 * Extract the storage path from a file_url field.
 * Handles:
 *  - Pure storage paths (new format): "postId/timestamp-filename"
 *  - Old public URLs: "https://.../storage/v1/object/public/attachments/..."
 *  - Old signed URLs: "https://.../storage/v1/object/sign/attachments/...?token=..."
 */
export function extractStoragePath(fileUrl: string): string {
  if (!fileUrl) return fileUrl;
  // Already a clean path (no http)
  if (!fileUrl.startsWith("http")) return fileUrl;

  if (fileUrl.startsWith(PUBLIC_PREFIX)) {
    return decodeURIComponent(fileUrl.slice(PUBLIC_PREFIX.length));
  }
  if (fileUrl.includes("/storage/v1/object/public/attachments/")) {
    const idx = fileUrl.indexOf("/storage/v1/object/public/attachments/");
    return decodeURIComponent(fileUrl.slice(idx + "/storage/v1/object/public/attachments/".length));
  }
  if (fileUrl.includes("/storage/v1/object/sign/attachments/")) {
    const idx = fileUrl.indexOf("/storage/v1/object/sign/attachments/");
    let path = fileUrl.slice(idx + "/storage/v1/object/sign/attachments/".length);
    // Remove query params (token)
    const qIdx = path.indexOf("?");
    if (qIdx > -1) path = path.slice(0, qIdx);
    return decodeURIComponent(path);
  }
  // Fallback: return as-is
  return fileUrl;
}

/**
 * Resolve a list of attachments by generating fresh signed URLs.
 * Returns attachments with file_url replaced by a valid signed URL.
 */
export async function resolveAttachmentUrls<T extends { file_url: string }>(
  attachments: T[]
): Promise<T[]> {
  if (!attachments || attachments.length === 0) return attachments;

  const results = await Promise.all(
    attachments.map(async (att) => {
      const path = extractStoragePath(att.file_url);
      const { data } = await supabase.storage
        .from("attachments")
        .createSignedUrl(path, 3600); // 1 hour
      return { ...att, file_url: data?.signedUrl || att.file_url };
    })
  );
  return results;
}

/**
 * Resolve attachments for multiple posts in batch.
 */
export async function resolvePostsAttachments<
  T extends { post_attachments: { id: string; file_url: string; file_name: string }[] }
>(posts: T[]): Promise<T[]> {
  // Collect all unique paths
  const allAtts = posts.flatMap((p) => p.post_attachments || []);
  if (allAtts.length === 0) return posts;

  // Generate signed URLs in parallel
  const urlMap = new Map<string, string>();
  await Promise.all(
    allAtts.map(async (att) => {
      if (urlMap.has(att.file_url)) return;
      const path = extractStoragePath(att.file_url);
      const { data } = await supabase.storage
        .from("attachments")
        .createSignedUrl(path, 3600);
      urlMap.set(att.file_url, data?.signedUrl || att.file_url);
    })
  );

  return posts.map((p) => ({
    ...p,
    post_attachments: (p.post_attachments || []).map((att) => ({
      ...att,
      file_url: urlMap.get(att.file_url) || att.file_url,
    })),
  }));
}
