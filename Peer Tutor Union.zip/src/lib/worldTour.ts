/**
 * World Tour — global multi-stop basketball tournament system.
 *
 * Replaces the old single "World Champion" league with a 30-stop
 * international circuit. The user advances through tour stops in order
 * (city by city), earns tour points based on score margin, and unlocks
 * the Finals once enough points are accumulated.
 *
 * State persists per-user in localStorage keyed by user_id. A separate
 * "tour title" counter is stored on team_managers.wc_titles (re-used,
 * since the column already exists) to track championships won.
 *
 * Points formula: base 60 per win + score margin (capped 60), scaled by
 * stop's pointsWeight (1.0 normal, 1.5 high-tier, 2.0 finals).
 */

export interface TourStop {
  id: number;
  city: string;
  country: string;
  eventName: string;
  venue: string;
  startDate: string;   // ISO yyyy-mm-dd
  endDate: string;
  timezone: string;
  pointsWeight: number; // 1.0 normal · 1.5 major · 2.0 grand finals
  /** Pixel coords on the world-tour-map background (1672 × 941). */
  x: number;
  y: number;
}

export type TourStatus = "locked" | "upcoming" | "current" | "completed";

export interface TourStopProgress {
  stopId: number;
  status: TourStatus;
  pointsEarned: number;
  myScore: number;
  oppScore: number;
  won: boolean;
  completedAt: string | null;
}

export interface RivalTeam {
  id: string;
  name: string;
  emoji: string;
  country: string;
  /** Average team OVR — affects the AI sim outcome at this stop. */
  baseOvr: number;
  totalPoints: number;
}

export interface TourState {
  /** Display label, e.g. "26 World Tour" or "27 World Tour". */
  season: string;
  /** Numeric season year (26, 27, 28…). Increments by 1 on each reset. */
  seasonYear: number;
  currentStopIdx: number;     // 0-based — first not-yet-completed stop
  totalPoints: number;
  finalsUnlocked: boolean;
  finalsCompleted: boolean;
  finalsWon: boolean;
  progress: TourStopProgress[];
  rivals: RivalTeam[];
  /** Knockout bracket for stop #31 (built lazily when player enters Finals). */
  finalsBracket?: FinalsBracketState | null;
  /** Unix ms of last save — used to invalidate stale localStorage on schema bump. */
  savedAt: number;
}

const STORAGE_KEY_PREFIX = "world_tour_v2::";
const SCHEMA_VERSION = 2;

/** Tour Finals threshold — accumulating ≥ this many points unlocks the Finals stop. */
export const FINALS_QUALIFY_POINTS = 1500;

/** ID of the World Final stop (always the last entry in TOUR_STOPS). */
export const FINALS_STOP_ID = 31;

/**
 * 31-stop World Tour itinerary — order follows the official poster:
 *   1 Pyongyang → 2 Moscow → 3-8 Europe → 9-10 Africa →
 *   11-14 South America → 15-17 North America → 18 Honolulu →
 *   19-20 Oceania → 21-30 Asia → 31 Shanghai (World Final).
 *
 * Pixel coords (x, y) match the 1672 × 941 background poster
 * `src/assets/world-tour-map.jpg`.
 */
export const TOUR_STOPS: TourStop[] = [
  // ── Opening ──
  { id: 1,  city: "Pyongyang",    country: "North Korea",    eventName: "Pyongyang Cup",         venue: "Ryugyong Chung Ju-yung Arena", startDate: "2026-01-10", endDate: "2026-01-12", timezone: "Asia/Pyongyang",    pointsWeight: 1.0, x: 947,  y: 283 },
  { id: 2,  city: "Moscow",       country: "Russia",         eventName: "Moscow Open",           venue: "Megasport Arena",              startDate: "2026-01-24", endDate: "2026-01-26", timezone: "Europe/Moscow",     pointsWeight: 1.0, x: 1180, y: 357 },
  // ── Europe ──
  { id: 3,  city: "London",       country: "UK",             eventName: "London Invitational",   venue: "O2 Arena",                     startDate: "2026-02-07", endDate: "2026-02-09", timezone: "Europe/London",     pointsWeight: 1.5, x: 704,  y: 365 },
  { id: 4,  city: "Paris",        country: "France",         eventName: "Paris Open",            venue: "Accor Arena",                  startDate: "2026-02-21", endDate: "2026-02-23", timezone: "Europe/Paris",      pointsWeight: 1.0, x: 817,  y: 365 },
  { id: 5,  city: "Madrid",       country: "Spain",          eventName: "Madrid Showcase",       venue: "WiZink Center",                startDate: "2026-03-07", endDate: "2026-03-09", timezone: "Europe/Madrid",     pointsWeight: 1.0, x: 919,  y: 365 },
  { id: 6,  city: "Berlin",       country: "Germany",        eventName: "Berlin Trophy",         venue: "Mercedes-Benz Arena",          startDate: "2026-03-21", endDate: "2026-03-23", timezone: "Europe/Berlin",     pointsWeight: 1.0, x: 704,  y: 423 },
  { id: 7,  city: "Rome",         country: "Italy",          eventName: "Rome Elite",            venue: "Palazzo dello Sport",          startDate: "2026-04-04", endDate: "2026-04-06", timezone: "Europe/Rome",       pointsWeight: 1.0, x: 817,  y: 423 },
  { id: 8,  city: "Istanbul",     country: "Türkiye",        eventName: "Istanbul Series",       venue: "Sinan Erdem Dome",             startDate: "2026-04-18", endDate: "2026-04-20", timezone: "Europe/Istanbul",   pointsWeight: 1.0, x: 919,  y: 423 },
  // ── Africa ──
  { id: 9,  city: "Cairo",        country: "Egypt",          eventName: "Cairo Cup",             venue: "Cairo Stadium",                startDate: "2026-05-02", endDate: "2026-05-04", timezone: "Africa/Cairo",      pointsWeight: 1.0, x: 782,  y: 530 },
  { id: 10, city: "Johannesburg", country: "South Africa",   eventName: "Johannesburg Open",     venue: "Ellis Park Arena",             startDate: "2026-05-16", endDate: "2026-05-18", timezone: "Africa/Johannesburg", pointsWeight: 1.0, x: 782, y: 590 },
  // ── South America ──
  { id: 11, city: "Bogota",       country: "Colombia",       eventName: "Bogota Challenge",      venue: "Movistar Arena",               startDate: "2026-05-30", endDate: "2026-06-01", timezone: "America/Bogota",    pointsWeight: 1.0, x: 450,  y: 580 },
  { id: 12, city: "Lima",         country: "Peru",           eventName: "Lima Series",           venue: "Coliseo Eduardo Dibos",        startDate: "2026-06-13", endDate: "2026-06-15", timezone: "America/Lima",      pointsWeight: 1.0, x: 450,  y: 635 },
  { id: 13, city: "Sao Paulo",    country: "Brazil",         eventName: "Sao Paulo Slam",        venue: "Allianz Parque",               startDate: "2026-06-27", endDate: "2026-06-29", timezone: "America/Sao_Paulo", pointsWeight: 1.5, x: 450,  y: 690 },
  { id: 14, city: "Buenos Aires", country: "Argentina",      eventName: "Buenos Aires Cup",      venue: "Luna Park",                    startDate: "2026-07-11", endDate: "2026-07-13", timezone: "America/Argentina/Buenos_Aires", pointsWeight: 1.0, x: 450, y: 750 },
  // ── North America ──
  { id: 15, city: "Vancouver",    country: "Canada",         eventName: "Vancouver Classic",     venue: "Rogers Arena",                 startDate: "2026-07-25", endDate: "2026-07-27", timezone: "America/Vancouver", pointsWeight: 1.0, x: 307,  y: 350 },
  { id: 16, city: "New York",     country: "USA",            eventName: "New York Masters",      venue: "Madison Square Garden",        startDate: "2026-08-08", endDate: "2026-08-10", timezone: "America/New_York",  pointsWeight: 1.5, x: 307,  y: 405 },
  { id: 17, city: "Mexico City",  country: "Mexico",         eventName: "Mexico City Cup",       venue: "Arena CDMX",                   startDate: "2026-08-22", endDate: "2026-08-24", timezone: "America/Mexico_City", pointsWeight: 1.0, x: 307, y: 462 },
  // ── Pacific bridge ──
  { id: 18, city: "Honolulu",     country: "USA / Hawaii",   eventName: "Honolulu Open",         venue: "Aloha Arena",                  startDate: "2026-09-05", endDate: "2026-09-07", timezone: "Pacific/Honolulu",  pointsWeight: 1.0, x: 80,   y: 506 },
  // ── Oceania ──
  { id: 19, city: "Sydney",       country: "Australia",      eventName: "Sydney Cup",            venue: "Qudos Bank Arena",             startDate: "2026-09-19", endDate: "2026-09-21", timezone: "Australia/Sydney",  pointsWeight: 1.0, x: 1408, y: 740 },
  { id: 20, city: "Auckland",     country: "New Zealand",    eventName: "Auckland Open",         venue: "Spark Arena",                  startDate: "2026-10-03", endDate: "2026-10-05", timezone: "Pacific/Auckland",  pointsWeight: 1.0, x: 1408, y: 800 },
  // ── Asia ──
  { id: 21, city: "Tokyo",        country: "Japan",          eventName: "Tokyo Grand Slam",      venue: "Saitama Super Arena",          startDate: "2026-10-17", endDate: "2026-10-19", timezone: "Asia/Tokyo",        pointsWeight: 1.5, x: 1140, y: 449 },
  { id: 22, city: "Seoul",        country: "South Korea",    eventName: "Seoul Series",          venue: "Jamsil Arena",                 startDate: "2026-10-31", endDate: "2026-11-02", timezone: "Asia/Seoul",        pointsWeight: 1.0, x: 1255, y: 449 },
  { id: 23, city: "Hong Kong",    country: "Hong Kong",      eventName: "Hong Kong Open",        venue: "Hong Kong Coliseum",           startDate: "2026-11-14", endDate: "2026-11-16", timezone: "Asia/Hong_Kong",    pointsWeight: 1.0, x: 1140, y: 503 },
  { id: 24, city: "Beijing",      country: "China",          eventName: "Beijing Finals",        venue: "MasterCard Center",            startDate: "2026-11-28", endDate: "2026-11-30", timezone: "Asia/Shanghai",     pointsWeight: 1.5, x: 1255, y: 503 },
  { id: 25, city: "Bangkok",      country: "Thailand",       eventName: "Bangkok Masters",       venue: "Indoor Stadium Huamark",       startDate: "2026-12-12", endDate: "2026-12-14", timezone: "Asia/Bangkok",      pointsWeight: 1.0, x: 1140, y: 555 },
  { id: 26, city: "Singapore",    country: "Singapore",      eventName: "Singapore Cup",         venue: "Singapore Indoor Stadium",     startDate: "2026-12-26", endDate: "2026-12-28", timezone: "Asia/Singapore",    pointsWeight: 1.0, x: 1255, y: 555 },
  { id: 27, city: "Jakarta",      country: "Indonesia",      eventName: "Jakarta Invitational",  venue: "Istora Senayan",               startDate: "2027-01-09", endDate: "2027-01-11", timezone: "Asia/Jakarta",      pointsWeight: 1.0, x: 1140, y: 607 },
  { id: 28, city: "Manila",       country: "Philippines",    eventName: "Manila Challenge",      venue: "Mall of Asia Arena",           startDate: "2027-01-23", endDate: "2027-01-25", timezone: "Asia/Manila",       pointsWeight: 1.0, x: 1255, y: 607 },
  { id: 29, city: "Dubai",        country: "UAE",            eventName: "Dubai Championship",    venue: "Coca-Cola Arena",              startDate: "2027-02-06", endDate: "2027-02-08", timezone: "Asia/Dubai",        pointsWeight: 1.5, x: 1140, y: 661 },
  { id: 30, city: "Mumbai",       country: "India",          eventName: "Mumbai Classic",        venue: "NSCI Dome",                    startDate: "2027-02-20", endDate: "2027-02-22", timezone: "Asia/Kolkata",      pointsWeight: 1.0, x: 1255, y: 661 },
  // ── World Final ──
  { id: 31, city: "Shanghai",     country: "China",          eventName: "Shanghai · WORLD FINAL", venue: "Mercedes-Benz Arena",         startDate: "2027-03-13", endDate: "2027-03-15", timezone: "Asia/Shanghai",     pointsWeight: 2.0, x: 1503, y: 543 },
];

/** Original aspect ratio of the map background image (matches the JSON schema). */
export const MAP_IMAGE_W = 1672;
export const MAP_IMAGE_H = 941;

const RIVAL_NAMES = [
  { n: "Tokyo Dragons",       c: "Japan",        e: "🐉" },
  { n: "Paris Lightning",     c: "France",       e: "⚡" },
  { n: "London Crown",        c: "UK",           e: "👑" },
  { n: "NYC Skyline",         c: "USA",          e: "🗽" },
  { n: "Madrid Toros",        c: "Spain",        e: "🐂" },
  { n: "Berlin Iron",         c: "Germany",      e: "🛡️" },
  { n: "Sydney Sharks",       c: "Australia",    e: "🦈" },
  { n: "Rio Phoenix",         c: "Brazil",       e: "🔥" },
  { n: "Mumbai Tigers",       c: "India",        e: "🐯" },
  { n: "Cairo Pharaohs",      c: "Egypt",        e: "🏺" },
  { n: "Dubai Falcons",       c: "UAE",          e: "🦅" },
  { n: "Seoul Tornados",      c: "South Korea",  e: "🌪️" },
  { n: "Beijing Pandas",      c: "China",        e: "🐼" },
  { n: "Shanghai Storm",      c: "China",        e: "⛈️" },
  { n: "Manila Heat",         c: "Philippines",  e: "🌋" },
  { n: "Bangkok Royals",      c: "Thailand",     e: "🏯" },
  { n: "Singapore Lions",     c: "Singapore",    e: "🦁" },
  { n: "Jakarta Komodo",      c: "Indonesia",    e: "🦎" },
  { n: "Istanbul Sultans",    c: "Türkiye",      e: "⚔️" },
  { n: "Joburg Rhinos",       c: "South Africa", e: "🦏" },
  { n: "Mexico Aztecs",       c: "Mexico",       e: "🌵" },
  { n: "Lima Condors",        c: "Peru",         e: "🪽" },
  { n: "Bogota Comets",       c: "Colombia",     e: "☄️" },
  { n: "Buenos Aires Pumas",  c: "Argentina",    e: "🐆" },
  { n: "Vancouver Wolves",    c: "Canada",       e: "🐺" },
  { n: "Auckland Kiwis",      c: "New Zealand",  e: "🥝" },
  { n: "Honolulu Surf",       c: "USA / Hawaii", e: "🏄" },
  { n: "Pyongyang Stars",     c: "North Korea",  e: "⭐" },
  { n: "Hong Kong Drift",     c: "Hong Kong",    e: "🌃" },
  { n: "Rome Gladiators",     c: "Italy",        e: "🏛️" },
];

function generateRivals(seed: number): RivalTeam[] {
  return RIVAL_NAMES.map((r, i) => {
    // Deterministic-ish pseudo-random base OVR per rival, range ~280-440.
    const rnd = Math.abs(Math.sin((seed + i * 17) * 0.731));
    const baseOvr = Math.round(280 + rnd * 160);
    return {
      id: `rival-${i + 1}`,
      name: r.n,
      emoji: r.e,
      country: r.c,
      baseOvr,
      totalPoints: 0,
    };
  });
}

/** Default starting season year (26 = "26 World Tour" = year 2026). */
export const DEFAULT_SEASON_YEAR = 26;
const seasonLabel = (year: number) => `${year} World Tour`;

function freshState(seasonYear: number = DEFAULT_SEASON_YEAR): TourState {
  return {
    season: seasonLabel(seasonYear),
    seasonYear,
    currentStopIdx: 0,
    totalPoints: 0,
    finalsUnlocked: false,
    finalsCompleted: false,
    finalsWon: false,
    progress: TOUR_STOPS.map(s => ({
      stopId: s.id,
      status: s.id === 1 ? "current" : "locked",
      pointsEarned: 0,
      myScore: 0,
      oppScore: 0,
      won: false,
      completedAt: null,
    })),
    rivals: generateRivals(Date.now() & 0xffff),
    savedAt: Date.now(),
  };
}

export function loadTourState(userId: string): TourState {
  try {
    const raw = localStorage.getItem(STORAGE_KEY_PREFIX + userId);
    if (!raw) return freshState();
    const parsed = JSON.parse(raw) as TourState & { _v?: number };
    if ((parsed as any)._v !== SCHEMA_VERSION) {
      // Schema bump → start fresh but preserve nothing; safer than half-migrated.
      return freshState();
    }
    // Backfill any new stops added since this user last played.
    if (parsed.progress.length !== TOUR_STOPS.length) {
      const knownIds = new Set(parsed.progress.map(p => p.stopId));
      for (const s of TOUR_STOPS) {
        if (!knownIds.has(s.id)) {
          parsed.progress.push({
            stopId: s.id, status: "locked",
            pointsEarned: 0, myScore: 0, oppScore: 0, won: false, completedAt: null,
          });
        }
      }
      parsed.progress.sort((a, b) => a.stopId - b.stopId);
    }
    // Rebalance legacy saves: the old formula gave rivals huge runaway leads
    // independent of the player's pace. If rivals have wildly more points than
    // the player on average, compress them down so the leaderboard stays
    // competitive (player's progress actually shows on the standings).
    if (parsed.rivals && parsed.rivals.length > 0) {
      const avgRival = parsed.rivals.reduce((s, r) => s + r.totalPoints, 0) / parsed.rivals.length;
      const playerPoints = parsed.totalPoints || 0;
      // Target: top rival ~1.4× player, weakest rival ~0.4× player (min floor 60).
      const target = Math.max(120, playerPoints * 1.0);
      if (avgRival > target * 1.5 || (playerPoints > 0 && avgRival > playerPoints * 2.5)) {
        parsed.rivals = parsed.rivals.map(r => {
          const strength = (r.baseOvr - 280) / 160; // 0..1
          const factor = 0.4 + strength * 1.0; // 0.4..1.4 of target
          return { ...r, totalPoints: Math.round(target * factor) };
        });
      }
    }
    // Backfill seasonYear / season label for older saves predating year tracking.
    if (typeof parsed.seasonYear !== "number") {
      parsed.seasonYear = DEFAULT_SEASON_YEAR;
    }
    parsed.season = seasonLabel(parsed.seasonYear);
    return parsed;
  } catch {
    return freshState();
  }
}

export function saveTourState(userId: string, state: TourState): void {
  try {
    const payload = { ...state, _v: SCHEMA_VERSION, savedAt: Date.now() };
    localStorage.setItem(STORAGE_KEY_PREFIX + userId, JSON.stringify(payload));
  } catch {
    /* quota exceeded — silent */
  }
}

/**
 * Reset the tour to a fresh slate. The season YEAR bumps by 1 each reset
 * (26 → 27 → 28 …) so each replay is its own labelled World Tour.
 *
 * Optionally accepts an explicit nextYear when callers (e.g. server-synced
 * `current_tour_season`) want to set it deterministically.
 */
export function resetTourState(userId: string, nextYear?: number): TourState {
  const prev = (() => {
    try {
      const raw = localStorage.getItem(STORAGE_KEY_PREFIX + userId);
      if (!raw) return null;
      return JSON.parse(raw) as TourState;
    } catch { return null; }
  })();
  const year = nextYear ?? ((prev?.seasonYear ?? DEFAULT_SEASON_YEAR - 1) + 1);
  const fresh = freshState(year);
  saveTourState(userId, fresh);
  return fresh;
}

/**
 * Compute tour points awarded for a single stop result.
 * Win:  base 60 + min(60, scoreMargin*4), times stop weight
 * Loss: base 10 + min(20, oppMargin/2),  times stop weight (consolation)
 * Capped at 240 per stop.
 */
export function computeStopPoints(stop: TourStop, myScore: number, oppScore: number): number {
  const margin = Math.abs(myScore - oppScore);
  const won = myScore > oppScore;
  const raw = won
    ? 60 + Math.min(60, margin * 4)
    : 10 + Math.min(20, margin * 0.5);
  return Math.min(240, Math.round(raw * stop.pointsWeight));
}

/**
 * Apply a stop result: mark completed, advance currentStopIdx, accumulate points,
 * unlock Finals when threshold reached, simulate rival point progression.
 */
export function applyStopResult(
  state: TourState,
  stopId: number,
  myScore: number,
  oppScore: number,
): TourState {
  const stop = TOUR_STOPS.find(s => s.id === stopId);
  if (!stop) return state;
  const idx = state.progress.findIndex(p => p.stopId === stopId);
  if (idx < 0) return state;
  const current = state.progress[idx];
  if (current.status === "completed") return state;

  const won = myScore > oppScore;
  const earned = computeStopPoints(stop, myScore, oppScore);
  const isFinals = stop.id === FINALS_STOP_ID;

  // ── Loss handling: stop stays "current" — player must win to progress.
  // Finals bracket has its own elimination logic, so we let the bracket
  // pipeline mark the finals stop completed even on a loss.
  if (!won && !isFinals) {
    // On a player loss, rivals only earn a SMALL share of stop points
    // (they "also had a tough night") so a loss doesn't tank the player's
    // ranking. Strong rivals still slightly outperform weak ones.
    const lossEarnBase = Math.round(earned * 0.35); // earned was the player's consolation
    return {
      ...state,
      rivals: state.rivals.map(r => {
        const strength = (r.baseOvr - 280) / 160; // 0..1
        const noise = (Math.random() - 0.5) * 18;
        const rivalEarn = Math.max(8, Math.round(lossEarnBase * (0.6 + strength * 0.7) + noise));
        return { ...r, totalPoints: r.totalPoints + rivalEarn };
      }),
    };
  }

  const newProgress = state.progress.map((p, i) => {
    if (i === idx) {
      return { ...p,
        status: "completed" as TourStatus,
        pointsEarned: earned,
        myScore, oppScore, won,
        completedAt: new Date().toISOString(),
      };
    }
    return p;
  });

  // Advance the next stop to "current" if it was just unlocked.
  if (idx + 1 < newProgress.length) {
    const next = newProgress[idx + 1];
    if (next.status === "locked" || next.status === "upcoming") {
      // Block Finals until points threshold reached.
      const nextStop = TOUR_STOPS[idx + 1];
      if (nextStop.id === FINALS_STOP_ID) {
        const newTotal = state.totalPoints + earned;
        newProgress[idx + 1] = { ...next, status: newTotal >= FINALS_QUALIFY_POINTS ? "current" : "locked" };
      } else {
        newProgress[idx + 1] = { ...next, status: "current" };
      }
    }
  }

  const newTotal = state.totalPoints + earned;
  const finalsUnlocked = state.finalsUnlocked || newTotal >= FINALS_QUALIFY_POINTS;

  // Re-evaluate Finals lock once we cross threshold mid-tour.
  if (finalsUnlocked) {
    const finalsIdx = newProgress.findIndex(p => p.stopId === FINALS_STOP_ID);
    if (finalsIdx >= 0 && newProgress[finalsIdx].status === "locked") {
      newProgress[finalsIdx] = { ...newProgress[finalsIdx], status: "upcoming" };
    }
  }

  // Simulate rival point progression — pegged to the PLAYER'S earnings on this stop
  // so the leaderboard stays competitive instead of pre-stacking rivals with points
  // the player can never catch up to. Strong rivals (high baseOvr) earn close to
  // the player's haul, weaker rivals earn noticeably less.
  const newRivals = state.rivals.map(r => {
    const strength = (r.baseOvr - 280) / 160; // 0..1, weaker→0, top→1
    // Each rival earns 35%..105% of the player's stop points, scaled by strength.
    const factor = 0.35 + strength * 0.7;
    const noise = (Math.random() - 0.5) * 0.2; // ±10% jitter
    const rivalEarn = Math.max(15, Math.round(earned * (factor + noise)));
    return { ...r, totalPoints: r.totalPoints + rivalEarn };
  });

  return {
    ...state,
    progress: newProgress,
    totalPoints: newTotal,
    finalsUnlocked,
    finalsCompleted: state.finalsCompleted || (isFinals && true),
    finalsWon: state.finalsWon || (isFinals && won),
    currentStopIdx: Math.min(newProgress.length - 1, idx + 1),
    rivals: newRivals,
    savedAt: Date.now(),
  };
}

/** Per-stop status for UI rendering, computed from progress + finals lock. */
export function getStopStatus(state: TourState, stop: TourStop): TourStatus {
  return state.progress.find(p => p.stopId === stop.id)?.status ?? "locked";
}

/** "Road to Finals" — combined ranking of player + AI rivals by total points. */
export interface RankingRow {
  rank: number;
  isPlayer: boolean;
  name: string;
  emoji: string;
  country: string;
  totalPoints: number;
  qualified: boolean;   // top 8 → Finals qualifier
}

export const FINALS_QUALIFIER_SLOTS = 8;

export function buildRankings(
  state: TourState,
  myTeamName: string,
  myEmoji: string,
  myCountry: string = "Worldwide",
): RankingRow[] {
  const all = [
    { isPlayer: true,  name: myTeamName, emoji: myEmoji, country: myCountry, totalPoints: state.totalPoints },
    ...state.rivals.map(r => ({
      isPlayer: false, name: r.name, emoji: r.emoji, country: r.country, totalPoints: r.totalPoints,
    })),
  ];
  all.sort((a, b) => b.totalPoints - a.totalPoints);
  return all.map((row, i) => ({
    rank: i + 1,
    ...row,
    qualified: i < FINALS_QUALIFIER_SLOTS,
  }));
}

/** Determine the "next playable" stop id (current status), or null when tour done. */
export function getNextPlayableStop(state: TourState): TourStop | null {
  const cur = state.progress.find(p => p.status === "current");
  if (!cur) return null;
  return TOUR_STOPS.find(s => s.id === cur.stopId) ?? null;
}

/** Days until a given stop (negative if past). */
export function daysUntil(dateIso: string): number {
  const target = new Date(dateIso + "T00:00:00Z").getTime();
  return Math.floor((target - Date.now()) / 86_400_000);
}

/** Pretty short date: "Mar 12" */
export function formatShortDate(iso: string): string {
  const d = new Date(iso + "T00:00:00Z");
  return d.toLocaleDateString("en-US", { month: "short", day: "numeric", timeZone: "UTC" });
}

/**
 * Gate: World Tour is only accessible after the player has CLEARED NBA Masters.
 * "Cleared" = currently in the `nba` league AND has reached the promotion-win
 * threshold (5 wins). NBA is the top PTC-Star league, so reaching its
 * promotion bar is what unlocks the global tour.
 */
export function canAccessWorldTour(team: { current_league?: string | null; league_wins?: number | null } | null | undefined): boolean {
  if (!team) return false;
  return team.current_league === "nba" && (team.league_wins ?? 0) >= 5;
}

// ───────────────────────── Difficulty curve ─────────────────────────
//
// Per-stop "100% beatable" OVR thresholds (set by product). Stops 1..20 ramp
// +10 OVR each (1800 → 1990). Stops 21..25 ramp +20 each (2010 → 2090). Stops
// 26..30 spike (2150 / 2200 / 2300 / 2420 / 2580). The Final (#31) is 2780.
// Conversion to AI baseStat uses the same calibration as the league system:
//   baseStat ≈ 78 + (OVR - 1400) / 18
// For stops where baseStat exceeds 99 (the per-axis stat cap), the overflow
// gets converted into an AI-side boost (extraBoost) that is applied live to
// the engine's gameplay parameters — same mechanism the player's coach /
// consumable bonuses use, just on team 1 instead of team 0.

/**
 * Target "100% beatable" team OVR for each stop id (1..31).
 * Stops 1-30 have been reduced ~37% in difficulty (relative to a 1400 OVR
 * baseline) — original ~30% reduction plus an additional ~10% global ease.
 * Stop 31 (Shanghai Final) also reduced ~10% to keep relative pacing.
 */
export const STOP_TARGET_OVR: Record<number, number> = {
  1: 1652, 2: 1658, 3: 1665, 4: 1671, 5: 1677, 6: 1684, 7: 1690, 8: 1696, 9: 1702, 10: 1709,
  11: 1715, 12: 1721, 13: 1728, 14: 1734, 15: 1740, 16: 1747, 17: 1753, 18: 1759, 19: 1765, 20: 1772,
  21: 1784, 22: 1797, 23: 1810, 24: 1822, 25: 1835,
  26: 1873, 27: 1904, 28: 1967, 29: 2043, 30: 2143,
  31: 2642, // 🏆 Shanghai · WORLD FINAL (also -10%)
};

/** Raw per-stop AI baseStat (may exceed the 99 cap — overflow → extraBoost). */
export function rawStopBaseStat(stopId: number): number {
  const ovr = STOP_TARGET_OVR[stopId] ?? 1800;
  return 78 + (ovr - 1400) / 18;
}

/** Effective AI difficulty preset for a stop, scaling with baseStat tier. */
export function stopAIDifficulty(stopId: number): "medium" | "hard" | "allstar" | "nba" {
  const bs = rawStopBaseStat(stopId);
  if (bs >= 116) return "nba";       // stop 26+
  if (bs >= 106) return "allstar";   // stops ~14-25
  if (bs >= 96)  return "hard";      // stops ~1-13 upper
  return "medium";
}

/** Clamped per-axis stat for the AI roster (capped at 99). */
export function stopStatCapped(stopId: number, offset: number = 0): number {
  return Math.max(40, Math.min(99, Math.round(rawStopBaseStat(stopId) + offset)));
}

/**
 * Overflow boost — when raw baseStat exceeds 99, every stat axis is "wasted"
 * past the cap. Convert that overflow into a multiplicative boost applied to
 * the AI's live gameplay parameters (speed / steal / block / shootPower / …).
 * Mirrors how the player's coach + consumable boost works on team 0.
 *
 * Example: baseStat 154 (Final) → +55% AI boost on top of capped 99 stats.
 */
export function stopAIExtraBoost(stopId: number): number {
  const bs = rawStopBaseStat(stopId);
  if (bs <= 99) return 0;
  return (bs - 99) / 99;
}

// ───────────────────────── Coin rewards ─────────────────────────
//
// Per-stop coin payout when the player WINS that stop. Loss = 0 coins
// (consolation is only tour points). Final stop (#31) coins are awarded
// per bracket round in the finals knockout, NOT via this table.

const STOP_WIN_COINS: Record<number, number> = {
  // Stops 1-9: 50,000 each
  1: 50_000, 2: 50_000, 3: 50_000, 4: 50_000, 5: 50_000,
  6: 50_000, 7: 50_000, 8: 50_000, 9: 50_000,
  // Stops 10-19: 80,000 each
  10: 80_000, 11: 80_000, 12: 80_000, 13: 80_000, 14: 80_000,
  15: 80_000, 16: 80_000, 17: 80_000, 18: 80_000, 19: 80_000,
  // Stops 20-24: 150,000 each
  20: 150_000, 21: 150_000, 22: 150_000, 23: 150_000, 24: 150_000,
  // Stop 25: 200k · 26: 250k · 27: 300k · 28: 400k · 29: 500k · 30: 1,000,000
  25: 200_000,
  26: 250_000,
  27: 300_000,
  28: 400_000,
  29: 500_000,
  30: 1_000_000,
};

/** Coins awarded for winning a regular tour stop (1..30). Final (#31) handled separately. */
export function coinsRewardForStop(stopId: number): number {
  return STOP_WIN_COINS[stopId] ?? 0;
}

/**
 * Entry fee charged when STARTING a tour stop (win or lose).
 *   1-19 → 30,000 · 20-27 → 50,000 · 28 → 80,000 · 29 → 100,000
 *   30   → 100,000 (kept consistent with the late-game tier)
 *   31   → 500,000 (Shanghai · World Final)
 */
export function entryFeeForStop(stopId: number): number {
  if (stopId === FINALS_STOP_ID) return 500_000;
  if (stopId >= 29) return 100_000;
  if (stopId === 28) return 80_000;
  if (stopId >= 20) return 50_000;
  return 30_000;
}

// ───────────────────────── Finals bracket ─────────────────────────
//
// Stop #31 (Shanghai · WORLD FINAL) becomes a single-elimination knockout
// with 8 teams: the player + top 7 AI rivals by tour points. The bracket
// is 8→4→2→1 with separate prizes:
//   QF round (8→4) win: 500,000 coins
//   SF round (4→2) win: 1,000,000 coins
//   3rd-place playoff (Bronze): 1,000,000 coins
//   Final: Gold 10,000,000 · Silver 5,000,000
//
// State persists inside TourState.finalsBracket.

export type BracketRound = "qf" | "sf" | "final" | "bronze" | "done";
export type FinalsMedal = "gold" | "silver" | "bronze" | "none";

export interface BracketTeam {
  id: string;        // "player" | rival.id
  name: string;
  emoji: string;
  baseOvr: number;   // for AI sim of non-player matches
  isPlayer: boolean;
}

export interface BracketMatch {
  round: BracketRound;
  slot: number;          // 0..3 in QF, 0..1 in SF, 0 in Final/Bronze
  a: BracketTeam;
  b: BracketTeam;
  winnerId: string | null;
  scoreA: number;
  scoreB: number;
}

export interface FinalsBracketState {
  teams: BracketTeam[];     // length 8 — seeded by tour-points rank
  matches: BracketMatch[];  // QF(4) + SF(2) + Final(1) + Bronze(1) = 8 slots
  currentRound: BracketRound;
  medal: FinalsMedal;       // player's outcome once round === 'done'
}

/** Per-round coin reward for the PLAYER. */
export const FINALS_REWARDS = {
  qfWin:    500_000,        // win quarterfinal
  sfWin:    1_000_000,      // win semifinal (advance to gold-medal final)
  bronze:   1_000_000,      // win bronze playoff
  silver:   5_000_000,      // lose final
  gold:     1_000_000_000,  // 🏆 win final — 1 BILLION coin grand prize
} as const;

/** Build the 8-team bracket: player + top 7 AI rivals by points. */
export function buildFinalsBracket(
  state: TourState,
  playerName: string,
  playerEmoji: string,
): FinalsBracketState {
  const sortedRivals = [...state.rivals].sort((a, b) => b.totalPoints - a.totalPoints).slice(0, 7);
  const playerOvr = 380; // baseline; AI sim only used when player not in match
  const teams: BracketTeam[] = [
    { id: "player", name: playerName, emoji: playerEmoji, baseOvr: playerOvr, isPlayer: true },
    ...sortedRivals.map(r => ({ id: r.id, name: r.name, emoji: r.emoji, baseOvr: r.baseOvr, isPlayer: false })),
  ];
  // Standard 1v8, 4v5, 3v6, 2v7 seeding so player (top seed) faces weakest opponent first.
  const seedOrder = [0, 7, 3, 4, 2, 5, 1, 6];
  const seeded = seedOrder.map(i => teams[i]);
  const matches: BracketMatch[] = [];
  for (let i = 0; i < 4; i++) {
    matches.push({
      round: "qf", slot: i,
      a: seeded[i * 2], b: seeded[i * 2 + 1],
      winnerId: null, scoreA: 0, scoreB: 0,
    });
  }
  return { teams: seeded, matches, currentRound: "qf", medal: "none" };
}

/** Find the next bracket match the player is in (or null if eliminated/done). */
export function getPlayerNextBracketMatch(b: FinalsBracketState): BracketMatch | null {
  return b.matches.find(m => m.winnerId === null && (m.a.isPlayer || m.b.isPlayer)) ?? null;
}

/** Simulate a non-player match deterministically by OVR + small noise. */
function simBracketMatch(a: BracketTeam, b: BracketTeam): { winnerId: string; scoreA: number; scoreB: number } {
  const noise = () => Math.random() * 10 - 5;
  const aPow = a.baseOvr + noise();
  const bPow = b.baseOvr + noise();
  // Score scales with OVR difference: stronger team scores more.
  const baseA = Math.round(40 + aPow / 12);
  const baseB = Math.round(40 + bPow / 12);
  // Ensure no tie.
  let scoreA = baseA, scoreB = baseB;
  if (scoreA === scoreB) (Math.random() > 0.5 ? scoreA++ : scoreB++);
  return { winnerId: scoreA > scoreB ? a.id : b.id, scoreA, scoreB };
}

/**
 * Apply player's bracket match result and auto-simulate the parallel match
 * in the same round. Advances bracket to next round when the round is full.
 * Returns updated bracket + coin reward for the player from this round.
 */
export function applyBracketResult(
  bracket: FinalsBracketState,
  playerScore: number,
  oppScore: number,
): { bracket: FinalsBracketState; coinsEarned: number; medal: FinalsMedal } {
  const match = getPlayerNextBracketMatch(bracket);
  if (!match) return { bracket, coinsEarned: 0, medal: bracket.medal };

  const playerIsA = match.a.isPlayer;
  const playerWon = playerScore > oppScore;
  const winnerId = playerWon ? (playerIsA ? match.a.id : match.b.id) : (playerIsA ? match.b.id : match.a.id);
  const updatedMatches = bracket.matches.map(m => {
    if (m === match) {
      return {
        ...m,
        winnerId,
        scoreA: playerIsA ? playerScore : oppScore,
        scoreB: playerIsA ? oppScore : playerScore,
      };
    }
    return m;
  });

  // Auto-sim other matches in the same round if any are still pending.
  for (let i = 0; i < updatedMatches.length; i++) {
    const m = updatedMatches[i];
    if (m.round === match.round && m.winnerId === null && !m.a.isPlayer && !m.b.isPlayer) {
      const sim = simBracketMatch(m.a, m.b);
      updatedMatches[i] = { ...m, ...sim };
    }
  }

  // Determine if round is complete → seed the next round.
  const roundDone = updatedMatches.filter(m => m.round === match.round).every(m => m.winnerId !== null);
  let currentRound: BracketRound = bracket.currentRound;
  let medal: FinalsMedal = bracket.medal;
  let coinsEarned = 0;

  // Reward calculation for player.
  if (match.round === "qf") {
    if (playerWon) coinsEarned += FINALS_REWARDS.qfWin;
  } else if (match.round === "sf") {
    if (playerWon) coinsEarned += FINALS_REWARDS.sfWin;
  } else if (match.round === "bronze") {
    if (playerWon) { coinsEarned += FINALS_REWARDS.bronze; medal = "bronze"; }
    else { medal = "none"; }
  } else if (match.round === "final") {
    if (playerWon) { coinsEarned += FINALS_REWARDS.gold; medal = "gold"; }
    else { coinsEarned += FINALS_REWARDS.silver; medal = "silver"; }
  }

  let nextMatches = updatedMatches;
  if (roundDone) {
    if (match.round === "qf") {
      // Build SF from QF winners (slots 0/1 → SF0; 2/3 → SF1)
      const qf = updatedMatches.filter(m => m.round === "qf");
      const winnerOf = (m: BracketMatch) => m.winnerId === m.a.id ? m.a : m.b;
      const sf: BracketMatch[] = [
        { round: "sf", slot: 0, a: winnerOf(qf[0]), b: winnerOf(qf[1]), winnerId: null, scoreA: 0, scoreB: 0 },
        { round: "sf", slot: 1, a: winnerOf(qf[2]), b: winnerOf(qf[3]), winnerId: null, scoreA: 0, scoreB: 0 },
      ];
      nextMatches = [...updatedMatches, ...sf];
      currentRound = "sf";
    } else if (match.round === "sf") {
      // Build Final + Bronze
      const sf = updatedMatches.filter(m => m.round === "sf");
      const winnerOf = (m: BracketMatch) => m.winnerId === m.a.id ? m.a : m.b;
      const loserOf  = (m: BracketMatch) => m.winnerId === m.a.id ? m.b : m.a;
      const final: BracketMatch  = { round: "final",  slot: 0, a: winnerOf(sf[0]), b: winnerOf(sf[1]), winnerId: null, scoreA: 0, scoreB: 0 };
      const bronze: BracketMatch = { round: "bronze", slot: 0, a: loserOf(sf[0]),  b: loserOf(sf[1]),  winnerId: null, scoreA: 0, scoreB: 0 };
      nextMatches = [...updatedMatches, final, bronze];
      // If player lost SF, they go to bronze; otherwise final.
      currentRound = playerWon ? "final" : "bronze";
    } else if (match.round === "final" || match.round === "bronze") {
      // Both final and bronze must be done → tournament over.
      const otherDone = nextMatches.find(m => (m.round === "final" || m.round === "bronze") && m !== match)?.winnerId !== null;
      if (otherDone) currentRound = "done";
      else currentRound = match.round === "final" ? "bronze" : "final";
    }
  }

  return {
    bracket: { ...bracket, matches: nextMatches, currentRound, medal },
    coinsEarned,
    medal,
  };
}

/** Label each round for the UI. */
export const BRACKET_ROUND_LABELS: Record<BracketRound, string> = {
  qf: "Quarterfinals (8 → 4)",
  sf: "Semifinals (4 → 2)",
  final: "Gold Medal Final",
  bronze: "Bronze Medal Match",
  done: "Tournament Complete",
};

