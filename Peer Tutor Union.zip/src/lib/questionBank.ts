import { supabase } from "@/integrations/supabase/client";

export type Subject = { id: string; name: string; club_id?: string | null };

export type KnowledgePoint = { id: string; subject_id: string; name: string; sort_order?: number };

export type QuestionPart = {
  id: string;
  question_id: string;
  label: string;
  prompt: string;
  points: number;
  sample_answer: string | null;
  sample_answer_file_url?: string | null;
  sample_answer_file_name?: string | null;
  sort_order: number;
};

export type Question = {
  id: string;
  subject_id: string;
  knowledge_point_id: string | null;
  club_id: string | null;
  visibility: "public" | "private";
  title?: string | null;
  difficulty: number;
  question_type: "mcq" | "frq";
  stem: string | null;
  stimulus_text: string | null;
  stimulus_file_url: string | null;
  stimulus_file_name: string | null;
  option_a: string | null;
  option_b: string | null;
  option_c: string | null;
  option_d: string | null;
  options?: string[] | null;
  correct_option: string | null;
  explanation: string | null;
  answer_file_url?: string | null;
  answer_file_name?: string | null;
  max_points: number;
  created_by: string;
  created_at: string;
};

export const OPTION_LETTERS = ["A", "B", "C", "D", "E", "F"] as const;

/** Answer choices for an MCQ: the flexible `options` array, falling back to legacy A–D columns. */
export function questionOptions(q: Pick<Question, "options" | "option_a" | "option_b" | "option_c" | "option_d">) {
  const flexible = (q.options || []).filter((t) => t !== null && t !== undefined);
  const list = flexible.length > 0
    ? flexible
    : [q.option_a, q.option_b, q.option_c, q.option_d].filter((t) => t != null && String(t).trim() !== "") as string[];
  return list.slice(0, OPTION_LETTERS.length).map((text, i) => ({ letter: OPTION_LETTERS[i] as string, text: text || "" }));
}

/** Short label for a question in lists. */
export function questionLabel(q: Pick<Question, "title" | "stem">) {
  return (q.title || "").trim() || (q.stem || "").trim() || "Untitled question";
}

export const AUTHOR_ROLES = ["President", "VicePresident", "Teacher"];
export const SUBJECT_MANAGER_ROLES = ["President", "VicePresident"];

/** President / Vice President / Teacher of a club (or a legacy staff display role) can upload questions. */
export function canAuthorQuestions(displayRole?: string, isAdmin?: boolean, clubRole?: string) {
  return !!isAdmin || AUTHOR_ROLES.includes(clubRole || "") || AUTHOR_ROLES.includes(displayRole || "");
}
/** Uploading a new question: authors, plus members with a temporary upload grant. */
export function canUploadQuestions(displayRole?: string, isAdmin?: boolean, clubRole?: string, hasGrant?: boolean) {
  return canAuthorQuestions(displayRole, isAdmin, clubRole) || !!hasGrant;
}
/** Editing or deleting existing questions is never allowed through a temporary grant. */
export const canEditQuestions = canAuthorQuestions;
/** Only President / Vice President can add subjects, knowledge points and set visibility. */
export function canManageSubjects(displayRole?: string, isAdmin?: boolean, clubRole?: string) {
  return !!isAdmin || SUBJECT_MANAGER_ROLES.includes(clubRole || "") || SUBJECT_MANAGER_ROLES.includes(displayRole || "");
}

export const MAX_STIMULUS_BYTES = 20 * 1024 * 1024;
export const ALLOWED_STIMULUS_TYPES = [
  "application/pdf",
  "image/png",
  "image/jpeg",
  "image/webp",
  "image/gif",
  "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
  "application/msword",
];

export async function fetchSubjects(): Promise<Subject[]> {
  const { data } = await supabase.from("subjects").select("id, name, club_id").order("name");
  return (data as Subject[]) || [];
}

export async function addSubject(name: string, userId: string, clubId?: string | null) {
  const clean = name.trim();
  if (!clean) return { error: "Subject name is required" };
  const { data: existing } = await supabase.from("subjects").select("id, name");
  if ((existing || []).some((s) => s.name.trim().toLowerCase() === clean.toLowerCase())) {
    return { error: `Subject "${clean}" already exists` };
  }
  const { error } = await supabase.from("subjects").insert({ name: clean, created_by: userId, club_id: clubId ?? null });
  if (error) {
    return { error: /duplicate|unique/i.test(error.message) ? `Subject "${clean}" already exists` : error.message };
  }
  return { error: null };
}

export async function fetchKnowledgePoints(subjectId?: string): Promise<KnowledgePoint[]> {
  let q = supabase
    .from("knowledge_points")
    .select("id, subject_id, name, sort_order")
    .order("sort_order", { ascending: true })
    .order("name");
  if (subjectId) q = q.eq("subject_id", subjectId);
  const { data } = await q;
  return (data as KnowledgePoint[]) || [];
}

export async function renameKnowledgePoint(id: string, name: string) {
  const clean = name.trim();
  if (!clean) return { error: "Knowledge point name is required" };
  const { error } = await supabase.from("knowledge_points").update({ name: clean }).eq("id", id);
  return { error: error?.message ?? null };
}

export async function deleteKnowledgePoint(id: string) {
  const { error } = await supabase.from("knowledge_points").delete().eq("id", id);
  return { error: error?.message ?? null };
}

/** Persist the given order (index becomes sort_order). */
export async function reorderKnowledgePoints(ids: string[]) {
  const results = await Promise.all(
    ids.map((id, i) => supabase.from("knowledge_points").update({ sort_order: i }).eq("id", id))
  );
  const failed = results.find((r) => r.error);
  return { error: failed?.error?.message ?? null };
}

export async function addKnowledgePoint(subjectId: string, name: string, userId: string) {
  const clean = name.trim();
  if (!clean) return { error: "Knowledge point name is required" };
  if (!subjectId) return { error: "Select a subject first" };
  const existing = await fetchKnowledgePoints(subjectId);
  if (existing.some((k) => k.name.trim().toLowerCase() === clean.toLowerCase())) {
    return { error: `"${clean}" already exists in this subject` };
  }
  const { error } = await supabase
    .from("knowledge_points")
    .insert({ subject_id: subjectId, name: clean, created_by: userId, sort_order: existing.length });
  if (error) {
    return { error: /duplicate|unique/i.test(error.message) ? `"${clean}" already exists in this subject` : error.message };
  }
  return { error: null };
}

/** Upload any supporting file (stimulus, sample answer) to the question-bank folder. */
export const uploadQuestionFile = (file: File) => uploadStimulusFile(file);

export async function uploadStimulusFile(file: File): Promise<{ path?: string; error?: string }> {
  if (!ALLOWED_STIMULUS_TYPES.includes(file.type)) {
    return { error: "Only PDF, DOCX or image files are allowed" };
  }
  if (file.size > MAX_STIMULUS_BYTES) {
    return { error: "File must be smaller than 20MB" };
  }
  const safe = file.name.replace(/[^a-zA-Z0-9._-]/g, "_").slice(-60);
  const path = `question-bank/${Date.now()}_${Math.random().toString(36).slice(2, 8)}_${safe}`;
  const { error } = await supabase.storage.from("attachments").upload(path, file);
  if (error) return { error: error.message };
  return { path };
}

export type QuestionFilters = {
  subjectId?: string;
  knowledgePointId?: string;
  difficulty?: number;
  difficulties?: number[];
  type?: "mcq" | "frq";
  creatorId?: string;
  visibility?: "public" | "private";
  ids?: string[];
};

function applyFilters(q: any, filters: QuestionFilters) {
  if (filters.subjectId) q = q.eq("subject_id", filters.subjectId);
  if (filters.knowledgePointId) q = q.eq("knowledge_point_id", filters.knowledgePointId);
  if (filters.difficulty) q = q.eq("difficulty", filters.difficulty);
  if (filters.difficulties && filters.difficulties.length > 0 && filters.difficulties.length < 3)
    q = q.in("difficulty", filters.difficulties);
  if (filters.type) q = q.eq("question_type", filters.type);
  if (filters.creatorId) q = q.eq("created_by", filters.creatorId);
  if (filters.visibility) q = q.eq("visibility", filters.visibility);
  if (filters.ids) q = q.in("id", filters.ids);
  return q;
}

export async function fetchQuestions(filters: QuestionFilters = {}, limit = 500): Promise<Question[]> {
  let q = supabase.from("questions").select("*").order("created_at", { ascending: false }).limit(limit);
  q = applyFilters(q, filters);
  const { data } = await q;
  return (data as Question[]) || [];
}

/** Live count of questions matching the filters (row-level rules already hide other clubs' private items). */
export async function countQuestions(filters: QuestionFilters = {}): Promise<number> {
  let q = supabase.from("questions").select("id", { count: "exact", head: true });
  q = applyFilters(q, filters);
  const { count } = await q;
  return count || 0;
}

export async function fetchParts(questionIds: string[]): Promise<Record<string, QuestionPart[]>> {
  if (questionIds.length === 0) return {};
  const { data } = await supabase
    .from("question_parts")
    .select("*")
    .in("question_id", questionIds)
    .order("sort_order");
  const grouped: Record<string, QuestionPart[]> = {};
  ((data as QuestionPart[]) || []).forEach((p) => {
    (grouped[p.question_id] ||= []).push(p);
  });
  return grouped;
}

export function questionPoints(q: Question, parts: QuestionPart[] = []): number {
  if (q.question_type === "frq" && parts.length > 0) {
    return parts.reduce((s, p) => s + Number(p.points || 0), 0);
  }
  return Number(q.max_points || 1);
}
