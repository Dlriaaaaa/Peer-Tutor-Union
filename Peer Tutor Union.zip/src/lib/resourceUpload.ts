import { supabase } from "@/integrations/supabase/client";

/**
 * Upload a single file to the resources storage path and create a row in `resources`.
 * Returns the inserted row id, or throws on error.
 */
export async function uploadResourceFile(opts: {
  file: File;
  category: string;          // folder path e.g. "Math / Year1"
  authorId: string;
  title?: string;            // defaults to file name without extension
  description?: string;
  sortOrder?: number;
}): Promise<string> {
  const { file, category, authorId } = opts;
  const lastDot = file.name.lastIndexOf(".");
  const ext = lastDot > -1 ? file.name.slice(lastDot) : "";
  const baseName = lastDot > -1 ? file.name.slice(0, lastDot) : file.name;
  const safeBase = baseName.replace(/[^a-zA-Z0-9-_]/g, "_").slice(0, 50) || "file";
  const safeExt = ext.replace(/[^a-zA-Z0-9.]/g, "");
  const path = `resources/${Date.now()}_${Math.random().toString(36).slice(2, 8)}_${safeBase}${safeExt}`;

  const { error: upErr } = await supabase.storage.from("attachments").upload(path, file);
  if (upErr) throw new Error("Upload failed: " + upErr.message);

  const { data, error } = await supabase
    .from("resources")
    .insert({
      title: opts.title?.trim() || baseName,
      description: opts.description || "",
      file_url: path,
      file_name: file.name,
      category,
      author_id: authorId,
      sort_order: opts.sortOrder ?? 0,
    })
    .select("id")
    .single();
  if (error) throw new Error(error.message);
  return data.id;
}
