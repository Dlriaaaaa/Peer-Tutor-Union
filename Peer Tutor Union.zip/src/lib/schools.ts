import { supabase } from "@/integrations/supabase/client";

export const SUPER_ADMIN_EMAIL = "ria7883@outlook.com";

export type School = {
  id: string;
  country: string;
  region: string;
  city: string;
  name: string;
  is_active: boolean;
};

export type Club = {
  id: string;
  school_id: string;
  name: string;
  description: string | null;
};

export type ClubRole = "President" | "VicePresident" | "Teacher" | "Member";

export type ClubMembership = {
  id: string;
  club_id: string;
  user_id: string;
  club_role: ClubRole;
  status: "pending" | "approved" | "rejected";
};

export const CLUB_ROLES: ClubRole[] = ["President", "VicePresident", "Teacher", "Member"];

export const clubRoleLabel: Record<string, string> = {
  President: "President",
  VicePresident: "Vice President",
  Teacher: "Teacher",
  Member: "Member",
};

export async function fetchSchools(activeOnly = true): Promise<School[]> {
  let q = supabase.from("schools").select("*").order("country").order("region").order("city").order("name");
  if (activeOnly) q = q.eq("is_active", true);
  const { data } = await q;
  return (data as School[]) || [];
}

export async function fetchClubs(schoolId?: string): Promise<Club[]> {
  let q = supabase.from("clubs").select("*").order("name");
  if (schoolId) q = q.eq("school_id", schoolId);
  const { data } = await q;
  return (data as Club[]) || [];
}

export async function fetchMyMemberships(userId: string): Promise<ClubMembership[]> {
  const { data } = await supabase.from("club_members").select("*").eq("user_id", userId);
  return (data as ClubMembership[]) || [];
}

/** Cascading option helpers built from the school registry. */
export function uniqueSorted(values: string[]): string[] {
  return [...new Set(values.filter(Boolean))].sort((a, b) => a.localeCompare(b));
}

export function countriesOf(schools: School[]) {
  return uniqueSorted(schools.map((s) => s.country));
}
export function regionsOf(schools: School[], country: string) {
  return uniqueSorted(schools.filter((s) => s.country === country).map((s) => s.region));
}
export function citiesOf(schools: School[], country: string, region: string) {
  return uniqueSorted(schools.filter((s) => s.country === country && s.region === region).map((s) => s.city));
}
export function schoolsOf(schools: School[], country: string, region: string, city: string) {
  return schools
    .filter((s) => s.country === country && s.region === region && s.city === city)
    .sort((a, b) => a.name.localeCompare(b.name));
}
