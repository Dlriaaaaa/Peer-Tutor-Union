/**
 * Lottery Manager — wheel spin & scratch card game logic.
 *
 * Two products live here:
 *   1. Spin wheel (cost 100/spin, 1000/×10) with fixed top-tier odds:
 *        1,000,000 → 0.01%   100,000 → 0.1%   10,000 → 0.5%
 *        100 (break even) → 20%   remainder → small coins / boost items
 *      The ×10 spin guarantees at least one ≥100 reward (anti-bust).
 *   2. Scratch tickets (face values 100 / 1000 / 100000) — prize pool driven
 *      by the `scratch_card_configs` table, which admins can edit.
 *
 * All purchases are recorded in `lottery_history` for audit.
 */

import { supabase } from "@/integrations/supabase/client";
import {
  getConsumableDef,
  type TeamManager,
} from "@/lib/teamManager";

// ─── Types ─────────────────────────────────────────────────────

export type WheelPrizeKind =
  | "jackpot_1m"
  | "big_100k"
  | "mid_10k"
  | "break_even"
  | "small_50"
  | "small_30"
  | "small_10"
  | "item_water"
  | "item_banana"
  | "item_elixir"
  | "bust";

export interface WheelSlice {
  key: WheelPrizeKind;
  label: string;
  emoji: string;
  /** Percent (0-100). Sum across all slices = 100. */
  weight: number;
  /** Coin payout (0 if item or bust). */
  coins: number;
  /** Optional item reward. */
  item?: { key: string; qty: number };
  /** Tailwind background gradient for the wheel slice. */
  color: string;
}

/** The wheel layout. Top-tier odds are user-spec'd; small slices fill the rest.
 *  Sum = 0.01 + 0.1 + 0.5 + 20 + 25 + 25 + 20 + 4 + 3 + 1 + 1.39 = 100. */
export const WHEEL_SLICES: WheelSlice[] = [
  { key: "jackpot_1m", label: "1,000,000", emoji: "💎", weight: 0.01,  coins: 1_000_000, color: "from-fuchsia-600 to-purple-700" },
  { key: "big_100k",   label: "100,000",   emoji: "🎉", weight: 0.1,   coins: 100_000,   color: "from-orange-500 to-red-600" },
  { key: "mid_10k",    label: "10,000",    emoji: "💰", weight: 0.5,   coins: 10_000,    color: "from-yellow-400 to-amber-500" },
  { key: "break_even", label: "100",       emoji: "🪙", weight: 20,    coins: 100,       color: "from-emerald-500 to-green-600" },
  { key: "small_50",   label: "50",        emoji: "🪙", weight: 25,    coins: 50,        color: "from-sky-500 to-blue-600" },
  { key: "small_30",   label: "30",        emoji: "🪙", weight: 25,    coins: 30,        color: "from-indigo-500 to-violet-600" },
  { key: "small_10",   label: "10",        emoji: "🪙", weight: 20,    coins: 10,        color: "from-slate-500 to-slate-700" },
  { key: "item_water", label: "Water",     emoji: "💧", weight: 4,     coins: 0, item: { key: "water",        qty: 1 }, color: "from-cyan-400 to-sky-600" },
  { key: "item_banana",label: "Banana",    emoji: "🍌", weight: 3,     coins: 0, item: { key: "banana",       qty: 1 }, color: "from-yellow-300 to-yellow-500" },
  { key: "item_elixir",label: "Elixir",    emoji: "✨", weight: 1,     coins: 0, item: { key: "elixir",       qty: 1 }, color: "from-pink-400 to-rose-600" },
  { key: "bust",       label: "Try Again", emoji: "💔", weight: 1.39,  coins: 0,         color: "from-zinc-700 to-zinc-900" },
];

export const SPIN_COST = 100;
export const SPIN_X10_COST = 1000;

// ─── Golden Gacha (奖池 = 大转盘 × 100) ─────────────────────────
export const GOLDEN_MULTIPLIER = 100;
export const GOLDEN_COST = 10_000;
export const GOLDEN_X10_COST = 100_000;
export const GOLDEN_X100_COST = 5_000_000;

/** Wheel slices scaled ×100 for the Golden Gacha. Items get qty×3 to feel premium. */
export const GOLDEN_SLICES: WheelSlice[] = WHEEL_SLICES.map(s => ({
  ...s,
  coins: s.coins * GOLDEN_MULTIPLIER,
  // Scale the displayed label too when it's a coin payout.
  label: s.coins > 0 ? (s.coins * GOLDEN_MULTIPLIER).toLocaleString() : s.label,
  item: s.item ? { key: s.item.key, qty: s.item.qty * 3 } : undefined,
}));

// ─── Spin wheel ────────────────────────────────────────────────

/** Roll a single slice from the weighted wheel. */
export function rollWheelSlice(): WheelSlice {
  const total = WHEEL_SLICES.reduce((s, x) => s + x.weight, 0);
  let r = Math.random() * total;
  for (const s of WHEEL_SLICES) {
    r -= s.weight;
    if (r <= 0) return s;
  }
  return WHEEL_SLICES[WHEEL_SLICES.length - 1];
}

/** Roll N slices. If `guaranteePayback`, ensures at least one ≥SPIN_COST. */
export function rollWheelN(n: number, guaranteePayback: boolean): WheelSlice[] {
  const out: WheelSlice[] = [];
  for (let i = 0; i < n; i++) out.push(rollWheelSlice());
  if (guaranteePayback && !out.some(s => s.coins >= SPIN_COST)) {
    // Replace the lowest result with a guaranteed break-even slice.
    let worstIdx = 0;
    for (let i = 1; i < out.length; i++) if (out[i].coins < out[worstIdx].coins) worstIdx = i;
    out[worstIdx] = WHEEL_SLICES.find(s => s.key === "break_even")!;
  }
  return out;
}

export interface SpinResult {
  updatedTeam: TeamManager;
  slices: WheelSlice[];
  totalCoins: number;
}

/**
 * Spend coins to spin the wheel N times, then credit rewards atomically.
 * `n=1` → SPIN_COST, `n=10` → SPIN_X10_COST (with payback guarantee).
 */
export async function spinWheel(team: TeamManager, n: 1 | 10): Promise<SpinResult> {
  return serverSpin(team, n === 1 ? "spin" : "spin_x10", WHEEL_SLICES);
}

/** Shared helper: the server rolls, pays and logs; we just map the returned keys. */
async function serverSpin(
  team: TeamManager,
  kind: string,
  pool: WheelSlice[],
): Promise<SpinResult> {
  const { data, error } = await supabase.rpc("spin_lottery" as any, { _kind: kind });
  if (error) throw new Error(error.message);
  const res = data as any;
  const slices: WheelSlice[] = (res.slice_keys ?? []).map(
    (k: string) => pool.find(s => s.key === k) ?? pool[pool.length - 1],
  );
  const { data: updated } = await supabase
    .from("team_managers").select("*").eq("id", team.id).single();
  return {
    updatedTeam: (updated ?? { ...team, coins: res.coins }) as TeamManager,
    slices,
    totalCoins: Number(res.total_coins ?? 0),
  };
}


// ─── Golden Gacha spin ─────────────────────────────────────────

/** Roll one slice from the Golden pool (same weights, 100× payout). */
function rollGoldenSlice(): WheelSlice {
  const total = GOLDEN_SLICES.reduce((s, x) => s + x.weight, 0);
  let r = Math.random() * total;
  for (const s of GOLDEN_SLICES) {
    r -= s.weight;
    if (r <= 0) return s;
  }
  return GOLDEN_SLICES[GOLDEN_SLICES.length - 1];
}

/** Roll N golden slices, with optional payback guarantee (≥ break-even). */
function rollGoldenN(n: number, guaranteePayback: boolean): WheelSlice[] {
  const out: WheelSlice[] = [];
  for (let i = 0; i < n; i++) out.push(rollGoldenSlice());
  if (guaranteePayback && !out.some(s => s.coins >= 100 * GOLDEN_MULTIPLIER)) {
    let worstIdx = 0;
    for (let i = 1; i < out.length; i++) if (out[i].coins < out[worstIdx].coins) worstIdx = i;
    out[worstIdx] = GOLDEN_SLICES.find(s => s.key === "break_even")!;
  }
  return out;
}

/**
 * Pull the Golden Gacha. Pricing:
 *   1×   = $10,000
 *   10×  = $100,000
 *   100× = $5,000,000  (discounted from $1M sticker; guarantees a ≥10k payout)
 */
export async function pullGoldenGacha(
  team: TeamManager,
  n: 1 | 10 | 100,
): Promise<SpinResult> {
  const kind = n === 1 ? "golden" : n === 10 ? "golden_x10" : "golden_x100";
  return serverSpin(team, kind, GOLDEN_SLICES);
}


// ─── Scratch cards ─────────────────────────────────────────────

export type ScratchFace = 100 | 1000 | 100000 | 2000000;
export const SCRATCH_FACE_VALUES: ScratchFace[] = [100, 1000, 100000, 2000000];

export interface ScratchPrize {
  kind: "coins" | "item";
  amount?: number;
  item_key?: string;
  qty?: number;
  weight: number;
  label: string;
}

export interface ScratchConfig {
  id: string;
  face_value: ScratchFace;
  prizes: ScratchPrize[];
  updated_at: string;
}

export async function loadScratchConfigs(): Promise<ScratchConfig[]> {
  const { data, error } = await supabase
    .from("scratch_card_configs" as any)
    .select("*")
    .order("face_value", { ascending: true });
  if (error) throw error;
  return ((data ?? []) as any[]).map(r => ({
    id: r.id,
    face_value: r.face_value as ScratchFace,
    prizes: (r.prizes ?? []) as ScratchPrize[],
    updated_at: r.updated_at,
  }));
}

export async function saveScratchConfig(face_value: ScratchFace, prizes: ScratchPrize[]): Promise<void> {
  const { error } = await supabase
    .from("scratch_card_configs" as any)
    .update({ prizes })
    .eq("face_value", face_value);
  if (error) throw error;
}

/** Pick one prize from a config's weighted prize list. */
export function rollScratchPrize(config: ScratchConfig): ScratchPrize {
  const total = config.prizes.reduce((s, p) => s + p.weight, 0);
  if (total <= 0) {
    return { kind: "coins", amount: 0, weight: 1, label: "Bust" };
  }
  let r = Math.random() * total;
  for (const p of config.prizes) {
    r -= p.weight;
    if (r <= 0) return p;
  }
  return config.prizes[config.prizes.length - 1];
}

export interface ScratchPanelResult {
  prize: ScratchPrize;
  /**
   * 16 tiles (4×4 grid) shown on the card. The won `prize` appears at the
   * indices listed in `winningTiles` (3 tiles — match-3 mechanic). The
   * remaining 13 tiles are random filler prizes from the pool, used for
   * decoration only — they do NOT award anything.
   */
  panels: ScratchPrize[];
  winningTiles: number[];
}

export const SCRATCH_TILE_COUNT = 16;
export const SCRATCH_MATCH_COUNT = 3;

export interface ScratchBuyResult {
  updatedTeam: TeamManager;
  result: ScratchPanelResult;
}

/** Pick `n` distinct random indices in [0, total). */
function pickIndices(total: number, n: number): number[] {
  const pool = Array.from({ length: total }, (_, i) => i);
  for (let i = pool.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [pool[i], pool[j]] = [pool[j], pool[i]];
  }
  return pool.slice(0, n);
}

/**
 * Buy a scratch ticket. Coin cost is deducted up front; the prize is credited
 * immediately (the UI plays a reveal animation but the result is already final).
 */
export async function buyScratchTicket(
  team: TeamManager,
  face_value: ScratchFace,
): Promise<ScratchBuyResult> {
  if (team.coins < face_value) throw new Error(`Need $${face_value.toLocaleString()}`);

  const configs = await loadScratchConfigs();
  const config = configs.find(c => c.face_value === face_value);
  if (!config || config.prizes.length === 0) throw new Error("Scratch card not configured");

  // The server rolls the prize, charges the ticket and credits the reward.
  const { data, error } = await supabase.rpc("buy_scratch_ticket" as any, { _face: face_value });
  if (error) throw new Error(error.message);
  const prize = ((data as any)?.prize ?? { kind: "coins", amount: 0, weight: 1, label: "Bust" }) as ScratchPrize;

  // Build the 16-tile grid: the prize appears 3 times (match-3), the
  // remaining 13 slots are random fillers — decoration only.
  const winningTiles = pickIndices(SCRATCH_TILE_COUNT, SCRATCH_MATCH_COUNT);
  const winningSet = new Set(winningTiles);
  const panels: ScratchPrize[] = Array.from({ length: SCRATCH_TILE_COUNT }, (_, i) =>
    winningSet.has(i) ? prize : rollScratchPrize(config),
  );

  const { data: updated } = await supabase
    .from("team_managers").select("*").eq("id", team.id).single();

  return {
    updatedTeam: (updated ?? { ...team, coins: (data as any)?.coins ?? team.coins }) as TeamManager,
    result: { prize, panels, winningTiles },
  };
}


/** Friendly label for a scratch prize (for toasts / history). */
export function describeScratchPrize(prize: ScratchPrize): string {
  if (prize.kind === "coins") return `$${(prize.amount ?? 0).toLocaleString()}`;
  const def = getConsumableDef(prize.item_key ?? "");
  return `${def?.emoji ?? "🎁"} ${def?.name ?? prize.item_key} ×${prize.qty ?? 1}`;
}
