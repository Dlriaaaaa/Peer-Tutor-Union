import type { School } from "@/lib/schools";

/** How far a post travels: from the whole network down to a single school. */
export type FeedScope = "global" | "country" | "region" | "city" | "school";

export const FEED_SCOPES: FeedScope[] = ["global", "country", "region", "city", "school"];

export const feedScopeLabel: Record<FeedScope, string> = {
  global: "Everyone",
  country: "My country",
  region: "My region",
  city: "My city",
  school: "My school",
};

export const feedScopeHint: Record<FeedScope, string> = {
  global: "Visible to every school on the platform",
  country: "Visible to schools in your country",
  region: "Visible to schools in your region",
  city: "Visible to schools in your city",
  school: "Visible only inside your school",
};

function sameLevel(a: School | undefined, b: School | undefined, level: FeedScope) {
  if (level === "global") return true;
  if (!a || !b) return false;
  if (level === "school") return a.id === b.id;
  if (level === "city") return a.country === b.country && a.region === b.region && a.city === b.city;
  if (level === "region") return a.country === b.country && a.region === b.region;
  return a.country === b.country;
}

/** Can a viewer at `mine` see a post published from `theirs` with the given scope? */
export function canSeePost(scope: FeedScope, theirs?: School, mine?: School) {
  return sameLevel(theirs, mine, scope);
}

/** Does the post fall inside the level the viewer is currently browsing? */
export function matchesFilter(filter: FeedScope, theirs?: School, mine?: School) {
  return sameLevel(theirs, mine, filter);
}
