export const AP_SUBJECTS = [
  "AP Calculus",
  "AP Chemistry",
  "AP Physics",
  "AP Microeconomics",
  "AP Macroeconomics",
  "AP Biology",
] as const;

export type ApSubject = (typeof AP_SUBJECTS)[number];
