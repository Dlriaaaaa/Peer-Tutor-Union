export type DisplayRole =
  | "President"
  | "VicePresident"
  | "Teacher"
  | "GeneralSecretary"
  | "VIPStudent"
  | "Student"
  | "Mascot"
  | "BadStudent"
  | "Deadbeat"
  | "Gay";

export const roleBorderColor: Record<string, string> = {
  President: "ring-amber-400",
  VicePresident: "ring-blue-400",
  Teacher: "ring-emerald-400",
  GeneralSecretary: "ring-purple-400",
  VIPStudent: "ring-yellow-400",
  Student: "ring-muted-foreground/30",
  Mascot: "ring-pink-400",
  BadStudent: "ring-red-500",
  Deadbeat: "ring-orange-600",
  Gay: "ring-fuchsia-400",
};

export const roleLabel: Record<string, string> = {
  President: "President",
  VicePresident: "Vice President",
  Teacher: "Teacher",
  GeneralSecretary: "General Secretary",
  VIPStudent: "VIP Student",
  Student: "Student",
  Mascot: "吉祥物",
  BadStudent: "Bad Student",
  Deadbeat: "老赖",
  Gay: "Gay",
};

export function getRoleBorderClass(displayRole?: string): string {
  return `ring-2 ${roleBorderColor[displayRole || "Student"] || roleBorderColor.Student}`;
}

// Roles that are "staff" (not just students)
const STAFF_ROLES = ["President", "VicePresident", "Teacher", "GeneralSecretary"];

/**
 * Can access AI tools at all. BadStudent is blocked entirely.
 * Regular students can access but are gated by their AI credit balance.
 */
export function canUseAI(displayRole?: string): boolean {
  if (!displayRole) return false;
  return displayRole !== "BadStudent";
}

/**
 * Has unlimited AI usage (no per-message charge). Only VIP students + staff.
 * Everyone else must pay from their ai_credits balance.
 */
export function canUseAIUnlimited(displayRole?: string): boolean {
  if (!displayRole) return false;
  return displayRole === "VIPStudent" || STAFF_ROLES.includes(displayRole);
}

/** Can publish posts on the dashboard. BadStudent cannot. */
export function canPost(displayRole?: string): boolean {
  return displayRole !== "BadStudent";
}

/** Can use the chat feature at all. BadStudent cannot. */
export function canChat(displayRole?: string): boolean {
  return displayRole !== "BadStudent";
}
