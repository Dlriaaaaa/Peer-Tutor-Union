/**
 * gameSounds — Lightweight WebAudio sound effects for the basketball game.
 *
 * Uses synthesized tones (no asset downloads). The AudioContext is lazily
 * created on the first user-triggered play to satisfy browser autoplay rules.
 *
 * Public API:
 *   playShoot()     — short upward whoosh, used when a player releases a shot
 *   playScore()     — bell + cheer, used when a basket is made
 *   playFootstep()  — soft tap, throttled internally, used while players run
 *   playJump()      — quick low thump for jumps (optional)
 *   setSoundEnabled(b) / isSoundEnabled()
 */
let ctx: AudioContext | null = null;
let masterGain: GainNode | null = null;
let enabled = true;

function getCtx(): AudioContext | null {
  if (typeof window === "undefined") return null;
  if (!ctx) {
    try {
      const Ctor = (window.AudioContext || (window as any).webkitAudioContext) as typeof AudioContext;
      if (!Ctor) return null;
      ctx = new Ctor();
      masterGain = ctx.createGain();
      masterGain.gain.value = 0.35;
      masterGain.connect(ctx.destination);
    } catch {
      ctx = null;
    }
  }
  // Try to resume if suspended (autoplay policy)
  if (ctx && ctx.state === "suspended") void ctx.resume();
  return ctx;
}

export function setSoundEnabled(v: boolean) { enabled = v; }
export function isSoundEnabled() { return enabled; }

/** Quick whoosh for shot release. */
export function playShoot() {
  if (!enabled) return;
  const c = getCtx(); if (!c || !masterGain) return;
  const t0 = c.currentTime;
  const osc = c.createOscillator();
  const gain = c.createGain();
  osc.type = "triangle";
  osc.frequency.setValueAtTime(620, t0);
  osc.frequency.exponentialRampToValueAtTime(180, t0 + 0.18);
  gain.gain.setValueAtTime(0.0001, t0);
  gain.gain.exponentialRampToValueAtTime(0.45, t0 + 0.02);
  gain.gain.exponentialRampToValueAtTime(0.001, t0 + 0.22);
  osc.connect(gain).connect(masterGain);
  osc.start(t0);
  osc.stop(t0 + 0.25);
}

/** Bell + cheer for a made basket. */
export function playScore() {
  if (!enabled) return;
  const c = getCtx(); if (!c || !masterGain) return;
  const t0 = c.currentTime;
  // Bell — two stacked sine partials
  [880, 1320].forEach((freq, i) => {
    const osc = c.createOscillator();
    const gain = c.createGain();
    osc.type = "sine";
    osc.frequency.value = freq;
    gain.gain.setValueAtTime(0.0001, t0);
    gain.gain.exponentialRampToValueAtTime(i === 0 ? 0.5 : 0.3, t0 + 0.01);
    gain.gain.exponentialRampToValueAtTime(0.001, t0 + 0.6);
    osc.connect(gain).connect(masterGain);
    osc.start(t0);
    osc.stop(t0 + 0.65);
  });
  // Crowd "cheer" — short noise burst, band-passed
  const noiseLen = 0.55;
  const buffer = c.createBuffer(1, Math.floor(c.sampleRate * noiseLen), c.sampleRate);
  const data = buffer.getChannelData(0);
  for (let i = 0; i < data.length; i++) data[i] = (Math.random() * 2 - 1) * (1 - i / data.length);
  const noise = c.createBufferSource();
  noise.buffer = buffer;
  const bp = c.createBiquadFilter();
  bp.type = "bandpass";
  bp.frequency.value = 1800;
  bp.Q.value = 0.6;
  const ng = c.createGain();
  ng.gain.value = 0.25;
  noise.connect(bp).connect(ng).connect(masterGain);
  noise.start(t0 + 0.05);
}

/** Soft running tap. Throttled so callers can fire freely each frame. */
let lastFootstepAt = 0;
export function playFootstep() {
  if (!enabled) return;
  const now = performance.now();
  if (now - lastFootstepAt < 230) return;
  lastFootstepAt = now;
  const c = getCtx(); if (!c || !masterGain) return;
  const t0 = c.currentTime;
  const osc = c.createOscillator();
  const gain = c.createGain();
  osc.type = "sine";
  osc.frequency.setValueAtTime(180, t0);
  osc.frequency.exponentialRampToValueAtTime(80, t0 + 0.06);
  gain.gain.setValueAtTime(0.0001, t0);
  gain.gain.exponentialRampToValueAtTime(0.18, t0 + 0.01);
  gain.gain.exponentialRampToValueAtTime(0.001, t0 + 0.09);
  osc.connect(gain).connect(masterGain);
  osc.start(t0);
  osc.stop(t0 + 0.1);
}

/** Low thump for jumps (used sparingly). */
let lastJumpAt = 0;
export function playJump() {
  if (!enabled) return;
  const now = performance.now();
  if (now - lastJumpAt < 120) return;
  lastJumpAt = now;
  const c = getCtx(); if (!c || !masterGain) return;
  const t0 = c.currentTime;
  const osc = c.createOscillator();
  const gain = c.createGain();
  osc.type = "sine";
  osc.frequency.setValueAtTime(220, t0);
  osc.frequency.exponentialRampToValueAtTime(110, t0 + 0.12);
  gain.gain.setValueAtTime(0.0001, t0);
  gain.gain.exponentialRampToValueAtTime(0.22, t0 + 0.01);
  gain.gain.exponentialRampToValueAtTime(0.001, t0 + 0.14);
  osc.connect(gain).connect(masterGain);
  osc.start(t0);
  osc.stop(t0 + 0.16);
}
