import { supabase } from "@/integrations/supabase/client";
import { uploadResourceFile } from "@/lib/resourceUpload";
import { toast } from "sonner";
import type { FolderItem, ResourceItem } from "@/components/resources/ResourceTree";
import { buildPath } from "@/components/resources/ResourceTree";

type DragPayload = { kind: "folder"; id: string } | { kind: "file"; id: string };
type DropTarget = { kind: "file" | "folder"; id: string } | { kind: "root" };

/**
 * Handle a drop event from ResourceTree.
 * Performs the necessary DB writes, then calls onChanged() to refresh.
 *
 * Drop semantics:
 *  - External files dropped on a folder → upload into that folder
 *  - External files dropped on a file row → upload into that file's folder
 *  - External files dropped on root → must have a folder; we ignore (can't upload to root)
 *  - Internal file dropped on folder → change file.category to that folder's path, append to end
 *  - Internal file dropped on another file → reorder within target file's folder, place AFTER target
 *  - Internal folder dropped on folder → re-parent (cannot drop into self/descendant)
 *  - Internal folder dropped on root → make it root-level
 *  - Internal folder dropped on file → re-parent into the file's folder
 */
export async function handleResourceDrop(args: {
  target: DropTarget;
  payload: DragPayload | null;
  files: FileList | null;
  folders: FolderItem[];
  resources: ResourceItem[];
  authorId: string;
  onChanged: () => void;
}) {
  const { target, payload, files, folders, resources, authorId, onChanged } = args;

  // Resolve the destination folder path (where dropped items land).
  const resolveDestFolderPath = (): string | null => {
    if (target.kind === "folder") {
      const f = folders.find(x => x.id === target.id);
      return f ? buildPath(f, folders) : null;
    }
    if (target.kind === "file") {
      const r = resources.find(x => x.id === target.id);
      return r?.category ?? null;
    }
    return null; // root
  };

  // ---- 1) External files: upload ----
  if (files && files.length > 0) {
    const destPath = resolveDestFolderPath();
    if (!destPath) {
      toast.error("Drop files onto a folder to upload");
      return;
    }
    const existing = resources.filter(r => r.category === destPath);
    let nextOrder = existing.length;
    let success = 0;
    for (const file of Array.from(files)) {
      try {
        await uploadResourceFile({ file, category: destPath, authorId, sortOrder: nextOrder++ });
        success++;
      } catch (e: any) {
        toast.error(`Upload failed: ${file.name} — ${e.message}`);
      }
    }
    if (success > 0) toast.success(`Uploaded ${success} file${success > 1 ? "s" : ""} to ${destPath}`);
    onChanged();
    return;
  }

  if (!payload) return;

  // ---- 2) Internal file move/reorder ----
  if (payload.kind === "file") {
    const src = resources.find(r => r.id === payload.id);
    if (!src) return;

    if (target.kind === "folder") {
      const f = folders.find(x => x.id === target.id);
      if (!f) return;
      const destPath = buildPath(f, folders);
      const siblings = resources.filter(r => r.category === destPath && r.id !== src.id);
      await supabase.from("resources")
        .update({ category: destPath, sort_order: siblings.length })
        .eq("id", src.id);
      toast.success(`Moved to ${destPath}`);
      onChanged();
      return;
    }

    if (target.kind === "file") {
      const tgt = resources.find(r => r.id === target.id);
      if (!tgt || tgt.id === src.id) return;
      const destPath = tgt.category;
      // Reorder: place src right AFTER tgt within destPath
      const sameFolder = resources
        .filter(r => r.category === destPath && r.id !== src.id)
        .sort((a, b) => (a.sort_order ?? 0) - (b.sort_order ?? 0));
      const tgtIdx = sameFolder.findIndex(r => r.id === tgt.id);
      const newOrder = [
        ...sameFolder.slice(0, tgtIdx + 1),
        src,
        ...sameFolder.slice(tgtIdx + 1),
      ];
      await Promise.all(newOrder.map((r, i) =>
        supabase.from("resources").update({ category: destPath, sort_order: i }).eq("id", r.id)
      ));
      onChanged();
      return;
    }
    // Drop on root: not supported for files (need a folder)
    toast.error("Files must be inside a folder");
    return;
  }

  // ---- 3) Internal folder move/reparent ----
  if (payload.kind === "folder") {
    const src = folders.find(f => f.id === payload.id);
    if (!src) return;

    // Compute new parent_id
    let newParentId: string | null = null;
    if (target.kind === "folder") {
      newParentId = target.id;
    } else if (target.kind === "file") {
      const r = resources.find(x => x.id === target.id);
      // Find folder by path for that file
      const f = folders.find(ff => buildPath(ff, folders) === r?.category);
      newParentId = f?.id ?? null;
    } else {
      newParentId = null; // root
    }

    if (newParentId === src.id) return;
    // Prevent dropping onto own descendant
    const isDescendant = (candidate: string | null): boolean => {
      let cur = candidate;
      while (cur) {
        if (cur === src.id) return true;
        const p = folders.find(f => f.id === cur);
        cur = p?.parent_id ?? null;
      }
      return false;
    };
    if (isDescendant(newParentId)) {
      toast.error("Cannot move folder into itself or a sub-folder");
      return;
    }

    const oldPath = buildPath(src, folders);
    const updatedSrc = { ...src, parent_id: newParentId };
    const newPath = buildPath(updatedSrc, folders.map(f => f.id === src.id ? updatedSrc : f));

    const newSiblings = folders.filter(f => f.parent_id === newParentId && f.id !== src.id);
    const { error } = await supabase.from("resource_folders")
      .update({ parent_id: newParentId, sort_order: newSiblings.length })
      .eq("id", src.id);
    if (error) { toast.error(error.message); return; }

    // Update categories for all resources under this folder (and descendants)
    if (oldPath !== newPath) {
      const affected = resources.filter(r => r.category === oldPath || r.category.startsWith(oldPath + " / "));
      await Promise.all(affected.map(r => {
        const newCat = newPath + r.category.slice(oldPath.length);
        return supabase.from("resources").update({ category: newCat }).eq("id", r.id);
      }));
    }
    toast.success(`Moved folder to ${newPath}`);
    onChanged();
  }
}
