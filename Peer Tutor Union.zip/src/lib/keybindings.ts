/**
 * Custom key bindings for BasketballGame.
 * Persisted in localStorage. Two slots:
 *   - p1 = primary human (red team) — defaults to WASD + F + G + R
 *   - p2 = secondary human (blue team) — defaults to arrows + . + , + /
 *
 * Stored as lowercased KeyboardEvent.key values (so "arrowup", "a", ".", etc.).
 * The BasketballGame engine looks up keys via this same lowercased form.
 */

export type ActionKey = "left" | "right" | "jump" | "shoot" | "steal" | "sprint";

export type SlotBindings = Record<ActionKey, string>;

export type AllBindings = {
  p1: SlotBindings;
  p2: SlotBindings;
};

export const DEFAULT_BINDINGS: AllBindings = {
  p1: {
    left: "a",
    right: "d",
    jump: "w",
    shoot: "f",
    steal: "g",
    sprint: "r",
  },
  p2: {
    left: "arrowleft",
    right: "arrowright",
    jump: "arrowup",
    shoot: ".",
    steal: ",",
    sprint: "/",
  },
};

const STORAGE_KEY = "nmba.basketball.keybindings.v1";

export const ACTION_LABELS: Record<ActionKey, string> = {
  left: "← Move Left",
  right: "→ Move Right",
  jump: "Jump",
  shoot: "Shoot",
  steal: "Steal",
  sprint: "Sprint",
};

/** Pretty display for a stored key (e.g. "arrowleft" → "←", " " → "Space"). */
export function prettyKey(k: string): string {
  if (!k) return "—";
  const map: Record<string, string> = {
    arrowleft: "←",
    arrowright: "→",
    arrowup: "↑",
    arrowdown: "↓",
    " ": "Space",
    spacebar: "Space",
    escape: "Esc",
    enter: "Enter",
    tab: "Tab",
    shift: "Shift",
    control: "Ctrl",
    alt: "Alt",
    meta: "Meta",
  };
  return map[k] ?? k.toUpperCase();
}

function isValidSlot(s: unknown): s is SlotBindings {
  if (!s || typeof s !== "object") return false;
  const required: ActionKey[] = ["left", "right", "jump", "shoot", "steal", "sprint"];
  return required.every((k) => typeof (s as Record<string, unknown>)[k] === "string");
}

export function loadBindings(): AllBindings {
  if (typeof window === "undefined") return DEFAULT_BINDINGS;
  try {
    const raw = window.localStorage.getItem(STORAGE_KEY);
    if (!raw) return DEFAULT_BINDINGS;
    const parsed = JSON.parse(raw);
    if (parsed && isValidSlot(parsed.p1) && isValidSlot(parsed.p2)) {
      return parsed as AllBindings;
    }
  } catch {
    // ignore
  }
  return DEFAULT_BINDINGS;
}

export function saveBindings(b: AllBindings): void {
  if (typeof window === "undefined") return;
  try {
    window.localStorage.setItem(STORAGE_KEY, JSON.stringify(b));
    // Notify listeners (other tabs + same tab) so the engine can pick up
    // changes without requiring a page reload.
    window.dispatchEvent(new CustomEvent("nmba-keybindings-changed"));
  } catch {
    // ignore
  }
}

export function resetBindings(): AllBindings {
  saveBindings(DEFAULT_BINDINGS);
  return DEFAULT_BINDINGS;
}

/** Flat set of every key the engine should preventDefault on (so browser
 *  shortcuts like arrows/space scrolling don't fight us). */
export function activeControlKeys(b: AllBindings = loadBindings()): Set<string> {
  const keys = new Set<string>();
  (Object.keys(b) as Array<keyof AllBindings>).forEach((slot) => {
    Object.values(b[slot]).forEach((k) => keys.add(k.toLowerCase()));
  });
  return keys;
}
