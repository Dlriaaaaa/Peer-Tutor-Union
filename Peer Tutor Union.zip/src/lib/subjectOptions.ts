import { useEffect, useState } from "react";
import { fetchSubjects } from "@/lib/questionBank";
import { AP_SUBJECTS } from "@/lib/subjects";

export const OTHER_SUBJECT = "__other";

/** Subject names maintained in the question bank, so every module stays in sync. */
export async function fetchSubjectNames(): Promise<string[]> {
  const subjects = await fetchSubjects();
  const names = subjects.map((s) => s.name.trim()).filter(Boolean);
  const merged = [...new Set([...names, ...AP_SUBJECTS])];
  return merged.sort((a, b) => a.localeCompare(b));
}

/** Shared subject list for tutoring, study groups and anywhere else a subject is picked. */
export function useSubjectOptions() {
  const [subjectNames, setSubjectNames] = useState<string[]>([]);

  const reload = () => { fetchSubjectNames().then(setSubjectNames); };
  useEffect(() => { reload(); }, []);

  return { subjectNames, reload };
}
