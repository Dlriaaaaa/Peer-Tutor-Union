export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[]

export type Database = {
  // Allows to automatically instantiate createClient with right options
  // instead of createClient<Database, { PostgrestVersion: 'XX' }>(URL, KEY)
  __InternalSupabase: {
    PostgrestVersion: "14.5"
  }
  public: {
    Tables: {
      ai_credits: {
        Row: {
          balance: number
          created_at: string
          id: string
          price_per_1k_input: number
          price_per_1k_output: number
          price_per_message: number
          updated_at: string
          user_id: string
        }
        Insert: {
          balance?: number
          created_at?: string
          id?: string
          price_per_1k_input?: number
          price_per_1k_output?: number
          price_per_message?: number
          updated_at?: string
          user_id: string
        }
        Update: {
          balance?: number
          created_at?: string
          id?: string
          price_per_1k_input?: number
          price_per_1k_output?: number
          price_per_message?: number
          updated_at?: string
          user_id?: string
        }
        Relationships: []
      }
      ai_training_data: {
        Row: {
          content: string
          created_at: string
          created_by: string
          id: string
          source_type: string
          title: string
          updated_at: string
        }
        Insert: {
          content?: string
          created_at?: string
          created_by: string
          id?: string
          source_type?: string
          title: string
          updated_at?: string
        }
        Update: {
          content?: string
          created_at?: string
          created_by?: string
          id?: string
          source_type?: string
          title?: string
          updated_at?: string
        }
        Relationships: []
      }
      assignments: {
        Row: {
          category_id: string
          created_at: string
          id: string
          max_score: number
          name: string
        }
        Insert: {
          category_id: string
          created_at?: string
          id?: string
          max_score?: number
          name: string
        }
        Update: {
          category_id?: string
          created_at?: string
          id?: string
          max_score?: number
          name?: string
        }
        Relationships: [
          {
            foreignKeyName: "assignments_category_id_fkey"
            columns: ["category_id"]
            isOneToOne: false
            referencedRelation: "grade_categories"
            referencedColumns: ["id"]
          },
        ]
      }
      awards: {
        Row: {
          description: string | null
          granted_at: string
          granted_by: string | null
          id: string
          student_id: string
          title: string
        }
        Insert: {
          description?: string | null
          granted_at?: string
          granted_by?: string | null
          id?: string
          student_id: string
          title: string
        }
        Update: {
          description?: string | null
          granted_at?: string
          granted_by?: string | null
          id?: string
          student_id?: string
          title?: string
        }
        Relationships: []
      }
      bot_personas: {
        Row: {
          avatar_url: string | null
          created_at: string
          created_by: string
          id: string
          is_enabled: boolean
          name: string
          system_prompt: string
          updated_at: string
        }
        Insert: {
          avatar_url?: string | null
          created_at?: string
          created_by: string
          id?: string
          is_enabled?: boolean
          name?: string
          system_prompt?: string
          updated_at?: string
        }
        Update: {
          avatar_url?: string | null
          created_at?: string
          created_by?: string
          id?: string
          is_enabled?: boolean
          name?: string
          system_prompt?: string
          updated_at?: string
        }
        Relationships: []
      }
      celebrities: {
        Row: {
          badge_color: string
          badge_icon: string
          badge_style: string
          created_at: string
          follower_multiplier: number
          follower_multiplier_changed_at: string
          id: string
          likes_multiplier: number
          likes_multiplier_changed_at: string
          title: string
          user_id: string
          virtual_follower_seed: number
        }
        Insert: {
          badge_color?: string
          badge_icon?: string
          badge_style?: string
          created_at?: string
          follower_multiplier?: number
          follower_multiplier_changed_at?: string
          id?: string
          likes_multiplier?: number
          likes_multiplier_changed_at?: string
          title?: string
          user_id: string
          virtual_follower_seed?: number
        }
        Update: {
          badge_color?: string
          badge_icon?: string
          badge_style?: string
          created_at?: string
          follower_multiplier?: number
          follower_multiplier_changed_at?: string
          id?: string
          likes_multiplier?: number
          likes_multiplier_changed_at?: string
          title?: string
          user_id?: string
          virtual_follower_seed?: number
        }
        Relationships: []
      }
      club_members: {
        Row: {
          club_id: string
          club_role: string
          created_at: string
          id: string
          status: string
          updated_at: string
          user_id: string
        }
        Insert: {
          club_id: string
          club_role?: string
          created_at?: string
          id?: string
          status?: string
          updated_at?: string
          user_id: string
        }
        Update: {
          club_id?: string
          club_role?: string
          created_at?: string
          id?: string
          status?: string
          updated_at?: string
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "club_members_club_id_fkey"
            columns: ["club_id"]
            isOneToOne: false
            referencedRelation: "clubs"
            referencedColumns: ["id"]
          },
        ]
      }
      clubs: {
        Row: {
          created_at: string
          description: string | null
          id: string
          name: string
          school_id: string
          updated_at: string
        }
        Insert: {
          created_at?: string
          description?: string | null
          id?: string
          name: string
          school_id: string
          updated_at?: string
        }
        Update: {
          created_at?: string
          description?: string | null
          id?: string
          name?: string
          school_id?: string
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "clubs_school_id_fkey"
            columns: ["school_id"]
            isOneToOne: false
            referencedRelation: "schools"
            referencedColumns: ["id"]
          },
        ]
      }
      consumables: {
        Row: {
          created_at: string
          id: string
          item_key: string
          quantity: number
          updated_at: string
          user_id: string
        }
        Insert: {
          created_at?: string
          id?: string
          item_key: string
          quantity?: number
          updated_at?: string
          user_id: string
        }
        Update: {
          created_at?: string
          id?: string
          item_key?: string
          quantity?: number
          updated_at?: string
          user_id?: string
        }
        Relationships: []
      }
      conversation_bots: {
        Row: {
          added_at: string
          bot_persona_id: string
          conversation_id: string
          id: string
        }
        Insert: {
          added_at?: string
          bot_persona_id: string
          conversation_id: string
          id?: string
        }
        Update: {
          added_at?: string
          bot_persona_id?: string
          conversation_id?: string
          id?: string
        }
        Relationships: [
          {
            foreignKeyName: "conversation_bots_bot_persona_id_fkey"
            columns: ["bot_persona_id"]
            isOneToOne: false
            referencedRelation: "bot_personas"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "conversation_bots_conversation_id_fkey"
            columns: ["conversation_id"]
            isOneToOne: false
            referencedRelation: "conversations"
            referencedColumns: ["id"]
          },
        ]
      }
      conversation_members: {
        Row: {
          conversation_id: string
          id: string
          joined_at: string
          user_id: string
        }
        Insert: {
          conversation_id: string
          id?: string
          joined_at?: string
          user_id: string
        }
        Update: {
          conversation_id?: string
          id?: string
          joined_at?: string
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "conversation_members_conversation_id_fkey"
            columns: ["conversation_id"]
            isOneToOne: false
            referencedRelation: "conversations"
            referencedColumns: ["id"]
          },
        ]
      }
      conversations: {
        Row: {
          avatar_url: string | null
          bot_enabled: boolean
          bot_persona_id: string | null
          created_at: string
          created_by: string
          id: string
          is_group: boolean
          name: string | null
          updated_at: string
        }
        Insert: {
          avatar_url?: string | null
          bot_enabled?: boolean
          bot_persona_id?: string | null
          created_at?: string
          created_by: string
          id?: string
          is_group?: boolean
          name?: string | null
          updated_at?: string
        }
        Update: {
          avatar_url?: string | null
          bot_enabled?: boolean
          bot_persona_id?: string | null
          created_at?: string
          created_by?: string
          id?: string
          is_group?: boolean
          name?: string | null
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "conversations_bot_persona_id_fkey"
            columns: ["bot_persona_id"]
            isOneToOne: false
            referencedRelation: "bot_personas"
            referencedColumns: ["id"]
          },
        ]
      }
      event_registrations: {
        Row: {
          created_at: string
          event_id: string
          id: string
          notes: string | null
          phone: string | null
          user_id: string
        }
        Insert: {
          created_at?: string
          event_id: string
          id?: string
          notes?: string | null
          phone?: string | null
          user_id: string
        }
        Update: {
          created_at?: string
          event_id?: string
          id?: string
          notes?: string | null
          phone?: string | null
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "event_registrations_event_id_fkey"
            columns: ["event_id"]
            isOneToOne: false
            referencedRelation: "events"
            referencedColumns: ["id"]
          },
        ]
      }
      events: {
        Row: {
          created_at: string
          created_by: string
          description: string | null
          event_date: string | null
          id: string
          location: string | null
          max_participants: number | null
          registration_deadline: string | null
          registration_link: string | null
          status: string
          title: string
          updated_at: string
        }
        Insert: {
          created_at?: string
          created_by: string
          description?: string | null
          event_date?: string | null
          id?: string
          location?: string | null
          max_participants?: number | null
          registration_deadline?: string | null
          registration_link?: string | null
          status?: string
          title: string
          updated_at?: string
        }
        Update: {
          created_at?: string
          created_by?: string
          description?: string | null
          event_date?: string | null
          id?: string
          location?: string | null
          max_participants?: number | null
          registration_deadline?: string | null
          registration_link?: string | null
          status?: string
          title?: string
          updated_at?: string
        }
        Relationships: []
      }
      follows: {
        Row: {
          created_at: string
          follower_id: string
          following_id: string
          id: string
        }
        Insert: {
          created_at?: string
          follower_id: string
          following_id: string
          id?: string
        }
        Update: {
          created_at?: string
          follower_id?: string
          following_id?: string
          id?: string
        }
        Relationships: []
      }
      friend_challenges: {
        Row: {
          bet_amount: number
          challenger_id: string
          challenger_score: number | null
          created_at: string
          id: string
          opponent_id: string
          opponent_score: number | null
          status: string
          winner_id: string | null
        }
        Insert: {
          bet_amount?: number
          challenger_id: string
          challenger_score?: number | null
          created_at?: string
          id?: string
          opponent_id: string
          opponent_score?: number | null
          status?: string
          winner_id?: string | null
        }
        Update: {
          bet_amount?: number
          challenger_id?: string
          challenger_score?: number | null
          created_at?: string
          id?: string
          opponent_id?: string
          opponent_score?: number | null
          status?: string
          winner_id?: string | null
        }
        Relationships: []
      }
      friendships: {
        Row: {
          addressee_id: string
          created_at: string
          id: string
          requester_id: string
          status: string
        }
        Insert: {
          addressee_id: string
          created_at?: string
          id?: string
          requester_id: string
          status?: string
        }
        Update: {
          addressee_id?: string
          created_at?: string
          id?: string
          requester_id?: string
          status?: string
        }
        Relationships: []
      }
      game_invitations: {
        Row: {
          created_at: string
          id: string
          invitee_id: string
          inviter_id: string
          session_id: string
          status: string
        }
        Insert: {
          created_at?: string
          id?: string
          invitee_id: string
          inviter_id: string
          session_id: string
          status?: string
        }
        Update: {
          created_at?: string
          id?: string
          invitee_id?: string
          inviter_id?: string
          session_id?: string
          status?: string
        }
        Relationships: [
          {
            foreignKeyName: "game_invitations_session_id_fkey"
            columns: ["session_id"]
            isOneToOne: false
            referencedRelation: "game_sessions"
            referencedColumns: ["id"]
          },
        ]
      }
      game_leaderboards: {
        Row: {
          created_at: string
          game_type: string
          id: string
          mode: string
          score: number
          user_id: string
        }
        Insert: {
          created_at?: string
          game_type: string
          id?: string
          mode?: string
          score?: number
          user_id: string
        }
        Update: {
          created_at?: string
          game_type?: string
          id?: string
          mode?: string
          score?: number
          user_id?: string
        }
        Relationships: []
      }
      game_players: {
        Row: {
          id: string
          is_ready: boolean | null
          joined_at: string
          player_color: string | null
          session_id: string
          user_id: string
        }
        Insert: {
          id?: string
          is_ready?: boolean | null
          joined_at?: string
          player_color?: string | null
          session_id: string
          user_id: string
        }
        Update: {
          id?: string
          is_ready?: boolean | null
          joined_at?: string
          player_color?: string | null
          session_id?: string
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "game_players_session_id_fkey"
            columns: ["session_id"]
            isOneToOne: false
            referencedRelation: "game_sessions"
            referencedColumns: ["id"]
          },
        ]
      }
      game_sessions: {
        Row: {
          created_at: string
          current_turn: string | null
          game_state: Json | null
          game_type: string
          host_id: string
          id: string
          status: string
          updated_at: string
          winner_id: string | null
        }
        Insert: {
          created_at?: string
          current_turn?: string | null
          game_state?: Json | null
          game_type: string
          host_id: string
          id?: string
          status?: string
          updated_at?: string
          winner_id?: string | null
        }
        Update: {
          created_at?: string
          current_turn?: string | null
          game_state?: Json | null
          game_type?: string
          host_id?: string
          id?: string
          status?: string
          updated_at?: string
          winner_id?: string | null
        }
        Relationships: []
      }
      grade_categories: {
        Row: {
          created_at: string
          id: string
          name: string
          weight: number
        }
        Insert: {
          created_at?: string
          id?: string
          name: string
          weight?: number
        }
        Update: {
          created_at?: string
          id?: string
          name?: string
          weight?: number
        }
        Relationships: []
      }
      knowledge_points: {
        Row: {
          created_at: string
          created_by: string | null
          id: string
          name: string
          sort_order: number
          subject_id: string
          updated_at: string
        }
        Insert: {
          created_at?: string
          created_by?: string | null
          id?: string
          name: string
          sort_order?: number
          subject_id: string
          updated_at?: string
        }
        Update: {
          created_at?: string
          created_by?: string | null
          id?: string
          name?: string
          sort_order?: number
          subject_id?: string
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "knowledge_points_subject_id_fkey"
            columns: ["subject_id"]
            isOneToOne: false
            referencedRelation: "subjects"
            referencedColumns: ["id"]
          },
        ]
      }
      loans: {
        Row: {
          created_at: string
          daily_rate: number
          id: string
          penalty_after_days: number
          penalty_rate: number
          principal: number
          repaid_at: string | null
          status: string
          taken_at: string
          total_repaid: number
          user_id: string
        }
        Insert: {
          created_at?: string
          daily_rate?: number
          id?: string
          penalty_after_days?: number
          penalty_rate?: number
          principal: number
          repaid_at?: string | null
          status?: string
          taken_at?: string
          total_repaid?: number
          user_id: string
        }
        Update: {
          created_at?: string
          daily_rate?: number
          id?: string
          penalty_after_days?: number
          penalty_rate?: number
          principal?: number
          repaid_at?: string | null
          status?: string
          taken_at?: string
          total_repaid?: number
          user_id?: string
        }
        Relationships: []
      }
      lottery_history: {
        Row: {
          cost: number
          created_at: string
          id: string
          kind: string
          reward_coins: number
          reward_items: Json
          user_id: string
        }
        Insert: {
          cost: number
          created_at?: string
          id?: string
          kind: string
          reward_coins?: number
          reward_items?: Json
          user_id: string
        }
        Update: {
          cost?: number
          created_at?: string
          id?: string
          kind?: string
          reward_coins?: number
          reward_items?: Json
          user_id?: string
        }
        Relationships: []
      }
      match_history: {
        Row: {
          ai_difficulty: string
          ai_score: number
          coins_change: number
          created_at: string
          id: string
          league: string
          player_score: number
          user_id: string
          won: boolean
        }
        Insert: {
          ai_difficulty: string
          ai_score: number
          coins_change: number
          created_at?: string
          id?: string
          league: string
          player_score: number
          user_id: string
          won: boolean
        }
        Update: {
          ai_difficulty?: string
          ai_score?: number
          coins_change?: number
          created_at?: string
          id?: string
          league?: string
          player_score?: number
          user_id?: string
          won?: boolean
        }
        Relationships: []
      }
      messages: {
        Row: {
          bot_persona_id: string | null
          content: string
          conversation_id: string
          created_at: string
          id: string
          sender_id: string
        }
        Insert: {
          bot_persona_id?: string | null
          content?: string
          conversation_id: string
          created_at?: string
          id?: string
          sender_id: string
        }
        Update: {
          bot_persona_id?: string | null
          content?: string
          conversation_id?: string
          created_at?: string
          id?: string
          sender_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "messages_bot_persona_id_fkey"
            columns: ["bot_persona_id"]
            isOneToOne: false
            referencedRelation: "bot_personas"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "messages_conversation_id_fkey"
            columns: ["conversation_id"]
            isOneToOne: false
            referencedRelation: "conversations"
            referencedColumns: ["id"]
          },
        ]
      }
      nanmo_ai_chats: {
        Row: {
          created_at: string
          id: string
          messages: Json
          persona_id: string | null
          title: string
          updated_at: string
          user_id: string
        }
        Insert: {
          created_at?: string
          id?: string
          messages?: Json
          persona_id?: string | null
          title?: string
          updated_at?: string
          user_id: string
        }
        Update: {
          created_at?: string
          id?: string
          messages?: Json
          persona_id?: string | null
          title?: string
          updated_at?: string
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "nanmo_ai_chats_persona_id_fkey"
            columns: ["persona_id"]
            isOneToOne: false
            referencedRelation: "bot_personas"
            referencedColumns: ["id"]
          },
        ]
      }
      notifications: {
        Row: {
          actor_id: string
          comment_content: string | null
          created_at: string
          id: string
          is_read: boolean
          post_id: string | null
          type: string
          user_id: string
        }
        Insert: {
          actor_id: string
          comment_content?: string | null
          created_at?: string
          id?: string
          is_read?: boolean
          post_id?: string | null
          type: string
          user_id: string
        }
        Update: {
          actor_id?: string
          comment_content?: string | null
          created_at?: string
          id?: string
          is_read?: boolean
          post_id?: string | null
          type?: string
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "notifications_post_id_fkey"
            columns: ["post_id"]
            isOneToOne: false
            referencedRelation: "posts"
            referencedColumns: ["id"]
          },
        ]
      }
      pinned_conversations: {
        Row: {
          conversation_id: string
          created_at: string
          id: string
          user_id: string
        }
        Insert: {
          conversation_id: string
          created_at?: string
          id?: string
          user_id: string
        }
        Update: {
          conversation_id?: string
          created_at?: string
          id?: string
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "pinned_conversations_conversation_id_fkey"
            columns: ["conversation_id"]
            isOneToOne: false
            referencedRelation: "conversations"
            referencedColumns: ["id"]
          },
        ]
      }
      player_card_stats: {
        Row: {
          card_id: string
          created_at: string
          games_played: number
          id: string
          losses: number
          mvp_count: number
          points_scored: number
          updated_at: string
          user_id: string
          wins: number
        }
        Insert: {
          card_id: string
          created_at?: string
          games_played?: number
          id?: string
          losses?: number
          mvp_count?: number
          points_scored?: number
          updated_at?: string
          user_id: string
          wins?: number
        }
        Update: {
          card_id?: string
          created_at?: string
          games_played?: number
          id?: string
          losses?: number
          mvp_count?: number
          points_scored?: number
          updated_at?: string
          user_id?: string
          wins?: number
        }
        Relationships: [
          {
            foreignKeyName: "player_card_stats_card_id_fkey"
            columns: ["card_id"]
            isOneToOne: true
            referencedRelation: "player_cards"
            referencedColumns: ["id"]
          },
        ]
      }
      player_cards: {
        Row: {
          acquired_at: string
          bonus_defense: number
          bonus_dunk: number
          bonus_shooting: number
          bonus_speed: number
          bonus_three_point: number
          id: string
          level: number
          stamina: number
          stamina_updated_at: string
          template_id: string
          user_id: string
        }
        Insert: {
          acquired_at?: string
          bonus_defense?: number
          bonus_dunk?: number
          bonus_shooting?: number
          bonus_speed?: number
          bonus_three_point?: number
          id?: string
          level?: number
          stamina?: number
          stamina_updated_at?: string
          template_id: string
          user_id: string
        }
        Update: {
          acquired_at?: string
          bonus_defense?: number
          bonus_dunk?: number
          bonus_shooting?: number
          bonus_speed?: number
          bonus_three_point?: number
          id?: string
          level?: number
          stamina?: number
          stamina_updated_at?: string
          template_id?: string
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "player_cards_template_id_fkey"
            columns: ["template_id"]
            isOneToOne: false
            referencedRelation: "player_templates"
            referencedColumns: ["id"]
          },
        ]
      }
      player_listings: {
        Row: {
          buyer_id: string | null
          card_id: string
          created_at: string
          id: string
          price: number
          seller_id: string
          sold_at: string | null
          status: string
        }
        Insert: {
          buyer_id?: string | null
          card_id: string
          created_at?: string
          id?: string
          price: number
          seller_id: string
          sold_at?: string | null
          status?: string
        }
        Update: {
          buyer_id?: string | null
          card_id?: string
          created_at?: string
          id?: string
          price?: number
          seller_id?: string
          sold_at?: string | null
          status?: string
        }
        Relationships: [
          {
            foreignKeyName: "player_listings_card_id_fkey"
            columns: ["card_id"]
            isOneToOne: true
            referencedRelation: "player_cards"
            referencedColumns: ["id"]
          },
        ]
      }
      player_templates: {
        Row: {
          avatar_url: string | null
          created_at: string
          defense: number
          description: string | null
          dunk: number
          emoji: string
          id: string
          name: string
          rarity: string
          shooting: number
          speed: number
          three_point: number
        }
        Insert: {
          avatar_url?: string | null
          created_at?: string
          defense: number
          description?: string | null
          dunk: number
          emoji?: string
          id?: string
          name: string
          rarity: string
          shooting: number
          speed: number
          three_point: number
        }
        Update: {
          avatar_url?: string | null
          created_at?: string
          defense?: number
          description?: string | null
          dunk?: number
          emoji?: string
          id?: string
          name?: string
          rarity?: string
          shooting?: number
          speed?: number
          three_point?: number
        }
        Relationships: []
      }
      post_attachments: {
        Row: {
          created_at: string
          file_name: string
          file_url: string
          id: string
          post_id: string
        }
        Insert: {
          created_at?: string
          file_name: string
          file_url: string
          id?: string
          post_id: string
        }
        Update: {
          created_at?: string
          file_name?: string
          file_url?: string
          id?: string
          post_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "post_attachments_post_id_fkey"
            columns: ["post_id"]
            isOneToOne: false
            referencedRelation: "posts"
            referencedColumns: ["id"]
          },
        ]
      }
      post_comments: {
        Row: {
          content: string
          created_at: string
          id: string
          post_id: string
          user_id: string
        }
        Insert: {
          content: string
          created_at?: string
          id?: string
          post_id: string
          user_id: string
        }
        Update: {
          content?: string
          created_at?: string
          id?: string
          post_id?: string
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "post_comments_post_id_fkey"
            columns: ["post_id"]
            isOneToOne: false
            referencedRelation: "posts"
            referencedColumns: ["id"]
          },
        ]
      }
      post_likes: {
        Row: {
          created_at: string
          id: string
          post_id: string
          user_id: string
        }
        Insert: {
          created_at?: string
          id?: string
          post_id: string
          user_id: string
        }
        Update: {
          created_at?: string
          id?: string
          post_id?: string
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "post_likes_post_id_fkey"
            columns: ["post_id"]
            isOneToOne: false
            referencedRelation: "posts"
            referencedColumns: ["id"]
          },
        ]
      }
      post_tags: {
        Row: {
          created_at: string
          id: string
          post_id: string
          tag: string
        }
        Insert: {
          created_at?: string
          id?: string
          post_id: string
          tag: string
        }
        Update: {
          created_at?: string
          id?: string
          post_id?: string
          tag?: string
        }
        Relationships: [
          {
            foreignKeyName: "post_tags_post_id_fkey"
            columns: ["post_id"]
            isOneToOne: false
            referencedRelation: "posts"
            referencedColumns: ["id"]
          },
        ]
      }
      posts: {
        Row: {
          author_id: string
          content: string
          created_at: string
          id: string
          school_id: string | null
          scope: string
          title: string
          updated_at: string
        }
        Insert: {
          author_id: string
          content?: string
          created_at?: string
          id?: string
          school_id?: string | null
          scope?: string
          title: string
          updated_at?: string
        }
        Update: {
          author_id?: string
          content?: string
          created_at?: string
          id?: string
          school_id?: string | null
          scope?: string
          title?: string
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "posts_school_id_fkey"
            columns: ["school_id"]
            isOneToOne: false
            referencedRelation: "schools"
            referencedColumns: ["id"]
          },
        ]
      }
      practice_answers: {
        Row: {
          created_at: string
          feedback: string | null
          flagged: boolean
          graded_at: string | null
          graded_by: string | null
          id: string
          is_correct: boolean | null
          part_id: string | null
          points_awarded: number | null
          question_id: string
          selected_option: string | null
          session_id: string
          text_answer: string | null
          time_spent_seconds: number
          updated_at: string
          user_id: string
        }
        Insert: {
          created_at?: string
          feedback?: string | null
          flagged?: boolean
          graded_at?: string | null
          graded_by?: string | null
          id?: string
          is_correct?: boolean | null
          part_id?: string | null
          points_awarded?: number | null
          question_id: string
          selected_option?: string | null
          session_id: string
          text_answer?: string | null
          time_spent_seconds?: number
          updated_at?: string
          user_id: string
        }
        Update: {
          created_at?: string
          feedback?: string | null
          flagged?: boolean
          graded_at?: string | null
          graded_by?: string | null
          id?: string
          is_correct?: boolean | null
          part_id?: string | null
          points_awarded?: number | null
          question_id?: string
          selected_option?: string | null
          session_id?: string
          text_answer?: string | null
          time_spent_seconds?: number
          updated_at?: string
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "practice_answers_part_id_fkey"
            columns: ["part_id"]
            isOneToOne: false
            referencedRelation: "question_parts"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "practice_answers_question_id_fkey"
            columns: ["question_id"]
            isOneToOne: false
            referencedRelation: "questions"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "practice_answers_session_id_fkey"
            columns: ["session_id"]
            isOneToOne: false
            referencedRelation: "practice_sessions"
            referencedColumns: ["id"]
          },
        ]
      }
      practice_sessions: {
        Row: {
          completed_at: string | null
          created_at: string
          difficulty: number | null
          id: string
          mode: string
          question_ids: string[]
          score: number | null
          section_seconds: Json
          sections_submitted: string[]
          started_at: string
          status: string
          subject_id: string | null
          title: string
          total_points: number | null
          updated_at: string
          user_id: string
        }
        Insert: {
          completed_at?: string | null
          created_at?: string
          difficulty?: number | null
          id?: string
          mode: string
          question_ids?: string[]
          score?: number | null
          section_seconds?: Json
          sections_submitted?: string[]
          started_at?: string
          status?: string
          subject_id?: string | null
          title?: string
          total_points?: number | null
          updated_at?: string
          user_id: string
        }
        Update: {
          completed_at?: string | null
          created_at?: string
          difficulty?: number | null
          id?: string
          mode?: string
          question_ids?: string[]
          score?: number | null
          section_seconds?: Json
          sections_submitted?: string[]
          started_at?: string
          status?: string
          subject_id?: string | null
          title?: string
          total_points?: number | null
          updated_at?: string
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "practice_sessions_subject_id_fkey"
            columns: ["subject_id"]
            isOneToOne: false
            referencedRelation: "subjects"
            referencedColumns: ["id"]
          },
        ]
      }
      profiles: {
        Row: {
          avatar_url: string | null
          banner_url: string | null
          bio: string | null
          created_at: string
          display_role: string
          id: string
          is_approved: boolean
          name: string
          school_id: string | null
          updated_at: string
          user_id: string
        }
        Insert: {
          avatar_url?: string | null
          banner_url?: string | null
          bio?: string | null
          created_at?: string
          display_role?: string
          id?: string
          is_approved?: boolean
          name?: string
          school_id?: string | null
          updated_at?: string
          user_id: string
        }
        Update: {
          avatar_url?: string | null
          banner_url?: string | null
          bio?: string | null
          created_at?: string
          display_role?: string
          id?: string
          is_approved?: boolean
          name?: string
          school_id?: string | null
          updated_at?: string
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "profiles_school_id_fkey"
            columns: ["school_id"]
            isOneToOne: false
            referencedRelation: "schools"
            referencedColumns: ["id"]
          },
        ]
      }
      question_parts: {
        Row: {
          created_at: string
          id: string
          label: string
          points: number
          prompt: string | null
          question_id: string
          sample_answer: string | null
          sample_answer_file_name: string | null
          sample_answer_file_url: string | null
          sort_order: number
        }
        Insert: {
          created_at?: string
          id?: string
          label: string
          points?: number
          prompt?: string | null
          question_id: string
          sample_answer?: string | null
          sample_answer_file_name?: string | null
          sample_answer_file_url?: string | null
          sort_order?: number
        }
        Update: {
          created_at?: string
          id?: string
          label?: string
          points?: number
          prompt?: string | null
          question_id?: string
          sample_answer?: string | null
          sample_answer_file_name?: string | null
          sample_answer_file_url?: string | null
          sort_order?: number
        }
        Relationships: [
          {
            foreignKeyName: "question_parts_question_id_fkey"
            columns: ["question_id"]
            isOneToOne: false
            referencedRelation: "questions"
            referencedColumns: ["id"]
          },
        ]
      }
      question_upload_grants: {
        Row: {
          created_at: string
          granted_by: string | null
          id: string
          is_active: boolean
          updated_at: string
          user_id: string
        }
        Insert: {
          created_at?: string
          granted_by?: string | null
          id?: string
          is_active?: boolean
          updated_at?: string
          user_id: string
        }
        Update: {
          created_at?: string
          granted_by?: string | null
          id?: string
          is_active?: boolean
          updated_at?: string
          user_id?: string
        }
        Relationships: []
      }
      questions: {
        Row: {
          answer_file_name: string | null
          answer_file_url: string | null
          club_id: string | null
          correct_option: string | null
          created_at: string
          created_by: string
          difficulty: number
          explanation: string | null
          id: string
          knowledge_point_id: string | null
          max_points: number
          option_a: string | null
          option_b: string | null
          option_c: string | null
          option_d: string | null
          options: string[] | null
          question_type: string
          stem: string | null
          stimulus_file_name: string | null
          stimulus_file_url: string | null
          stimulus_text: string | null
          subject_id: string
          title: string | null
          updated_at: string
          visibility: string
        }
        Insert: {
          answer_file_name?: string | null
          answer_file_url?: string | null
          club_id?: string | null
          correct_option?: string | null
          created_at?: string
          created_by: string
          difficulty?: number
          explanation?: string | null
          id?: string
          knowledge_point_id?: string | null
          max_points?: number
          option_a?: string | null
          option_b?: string | null
          option_c?: string | null
          option_d?: string | null
          options?: string[] | null
          question_type: string
          stem?: string | null
          stimulus_file_name?: string | null
          stimulus_file_url?: string | null
          stimulus_text?: string | null
          subject_id: string
          title?: string | null
          updated_at?: string
          visibility?: string
        }
        Update: {
          answer_file_name?: string | null
          answer_file_url?: string | null
          club_id?: string | null
          correct_option?: string | null
          created_at?: string
          created_by?: string
          difficulty?: number
          explanation?: string | null
          id?: string
          knowledge_point_id?: string | null
          max_points?: number
          option_a?: string | null
          option_b?: string | null
          option_c?: string | null
          option_d?: string | null
          options?: string[] | null
          question_type?: string
          stem?: string | null
          stimulus_file_name?: string | null
          stimulus_file_url?: string | null
          stimulus_text?: string | null
          subject_id?: string
          title?: string | null
          updated_at?: string
          visibility?: string
        }
        Relationships: [
          {
            foreignKeyName: "questions_club_id_fkey"
            columns: ["club_id"]
            isOneToOne: false
            referencedRelation: "clubs"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "questions_knowledge_point_id_fkey"
            columns: ["knowledge_point_id"]
            isOneToOne: false
            referencedRelation: "knowledge_points"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "questions_subject_id_fkey"
            columns: ["subject_id"]
            isOneToOne: false
            referencedRelation: "subjects"
            referencedColumns: ["id"]
          },
        ]
      }
      quiz_answers: {
        Row: {
          attempt_id: string
          created_at: string
          id: string
          is_correct: boolean | null
          question_id: string
          selected_option_id: string | null
          selected_option_ids: string[] | null
          text_answer: string | null
        }
        Insert: {
          attempt_id: string
          created_at?: string
          id?: string
          is_correct?: boolean | null
          question_id: string
          selected_option_id?: string | null
          selected_option_ids?: string[] | null
          text_answer?: string | null
        }
        Update: {
          attempt_id?: string
          created_at?: string
          id?: string
          is_correct?: boolean | null
          question_id?: string
          selected_option_id?: string | null
          selected_option_ids?: string[] | null
          text_answer?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "quiz_answers_attempt_id_fkey"
            columns: ["attempt_id"]
            isOneToOne: false
            referencedRelation: "quiz_attempts"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "quiz_answers_question_id_fkey"
            columns: ["question_id"]
            isOneToOne: false
            referencedRelation: "quiz_questions"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "quiz_answers_selected_option_id_fkey"
            columns: ["selected_option_id"]
            isOneToOne: false
            referencedRelation: "quiz_options"
            referencedColumns: ["id"]
          },
        ]
      }
      quiz_attempts: {
        Row: {
          completed_at: string | null
          created_at: string
          id: string
          quiz_id: string
          score: number | null
          student_id: string
          total_points: number | null
        }
        Insert: {
          completed_at?: string | null
          created_at?: string
          id?: string
          quiz_id: string
          score?: number | null
          student_id: string
          total_points?: number | null
        }
        Update: {
          completed_at?: string | null
          created_at?: string
          id?: string
          quiz_id?: string
          score?: number | null
          student_id?: string
          total_points?: number | null
        }
        Relationships: [
          {
            foreignKeyName: "quiz_attempts_quiz_id_fkey"
            columns: ["quiz_id"]
            isOneToOne: false
            referencedRelation: "quizzes"
            referencedColumns: ["id"]
          },
        ]
      }
      quiz_options: {
        Row: {
          created_at: string
          id: string
          is_correct: boolean
          option_text: string
          question_id: string
          sort_order: number
        }
        Insert: {
          created_at?: string
          id?: string
          is_correct?: boolean
          option_text: string
          question_id: string
          sort_order?: number
        }
        Update: {
          created_at?: string
          id?: string
          is_correct?: boolean
          option_text?: string
          question_id?: string
          sort_order?: number
        }
        Relationships: [
          {
            foreignKeyName: "quiz_options_question_id_fkey"
            columns: ["question_id"]
            isOneToOne: false
            referencedRelation: "quiz_questions"
            referencedColumns: ["id"]
          },
        ]
      }
      quiz_paper_questions: {
        Row: {
          created_at: string
          id: string
          question_id: string
          quiz_id: string
          section: string
          sort_order: number
        }
        Insert: {
          created_at?: string
          id?: string
          question_id: string
          quiz_id: string
          section?: string
          sort_order?: number
        }
        Update: {
          created_at?: string
          id?: string
          question_id?: string
          quiz_id?: string
          section?: string
          sort_order?: number
        }
        Relationships: [
          {
            foreignKeyName: "quiz_paper_questions_question_id_fkey"
            columns: ["question_id"]
            isOneToOne: false
            referencedRelation: "questions"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "quiz_paper_questions_quiz_id_fkey"
            columns: ["quiz_id"]
            isOneToOne: false
            referencedRelation: "quizzes"
            referencedColumns: ["id"]
          },
        ]
      }
      quiz_questions: {
        Row: {
          correct_answer: string | null
          created_at: string
          id: string
          image_url: string | null
          points: number
          question_text: string
          question_type: string
          quiz_id: string
          sort_order: number
        }
        Insert: {
          correct_answer?: string | null
          created_at?: string
          id?: string
          image_url?: string | null
          points?: number
          question_text: string
          question_type?: string
          quiz_id: string
          sort_order?: number
        }
        Update: {
          correct_answer?: string | null
          created_at?: string
          id?: string
          image_url?: string | null
          points?: number
          question_text?: string
          question_type?: string
          quiz_id?: string
          sort_order?: number
        }
        Relationships: [
          {
            foreignKeyName: "quiz_questions_quiz_id_fkey"
            columns: ["quiz_id"]
            isOneToOne: false
            referencedRelation: "quizzes"
            referencedColumns: ["id"]
          },
        ]
      }
      quizzes: {
        Row: {
          allow_retake: boolean
          category: string
          created_at: string
          created_by: string
          description: string | null
          id: string
          image_url: string | null
          is_published: boolean
          passing_score: number | null
          results_published: boolean
          time_limit_minutes: number | null
          title: string
          updated_at: string
        }
        Insert: {
          allow_retake?: boolean
          category?: string
          created_at?: string
          created_by: string
          description?: string | null
          id?: string
          image_url?: string | null
          is_published?: boolean
          passing_score?: number | null
          results_published?: boolean
          time_limit_minutes?: number | null
          title: string
          updated_at?: string
        }
        Update: {
          allow_retake?: boolean
          category?: string
          created_at?: string
          created_by?: string
          description?: string | null
          id?: string
          image_url?: string | null
          is_published?: boolean
          passing_score?: number | null
          results_published?: boolean
          time_limit_minutes?: number | null
          title?: string
          updated_at?: string
        }
        Relationships: []
      }
      registration_ips: {
        Row: {
          created_at: string
          id: string
          ip_address: string | null
          user_id: string
        }
        Insert: {
          created_at?: string
          id?: string
          ip_address?: string | null
          user_id: string
        }
        Update: {
          created_at?: string
          id?: string
          ip_address?: string | null
          user_id?: string
        }
        Relationships: []
      }
      resource_folders: {
        Row: {
          color: string
          created_at: string
          id: string
          name: string
          parent_id: string | null
          sort_order: number
        }
        Insert: {
          color?: string
          created_at?: string
          id?: string
          name: string
          parent_id?: string | null
          sort_order?: number
        }
        Update: {
          color?: string
          created_at?: string
          id?: string
          name?: string
          parent_id?: string | null
          sort_order?: number
        }
        Relationships: [
          {
            foreignKeyName: "resource_folders_parent_id_fkey"
            columns: ["parent_id"]
            isOneToOne: false
            referencedRelation: "resource_folders"
            referencedColumns: ["id"]
          },
        ]
      }
      resources: {
        Row: {
          author_id: string
          category: string
          created_at: string
          description: string | null
          file_name: string
          file_url: string
          id: string
          sort_order: number
          title: string
          updated_at: string
        }
        Insert: {
          author_id: string
          category?: string
          created_at?: string
          description?: string | null
          file_name: string
          file_url: string
          id?: string
          sort_order?: number
          title: string
          updated_at?: string
        }
        Update: {
          author_id?: string
          category?: string
          created_at?: string
          description?: string | null
          file_name?: string
          file_url?: string
          id?: string
          sort_order?: number
          title?: string
          updated_at?: string
        }
        Relationships: []
      }
      schools: {
        Row: {
          city: string
          country: string
          created_at: string
          id: string
          is_active: boolean
          name: string
          region: string
          updated_at: string
        }
        Insert: {
          city: string
          country: string
          created_at?: string
          id?: string
          is_active?: boolean
          name: string
          region: string
          updated_at?: string
        }
        Update: {
          city?: string
          country?: string
          created_at?: string
          id?: string
          is_active?: boolean
          name?: string
          region?: string
          updated_at?: string
        }
        Relationships: []
      }
      scores: {
        Row: {
          assignment_id: string
          created_at: string
          id: string
          score: number
          student_id: string
          updated_at: string
        }
        Insert: {
          assignment_id: string
          created_at?: string
          id?: string
          score?: number
          student_id: string
          updated_at?: string
        }
        Update: {
          assignment_id?: string
          created_at?: string
          id?: string
          score?: number
          student_id?: string
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "scores_assignment_id_fkey"
            columns: ["assignment_id"]
            isOneToOne: false
            referencedRelation: "assignments"
            referencedColumns: ["id"]
          },
        ]
      }
      scratch_card_configs: {
        Row: {
          created_at: string
          face_value: number
          id: string
          prizes: Json
          updated_at: string
        }
        Insert: {
          created_at?: string
          face_value: number
          id?: string
          prizes?: Json
          updated_at?: string
        }
        Update: {
          created_at?: string
          face_value?: number
          id?: string
          prizes?: Json
          updated_at?: string
        }
        Relationships: []
      }
      sticker_packs: {
        Row: {
          created_at: string
          id: string
          image_path: string
          user_id: string
        }
        Insert: {
          created_at?: string
          id?: string
          image_path: string
          user_id: string
        }
        Update: {
          created_at?: string
          id?: string
          image_path?: string
          user_id?: string
        }
        Relationships: []
      }
      study_group_members: {
        Row: {
          created_at: string
          group_id: string
          id: string
          user_id: string
        }
        Insert: {
          created_at?: string
          group_id: string
          id?: string
          user_id: string
        }
        Update: {
          created_at?: string
          group_id?: string
          id?: string
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "study_group_members_group_id_fkey"
            columns: ["group_id"]
            isOneToOne: false
            referencedRelation: "study_groups"
            referencedColumns: ["id"]
          },
        ]
      }
      study_group_sessions: {
        Row: {
          created_at: string
          end_time: string
          group_id: string
          id: string
          location: string | null
          session_date: string
          start_time: string
          updated_at: string
        }
        Insert: {
          created_at?: string
          end_time: string
          group_id: string
          id?: string
          location?: string | null
          session_date: string
          start_time: string
          updated_at?: string
        }
        Update: {
          created_at?: string
          end_time?: string
          group_id?: string
          id?: string
          location?: string | null
          session_date?: string
          start_time?: string
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "study_group_sessions_group_id_fkey"
            columns: ["group_id"]
            isOneToOne: false
            referencedRelation: "study_groups"
            referencedColumns: ["id"]
          },
        ]
      }
      study_groups: {
        Row: {
          content: string | null
          created_at: string
          creator_id: string
          expires_at: string | null
          frequency: string | null
          id: string
          is_public: boolean
          location: string | null
          max_members: number
          meeting_time: string | null
          requirements: string | null
          status: string
          subject: string
          title: string
          updated_at: string
        }
        Insert: {
          content?: string | null
          created_at?: string
          creator_id: string
          expires_at?: string | null
          frequency?: string | null
          id?: string
          is_public?: boolean
          location?: string | null
          max_members?: number
          meeting_time?: string | null
          requirements?: string | null
          status?: string
          subject: string
          title: string
          updated_at?: string
        }
        Update: {
          content?: string | null
          created_at?: string
          creator_id?: string
          expires_at?: string | null
          frequency?: string | null
          id?: string
          is_public?: boolean
          location?: string | null
          max_members?: number
          meeting_time?: string | null
          requirements?: string | null
          status?: string
          subject?: string
          title?: string
          updated_at?: string
        }
        Relationships: []
      }
      subjects: {
        Row: {
          club_id: string | null
          created_at: string
          created_by: string | null
          id: string
          name: string
          updated_at: string
        }
        Insert: {
          club_id?: string | null
          created_at?: string
          created_by?: string | null
          id?: string
          name: string
          updated_at?: string
        }
        Update: {
          club_id?: string | null
          created_at?: string
          created_by?: string | null
          id?: string
          name?: string
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "subjects_club_id_fkey"
            columns: ["club_id"]
            isOneToOne: false
            referencedRelation: "clubs"
            referencedColumns: ["id"]
          },
        ]
      }
      team_managers: {
        Row: {
          coach_key: string | null
          coach_matches_left: number
          coins: number
          created_at: string
          current_league: string
          current_tour_season: number
          equipped_consumables: string[]
          id: string
          jersey_primary: string
          jersey_secondary: string
          jersey_style: string
          league_wins: number
          starting_lineup: string[]
          team_emoji: string
          team_logo_url: string | null
          team_name: string
          total_losses: number
          total_wins: number
          updated_at: string
          user_id: string
          wc_titles: number
          world_tour_titles: Json
        }
        Insert: {
          coach_key?: string | null
          coach_matches_left?: number
          coins?: number
          created_at?: string
          current_league?: string
          current_tour_season?: number
          equipped_consumables?: string[]
          id?: string
          jersey_primary?: string
          jersey_secondary?: string
          jersey_style?: string
          league_wins?: number
          starting_lineup?: string[]
          team_emoji?: string
          team_logo_url?: string | null
          team_name?: string
          total_losses?: number
          total_wins?: number
          updated_at?: string
          user_id: string
          wc_titles?: number
          world_tour_titles?: Json
        }
        Update: {
          coach_key?: string | null
          coach_matches_left?: number
          coins?: number
          created_at?: string
          current_league?: string
          current_tour_season?: number
          equipped_consumables?: string[]
          id?: string
          jersey_primary?: string
          jersey_secondary?: string
          jersey_style?: string
          league_wins?: number
          starting_lineup?: string[]
          team_emoji?: string
          team_logo_url?: string | null
          team_name?: string
          total_losses?: number
          total_wins?: number
          updated_at?: string
          user_id?: string
          wc_titles?: number
          world_tour_titles?: Json
        }
        Relationships: []
      }
      tutoring_bookings: {
        Row: {
          admin_note: string | null
          created_at: string
          id: string
          slot_id: string
          status: string
          updated_at: string
          user_id: string
        }
        Insert: {
          admin_note?: string | null
          created_at?: string
          id?: string
          slot_id: string
          status?: string
          updated_at?: string
          user_id: string
        }
        Update: {
          admin_note?: string | null
          created_at?: string
          id?: string
          slot_id?: string
          status?: string
          updated_at?: string
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "tutoring_bookings_slot_id_fkey"
            columns: ["slot_id"]
            isOneToOne: false
            referencedRelation: "tutoring_slots"
            referencedColumns: ["id"]
          },
        ]
      }
      tutoring_requests: {
        Row: {
          admin_note: string | null
          created_at: string
          end_time: string
          id: string
          location: string | null
          parent_request_id: string | null
          requested_date: string
          session_type: string
          start_time: string
          status: string
          student_note: string | null
          subject: string
          tutor_name: string | null
          updated_at: string
          user_id: string
        }
        Insert: {
          admin_note?: string | null
          created_at?: string
          end_time: string
          id?: string
          location?: string | null
          parent_request_id?: string | null
          requested_date: string
          session_type?: string
          start_time: string
          status?: string
          student_note?: string | null
          subject: string
          tutor_name?: string | null
          updated_at?: string
          user_id: string
        }
        Update: {
          admin_note?: string | null
          created_at?: string
          end_time?: string
          id?: string
          location?: string | null
          parent_request_id?: string | null
          requested_date?: string
          session_type?: string
          start_time?: string
          status?: string
          student_note?: string | null
          subject?: string
          tutor_name?: string | null
          updated_at?: string
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "tutoring_requests_parent_request_id_fkey"
            columns: ["parent_request_id"]
            isOneToOne: false
            referencedRelation: "tutoring_requests"
            referencedColumns: ["id"]
          },
        ]
      }
      tutoring_slots: {
        Row: {
          capacity: number
          created_at: string
          created_by: string
          day_of_week: string
          end_time: string
          id: string
          location: string | null
          session_type: string
          start_time: string
          subject: string
          tutor_name: string | null
          updated_at: string
          week_number: number
        }
        Insert: {
          capacity?: number
          created_at?: string
          created_by: string
          day_of_week: string
          end_time: string
          id?: string
          location?: string | null
          session_type?: string
          start_time: string
          subject: string
          tutor_name?: string | null
          updated_at?: string
          week_number: number
        }
        Update: {
          capacity?: number
          created_at?: string
          created_by?: string
          day_of_week?: string
          end_time?: string
          id?: string
          location?: string | null
          session_type?: string
          start_time?: string
          subject?: string
          tutor_name?: string | null
          updated_at?: string
          week_number?: number
        }
        Relationships: []
      }
      user_roles: {
        Row: {
          id: string
          role: Database["public"]["Enums"]["app_role"]
          user_id: string
        }
        Insert: {
          id?: string
          role: Database["public"]["Enums"]["app_role"]
          user_id: string
        }
        Update: {
          id?: string
          role?: Database["public"]["Enums"]["app_role"]
          user_id?: string
        }
        Relationships: []
      }
      wrong_questions: {
        Row: {
          created_at: string
          id: string
          question_id: string
          user_id: string
        }
        Insert: {
          created_at?: string
          id?: string
          question_id: string
          user_id: string
        }
        Update: {
          created_at?: string
          id?: string
          question_id?: string
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "wrong_questions_question_id_fkey"
            columns: ["question_id"]
            isOneToOne: false
            referencedRelation: "questions"
            referencedColumns: ["id"]
          },
        ]
      }
    }
    Views: {
      [_ in never]: never
    }
    Functions: {
      accept_friend_duel: { Args: { _duel_id: string }; Returns: Json }
      admin_finance_overview: {
        Args: never
        Returns: {
          active_loans: number
          coins: number
          display_role: string
          friend_count: number
          friend_net: number
          loan_balance: number
          loan_principal: number
          lottery_spent: number
          match_count: number
          match_earned: number
          match_lost: number
          profile_name: string
          team_emoji: string
          team_name: string
          total_losses: number
          total_wins: number
          user_id: string
        }[]
      }
      buy_player_listing: { Args: { _listing_id: string }; Returns: Json }
      buy_scratch_ticket: { Args: { _face: number }; Returns: Json }
      can_author_questions: { Args: { _user_id: string }; Returns: boolean }
      can_grant_question_upload: {
        Args: { _user_id: string }
        Returns: boolean
      }
      can_manage_study_group: {
        Args: { _group_id: string; _user_id: string }
        Returns: boolean
      }
      can_manage_subject_row: {
        Args: { _club_id: string; _user_id: string }
        Returns: boolean
      }
      can_manage_subjects: { Args: { _user_id: string }; Returns: boolean }
      cancel_friend_duel: { Args: { _duel_id: string }; Returns: Json }
      create_friend_duel: {
        Args: { _amount: number; _opponent_id: string }
        Returns: Json
      }
      deduct_ai_tokens: {
        Args: { _input_tokens: number; _output_tokens: number }
        Returns: Json
      }
      drain_lineup_stamina: {
        Args: { _amount: number; _card_ids: string[] }
        Returns: undefined
      }
      drain_opponent_lineup_stamina: {
        Args: { _amount: number; _target_user_id: string }
        Returns: undefined
      }
      finalize_quiz_attempt: { Args: { _attempt_id: string }; Returns: Json }
      get_loan_balance: { Args: { _loan_id: string }; Returns: number }
      get_quiz_items: {
        Args: { _quiz_id: string }
        Returns: {
          id: string
          image_url: string
          options: Json
          points: number
          question_text: string
          question_type: string
          sort_order: number
        }[]
      }
      get_study_group_invite: {
        Args: { _group_id: string }
        Returns: {
          content: string
          frequency: string
          id: string
          is_member: boolean
          is_public: boolean
          location: string
          max_members: number
          meeting_time: string
          member_count: number
          status: string
          subject: string
          title: string
        }[]
      }
      grant_consumable: {
        Args: { _item_key: string; _qty: number; _user_id: string }
        Returns: undefined
      }
      has_question_upload_grant: {
        Args: { _user_id: string }
        Returns: boolean
      }
      has_role: {
        Args: {
          _role: Database["public"]["Enums"]["app_role"]
          _user_id: string
        }
        Returns: boolean
      }
      initialize_team_for_user: { Args: { _user_id: string }; Returns: string }
      is_club_leader: {
        Args: { _club_id: string; _user_id: string }
        Returns: boolean
      }
      is_club_member: {
        Args: { _club_id: string; _user_id: string }
        Returns: boolean
      }
      is_club_staff: {
        Args: { _club_id: string; _user_id: string }
        Returns: boolean
      }
      is_conversation_creator: {
        Args: { _conversation_id: string; _user_id: string }
        Returns: boolean
      }
      is_conversation_member: {
        Args: { _conversation_id: string; _user_id: string }
        Returns: boolean
      }
      is_president: { Args: { _user_id: string }; Returns: boolean }
      is_restricted_user: { Args: { _user_id: string }; Returns: boolean }
      is_study_group_member: {
        Args: { _group_id: string; _user_id: string }
        Returns: boolean
      }
      is_super_admin: { Args: { _user_id: string }; Returns: boolean }
      list_tutor_courses: {
        Args: never
        Returns: {
          already_requested: boolean
          end_time: string
          enrolled: number
          id: string
          location: string
          requested_date: string
          start_time: string
          subject: string
          tutor_name: string
        }[]
      }
      lottery_slices: {
        Args: never
        Returns: {
          coins: number
          item_key: string
          item_qty: number
          key: string
          ord: number
          weight: number
        }[]
      }
      principal_rate_surcharge: {
        Args: { _principal: number }
        Returns: number
      }
      record_match_contribution: {
        Args: {
          _card_id: string
          _is_mvp: boolean
          _points: number
          _user_id: string
          _won: boolean
        }
        Returns: undefined
      }
      recover_idle_stamina: {
        Args: { _lineup_ids: string[] }
        Returns: undefined
      }
      repay_loan: { Args: { _loan_id: string }; Returns: Json }
      restore_card_stamina: {
        Args: { _amount: number; _card_id: string }
        Returns: number
      }
      save_quiz_answer: {
        Args: {
          _attempt_id: string
          _option_id: string
          _option_ids: string[]
          _question_id: string
          _text: string
        }
        Returns: undefined
      }
      settle_friend_challenge: {
        Args: {
          _amount: number
          _challenger_won: boolean
          _opponent_id: string
        }
        Returns: Json
      }
      settle_league_match: {
        Args: {
          _ai_score: number
          _league: string
          _player_score: number
          _won: boolean
        }
        Returns: Json
      }
      spin_lottery: { Args: { _kind: string }; Returns: Json }
      submit_game_score: {
        Args: { _game_type: string; _mode: string; _score: number }
        Returns: undefined
      }
      take_loan: { Args: { _amount: number }; Returns: Json }
    }
    Enums: {
      app_role: "admin" | "student"
    }
    CompositeTypes: {
      [_ in never]: never
    }
  }
}

type DatabaseWithoutInternals = Omit<Database, "__InternalSupabase">

type DefaultSchema = DatabaseWithoutInternals[Extract<keyof Database, "public">]

export type Tables<
  DefaultSchemaTableNameOrOptions extends
    | keyof (DefaultSchema["Tables"] & DefaultSchema["Views"])
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends (DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
        DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])
    : never) = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
      DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])[TableName] extends {
      Row: infer R
    }
    ? R
    : never
  : DefaultSchemaTableNameOrOptions extends keyof (DefaultSchema["Tables"] &
        DefaultSchema["Views"])
    ? (DefaultSchema["Tables"] &
        DefaultSchema["Views"])[DefaultSchemaTableNameOrOptions] extends {
        Row: infer R
      }
      ? R
      : never
    : never

export type TablesInsert<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends (DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never) = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Insert: infer I
    }
    ? I
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Insert: infer I
      }
      ? I
      : never
    : never

export type TablesUpdate<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends (DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never) = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Update: infer U
    }
    ? U
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Update: infer U
      }
      ? U
      : never
    : never

export type Enums<
  DefaultSchemaEnumNameOrOptions extends
    | keyof DefaultSchema["Enums"]
    | { schema: keyof DatabaseWithoutInternals },
  EnumName extends (DefaultSchemaEnumNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"]
    : never) = never,
> = DefaultSchemaEnumNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"][EnumName]
  : DefaultSchemaEnumNameOrOptions extends keyof DefaultSchema["Enums"]
    ? DefaultSchema["Enums"][DefaultSchemaEnumNameOrOptions]
    : never

export type CompositeTypes<
  PublicCompositeTypeNameOrOptions extends
    | keyof DefaultSchema["CompositeTypes"]
    | { schema: keyof DatabaseWithoutInternals },
  CompositeTypeName extends (PublicCompositeTypeNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"]
    : never) = never,
> = PublicCompositeTypeNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"][CompositeTypeName]
  : PublicCompositeTypeNameOrOptions extends keyof DefaultSchema["CompositeTypes"]
    ? DefaultSchema["CompositeTypes"][PublicCompositeTypeNameOrOptions]
    : never

export const Constants = {
  public: {
    Enums: {
      app_role: ["admin", "student"],
    },
  },
} as const
